package com.last04ka.messenger.ui;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.Toast;
import com.last04ka.messenger.utils.AppLogger;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;

public class PDFReaderActivity extends Activity {

    private WebView webView;
    private Button btnOpen;
    private Uri currentUri;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        try {
            AppLogger.log(this, "PDFReader", "onCreate started");
            LinearLayout layout = new LinearLayout(this);
            layout.setOrientation(LinearLayout.VERTICAL);
            layout.setBackgroundColor(0xFF1A1A2E);

            btnOpen = new Button(this);
            btnOpen.setText("Открыть PDF файл");
            btnOpen.setTextSize(16);
            btnOpen.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    AppLogger.log(PDFReaderActivity.this, "PDFReader", "Open PDF clicked");
                    openPDF();
                }
            });
            layout.addView(btnOpen);

            webView = new WebView(this);
            WebSettings settings = webView.getSettings();
            settings.setJavaScriptEnabled(true);
            settings.setAllowFileAccess(true);
            settings.setAllowContentAccess(true);
            settings.setBuiltInZoomControls(true);
            settings.setDisplayZoomControls(false);
            settings.setLoadWithOverviewMode(true);
            settings.setUseWideViewPort(true);
            webView.setWebViewClient(new WebViewClient() {
                @Override
                public void onReceivedError(WebView view, int errorCode, String description, String failingUrl) {
                    AppLogger.log(PDFReaderActivity.this, "PDFReader", "WebView error: " + errorCode + " " + description);
                    Toast.makeText(PDFReaderActivity.this, "Не удалось загрузить PDF. Попробуйте другой файл.", Toast.LENGTH_LONG).show();
                }
                @Override
                public void onPageFinished(WebView view, String url) {
                    AppLogger.log(PDFReaderActivity.this, "PDFReader", "Page loaded: " + url);
                }
            });
            LinearLayout.LayoutParams wp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 1);
            webView.setLayoutParams(wp);
            layout.addView(webView);

            setContentView(layout);
            setTitle("📄 PDF читалка");
            AppLogger.log(this, "PDFReader", "onCreate completed");
        } catch (Exception e) {
            AppLogger.logException(this, "PDFReader", e);
            finish();
        }
    }

    private void openPDF() {
        try {
            Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
            intent.setType("application/pdf");
            intent.addCategory(Intent.CATEGORY_OPENABLE);
            startActivityForResult(intent, 1);
        } catch (Exception e) {
            AppLogger.logException(this, "PDFReader", e);
            Toast.makeText(this, "Не удалось открыть выбор файла", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 1 && resultCode == RESULT_OK && data != null) {
            Uri uri = data.getData();
            if (uri != null) {
                currentUri = uri;
                // Пробуем загрузить напрямую как файл
                loadPdfFromUri(uri);
            }
        }
    }

    private void loadPdfFromUri(Uri uri) {
        try {
            // Копируем файл во временную папку и открываем через WebView
            InputStream is = getContentResolver().openInputStream(uri);
            File tempFile = new File(getCacheDir(), "temp_pdf.pdf");
            FileOutputStream fos = new FileOutputStream(tempFile);
            byte[] buffer = new byte[8192];
            int bytes;
            while ((bytes = is.read(buffer)) != -1) {
                fos.write(buffer, 0, bytes);
            }
            fos.close();
            is.close();

            String filePath = tempFile.getAbsolutePath();
            webView.loadUrl("file://" + filePath);
            Toast.makeText(this, "PDF загружается...", Toast.LENGTH_SHORT).show();
            AppLogger.log(this, "PDFReader", "Loading from file: " + filePath);
        } catch (Exception e) {
            AppLogger.logException(this, "PDFReader", e);
            // Резервный вариант — Google Viewer
            String viewerUrl = "https://docs.google.com/gview?embedded=true&url=" + Uri.encode(uri.toString());
            webView.loadUrl(viewerUrl);
            Toast.makeText(this, "PDF загружается через Google...", Toast.LENGTH_SHORT).show();
        }
    }
}