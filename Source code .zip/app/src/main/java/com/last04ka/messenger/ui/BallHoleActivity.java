package com.last04ka.messenger.ui;

import android.content.Context;
import android.content.pm.ActivityInfo;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Vibrator;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;

import com.last04ka.messenger.R;
import com.last04ka.messenger.game.BallHoleView;
import com.last04ka.messenger.utils.AppLogger;
import com.last04ka.messenger.utils.ThemeManager;

public class BallHoleActivity extends AppCompatActivity implements SensorEventListener {
    private static final String TAG = "BallHole";

    private BallHoleView gameView;
    private TextView tvLevel, tvBalls, tvAttempts, tvStatus;
    private Button btnRestartLevel;
    private ImageButton btnRestart;

    private SensorManager sensorManager;
    private Sensor accelerometer;
    private Sensor magnetometer;
    private Vibrator vibrator;

    // ==================== ДАННЫЕ ДАТЧИКОВ ====================
    private float[] gravity = new float[3];
    private float[] geomagnetic = new float[3];

    // Коэффициент сглаживания (0.2f — баланс между отзывчивостью и плавностью)
    private static final float ALPHA = 0.2f;

    // Калибровка нуля
    private boolean isCalibrated = false;
    private float initialPitch = 0f;
    private float initialRoll = 0f;

    private int level = 1;
    private int attempts = 0;
    private boolean isGameActive = true;

    private Handler handler = new Handler(Looper.getMainLooper());

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        setTheme(ThemeManager.getThemeResource(this));
        super.onCreate(savedInstanceState);
        AppLogger.log(this, TAG, "═══════════════════════════════════════════════════════════");
        AppLogger.log(this, TAG, "🔵 BallHoleActivity onCreate START (гибридные датчики)");
        AppLogger.log(this, TAG, "═══════════════════════════════════════════════════════════");

        try {
            setContentView(R.layout.activity_ball_hole);
            getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

            setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);

            initViews();
            AppLogger.log(this, TAG, "✅ Views initialized");

            initSensors();
            AppLogger.log(this, TAG, "✅ Sensors initialized");

            vibrator = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
            AppLogger.log(this, TAG, "✅ Vibrator initialized");

            setupListeners();
            AppLogger.log(this, TAG, "✅ Listeners setup");

            startGame();
            AppLogger.log(this, TAG, "✅ Game started, level=" + level);

            AppLogger.log(this, TAG, "═══════════════════════════════════════════════════════════");
            AppLogger.log(this, TAG, "🔵 BallHoleActivity onCreate SUCCESS");
            AppLogger.log(this, TAG, "═══════════════════════════════════════════════════════════");

        } catch (Exception e) {
            AppLogger.logException(this, TAG, "❌ onCreate error", e);
            finish();
        }
    }

    private void initViews() {
        gameView = findViewById(R.id.ball_hole_view);
        tvLevel = findViewById(R.id.tv_level);
        tvBalls = findViewById(R.id.tv_balls);
        tvAttempts = findViewById(R.id.tv_attempts);
        tvStatus = findViewById(R.id.tv_status);
        btnRestartLevel = findViewById(R.id.btn_restart_level);
        btnRestart = findViewById(R.id.btn_restart);

        if (gameView == null) {
            AppLogger.log(this, TAG, "❌ gameView is NULL!");
        }
    }

    private void initSensors() {
        sensorManager = (SensorManager) getSystemService(Context.SENSOR_SERVICE);
        if (sensorManager != null) {
            accelerometer = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
            magnetometer = sensorManager.getDefaultSensor(Sensor.TYPE_MAGNETIC_FIELD);

            if (accelerometer != null) {
                AppLogger.log(this, TAG, "✅ Accelerometer found");
            } else {
                AppLogger.log(this, TAG, "❌ Accelerometer not found");
                tvStatus.setText("⚠️ Акселерометр не найден");
            }

            if (magnetometer != null) {
                AppLogger.log(this, TAG, "✅ Magnetometer found");
            } else {
                AppLogger.log(this, TAG, "⚠️ Magnetometer not found, using fallback");
                tvStatus.setText("⚠️ Компас не найден, управление может быть хуже");
            }
        } else {
            AppLogger.log(this, TAG, "❌ SensorManager is null");
        }
    }

    private void setupListeners() {
        if (gameView != null) {
            gameView.setGameCallback(new BallHoleView.GameCallback() {
                @Override
                public void onLevelComplete(int completedLevel, int ballsRemaining) {
                    AppLogger.log(BallHoleActivity.this, TAG, "🏆🏆🏆 onLevelComplete: level=" + completedLevel + ", ballsRemaining=" + ballsRemaining);
                    runOnUiThread(() -> {
                        vibrate(200);
                        showLevelCompleteDialog(completedLevel);
                    });
                }

                @Override
                public void onLevelFailed(int failedLevel) {
                    AppLogger.log(BallHoleActivity.this, TAG, "❌❌❌ onLevelFailed: level=" + failedLevel);
                    runOnUiThread(() -> {
                        attempts++;
                        vibrate(300);
                        updateUI();
                        showLevelFailedDialog(failedLevel);
                    });
                }

                @Override
                public void onBallCountChanged(int total, int remaining) {
                    runOnUiThread(() -> {
                        tvBalls.setText("Шариков: " + remaining + "/" + total);
                    });
                }

                @Override
                public void onRedBallWarning() {
                    runOnUiThread(() -> {
                        tvStatus.setText("⚠️ Красный шарик близко к дырке!");
                        tvStatus.setTextColor(0xFFFF5252);
                        handler.postDelayed(() -> {
                            tvStatus.setTextColor(0xFFBDBDBD);
                            tvStatus.setText("Наклоняйте телефон, чтобы управлять шариками");
                        }, 1500);
                    });
                }

                @Override
                public void onBallEnteredHole(boolean isRed, int remaining) {
                    AppLogger.log(BallHoleActivity.this, TAG, "🎯 Ball entered hole: isRed=" + isRed + ", remaining=" + remaining);
                    runOnUiThread(() -> {
                        if (isRed) {
                            tvStatus.setText("🔴 Красный в дырке! Осталось белых: " + remaining);
                            tvStatus.setTextColor(0xFFFF1744);
                        } else {
                            tvStatus.setText("⚪ Шарик закатился! Осталось: " + remaining);
                            tvStatus.setTextColor(0xFF4CAF50);
                            handler.postDelayed(() -> {
                                tvStatus.setTextColor(0xFFBDBDBD);
                            }, 1000);
                        }
                        updateUI();
                    });
                }
            });
            AppLogger.log(this, TAG, "✅ Game callback set");
        }

        btnRestartLevel.setOnClickListener(v -> {
            AppLogger.log(BallHoleActivity.this, TAG, "🔄 Restart level clicked");
            restartLevel();
        });

        btnRestart.setOnClickListener(v -> {
            AppLogger.log(BallHoleActivity.this, TAG, "🔄 Restart (menu) clicked");
            restartLevel();
        });

        AppLogger.log(this, TAG, "✅ Listeners setup complete");
    }

    private void startGame() {
        AppLogger.log(this, TAG, "🎮 startGame() called, level=" + level);
        if (gameView != null) {
            gameView.setLevel(level);
            updateUI();
        }
        registerSensors();
    }

    private void restartLevel() {
        AppLogger.log(this, TAG, "🔄 restartLevel() called, level=" + level + ", attempts=" + attempts);
        if (gameView != null) {
            gameView.resetLevel();
            isGameActive = true;
            // Сбрасываем калибровку при рестарте
            isCalibrated = false;
            tvStatus.setText("Наклоняйте телефон, чтобы управлять шариками");
            tvStatus.setTextColor(0xFFBDBDBD);
            updateUI();
        }
    }

    private void nextLevel() {
        level++;
        AppLogger.log(this, TAG, "⬆️ nextLevel() called, new level=" + level);
        if (gameView != null) {
            gameView.setLevel(level);
            isGameActive = true;
            // Сбрасываем калибровку на новом уровне
            isCalibrated = false;
            updateUI();
            tvStatus.setText("Уровень " + level + "! Наклоняйте телефон");
            tvStatus.setTextColor(0xFF4CAF50);
        }
    }

    private void updateUI() {
        if (gameView != null) {
            int total = gameView.getTotalBalls();
            int remaining = gameView.getRemainingBalls();
            int inHole = gameView.getBallsInHole();
            tvLevel.setText("Уровень: " + level);
            tvBalls.setText("Шариков: " + remaining + "/" + total);
            tvAttempts.setText("Попыток: " + attempts);
            AppLogger.log(this, TAG, "📊 UI updated: level=" + level + ", remaining=" + remaining + "/" + total + ", inHole=" + inHole);
        }
    }

    private void showLevelCompleteDialog(int completedLevel) {
        int bonus = 100 - completedLevel * 5;
        if (bonus < 10) bonus = 10;

        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("🏆 Уровень " + completedLevel + " пройден!");
        builder.setMessage(
            "🎉 Отлично!\n\n" +
            "✅ Все шарики закатаны!\n" +
            "⭐ Бонус: +" + bonus + " очков\n" +
            "📊 Уровень: " + completedLevel + "\n" +
            "💪 Попыток: " + attempts
        );
        builder.setPositiveButton("Следующий уровень", (dialog, which) -> {
            AppLogger.log(BallHoleActivity.this, TAG, "✅ User clicked Next Level");
            nextLevel();
        });
        builder.setNegativeButton("Заново", (dialog, which) -> {
            AppLogger.log(BallHoleActivity.this, TAG, "🔄 User clicked Restart");
            restartLevel();
        });
        builder.setCancelable(false);
        builder.show();
    }

    private void showLevelFailedDialog(int failedLevel) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("😞 Уровень " + failedLevel + " провален");
        builder.setMessage(
            "Красный шарик попал в дырку слишком рано!\n\n" +
            "💡 Попробуйте управлять шариками аккуратнее.\n" +
            "📊 Попыток: " + attempts
        );
        builder.setPositiveButton("Попробовать снова", (dialog, which) -> {
            AppLogger.log(BallHoleActivity.this, TAG, "🔄 User clicked Retry");
            restartLevel();
        });
        builder.setNegativeButton("Выйти", (dialog, which) -> {
            AppLogger.log(BallHoleActivity.this, TAG, "🚪 User clicked Exit");
            finish();
        });
        builder.setCancelable(false);
        builder.show();
    }

    // ==================== СЕНСОРЫ (ГИБРИДНЫЙ МЕТОД) ====================

    @Override
    public void onSensorChanged(SensorEvent event) {
        // Низкочастотный фильтр для акселерометра
        if (event.sensor.getType() == Sensor.TYPE_ACCELEROMETER) {
            gravity[0] = gravity[0] + ALPHA * (event.values[0] - gravity[0]);
            gravity[1] = gravity[1] + ALPHA * (event.values[1] - gravity[1]);
            gravity[2] = gravity[2] + ALPHA * (event.values[2] - gravity[2]);
        }

        // Низкочастотный фильтр для магнитометра
        if (event.sensor.getType() == Sensor.TYPE_MAGNETIC_FIELD) {
            geomagnetic[0] = geomagnetic[0] + ALPHA * (event.values[0] - geomagnetic[0]);
            geomagnetic[1] = geomagnetic[1] + ALPHA * (event.values[1] - geomagnetic[1]);
            geomagnetic[2] = geomagnetic[2] + ALPHA * (event.values[2] - geomagnetic[2]);
        }

        // Если нет магнитометра — используем только акселерометр (fallback)
        if (magnetometer == null) {
            if (event.sensor.getType() == Sensor.TYPE_ACCELEROMETER) {
                float x = event.values[0];
                float y = event.values[1];
                if (gameView != null && isGameActive) {
                    gameView.updateTilt(y, -x); // Упрощённое управление
                }
            }
            return;
        }

        // Вычисляем матрицу вращения (гибридный метод)
        float[] R = new float[9];
        float[] I = new float[9];
        boolean success = SensorManager.getRotationMatrix(R, I, gravity, geomagnetic);

        if (success) {
            float[] orientation = new float[3];
            SensorManager.getOrientation(R, orientation);

            // Переводим радианы в градусы
            float pitch = (float) Math.toDegrees(orientation[1]); // Наклон вперед/назад
            float roll = (float) Math.toDegrees(orientation[2]);  // Наклон влево/вправо

            // Автоматическая калибровка при первом запуске
            if (!isCalibrated && Math.abs(pitch) > 0.5f && Math.abs(roll) > 0.5f) {
                initialPitch = pitch;
                initialRoll = roll;
                isCalibrated = true;
                AppLogger.log(this, TAG, "🔧 Calibrated: pitch=" + pitch + ", roll=" + roll);
            }

            if (isCalibrated) {
                // Получаем чистый наклон относительно откалиброванного нуля
                float finalPitch = pitch - initialPitch;
                float finalRoll = roll - initialRoll;

                // Мёртвая зона (1 градус) — игнорируем микронаклоны
                float deadzone = 1.0f;

                if (gameView != null && isGameActive) {
                    gameView.updateTilt(finalPitch, finalRoll);
                }
            }
        }
    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {
        // Не используется
    }

    private void registerSensors() {
        if (sensorManager != null) {
            if (accelerometer != null) {
                sensorManager.registerListener(this, accelerometer, SensorManager.SENSOR_DELAY_GAME);
            }
            if (magnetometer != null) {
                sensorManager.registerListener(this, magnetometer, SensorManager.SENSOR_DELAY_GAME);
            }
            AppLogger.log(this, TAG, "✅ Sensors registered (SENSOR_DELAY_GAME)");
        }
    }

    private void unregisterSensors() {
        if (sensorManager != null) {
            sensorManager.unregisterListener(this);
            AppLogger.log(this, TAG, "✅ Sensors unregistered");
        }
    }

    // ==================== ВИБРАЦИЯ ====================

    private void vibrate(int ms) {
        if (vibrator != null && vibrator.hasVibrator()) {
            vibrator.vibrate(ms);
        }
    }

    // ==================== ЖИЗНЕННЫЙ ЦИКЛ ====================

    @Override
    protected void onResume() {
        super.onResume();
        AppLogger.log(this, TAG, "📱 onResume");
        registerSensors();
        if (gameView != null) {
            gameView.resume();
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        AppLogger.log(this, TAG, "📱 onPause");
        unregisterSensors();
        if (gameView != null) {
            gameView.pause();
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        AppLogger.log(this, TAG, "📱 onDestroy");
        unregisterSensors();
        handler.removeCallbacksAndMessages(null);
    }
}