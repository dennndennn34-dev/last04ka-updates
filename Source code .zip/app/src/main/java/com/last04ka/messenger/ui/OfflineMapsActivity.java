package com.last04ka.messenger.ui;

import android.content.Context;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.TextView;
import android.widget.Toast;
import com.last04ka.messenger.R;
import com.last04ka.messenger.utils.AppLogger;
import com.last04ka.messenger.utils.ThemeManager;

public class OfflineMapsActivity extends AppCompatActivity {

    private WebView mapView;
    private TextView coordsText;
    private LocationManager locationManager;
    private double lat = 55.7558, lon = 37.6173;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        setTheme(ThemeManager.getThemeResource(this));
        super.onCreate(savedInstanceState);
        try {
            AppLogger.log(this, "OfflineMaps", "onCreate started");
            setContentView(R.layout.activity_offline_maps);
            setTitle("🗺️ Офлайн-карты");

            mapView = findViewById(R.id.map_webview);
            coordsText = findViewById(R.id.coords_text);

            WebSettings settings = mapView.getSettings();
            settings.setJavaScriptEnabled(true);
            settings.setDomStorageEnabled(true);
            settings.setUseWideViewPort(true);
            settings.setLoadWithOverviewMode(true);
            settings.setAllowFileAccess(true);
            // setAppCacheEnabled удалён в Android 9+
            // settings.setAppCacheEnabled(true);
            settings.setDatabaseEnabled(true);
            settings.setGeolocationEnabled(true);

            mapView.setWebViewClient(new WebViewClient());
            loadMap();

            locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
            try {
                locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 5000, 5, new LocationListener() {
                    @Override
                    public void onLocationChanged(Location location) {
                        lat = location.getLatitude();
                        lon = location.getLongitude();
                        coordsText.setText(String.format("📍 %.5f, %.5f", lat, lon));
                        AppLogger.log(OfflineMapsActivity.this, "OfflineMaps", "GPS: " + lat + "," + lon);
                        loadMap();
                    }
                    @Override public void onStatusChanged(String provider, int status, Bundle extras) {}
                    @Override public void onProviderEnabled(String provider) {
                        AppLogger.log(OfflineMapsActivity.this, "OfflineMaps", "GPS enabled");
                    }
                    @Override public void onProviderDisabled(String provider) {
                        AppLogger.log(OfflineMapsActivity.this, "OfflineMaps", "GPS disabled");
                        Toast.makeText(OfflineMapsActivity.this, "GPS выключен", Toast.LENGTH_SHORT).show();
                    }
                });
            } catch (SecurityException e) {
                AppLogger.logException(this, "OfflineMaps", e);
                Toast.makeText(this, "Нет разрешения на GPS", Toast.LENGTH_SHORT).show();
            }

            findViewById(R.id.btn_zoom_in).setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) { mapView.zoomIn(); }
            });
            findViewById(R.id.btn_zoom_out).setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) { mapView.zoomOut(); }
            });
            findViewById(R.id.btn_my_location).setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) { loadMap(); }
            });
            AppLogger.log(this, "OfflineMaps", "onCreate completed");
        } catch (Exception e) {
            AppLogger.logException(this, "OfflineMaps", e);
            finish();
        }
    }

    private void loadMap() {
        String html = "<!DOCTYPE html><html><head><meta charset='utf-8'><meta name='viewport' content='width=device-width, initial-scale=1.0'>"
            + "<link rel='stylesheet' href='https://unpkg.com/leaflet@1.9.4/dist/leaflet.css'/>"
            + "<script src='https://unpkg.com/leaflet@1.9.4/dist/leaflet.js'></script>"
            + "<style>body{margin:0;padding:0}#map{width:100vw;height:100vh}</style></head><body>"
            + "<div id='map'></div><script>"
            + "var map=L.map('map').setView([" + lat + "," + lon + "],15);"
            + "L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',{maxZoom:19}).addTo(map);"
            + "L.marker([" + lat + "," + lon + "]).addTo(map).bindPopup('Вы здесь').openPopup();"
            + "</script></body></html>";
        mapView.loadDataWithBaseURL("https://a.tile.openstreetmap.org", html, "text/html", "UTF-8", null);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        AppLogger.log(this, "OfflineMaps", "onDestroy");
        if (locationManager != null) {
            locationManager.removeUpdates((LocationListener) locationManager);
        }
    }
}