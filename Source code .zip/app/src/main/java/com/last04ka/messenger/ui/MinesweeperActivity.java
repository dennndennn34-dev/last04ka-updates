package com.last04ka.messenger.ui;

import android.app.Activity;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import com.last04ka.messenger.utils.AppLogger;
import com.last04ka.messenger.utils.GameScores;
import java.util.Random;

public class MinesweeperActivity extends Activity {

    private MineView mineView;
    private TextView scoreText, modeText;
    private boolean flagMode = false;
    private Button btnMode, btnNewGame;
    private int cursorR = 4, cursorC = 4;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        try {
            AppLogger.log(this, "Minesweeper", "onCreate started");

            LinearLayout mainLayout = new LinearLayout(this);
            mainLayout.setOrientation(LinearLayout.VERTICAL);

            // Верхняя панель
            LinearLayout topPanel = new LinearLayout(this);
            topPanel.setPadding(16, 16, 16, 8);
            topPanel.setBackgroundColor(Color.rgb(40, 40, 40));

            scoreText = new TextView(this);
            scoreText.setText("Счёт: 0 | Рекорд: " + GameScores.getScore(this, "minesweeper"));
            scoreText.setTextSize(16);
            scoreText.setTextColor(Color.WHITE);
            topPanel.addView(scoreText);
            mainLayout.addView(topPanel);

            // Игровое поле
            mineView = new MineView(this);
            LinearLayout.LayoutParams gameParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 1);
            mineView.setLayoutParams(gameParams);
            mainLayout.addView(mineView);

            // Панель режима
            LinearLayout modePanel = new LinearLayout(this);
            modePanel.setPadding(16, 8, 16, 8);
            modePanel.setBackgroundColor(Color.rgb(50, 50, 50));

            modeText = new TextView(this);
            modeText.setText("Режим: 🔍 Открыть");
            modeText.setTextSize(14);
            modeText.setTextColor(Color.WHITE);
            modePanel.addView(modeText);
            mainLayout.addView(modePanel);

            // Кнопки управления
            LinearLayout buttonPanel = new LinearLayout(this);
            buttonPanel.setOrientation(LinearLayout.VERTICAL);
            buttonPanel.setPadding(16, 8, 16, 16);
            buttonPanel.setBackgroundColor(Color.rgb(40, 40, 40));

            // Кнопка ВВЕРХ
            LinearLayout row1 = new LinearLayout(this);
            row1.setGravity(android.view.Gravity.CENTER);
            Button btnUp = new Button(this);
            btnUp.setText("⬆️");
            btnUp.setTextSize(24);
            btnUp.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (cursorR > 0) cursorR--;
                    mineView.invalidate();
                }
            });
            row1.addView(btnUp);
            buttonPanel.addView(row1);

            // Кнопки ВЛЕВО, ДЕЙСТВИЕ, ВПРАВО
            LinearLayout row2 = new LinearLayout(this);
            row2.setGravity(android.view.Gravity.CENTER);

            Button btnLeft = new Button(this);
            btnLeft.setText("⬅️");
            btnLeft.setTextSize(24);
            btnLeft.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (cursorC > 0) cursorC--;
                    mineView.invalidate();
                }
            });
            row2.addView(btnLeft);

            // Кнопка действия (Открыть/Флажок)
            Button btnAction = new Button(this);
            btnAction.setText("🔍");
            btnAction.setTextSize(24);
            btnAction.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (flagMode) {
                        mineView.toggleFlag(cursorR, cursorC);
                    } else {
                        mineView.reveal(cursorR, cursorC);
                    }
                    mineView.invalidate();
                    updateScore();
                }
            });
            row2.addView(btnAction);

            Button btnRight = new Button(this);
            btnRight.setText("➡️");
            btnRight.setTextSize(24);
            btnRight.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (cursorC < 8) cursorC++;
                    mineView.invalidate();
                }
            });
            row2.addView(btnRight);

            buttonPanel.addView(row2);

            // Кнопка ВНИЗ
            LinearLayout row3 = new LinearLayout(this);
            row3.setGravity(android.view.Gravity.CENTER);
            Button btnDown = new Button(this);
            btnDown.setText("⬇️");
            btnDown.setTextSize(24);
            btnDown.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (cursorR < 8) cursorR++;
                    mineView.invalidate();
                }
            });
            row3.addView(btnDown);
            buttonPanel.addView(row3);

            // Кнопки режима и новой игры
            LinearLayout row4 = new LinearLayout(this);
            row4.setGravity(android.view.Gravity.CENTER);

            btnMode = new Button(this);
            btnMode.setText("🚩 Флажок");
            btnMode.setTextSize(14);
            btnMode.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    flagMode = !flagMode;
                    if (flagMode) {
                        modeText.setText("Режим: 🚩 Флажок");
                        btnMode.setText("🔍 Открыть");
                    } else {
                        modeText.setText("Режим: 🔍 Открыть");
                        btnMode.setText("🚩 Флажок");
                    }
                }
            });
            row4.addView(btnMode);

            btnNewGame = new Button(this);
            btnNewGame.setText("Новая игра");
            btnNewGame.setTextSize(14);
            btnNewGame.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    mineView.reset();
                    cursorR = 4; cursorC = 4;
                    updateScore();
                    mineView.invalidate();
                }
            });
            row4.addView(btnNewGame);

            buttonPanel.addView(row4);
            mainLayout.addView(buttonPanel);

            setContentView(mainLayout);
            setTitle("💣 Сапёр");
            AppLogger.log(this, "Minesweeper", "onCreate completed");
        } catch (Exception e) {
            AppLogger.logException(this, "Minesweeper", e);
            finish();
        }
    }

    private void updateScore() {
        scoreText.setText("Счёт: " + mineView.score + " | Рекорд: " + GameScores.getScore(this, "minesweeper"));
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (mineView != null) {
            GameScores.saveScore(this, "minesweeper", mineView.score);
            AppLogger.log(this, "Minesweeper", "onDestroy, score: " + mineView.score);
        }
    }

    class MineView extends View {
        private int rows = 9, cols = 9, mines = 10;
        private boolean[][] isMine = new boolean[rows][cols];
        private boolean[][] revealed = new boolean[rows][cols];
        private boolean[][] flagged = new boolean[rows][cols];
        private int[][] neighbors = new int[rows][cols];
        private boolean gameOver = false, gameWon = false;
        private int score = 0;
        private Paint paint = new Paint();

        public MineView(Context context) {
            super(context);
            setBackgroundColor(Color.rgb(189, 189, 189));
            initGame();
        }

        public void reset() {
            isMine = new boolean[rows][cols];
            revealed = new boolean[rows][cols];
            flagged = new boolean[rows][cols];
            neighbors = new int[rows][cols];
            score = 0;
            gameOver = false;
            gameWon = false;
            initGame();
            AppLogger.log(getContext(), "Minesweeper", "New game started");
            invalidate();
        }

        private void initGame() {
            Random r = new Random();
            for (int i = 0; i < mines; i++) {
                int mr, mc;
                do {
                    mr = r.nextInt(rows);
                    mc = r.nextInt(cols);
                } while (isMine[mr][mc]);
                isMine[mr][mc] = true;
            }
            for (int rr = 0; rr < rows; rr++) {
                for (int cc = 0; cc < cols; cc++) {
                    if (isMine[rr][cc]) continue;
                    int count = 0;
                    for (int dr = -1; dr <= 1; dr++)
                        for (int dc = -1; dc <= 1; dc++)
                            if (rr + dr >= 0 && rr + dr < rows && cc + dc >= 0 && cc + dc < cols)
                                if (isMine[rr + dr][cc + dc]) count++;
                    neighbors[rr][cc] = count;
                }
            }
        }

        public void toggleFlag(int r, int c) {
            if (gameOver || gameWon) return;
            if (!revealed[r][c]) {
                flagged[r][c] = !flagged[r][c];
            }
        }

        public void reveal(int r, int c) {
            if (gameOver || gameWon) return;
            if (r < 0 || r >= rows || c < 0 || c >= cols) return;
            if (revealed[r][c] || flagged[r][c]) return;
            revealed[r][c] = true;
            score++;
            if (isMine[r][c]) {
                gameOver = true;
                AppLogger.log(getContext(), "Minesweeper", "Mine hit at " + r + "," + c);
                return;
            }
            if (neighbors[r][c] == 0) {
                for (int dr = -1; dr <= 1; dr++)
                    for (int dc = -1; dc <= 1; dc++)
                        reveal(r + dr, c + dc);
            }
            checkWin();
        }

        private void checkWin() {
            int hidden = 0;
            for (int r = 0; r < rows; r++)
                for (int c = 0; c < cols; c++)
                    if (!revealed[r][c] && !isMine[r][c]) hidden++;
            if (hidden == 0) {
                gameWon = true;
                score += 50;
                GameScores.saveScore(getContext(), "minesweeper", score);
                AppLogger.log(getContext(), "Minesweeper", "Game won! Score: " + score);
            }
        }

        @Override
        protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            try {
                float cellW = (float) getWidth() / cols;
                float cellH = (float) getHeight() / rows;

                canvas.drawColor(Color.rgb(189, 189, 189));

                // Рисуем клетки
                for (int r = 0; r < rows; r++) {
                    for (int c = 0; c < cols; c++) {
                        float x = c * cellW, y = r * cellH;

                        if (revealed[r][c]) {
                            paint.setColor(isMine[r][c] ? Color.RED : Color.WHITE);
                        } else {
                            paint.setColor(flagged[r][c] ? Color.rgb(255, 200, 100) : Color.rgb(160, 160, 160));
                        }
                        
                        canvas.drawRect(x + 1, y + 1, x + cellW - 1, y + cellH - 1, paint);

                        // Цифра
                        if (revealed[r][c] && neighbors[r][c] > 0 && !isMine[r][c]) {
                            int[] colors = {0, 0xFF0000FF, 0xFF008000, 0xFFFF0000, 0xFF000080, 0xFF800000, 0xFF008080, 0xFF000000, 0xFF808080};
                            paint.setColor(colors[neighbors[r][c]]);
                            paint.setTextSize(cellW * 0.7f);
                            paint.setTextAlign(Paint.Align.CENTER);
                            canvas.drawText(String.valueOf(neighbors[r][c]), x + cellW / 2, y + cellH / 2 + cellW * 0.25f, paint);
                        }

                        // Флажок
                        if (flagged[r][c] && !revealed[r][c]) {
                            paint.setColor(Color.RED);
                            paint.setTextSize(cellW * 0.6f);
                            paint.setTextAlign(Paint.Align.CENTER);
                            canvas.drawText("🚩", x + cellW / 2, y + cellH / 2 + cellW * 0.2f, paint);
                        }

                        // Мина (если проиграл)
                        if (isMine[r][c] && gameOver) {
                            paint.setColor(Color.BLACK);
                            paint.setTextSize(cellW * 0.6f);
                            paint.setTextAlign(Paint.Align.CENTER);
                            canvas.drawText("💣", x + cellW / 2, y + cellH / 2 + cellW * 0.2f, paint);
                        }

                        // Сетка
                        paint.setColor(Color.rgb(120, 120, 120));
                        paint.setStrokeWidth(1);
                        canvas.drawLine(x, y, x + cellW, y, paint);
                        canvas.drawLine(x, y, x, y + cellH, paint);
                    }
                }

                // Рамка курсора
                paint.setColor(Color.YELLOW);
                paint.setStyle(Paint.Style.STROKE);
                paint.setStrokeWidth(3);
                canvas.drawRect(cursorC * cellW, cursorR * cellH, (cursorC + 1) * cellW, (cursorR + 1) * cellH, paint);
                paint.setStyle(Paint.Style.FILL);

                // Окно результата
                if (gameOver) {
                    paint.setColor(Color.argb(200, 200, 0, 0));
                    canvas.drawRect(0, 0, getWidth(), getHeight(), paint);
                    paint.setColor(Color.WHITE);
                    paint.setTextSize(50);
                    paint.setTextAlign(Paint.Align.CENTER);
                    canvas.drawText("💥 Взрыв!", getWidth() / 2, getHeight() / 2 - 10, paint);
                    paint.setTextSize(30);
                    canvas.drawText("Новая игра — кнопка внизу", getWidth() / 2, getHeight() / 2 + 40, paint);
                }
                if (gameWon) {
                    paint.setColor(Color.argb(200, 0, 150, 0));
                    canvas.drawRect(0, 0, getWidth(), getHeight(), paint);
                    paint.setColor(Color.WHITE);
                    paint.setTextSize(50);
                    paint.setTextAlign(Paint.Align.CENTER);
                    canvas.drawText("🏆 Победа!", getWidth() / 2, getHeight() / 2 - 10, paint);
                    paint.setTextSize(30);
                    canvas.drawText("Счёт: " + score, getWidth() / 2, getHeight() / 2 + 40, paint);
                }
            } catch (Exception e) {
                AppLogger.logException(getContext(), "Minesweeper", e);
            }
        }
    }
}