package com.last04ka.messenger.ui;

import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import com.last04ka.messenger.utils.AppLogger;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.InetAddress;
import java.net.URL;

public class IPToolsActivity extends Activity {

    private EditText input;
    private TextView resultText;
    private Button btnPing, btnWhois, btnTrace, btnMyIp;
    private Handler handler = new Handler();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        try {
            AppLogger.log(this, "IPTools", "onCreate started");
            LinearLayout layout = new LinearLayout(this);
            layout.setOrientation(LinearLayout.VERTICAL);
            layout.setPadding(16, 16, 16, 16);
            layout.setBackgroundColor(0xFF1A1A2E);

            TextView title = new TextView(this);
            title.setText("🌐 IP-инструменты"); title.setTextSize(20);
            title.setTextColor(0xFFFFFFFF); title.setGravity(Gravity.CENTER);
            layout.addView(title);

            input = new EditText(this);
            input.setHint("Введите IP или домен");
            input.setTextColor(0xFFFFFFFF); input.setHintTextColor(0xFF888888);
            input.setBackgroundColor(0xFF333333); input.setPadding(12, 10, 12, 10);
            layout.addView(input);

            LinearLayout btnRow = new LinearLayout(this);
            btnRow.setOrientation(LinearLayout.HORIZONTAL);
            btnRow.setGravity(Gravity.CENTER);

            btnPing = new Button(this); btnPing.setText("Ping");
            btnPing.setOnClickListener(v -> doPing()); btnRow.addView(btnPing);
            btnWhois = new Button(this); btnWhois.setText("Whois");
            btnWhois.setOnClickListener(v -> doWhois()); btnRow.addView(btnWhois);
            btnTrace = new Button(this); btnTrace.setText("Trace");
            btnTrace.setOnClickListener(v -> doTrace()); btnRow.addView(btnTrace);
            btnMyIp = new Button(this); btnMyIp.setText("Мой IP");
            btnMyIp.setOnClickListener(v -> showMyIp()); btnRow.addView(btnMyIp);
            layout.addView(btnRow);

            resultText = new TextView(this);
            resultText.setTextSize(12); resultText.setTextColor(0xFFFFFFFF);
            resultText.setBackgroundColor(0xFF333333); resultText.setPadding(12, 12, 12, 12);
            resultText.setMinHeight(300);
            ScrollView sv = new ScrollView(this); sv.addView(resultText);
            layout.addView(sv);

            setContentView(layout);
            setTitle("🌐 IP-инструменты");
            AppLogger.log(this, "IPTools", "onCreate completed");
        } catch (Exception e) { AppLogger.logException(this, "IPTools", e); finish(); }
    }

    private void doPing() {
        String host = input.getText().toString().trim();
        if (host.isEmpty()) { Toast.makeText(this, "Введите адрес", Toast.LENGTH_SHORT).show(); return; }
        resultText.setText("Пингую " + host + "...");
        new Thread(() -> {
            StringBuilder sb = new StringBuilder("Ping " + host + ":\n");
            try {
                InetAddress addr = InetAddress.getByName(host);
                for (int i = 0; i < 4; i++) {
                    long start = System.currentTimeMillis();
                    boolean reachable = addr.isReachable(3000);
                    long time = System.currentTimeMillis() - start;
                    sb.append(reachable ? "Ответ от " + addr.getHostAddress() + ": time=" + time + "ms\n" : "Request timeout\n");
                    if (i < 3) Thread.sleep(500);
                }
                AppLogger.log(this, "IPTools", "Ping " + host + " OK");
            } catch (Exception e) {
                sb.append("Ошибка: " + e.getMessage());
                AppLogger.logException(this, "IPTools", e);
            }
            runOnUiThread(() -> resultText.setText(sb.toString()));
        }).start();
    }

    private void doWhois() {
        String host = input.getText().toString().trim();
        if (host.isEmpty()) { Toast.makeText(this, "Введите домен", Toast.LENGTH_SHORT).show(); return; }
        resultText.setText("Запрос whois...");
        new Thread(() -> {
            try {
                URL url = new URL("https://api.domaintools.com/v1/" + host + "/whois/");
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setConnectTimeout(10000); conn.setReadTimeout(10000);
                BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream()));
                StringBuilder sb = new StringBuilder(); String line;
                while ((line = reader.readLine()) != null) sb.append(line).append("\n");
                reader.close(); conn.disconnect();
                if (sb.length() == 0) sb.append("Нет данных. Попробуйте другой домен.");
                runOnUiThread(() -> resultText.setText(sb.toString()));
                AppLogger.log(this, "IPTools", "Whois " + host);
            } catch (Exception e) {
                runOnUiThread(() -> resultText.setText("Ошибка whois: " + e.getMessage()));
                AppLogger.logException(this, "IPTools", e);
            }
        }).start();
    }

    private void doTrace() {
        String host = input.getText().toString().trim();
        if (host.isEmpty()) { Toast.makeText(this, "Введите адрес", Toast.LENGTH_SHORT).show(); return; }
        resultText.setText("Трассировка " + host + "...");
        new Thread(() -> {
            StringBuilder sb = new StringBuilder("Traceroute " + host + ":\n");
            try {
                InetAddress addr = InetAddress.getByName(host);
                for (int ttl = 1; ttl <= 15; ttl++) {
                    long start = System.currentTimeMillis();
                    String hop = addr.getHostAddress();
                    long time = System.currentTimeMillis() - start;
                    sb.append(ttl + "  " + hop + "  " + time + "ms\n");
                    if (addr.isReachable(2000)) { sb.append("Достигнут!\n"); break; }
                    Thread.sleep(200);
                }
                AppLogger.log(this, "IPTools", "Trace " + host);
            } catch (Exception e) { sb.append("Ошибка: " + e.getMessage()); }
            runOnUiThread(() -> resultText.setText(sb.toString()));
        }).start();
    }

    private void showMyIp() {
        resultText.setText("Получение IP...");
        new Thread(() -> {
            try {
                URL url = new URL("https://api.ipify.org");
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setConnectTimeout(5000); conn.setReadTimeout(5000);
                BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream()));
                String ip = reader.readLine();
                reader.close(); conn.disconnect();
                runOnUiThread(() -> resultText.setText("Ваш IP: " + ip));
                AppLogger.log(this, "IPTools", "My IP: " + ip);
            } catch (Exception e) {
                runOnUiThread(() -> resultText.setText("Ошибка получения IP"));
            }
        }).start();
    }
}