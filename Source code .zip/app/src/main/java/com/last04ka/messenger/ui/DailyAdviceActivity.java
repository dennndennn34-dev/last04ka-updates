package com.last04ka.messenger.ui;

import android.app.Activity;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import com.last04ka.messenger.utils.AppLogger;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.Random;

public class DailyAdviceActivity extends Activity {

    private TextView adviceText, dateText;
    private Button btnNewAdvice;

    private String[] advices = {
        "Выпейте стакан воды прямо сейчас — организм скажет спасибо.",
        "Сделайте 5-минутную разминку. Шея и спина будут благодарны.",
        "Позвоните родителям. Им будет приятно.",
        "Запишите 3 вещи, за которые вы благодарны сегодня.",
        "Проветрите комнату — свежий воздух улучшает мышление.",
        "Отложите телефон на 30 минут перед сном.",
        "Улыбнитесь себе в зеркало. Да, прямо сейчас.",
        "Прочитайте 5 страниц любой книги.",
        "Съешьте что-нибудь полезное. Овощи, фрукты, орехи.",
        "Сделайте одно маленькое дело, которое давно откладываете.",
        "Послушайте любимую песню. Громко.",
        "Напишите другу 'привет'. Просто так.",
        "Пройдитесь пешком 15 минут. Без телефона.",
        "Выучите одно новое слово на иностранном языке.",
        "Ложитесь спать на 30 минут раньше обычного.",
        "Помогите кому-нибудь. Любая мелочь имеет значение.",
        "Заварите вкусный чай и выпейте его не спеша.",
        "Посмотрите на небо. Оно прекрасно в любую погоду.",
        "Скажите спасибо тому, кто этого не ожидает.",
        "Планируйте завтрашний день сегодня вечером."
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        try {
            AppLogger.log(this, "DailyAdvice", "onCreate started");
            LinearLayout layout = new LinearLayout(this);
            layout.setOrientation(LinearLayout.VERTICAL);
            layout.setPadding(24, 24, 24, 24);
            layout.setBackgroundColor(0xFF1A1A2E);

            TextView title = new TextView(this);
            title.setText("📝 Ежедневный совет");
            title.setTextSize(20); title.setTextColor(0xFFFFFFFF);
            title.setGravity(android.view.Gravity.CENTER);
            title.setPadding(0, 0, 0, 16);
            layout.addView(title);

            dateText = new TextView(this);
            dateText.setText("Сегодня: " + new SimpleDateFormat("dd MMMM yyyy", new Locale("ru")).format(new Date()));
            dateText.setTextSize(14); dateText.setTextColor(0xFFBDBDBD);
            dateText.setGravity(android.view.Gravity.CENTER);
            dateText.setPadding(0, 0, 0, 16);
            layout.addView(dateText);

            adviceText = new TextView(this);
            adviceText.setTextSize(22); adviceText.setTextColor(0xFF00E676);
            adviceText.setGravity(android.view.Gravity.CENTER);
            adviceText.setPadding(16, 32, 16, 32);
            adviceText.setBackgroundColor(0xFF333333);
            adviceText.setMinHeight(150);
            layout.addView(adviceText);

            btnNewAdvice = new Button(this);
            btnNewAdvice.setText("Получить совет");

            // Проверяем, был ли уже совет сегодня
            SharedPreferences prefs = getSharedPreferences("daily_advice", MODE_PRIVATE);
            String today = new SimpleDateFormat("yyyyMMdd", Locale.getDefault()).format(new Date());
            String savedDate = prefs.getString("date", "");
            int savedIndex = prefs.getInt("index", -1);

            if (today.equals(savedDate) && savedIndex >= 0 && savedIndex < advices.length) {
                adviceText.setText(advices[savedIndex]);
                btnNewAdvice.setText("Сегодняшний совет (уже получен)");
                btnNewAdvice.setEnabled(false);
            } else {
                // Новый день — новый совет
                int idx = new Random().nextInt(advices.length);
                prefs.edit().putString("date", today).putInt("index", idx).apply();
                adviceText.setText(advices[idx]);
                btnNewAdvice.setText("Сегодняшний совет");
                btnNewAdvice.setEnabled(false);
                AppLogger.log(this, "DailyAdvice", "New daily advice generated");
            }

            layout.addView(btnNewAdvice);
            setContentView(layout);
            setTitle("📝 Совет дня");
            AppLogger.log(this, "DailyAdvice", "onCreate completed");
        } catch (Exception e) { AppLogger.logException(this, "DailyAdvice", e); finish(); }
    }
}