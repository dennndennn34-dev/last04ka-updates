package com.last04ka.messenger.ui;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.last04ka.messenger.R;
import com.last04ka.messenger.utils.AppLogger;
import com.last04ka.messenger.utils.ThemeManager;

public class JoinGroupActivity extends AppCompatActivity {
    private static final String TAG = "JoinGroup";

    private EditText inputCode;
    private Button btnJoin, btnCancel;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        try {
            setTheme(ThemeManager.getThemeResource(this));
            super.onCreate(savedInstanceState);
            AppLogger.log(this, TAG, "═══════════════════════════════════════════════════════════");
            AppLogger.log(this, TAG, "🔑 JoinGroupActivity onCreate START");
            AppLogger.log(this, TAG, "═══════════════════════════════════════════════════════════");

            setContentView(R.layout.activity_join_group);
            AppLogger.log(this, TAG, "✅ Content view set");

            inputCode = findViewById(R.id.input_group_code);
            btnJoin = findViewById(R.id.btn_join_group);
            btnCancel = findViewById(R.id.btn_cancel_join);

            AppLogger.log(this, TAG, "inputCode=" + (inputCode != null ? "OK" : "NULL"));
            AppLogger.log(this, TAG, "btnJoin=" + (btnJoin != null ? "OK" : "NULL"));
            AppLogger.log(this, TAG, "btnCancel=" + (btnCancel != null ? "OK" : "NULL"));

            if (inputCode == null || btnJoin == null || btnCancel == null) {
                AppLogger.log(this, TAG, "❌ CRITICAL: One or more views are NULL!");
                Toast.makeText(this, "Ошибка инициализации интерфейса", Toast.LENGTH_LONG).show();
                finish();
                return;
            }

            btnJoin.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    AppLogger.log(JoinGroupActivity.this, TAG, "🔘 btnJoin clicked");
                    String code = inputCode.getText().toString().trim();
                    AppLogger.log(JoinGroupActivity.this, TAG, "📝 Code entered: '" + code + "' (length=" + code.length() + ")");

                    if (TextUtils.isEmpty(code)) {
                        AppLogger.log(JoinGroupActivity.this, TAG, "❌ Code is empty");
                        Toast.makeText(JoinGroupActivity.this, "Введите код группы", Toast.LENGTH_SHORT).show();
                        return;
                    }

                    AppLogger.log(JoinGroupActivity.this, TAG, "✅ Joining group with code: " + code);
                    Intent intent = new Intent(JoinGroupActivity.this, GroupChatActivity.class);
                    intent.putExtra("GROUP_CODE", code);
                    AppLogger.log(JoinGroupActivity.this, TAG, "📤 Starting GroupChatActivity with code: " + code);
                    startActivity(intent);
                    AppLogger.log(JoinGroupActivity.this, TAG, "📤 finish() called");
                    finish();
                }
            });

            btnCancel.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    AppLogger.log(JoinGroupActivity.this, TAG, "🔘 btnCancel clicked");
                    finish();
                }
            });

            AppLogger.log(this, TAG, "✅ JoinGroupActivity onCreate completed");
            AppLogger.log(this, TAG, "═══════════════════════════════════════════════════════════");

        } catch (Exception e) {
            AppLogger.logException(this, TAG, "❌ FATAL: onCreate error", e);
            Toast.makeText(this, "Ошибка: " + e.getMessage(), Toast.LENGTH_LONG).show();
            finish();
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        AppLogger.log(this, TAG, "📱 onResume()");
    }

    @Override
    protected void onPause() {
        super.onPause();
        AppLogger.log(this, TAG, "📱 onPause()");
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        AppLogger.log(this, TAG, "📱 onDestroy()");
    }
}