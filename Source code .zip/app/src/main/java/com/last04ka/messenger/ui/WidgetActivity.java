package com.last04ka.messenger.ui;

import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.content.Intent;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import com.last04ka.messenger.utils.AppLogger;

public class WidgetActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        try {
            AppLogger.log(this, "Widget", "onCreate started");
            LinearLayout layout = new LinearLayout(this);
            layout.setOrientation(LinearLayout.VERTICAL);
            layout.setPadding(20, 20, 20, 20);
            layout.setBackgroundColor(0xFF1A1A2E);
            layout.setGravity(Gravity.CENTER);

            TextView title = new TextView(this);
            title.setText("⚡ Быстрый доступ"); title.setTextSize(20);
            title.setTextColor(0xFFFFFFFF); title.setGravity(Gravity.CENTER);
            title.setPadding(0, 0, 0, 24);
            layout.addView(title);

            Button btnBtChat = new Button(this);
            btnBtChat.setText("💬 Новый Bluetooth чат");
            btnBtChat.setTextSize(16);
            btnBtChat.setOnClickListener(v -> {
                BluetoothAdapter ba = BluetoothAdapter.getDefaultAdapter();
                if (ba == null || !ba.isEnabled()) {
                    Toast.makeText(this, "Включите Bluetooth", Toast.LENGTH_SHORT).show();
                    return;
                }
                Intent intent = new Intent(this, NewChatActivity.class);
                startActivity(intent);
                AppLogger.log(this, "Widget", "New BT chat started");
            });
            layout.addView(btnBtChat);

            Button btnGames = new Button(this);
            btnGames.setText("🎮 Мини-приложения");
            btnGames.setOnClickListener(v -> startActivity(new Intent(this, MiniAppsActivity.class)));
            layout.addView(btnGames);

            Button btnBrowser = new Button(this);
            btnBrowser.setText("🌐 Браузер");
            btnBrowser.setOnClickListener(v -> startActivity(new Intent(this, BrowserActivity.class)));
            layout.addView(btnBrowser);

            Button btnNotes = new Button(this);
            btnNotes.setText("📝 Заметки");
            btnNotes.setOnClickListener(v -> startActivity(new Intent(this, NotesActivity.class)));
            layout.addView(btnNotes);

            Button btnWeather = new Button(this);
            btnWeather.setText("🌤 Погода");
            btnWeather.setOnClickListener(v -> startActivity(new Intent(this, WeatherActivity.class)));
            layout.addView(btnWeather);

            setContentView(layout);
            setTitle("⚡ Быстрый доступ");
            AppLogger.log(this, "Widget", "onCreate completed");
        } catch (Exception e) { AppLogger.logException(this, "Widget", e); finish(); }
    }
}