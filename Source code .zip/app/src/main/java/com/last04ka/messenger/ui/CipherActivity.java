package com.last04ka.messenger.ui;

import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.os.Bundle;
import android.util.Base64;
import android.view.Gravity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import com.last04ka.messenger.utils.AppLogger;

public class CipherActivity extends Activity {

    private EditText inputText, keyInput, outputText;
    private Spinner cipherSpinner;
    private Button btnEncrypt, btnDecrypt, btnCopy;
    private String[] ciphers = {"Цезарь (ROT13)", "XOR", "Base64"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        try {
            AppLogger.log(this, "Cipher", "onCreate started");
            LinearLayout layout = new LinearLayout(this);
            layout.setOrientation(LinearLayout.VERTICAL);
            layout.setPadding(16, 16, 16, 16);
            layout.setBackgroundColor(0xFF1A1A2E);

            TextView title = new TextView(this);
            title.setText("🔐 Шифратор"); title.setTextSize(20);
            title.setTextColor(0xFFFFFFFF); title.setGravity(Gravity.CENTER);
            layout.addView(title);

            cipherSpinner = new Spinner(this);
            cipherSpinner.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, ciphers));
            layout.addView(cipherSpinner);

            inputText = new EditText(this);
            inputText.setHint("Текст для шифрования"); inputText.setTextColor(0xFFFFFFFF);
            inputText.setHintTextColor(0xFF888888); inputText.setBackgroundColor(0xFF333333);
            inputText.setPadding(12, 10, 12, 10); inputText.setMinHeight(80);
            layout.addView(inputText);

            keyInput = new EditText(this);
            keyInput.setHint("Ключ (для XOR/Цезаря)"); keyInput.setTextColor(0xFFFFFFFF);
            keyInput.setHintTextColor(0xFF888888); keyInput.setBackgroundColor(0xFF333333);
            keyInput.setPadding(12, 10, 12, 10);
            layout.addView(keyInput);

            LinearLayout btnRow = new LinearLayout(this);
            btnRow.setOrientation(LinearLayout.HORIZONTAL);
            btnRow.setGravity(Gravity.CENTER);
            btnEncrypt = new Button(this); btnEncrypt.setText("🔒 Шифровать");
            btnEncrypt.setOnClickListener(v -> encrypt()); btnRow.addView(btnEncrypt);
            btnDecrypt = new Button(this); btnDecrypt.setText("🔓 Расшифровать");
            btnDecrypt.setOnClickListener(v -> decrypt()); btnRow.addView(btnDecrypt);
            layout.addView(btnRow);

            outputText = new EditText(this);
            outputText.setHint("Результат"); outputText.setTextColor(0xFFFFD740);
            outputText.setHintTextColor(0xFF888888); outputText.setBackgroundColor(0xFF333333);
            outputText.setPadding(12, 10, 12, 10); outputText.setMinHeight(80);
            layout.addView(outputText);

            btnCopy = new Button(this); btnCopy.setText("📋 Копировать");
            btnCopy.setOnClickListener(v -> {
                String out = outputText.getText().toString();
                if (out.isEmpty()) { Toast.makeText(this, "Нечего копировать", Toast.LENGTH_SHORT).show(); return; }
                ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
                cm.setPrimaryClip(ClipData.newPlainText("cipher", out));
                Toast.makeText(this, "Скопировано!", Toast.LENGTH_SHORT).show();
            });
            layout.addView(btnCopy);

            setContentView(layout);
            setTitle("🔐 Шифратор");
            AppLogger.log(this, "Cipher", "onCreate completed");
        } catch (Exception e) { AppLogger.logException(this, "Cipher", e); finish(); }
    }

    private void encrypt() {
        String text = inputText.getText().toString();
        if (text.isEmpty()) { Toast.makeText(this, "Введите текст", Toast.LENGTH_SHORT).show(); return; }
        int cipher = cipherSpinner.getSelectedItemPosition();
        String result = "";
        String key = keyInput.getText().toString();
        int shift = key.isEmpty() ? 13 : Math.abs(key.hashCode() % 26);

        switch (cipher) {
            case 0: result = caesar(text, shift); break;
            case 1: result = xorCipher(text, key.isEmpty() ? "key" : key); break;
            case 2: result = Base64.encodeToString(text.getBytes(), Base64.NO_WRAP); break;
        }
        outputText.setText(result);
        AppLogger.log(this, "Cipher", "Encrypted with " + ciphers[cipher]);
    }

    private void decrypt() {
        String text = inputText.getText().toString();
        if (text.isEmpty()) { Toast.makeText(this, "Введите текст", Toast.LENGTH_SHORT).show(); return; }
        int cipher = cipherSpinner.getSelectedItemPosition();
        String result = "";
        String key = keyInput.getText().toString();
        int shift = key.isEmpty() ? 13 : Math.abs(key.hashCode() % 26);

        switch (cipher) {
            case 0: result = caesar(text, -shift); break;
            case 1: result = xorCipher(text, key.isEmpty() ? "key" : key); break;
            case 2:
                try { result = new String(Base64.decode(text, Base64.DEFAULT)); }
                catch (Exception e) { result = "Ошибка декодирования"; } break;
        }
        outputText.setText(result);
        AppLogger.log(this, "Cipher", "Decrypted with " + ciphers[cipher]);
    }

    private String caesar(String text, int shift) {
        StringBuilder sb = new StringBuilder();
        for (char c : text.toCharArray()) {
            if (Character.isLetter(c)) {
                char base = Character.isUpperCase(c) ? 'A' : 'a';
                sb.append((char)((c - base + shift + 26) % 26 + base));
            } else sb.append(c);
        }
        return sb.toString();
    }

    private String xorCipher(String text, String key) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < text.length(); i++) {
            sb.append((char)(text.charAt(i) ^ key.charAt(i % key.length())));
        }
        return sb.toString();
    }
}