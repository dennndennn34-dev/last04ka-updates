package com.last04ka.messenger.utils;

import android.content.Context;
import android.content.SharedPreferences;

import java.util.ArrayList;
import java.util.List;

public class AchievementManager {

    private static final String PREFS = "achievements";

    // ========== ДОСТИЖЕНИЯ ПО ИГРАМ ==========
    private static final String[][] ACHIEVEMENTS = {
        {"ach_snake_10", "Змеелов", "Наберите 10 очков в Змейке", "snake", "10"},
        {"ach_snake_50", "Змеиный король", "Наберите 50 очков в Змейке", "snake", "50"},
        {"ach_tetris_500", "Тетрис-мастер", "Наберите 500 очков в Тетрисе", "tetris", "500"},
        {"ach_tetris_2000", "Тетрис-грандмастер", "Наберите 2000 очков в Тетрисе", "tetris", "2000"},
        {"ach_minesweeper_1", "Сапёр-новичок", "Выиграйте 1 раз в Сапёра", "minesweeper", "1"},
        {"ach_minesweeper_5", "Сапёр-профи", "Выиграйте 5 раз в Сапёра", "minesweeper", "5"},
        {"ach_2048_500", "2048-любитель", "Наберите 500 очков в 2048", "2048", "500"},
        {"ach_2048_5000", "2048-чемпион", "Наберите 5000 очков в 2048", "2048", "5000"},
        {"ach_dice_100", "Кости-везунчик", "Наберите 100 очков в Кости", "dice", "100"},
        {"ach_timing_500", "Тайминг-снайпер", "Наберите 500 очков в Тайминге", "timing", "500"},
        {"ach_pong_200", "Пинг-понг профи", "Наберите 200 очков в Пинг-понге", "pong", "200"},
        {"ach_pong_1000", "Пинг-понг легенда", "Наберите 1000 очков в Пинг-понге", "pong", "1000"},
        {"ach_memory_1", "Память-чемпион", "Выиграйте игру Память", "memory", "1"},
        {"ach_quiz_20", "Викторина-отличник", "Наберите 20/25 в Викторине", "quiz", "20"},
        {"ach_flagsquiz_15", "Флаги-эксперт", "Наберите 15/20 в Флагах мира", "flagsquiz", "15"},
        {"ach_capitalsquiz_15", "Столицы-знаток", "Наберите 15/20 в Столицах мира", "capitalsquiz", "15"},
        {"ach_litquiz_18", "Литература-профессор", "Наберите 18/25 в Литературной викторине", "litquiz", "18"},
        {"ach_bioquiz_18", "Биолог-учёный", "Наберите 18/25 в Биологической викторине", "bioquiz", "18"},
        {"ach_mathblitz_20", "Математик-спринтер", "Решите 20+ примеров в Математическом блице", "mathblitz", "20"},
        {"ach_reaction_200", "Реакция-молния", "Реакция быстрее 200 мс", "reaction", "200"},
        {"ach_reaction_150", "Реакция-сверхчеловек", "Реакция быстрее 150 мс", "reaction", "150"},
        {"ach_multiplication_20", "Таблица умножения 20+", "Ответьте на 20+ вопросов за 30 секунд", "multiplication", "20"},
        {"ach_typingspeed_40", "Скорость печати 40 WPM", "Наберите 40+ слов в минуту", "typingspeed", "40"},
        {"ach_typingspeed_60", "Скорость печати 60 WPM", "Наберите 60+ слов в минуту", "typingspeed", "60"},
        {"ach_tictactoe_10", "Крестики-нолики победитель", "Выиграйте 10 раз в Крестики-нолики", "tictactoe", "10"},
        {"ach_colortest_10", "Цветовой эксперт", "Дойдите до 10 уровня в Цветовом тесте", "colortest", "10"},
        {"ach_colortest_20", "Цветовой мастер", "Дойдите до 20 уровня в Цветовом тесте", "colortest", "20"},
        {"ach_flappybird_10", "Флаппи-новичок", "Наберите 10 очков в Flappy Bird", "flappybird", "10"},
        {"ach_doodle_50", "Платформер-профи", "Наберите 50 очков в Платформере", "doodle", "50"},
    };

    public static void unlock(Context context, String game, int value) {
        if (context == null) {
            AppLogger.log(null, "AchievementManager", "❌ unlock: context is null");
            return;
        }

        AppLogger.log(context, "AchievementManager", "unlock() called: game=" + game + ", value=" + value);

        SharedPreferences prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);

        // Сохраняем максимальное значение для этой игры
        int current = prefs.getInt("game_" + game, 0);
        if (value > current) {
            prefs.edit().putInt("game_" + game, value).apply();
            AppLogger.log(context, "AchievementManager", "Updated game_" + game + " = " + value);
        }

        // Проверяем все достижения
        checkAllAchievements(context);
    }

    public static void checkAllAchievements(Context context) {
        if (context == null) {
            AppLogger.log(null, "AchievementManager", "❌ checkAllAchievements: context is null");
            return;
        }

        AppLogger.log(context, "AchievementManager", "checkAllAchievements() START");

        SharedPreferences prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);

        for (String[] ach : ACHIEVEMENTS) {
            String achId = ach[0];
            if (prefs.getBoolean(achId, false)) continue;

            String game = ach[3];
            int threshold = Integer.parseInt(ach[4]);
            int currentValue = prefs.getInt("game_" + game, 0);

            AppLogger.log(context, "AchievementManager", "Checking: " + ach[1] + " game=" + game + " current=" + currentValue + " threshold=" + threshold);

            if (currentValue >= threshold) {
                prefs.edit().putBoolean(achId, true).apply();
                AppLogger.log(context, "AchievementManager", "🏆 UNLOCKED: " + ach[1] + " (" + achId + ")");
            }
        }

        AppLogger.log(context, "AchievementManager", "checkAllAchievements() END");
    }

    public static List<String[]> getUnlocked(Context context) {
        if (context == null) return new ArrayList<>();
        SharedPreferences prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        List<String[]> unlocked = new ArrayList<>();

        for (String[] ach : ACHIEVEMENTS) {
            String name = ach[1];
            String description = ach[2];
            boolean isUnlocked = prefs.getBoolean(ach[0], false);
            unlocked.add(new String[]{name, description, String.valueOf(isUnlocked), ach[0]});
        }
        return unlocked;
    }

    public static int getUnlockedCount(Context context) {
        if (context == null) return 0;
        SharedPreferences prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        int count = 0;
        for (String[] ach : ACHIEVEMENTS) {
            if (prefs.getBoolean(ach[0], false)) count++;
        }
        return count;
    }
}