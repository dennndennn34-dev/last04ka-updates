package com.last04ka.messenger.ui;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import com.last04ka.messenger.R;
import com.last04ka.messenger.adapters.MessageAdapter;
import com.last04ka.messenger.data.DatabaseHelper;
import com.last04ka.messenger.data.Message;
import com.last04ka.messenger.utils.AppLogger;
import com.last04ka.messenger.utils.ThemeManager;

import java.util.ArrayList;
import java.util.List;

public class SearchMessagesActivity extends AppCompatActivity {
    private EditText searchInput;
    private RecyclerView recyclerView;
    private TextView emptyText;
    private MessageAdapter adapter;
    private List<Message> results = new ArrayList<>();
    private DatabaseHelper dbHelper;
    private String chatId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        setTheme(ThemeManager.getThemeResource(this));
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search_messages);
        setTitle("Поиск сообщений");

        chatId = getIntent().getStringExtra("CHAT_ID");
        if (chatId == null) {
            finish();
            return;
        }

        dbHelper = new DatabaseHelper(this);
        searchInput = findViewById(R.id.search_input);
        recyclerView = findViewById(R.id.recycler_search_results);
        emptyText = findViewById(R.id.tv_empty_search);

        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        adapter = new MessageAdapter(results, null, null);
        adapter.setChatId(chatId);
        recyclerView.setAdapter(adapter);

        searchInput.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) { search(s.toString()); }
            @Override public void afterTextChanged(Editable s) {}
        });

        AppLogger.log(this, "SearchMessages", "Activity created");
    }

    private void search(String query) {
        if (query.trim().isEmpty()) {
            results.clear();
            adapter.notifyDataSetChanged();
            emptyText.setVisibility(View.VISIBLE);
            return;
        }
        results.clear();
        results.addAll(dbHelper.searchMessages(chatId, query));
        adapter.notifyDataSetChanged();
        emptyText.setVisibility(results.isEmpty() ? View.VISIBLE : View.GONE);
        AppLogger.log(this, "SearchMessages", "Found " + results.size() + " messages");
    }
}