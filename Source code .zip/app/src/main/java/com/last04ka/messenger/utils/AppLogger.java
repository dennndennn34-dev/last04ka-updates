package com.last04ka.messenger.utils;

import android.content.Context;
import android.os.Environment;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class AppLogger {
    private static final String LOG_DIR = "Last04ka/logs";
    private static final int MAX_LINES = 3000;
    private static int errorCount = 0, uiLoadCount = 0, textureLoadCount = 0;

    // Чувствительные данные – фильтруем
    private static final String[] SENSITIVE_PATTERNS = {
        "PUB_KEY|", "private_key", "public_key", "shared_secret",
        "ENC|", "AUDIO_DATA|", "CALL_", "TICTACTOE_"
    };

    public static void log(Context ctx, String tag, String msg) {
        String filtered = filterSensitive(msg);
        write(ctx, tag, filtered);
    }

    public static void logException(Context ctx, String tag, Exception e) {
        errorCount++;
        StringWriter sw = new StringWriter();
        PrintWriter pw = new PrintWriter(sw);
        e.printStackTrace(pw);
        String stack = sw.toString();
        write(ctx, tag, "EXCEPTION: " + e.getClass().getSimpleName() + ": " + e.getMessage());
        for (String line : stack.split("\n")) {
            write(ctx, tag, "  " + filterSensitive(line));
        }
    }

    public static void logException(Context ctx, String tag, String extraMsg, Exception e) {
        errorCount++;
        StringWriter sw = new StringWriter();
        PrintWriter pw = new PrintWriter(sw);
        e.printStackTrace(pw);
        String stack = sw.toString();
        write(ctx, tag, "EXCEPTION (" + extraMsg + "): " + e.getClass().getSimpleName() + ": " + e.getMessage());
        for (String line : stack.split("\n")) {
            write(ctx, tag, "  " + filterSensitive(line));
        }
    }

    public static void logUI(Context ctx, String tag, String component, boolean success) {
        uiLoadCount++;
        write(ctx, tag, "[UI] " + component + " " + (success ? "OK" : "FAIL"));
    }

    public static void logTexture(Context ctx, String tag, String name, boolean loaded) {
        textureLoadCount++;
        write(ctx, tag, "[TEXTURE] " + name + " " + (loaded ? "OK" : "FAIL"));
    }

    public static void logAnimation(Context ctx, String tag, String name, long duration) {
        write(ctx, tag, "[ANIM] " + name + " (" + duration + "ms)");
    }

    public static void logInit(Context ctx, String tag, String component) {
        write(ctx, tag, "[INIT] " + component);
    }

    public static String getStats() {
        return "Errors:" + errorCount + "|UI:" + uiLoadCount + "|Textures:" + textureLoadCount;
    }

    public static void resetStats() {
        errorCount = 0;
        uiLoadCount = 0;
        textureLoadCount = 0;
    }

    private static String filterSensitive(String msg) {
        if (msg == null) return null;
        for (String pattern : SENSITIVE_PATTERNS) {
            if (msg.contains(pattern)) {
                return "[FILTERED] " + msg.substring(0, Math.min(20, msg.length())) + "...";
            }
        }
        return msg;
    }

    private static void write(Context ctx, String tag, String msg) {
        try {
            if (ctx == null) {
                // Если контекст null – пишем в системный лог (для отладки)
                android.util.Log.d("AppLogger", "[" + tag + "] " + msg);
                return;
            }

            // Создаём папку в Загрузках/Last04ka/logs/
            File baseDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);
            if (baseDir == null) return;
            File logDir = new File(baseDir, LOG_DIR);
            if (!logDir.exists() && !logDir.mkdirs()) {
                // Если не удалось создать папку – пишем во внутреннее хранилище
                logDir = new File(ctx.getFilesDir(), "logs");
                if (!logDir.exists() && !logDir.mkdirs()) return;
            }

            String dateStr = new SimpleDateFormat("yyyy-MM-dd", Locale.US).format(new Date());
            String fileName = "last04ka_log_" + dateStr + ".txt";
            File logFile = new File(logDir, fileName);

            String ts = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS", Locale.US).format(new Date());
            String line = "[" + ts + "] [" + tag + "] " + msg + "\n";
            appendToFile(logFile, line);
        } catch (Exception e) {
            // Если совсем не получается – пишем в System.err
            System.err.println("[AppLogger] " + e.getMessage());
            e.printStackTrace();
        }
    }

    private static void appendToFile(File f, String line) {
        try {
            StringBuilder sb = new StringBuilder();
            if (f.exists()) {
                BufferedReader r = new BufferedReader(new InputStreamReader(new FileInputStream(f)));
                String l;
                while ((l = r.readLine()) != null) sb.append(l).append("\n");
                r.close();
            }
            sb.append(line);
            String[] lines = sb.toString().split("\n");
            if (lines.length > MAX_LINES) {
                StringBuilder t = new StringBuilder();
                for (int i = Math.max(0, lines.length - MAX_LINES); i < lines.length; i++) {
                    t.append(lines[i]).append("\n");
                }
                sb = t;
            }
            OutputStreamWriter w = new OutputStreamWriter(new FileOutputStream(f));
            w.write(sb.toString());
            w.close();
        } catch (Exception e) {
            // Игнорируем
        }
    }

    public static String getFullLog(Context ctx) {
        try {
            File baseDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);
            if (baseDir == null) return "Не удалось получить папку Загрузки";
            File logDir = new File(baseDir, LOG_DIR);
            if (!logDir.exists()) return "Папка логов не существует.";

            // Берём самый свежий файл (сегодняшний) или любой
            String dateStr = new SimpleDateFormat("yyyy-MM-dd", Locale.US).format(new Date());
            File logFile = new File(logDir, "last04ka_log_" + dateStr + ".txt");
            if (!logFile.exists()) {
                // Ищем любой файл лога
                File[] files = logDir.listFiles();
                if (files == null || files.length == 0) return "Нет файлов лога.";
                logFile = files[0];
                for (File f : files) {
                    if (f.lastModified() > logFile.lastModified()) logFile = f;
                }
            }

            StringBuilder sb = new StringBuilder();
            BufferedReader r = new BufferedReader(new InputStreamReader(new FileInputStream(logFile)));
            String l;
            while ((l = r.readLine()) != null) sb.append(l).append("\n");
            r.close();
            return sb.toString();
        } catch (Exception e) {
            return "Ошибка чтения лога: " + e.getMessage();
        }
    }

    public static void clearLog(Context ctx) {
        try {
            File baseDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);
            if (baseDir == null) return;
            File logDir = new File(baseDir, LOG_DIR);
            if (logDir.exists()) {
                for (File f : logDir.listFiles()) {
                    if (f.isFile()) f.delete();
                }
            }
            resetStats();
        } catch (Exception e) {
            // игнорируем
        }
    }
}