package com.last04ka.messenger.ui;

import android.app.Activity;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.os.Bundle;
import android.os.Handler;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.last04ka.messenger.utils.AppLogger;
import com.last04ka.messenger.utils.GameScores;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Random;

public class DoodleJumpActivity extends Activity {

    private GameView gameView;
    private TextView scoreText, bestText;
    private int score = 0, best = 0;
    private Handler handler = new Handler();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        try {
            AppLogger.log(this, "DoodleJump", "onCreate v3 (fixed)");
            AppLogger.logTexture(this, "DoodleJump", "Player character", true);
            AppLogger.logTexture(this, "DoodleJump", "Platform textures", true);

            LinearLayout layout = new LinearLayout(this);
            layout.setOrientation(LinearLayout.VERTICAL);
            layout.setBackgroundColor(0xFFFFFFFF);

            LinearLayout stats = new LinearLayout(this);
            stats.setGravity(Gravity.CENTER);
            stats.setPadding(8, 4, 8, 4);
            scoreText = new TextView(this);
            scoreText.setText("Счёт: 0");
            scoreText.setTextSize(16);
            scoreText.setTextColor(0xFF212121);
            stats.addView(scoreText);
            bestText = new TextView(this);
            best = GameScores.getScore(this, "doodle");
            bestText.setText("  Рекорд: " + best);
            bestText.setTextSize(14);
            bestText.setTextColor(0xFF1565C0);
            stats.addView(bestText);
            layout.addView(stats);

            gameView = new GameView(this);
            layout.addView(gameView);
            setContentView(layout);
            setTitle("🏃 Платформер");
            AppLogger.log(this, "DoodleJump", "onCreate completed, best=" + best);
        } catch (Exception e) {
            AppLogger.logException(this, "DoodleJump", e);
            finish();
        }
    }

    class GameView extends View {
        private Paint paint = new Paint();
        private Random rand = new Random();
        private float playerX, playerY, playerW = 44, playerH = 54;
        private float vy = 0;
        private float gravity = 0.4f;
        private float jumpForce = -15f;
        private float maxFallSpeed = 13f;
        private float cameraY = 0;
        private List<RectF> platforms = new ArrayList<>();
        private boolean gameOver = false;
        private boolean running = false;
        private float touchStartX = 0;
        private boolean touching = false;
        private final Object platformsLock = new Object();

        public GameView(Context ctx) {
            super(ctx);
            setFocusable(true);
            setFocusableInTouchMode(true);
            setBackgroundColor(0xFFFFFFFF);
        }

        private void init() {
            int w = getWidth(), h = getHeight();
            if (w <= 0 || h <= 0) return;
            playerX = w / 2f - playerW / 2;
            playerY = h - 250;
            cameraY = 0;
            synchronized (platformsLock) {
                platforms.clear();
                platforms.add(new RectF(w / 2f - 90, h - 80, w / 2f + 90, h - 62));
                for (int i = 1; i < 18; i++) {
                    float pw = 100 + rand.nextFloat() * 50;
                    float px = rand.nextFloat() * (w - pw);
                    float py = h - i * 100 - rand.nextFloat() * 40;
                    platforms.add(new RectF(px, py, px + pw, py + 16));
                }
            }
            score = 0;
            vy = 0;
            gameOver = false;
            handler.post(() -> {
                scoreText.setText("Счёт: 0");
                bestText.setText("  Рекорд: " + best);
            });
        }

        @Override
        protected void onSizeChanged(int w, int h, int oldw, int oldh) {
            super.onSizeChanged(w, h, oldw, oldh);
            if (platforms.isEmpty()) init();
        }

        @Override
        protected void onDraw(Canvas c) {
            try {
                super.onDraw(c);
                int w = getWidth(), h = getHeight();
                if (w <= 0 || h <= 0) return;

                paint.setColor(0xFFE8F5E9);
                c.drawRect(0, 0, w, h, paint);

                // Копируем список платформ для безопасного рисования
                List<RectF> platformsCopy;
                synchronized (platformsLock) {
                    platformsCopy = new ArrayList<>(platforms);
                }

                for (RectF p : platformsCopy) {
                    float top = p.top - cameraY;
                    float bottom = p.bottom - cameraY;
                    if (bottom < -20 || top > h + 20) continue;
                    paint.setColor(0xFFC8E6C9);
                    c.drawRoundRect(p.left + 2, top + 2, p.right + 2, bottom + 2, 8, 8, paint);
                    paint.setColor(0xFF4CAF50);
                    c.drawRoundRect(p.left, top, p.right, bottom, 8, 8, paint);
                    paint.setColor(0xFF81C784);
                    c.drawRoundRect(p.left, top, p.right, top + 5, 8, 8, paint);
                }

                float py = playerY - cameraY;
                if (py > -100 && py < h + 100) {
                    paint.setColor(0xFF42A5F5);
                    c.drawRoundRect(playerX, py, playerX + playerW, py + playerH, 14, 14, paint);
                    paint.setColor(0xFF1E88E5);
                    c.drawRoundRect(playerX + 4, py, playerX + playerW - 4, py + playerH * 0.4f, 10, 10, paint);
                    paint.setColor(Color.WHITE);
                    c.drawCircle(playerX + playerW * 0.6f, py + playerH * 0.18f, 7, paint);
                    c.drawCircle(playerX + playerW * 0.85f, py + playerH * 0.18f, 6, paint);
                    paint.setColor(Color.BLACK);
                    c.drawCircle(playerX + playerW * 0.63f, py + playerH * 0.18f, 3, paint);
                    c.drawCircle(playerX + playerW * 0.88f, py + playerH * 0.18f, 2.5f, paint);
                    paint.setColor(0xFFFF5252);
                    c.drawArc(playerX + playerW * 0.6f, py + playerH * 0.22f, playerX + playerW * 0.85f, py + playerH * 0.32f, 0, 180, false, paint);
                }

                if (gameOver) {
                    paint.setColor(0xAA000000);
                    c.drawRect(0, 0, w, h, paint);
                    paint.setColor(Color.WHITE);
                    paint.setTextSize(40);
                    paint.setTextAlign(Paint.Align.CENTER);
                    c.drawText("Game Over", w / 2, h / 2 - 10, paint);
                    paint.setTextSize(22);
                    c.drawText("Счёт: " + score + " | Рекорд: " + best, w / 2, h / 2 + 30, paint);
                    c.drawText("Тап для рестарта", w / 2, h / 2 + 58, paint);
                    paint.setTextAlign(Paint.Align.LEFT);
                }
            } catch (Exception e) {
                AppLogger.logException(DoodleJumpActivity.this, "DoodleJump", e);
            }
        }

        public void update() {
            if (gameOver || !running) return;
            try {
                int w = getWidth(), h = getHeight();
                if (w <= 0 || h <= 0) return;

                vy += gravity;
                if (vy > maxFallSpeed) vy = maxFallSpeed;
                playerY += vy;

                synchronized (platformsLock) {
                    if (!platforms.isEmpty()) {
                        RectF last = platforms.get(platforms.size() - 1);
                        while (last.top - cameraY > -80) {
                            float pw = 90 + rand.nextFloat() * 60;
                            float px = rand.nextFloat() * (w - pw);
                            float py = last.top - 80 - rand.nextFloat() * 50;
                            last = new RectF(px, py, px + pw, py + 16);
                            platforms.add(last);
                        }
                    }

                    while (platforms.size() > 40) platforms.remove(0);

                    if (vy > 0) {
                        for (RectF p : platforms) {
                            if (playerX + playerW > p.left && playerX < p.right &&
                                    playerY + playerH >= p.top && playerY + playerH <= p.bottom + vy + 8) {
                                vy = jumpForce;
                                playerY = p.top - playerH;
                                score++;
                                handler.post(() -> {
                                    scoreText.setText("Счёт: " + score);
                                    if (score > best) {
                                        best = score;
                                        bestText.setText("  Рекорд: " + best);
                                        GameScores.saveScore(DoodleJumpActivity.this, "doodle", best);
                                    }
                                });
                                break;
                            }
                        }
                    }
                }

                if (playerY - cameraY > h + 150) {
                    gameOver = true;
                    AppLogger.log(DoodleJumpActivity.this, "DoodleJump", "Game over, score=" + score + " best=" + best);
                }

                if (vy < 0 && playerY - cameraY < h * 0.35f) {
                    cameraY += (playerY - h * 0.35f - cameraY) * 0.2f;
                }

                if (touching) {
                    float targetX = touchStartX - playerW / 2;
                    playerX += (targetX - playerX) * 0.15f;
                }
                if (playerX < -playerW) playerX = w;
                if (playerX > w) playerX = -playerW;

            } catch (Exception e) {
                AppLogger.logException(DoodleJumpActivity.this, "DoodleJump", e);
            }
        }

        @Override
        public boolean onTouchEvent(MotionEvent e) {
            if (gameOver) {
                gameOver = false;
                init();
                AppLogger.log(DoodleJumpActivity.this, "DoodleJump", "Game restarted");
                return true;
            }
            touchStartX = e.getX();
            touching = e.getAction() != MotionEvent.ACTION_UP;
            return true;
        }

        @Override
        protected void onAttachedToWindow() {
            super.onAttachedToWindow();
            running = true;
            new Thread(() -> {
                while (running) {
                    try {
                        Thread.sleep(16);
                        update();
                        postInvalidate();
                    } catch (InterruptedException e) {
                        break;
                    } catch (Exception e) {
                        AppLogger.logException(DoodleJumpActivity.this, "DoodleJump", e);
                    }
                }
            }).start();
        }

        @Override
        protected void onDetachedFromWindow() {
            super.onDetachedFromWindow();
            running = false;
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        handler.removeCallbacksAndMessages(null);
    }
}