package com.last04ka.messenger.ui;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import com.last04ka.messenger.utils.AppLogger;
import com.last04ka.messenger.utils.GameScores;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Random;

public class EruditeQuizActivity extends Activity {

    private TextView questionText, scoreText;
    private Button[] btns = new Button[5];
    private int current = 0, score = 0, total = 25;
    private List<String[]> pool = new ArrayList<>(), selected = new ArrayList<>();
    private Random r = new Random();

    private String[][] data = {
        {"В каком году началась Вторая мировая война?", "1937", "1939", "1941", "1943", "1945", "1"},
        {"Кто написал 'Гамлет'?", "Диккенс", "Шекспир", "Гюго", "Толстой", "Байрон", "1"},
        {"Сколько игроков в баскетбольной команде на площадке?", "4", "5", "6", "7", "11", "1"},
        {"Какой художник написал 'Звёздную ночь'?", "Пикассо", "Ван Гог", "Моне", "Дали", "Рембрандт", "1"},
        {"Столица Турции?", "Стамбул", "Анкара", "Измир", "Анталья", "Бурса", "1"},
        {"Какая планета самая большая в Солнечной системе?", "Земля", "Марс", "Юпитер", "Сатурн", "Нептун", "2"},
        {"Кто изобрёл лампочку?", "Тесла", "Эдисон", "Белл", "Эйнштейн", "Фарадей", "1"},
        {"Сколько зубов у взрослого человека?", "28", "30", "32", "34", "36", "2"},
        {"В каком году человек впервые полетел в космос?", "1957", "1959", "1961", "1963", "1965", "2"},
        {"Какая страна выиграла ЧМ по футболу 2018?", "Бразилия", "Германия", "Франция", "Аргентина", "Испания", "2"},
        {"Кто написал 'Теорию относительности'?", "Ньютон", "Эйнштейн", "Планк", "Бор", "Гейзенберг", "1"},
        {"Какой инструмент имеет 88 клавиш?", "Гитара", "Скрипка", "Пианино", "Арфа", "Орган", "2"},
        {"Какая гора самая высокая в мире?", "К2", "Эверест", "Килиманджаро", "Эльбрус", "Монблан", "1"},
        {"Столица Канады?", "Торонто", "Оттава", "Ванкувер", "Монреаль", "Калгари", "1"},
        {"Какой элемент имеет символ 'Fe'?", "Фтор", "Железо", "Франций", "Фермий", "Фосфор", "1"},
        {"Кто написал 'Божественную комедию'?", "Шекспир", "Данте", "Гомер", "Вергилий", "Петрарка", "1"},
        {"Сколько очков даётся за трёхочковый бросок в баскетболе?", "1", "2", "3", "4", "5", "2"},
        {"Какое море самое солёное?", "Красное", "Мёртвое", "Средиземное", "Чёрное", "Каспийское", "1"},
        {"В каком году распался СССР?", "1989", "1990", "1991", "1992", "1993", "2"},
        {"Кто сыграл Гарри Поттера в фильмах?", "Роберт Паттинсон", "Дэниел Рэдклифф", "Том Фелтон", "Руперт Гринт", "Эдди Редмэйн", "1"},
        {"Как называется наука о животных?", "Ботаника", "Зоология", "Экология", "Биология", "Анатомия", "1"},
        {"Сколько чудес света в классическом списке?", "5", "6", "7", "8", "9", "2"},
        {"Какая река самая длинная в Европе?", "Дунай", "Волга", "Рейн", "Днепр", "Эльба", "1"},
        {"Кто написал картину 'Мона Лиза'?", "Микеланджело", "Рафаэль", "Леонардо да Винчи", "Донателло", "Тициан", "2"},
        {"Сколько хромосом у человека?", "42", "44", "46", "48", "50", "2"},
        {"В каком виде спорта используется термин 'бёрди'?", "Теннис", "Гольф", "Футбол", "Хоккей", "Регби", "1"},
        {"Столица Аргентины?", "Сантьяго", "Буэнос-Айрес", "Лима", "Богота", "Кито", "1"},
        {"Кто открыл пенициллин?", "Пастер", "Флеминг", "Кох", "Менделеев", "Дарвин", "1"},
        {"Какой океан самый глубокий?", "Атлантический", "Индийский", "Тихий", "Северный Ледовитый", "Южный", "2"},
        {"Сколько длился 100-летняя война?", "100 лет", "116 лет", "95 лет", "120 лет", "99 лет", "1"},
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        try {
            AppLogger.log(this, "EruditeQuiz", "onCreate started");
            LinearLayout layout = new LinearLayout(this);
            layout.setOrientation(LinearLayout.VERTICAL); layout.setPadding(24,24,24,24); layout.setBackgroundColor(0xFF252525);

            scoreText = new TextView(this); scoreText.setText("Счёт: 0 / "+total+" | Рекорд: "+GameScores.getScore(this,"erudite"));
            scoreText.setTextSize(14); scoreText.setTextColor(0xFFBDBDBD); layout.addView(scoreText);

            questionText = new TextView(this); questionText.setTextSize(16); questionText.setTextColor(0xFFFFFFFF);
            questionText.setPadding(0,16,0,16); layout.addView(questionText);

            for(int i=0;i<5;i++){ final int idx=i; btns[i]=new Button(this); btns[i].setTextSize(14); btns[i].setAllCaps(false);
                btns[i].setPadding(8,12,8,12); btns[i].setOnClickListener(new View.OnClickListener() {
                    @Override public void onClick(View v) { checkAnswer(idx); }
                }); layout.addView(btns[i]); }

            pool.addAll(Arrays.asList(data)); Collections.shuffle(pool,r);
            for(int i=0;i<Math.min(total,pool.size());i++) selected.add(pool.get(i));
            setContentView(layout); setTitle("🧠 Эрудит"); showQuestion();
            AppLogger.log(this,"EruditeQuiz","onCreate completed, questions: "+selected.size());
        } catch(Exception e){ AppLogger.logException(this,"EruditeQuiz",e); finish(); }
    }

    private void showQuestion(){
        if(current>=selected.size()){ questionText.setText("🏆 Итог: "+score+" из "+total);
            for(Button b:btns)b.setVisibility(View.GONE); GameScores.saveScore(this,"erudite",score); return; }
        String[] q=selected.get(current); questionText.setText("Вопрос "+(current+1)+"/"+total+": "+q[0]);
        for(int i=0;i<5;i++) btns[i].setText(q[i+1]);
    }

    private void checkAnswer(int idx){
        if(current>=selected.size())return; String[] q=selected.get(current); int correct=Integer.parseInt(q[6]);
        if(idx==correct){score++; Toast.makeText(this,"✅",Toast.LENGTH_SHORT).show();}
        else Toast.makeText(this,"❌ "+q[correct+1],Toast.LENGTH_SHORT).show();
        scoreText.setText("Счёт: "+score+" / "+total+" | Рекорд: "+GameScores.getScore(this,"erudite"));
        current++; showQuestion();
    }
}