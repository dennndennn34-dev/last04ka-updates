package com.last04ka.messenger.connectivity;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.wifi.p2p.WifiP2pConfig;
import android.net.wifi.p2p.WifiP2pDevice;
import android.net.wifi.p2p.WifiP2pDeviceList;
import android.net.wifi.p2p.WifiP2pGroup;
import android.net.wifi.p2p.WifiP2pInfo;
import android.net.wifi.p2p.WifiP2pManager;
import android.net.wifi.p2p.WifiP2pManager.Channel;
import android.net.wifi.p2p.WifiP2pManager.ConnectionInfoListener;
import android.net.wifi.p2p.WifiP2pManager.PeerListListener;
import android.os.Handler;

import com.last04ka.messenger.utils.AppLogger;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.InetSocketAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketTimeoutException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class NearbyManager implements PeerListListener, ConnectionInfoListener {
    private static final String TAG = "NearbyManager";
    private static final int PORT = 8888;
    private static final int SOCKET_TIMEOUT = 30000;

    private Context context;
    private WifiP2pManager manager;
    private Channel channel;
    private BroadcastReceiver receiver;
    private boolean isReceiverRegistered = false;

    private List<WifiP2pDevice> peers = new ArrayList<>();
    private WifiP2pInfo connectionInfo;
    private WifiP2pGroup groupInfo;
    private WifiP2pDevice thisDevice;

    private ServerSocket serverSocket;
    private Socket clientSocket;
    private PrintWriter outputWriter;
    private BufferedReader inputReader;
    private Handler handler = new Handler();

    private MessageCallback callback;
    private boolean isGroupOwner = false;
    private boolean isConnected = false;

    public interface MessageCallback {
        void onMessageReceived(String message);
        void onConnectionStateChanged(boolean connected, boolean isGroupOwner);
        void onPeersChanged(List<WifiP2pDevice> peers);
        void onDeviceDisconnected();
        void onError(String error);
        void onThisDeviceChanged(WifiP2pDevice device);
    }

    public NearbyManager(Context context) {
        this.context = context;
        manager = (WifiP2pManager) context.getSystemService(Context.WIFI_P2P_SERVICE);
        if (manager != null) {
            channel = manager.initialize(context, context.getMainLooper(), null);
            AppLogger.log(context, TAG, "WiFi Direct initialized");
        } else {
            AppLogger.log(context, TAG, "❌ WiFi P2P not supported");
        }
        registerReceiver();
    }

    private void registerReceiver() {
        if (receiver != null) return;
        receiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                String action = intent.getAction();
                if (WifiP2pManager.WIFI_P2P_STATE_CHANGED_ACTION.equals(action)) {
                    int state = intent.getIntExtra(WifiP2pManager.EXTRA_WIFI_STATE, -1);
                    AppLogger.log(context, TAG, "WiFi P2P state changed: " + state);
                    if (state == WifiP2pManager.WIFI_P2P_STATE_ENABLED) {
                        AppLogger.log(context, TAG, "✅ WiFi Direct enabled");
                    } else {
                        AppLogger.log(context, TAG, "❌ WiFi Direct disabled");
                    }
                } else if (WifiP2pManager.WIFI_P2P_PEERS_CHANGED_ACTION.equals(action)) {
                    if (manager != null) {
                        manager.requestPeers(channel, NearbyManager.this);
                    }
                } else if (WifiP2pManager.WIFI_P2P_CONNECTION_CHANGED_ACTION.equals(action)) {
                    if (manager != null) {
                        manager.requestConnectionInfo(channel, NearbyManager.this);
                    }
                } else if (WifiP2pManager.WIFI_P2P_THIS_DEVICE_CHANGED_ACTION.equals(action)) {
                    WifiP2pDevice device = intent.getParcelableExtra(WifiP2pManager.EXTRA_WIFI_P2P_DEVICE);
                    if (device != null) {
                        thisDevice = device;
                        AppLogger.log(context, TAG, "This device: " + device.deviceName + " (" + device.deviceAddress + ")");
                        if (callback != null) {
                            callback.onThisDeviceChanged(device);
                        }
                    }
                }
            }
        };

        IntentFilter filter = new IntentFilter();
        filter.addAction(WifiP2pManager.WIFI_P2P_STATE_CHANGED_ACTION);
        filter.addAction(WifiP2pManager.WIFI_P2P_PEERS_CHANGED_ACTION);
        filter.addAction(WifiP2pManager.WIFI_P2P_CONNECTION_CHANGED_ACTION);
        filter.addAction(WifiP2pManager.WIFI_P2P_THIS_DEVICE_CHANGED_ACTION);
        context.registerReceiver(receiver, filter);
        isReceiverRegistered = true;
        AppLogger.log(context, TAG, "WiFi Direct receiver registered");
    }

    public void setCallback(MessageCallback callback) {
        this.callback = callback;
        AppLogger.log(context, TAG, "Callback set");
    }

    // ==================== ОБНАРУЖЕНИЕ ====================

    public void discoverPeers() {
        AppLogger.log(context, TAG, "discoverPeers() called");
        if (manager == null) {
            AppLogger.log(context, TAG, "❌ Manager is null");
            if (callback != null) callback.onError("WiFi Direct недоступен");
            return;
        }
        manager.discoverPeers(channel, new WifiP2pManager.ActionListener() {
            @Override
            public void onSuccess() {
                AppLogger.log(context, TAG, "✅ Discovery started");
                if (callback != null) {
                    callback.onError("Поиск устройств запущен");
                }
            }

            @Override
            public void onFailure(int reason) {
                AppLogger.log(context, TAG, "❌ Discovery failed: " + reason);
                if (callback != null) {
                    callback.onError("Ошибка поиска: " + reason);
                }
            }
        });
    }

    @Override
    public void onPeersAvailable(WifiP2pDeviceList peerList) {
        AppLogger.log(context, TAG, "onPeersAvailable() called");
        peers.clear();
        if (peerList != null) {
            for (WifiP2pDevice device : peerList.getDeviceList()) {
                // Игнорируем себя
                if (thisDevice != null && device.deviceAddress.equals(thisDevice.deviceAddress)) continue;
                peers.add(device);
            }
            // Сортировка по имени
            Collections.sort(peers, new Comparator<WifiP2pDevice>() {
                @Override
                public int compare(WifiP2pDevice o1, WifiP2pDevice o2) {
                    String n1 = o1.deviceName != null ? o1.deviceName : "";
                    String n2 = o2.deviceName != null ? o2.deviceName : "";
                    return n1.compareToIgnoreCase(n2);
                }
            });
            AppLogger.log(context, TAG, "✅ Found " + peers.size() + " peers (excluding self)");
            for (WifiP2pDevice device : peers) {
                AppLogger.log(context, TAG, "   Device: " + device.deviceName + " (" + device.deviceAddress + ")");
            }
        } else {
            AppLogger.log(context, TAG, "⚠️ Peer list is null");
        }
        if (callback != null) {
            callback.onPeersChanged(peers);
        }
    }

    // ==================== ПОДКЛЮЧЕНИЕ ====================

    public void connectToDevice(WifiP2pDevice device) {
        AppLogger.log(context, TAG, "connectToDevice() called: " + device.deviceName);
        if (manager == null) {
            AppLogger.log(context, TAG, "❌ Manager is null");
            return;
        }

        WifiP2pConfig config = new WifiP2pConfig();
        config.deviceAddress = device.deviceAddress;
        config.groupOwnerIntent = 0;

        manager.connect(channel, config, new WifiP2pManager.ActionListener() {
            @Override
            public void onSuccess() {
                AppLogger.log(context, TAG, "✅ Connection request sent to " + device.deviceName);
                if (callback != null) {
                    callback.onError("Подключение к " + device.deviceName + "...");
                }
            }

            @Override
            public void onFailure(int reason) {
                AppLogger.log(context, TAG, "❌ Connection request failed: " + reason);
                if (callback != null) {
                    callback.onError("Ошибка подключения: " + reason);
                }
            }
        });
    }

    public void createGroup() {
        AppLogger.log(context, TAG, "createGroup() called");
        if (manager == null) {
            AppLogger.log(context, TAG, "❌ Manager is null");
            return;
        }
        manager.createGroup(channel, new WifiP2pManager.ActionListener() {
            @Override
            public void onSuccess() {
                AppLogger.log(context, TAG, "✅ Group created (I am owner)");
                isGroupOwner = true;
                if (callback != null) {
                    callback.onError("Группа создана, вы владелец");
                }
                startServer();
            }

            @Override
            public void onFailure(int reason) {
                AppLogger.log(context, TAG, "❌ Group creation failed: " + reason);
                if (callback != null) {
                    callback.onError("Ошибка создания группы: " + reason);
                }
            }
        });
    }

    public void removeGroup() {
        AppLogger.log(context, TAG, "removeGroup() called");
        if (manager == null) return;
        manager.removeGroup(channel, new WifiP2pManager.ActionListener() {
            @Override
            public void onSuccess() {
                AppLogger.log(context, TAG, "✅ Group removed");
                isGroupOwner = false;
                isConnected = false;
                stopServer();
                if (callback != null) {
                    callback.onDeviceDisconnected();
                }
            }

            @Override
            public void onFailure(int reason) {
                AppLogger.log(context, TAG, "❌ Group removal failed: " + reason);
            }
        });
    }

    // ==================== СОЕДИНЕНИЕ УСТАНОВЛЕНО ====================

    @Override
    public void onConnectionInfoAvailable(WifiP2pInfo info) {
        AppLogger.log(context, TAG, "onConnectionInfoAvailable() called");
        connectionInfo = info;
        isConnected = info.groupFormed;
        isGroupOwner = info.isGroupOwner;

        AppLogger.log(context, TAG, "   Group formed: " + isConnected);
        AppLogger.log(context, TAG, "   Is group owner: " + isGroupOwner);
        AppLogger.log(context, TAG, "   Group owner address: " + (info.groupOwnerAddress != null ? info.groupOwnerAddress.getHostAddress() : "null"));

        if (isConnected && callback != null) {
            callback.onConnectionStateChanged(true, isGroupOwner);
        }

        if (isConnected && !isGroupOwner) {
            if (info.groupOwnerAddress != null) {
                connectToServer(info.groupOwnerAddress.getHostAddress());
            } else {
                AppLogger.log(context, TAG, "❌ No group owner address");
            }
        } else if (isConnected && isGroupOwner) {
            AppLogger.log(context, TAG, "✅ Already running server as group owner");
        }
    }

    // ==================== СЕРВЕР ДЛЯ ВЛАДЕЛЬЦА ГРУППЫ ====================

    private void startServer() {
        AppLogger.log(context, TAG, "startServer() called");
        new Thread(() -> {
            try {
                serverSocket = new ServerSocket(PORT);
                serverSocket.setSoTimeout(SOCKET_TIMEOUT);
                AppLogger.log(context, TAG, "✅ Server socket opened on port " + PORT);

                while (isConnected && isGroupOwner) {
                    try {
                        Socket socket = serverSocket.accept();
                        AppLogger.log(context, TAG, "✅ Client connected: " + socket.getInetAddress().getHostAddress());
                        handleClientSocket(socket);
                    } catch (SocketTimeoutException e) {
                        AppLogger.log(context, TAG, "Server timeout, continuing...");
                    } catch (IOException e) {
                        AppLogger.logException(context, TAG, "Server accept error", e);
                    }
                }
                AppLogger.log(context, TAG, "Server loop ended");
            } catch (IOException e) {
                AppLogger.logException(context, TAG, "Failed to start server", e);
                if (callback != null) {
                    callback.onError("Ошибка сервера: " + e.getMessage());
                }
            }
        }).start();
    }

    private void stopServer() {
        AppLogger.log(context, TAG, "stopServer() called");
        try {
            if (serverSocket != null) {
                serverSocket.close();
                serverSocket = null;
            }
        } catch (IOException e) {
            AppLogger.logException(context, TAG, "Error closing server socket", e);
        }
        closeClientSocket();
    }

    // ==================== КЛИЕНТСКОЕ ПОДКЛЮЧЕНИЕ ====================

    private void connectToServer(String host) {
        AppLogger.log(context, TAG, "connectToServer() called, host=" + host);
        new Thread(() -> {
            try {
                clientSocket = new Socket();
                clientSocket.connect(new InetSocketAddress(host, PORT), 10000);
                AppLogger.log(context, TAG, "✅ Connected to server at " + host);

                outputWriter = new PrintWriter(clientSocket.getOutputStream(), true);
                inputReader = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));

                startReadingFromServer();

                if (callback != null) {
                    callback.onConnectionStateChanged(true, false);
                }

            } catch (IOException e) {
                AppLogger.logException(context, TAG, "Failed to connect to server", e);
                if (callback != null) {
                    callback.onError("Не удалось подключиться к серверу: " + e.getMessage());
                }
            }
        }).start();
    }

    private void handleClientSocket(Socket socket) {
        try {
            outputWriter = new PrintWriter(socket.getOutputStream(), true);
            inputReader = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            clientSocket = socket;
            startReadingFromServer();
        } catch (IOException e) {
            AppLogger.logException(context, TAG, "Error handling client socket", e);
        }
    }

    private void startReadingFromServer() {
        new Thread(() -> {
            try {
                String line;
                while ((line = inputReader.readLine()) != null) {
                    AppLogger.log(context, TAG, "📨 Received from server: " + line);
                    final String msg = line;
                    handler.post(() -> {
                        if (callback != null) {
                            callback.onMessageReceived(msg);
                        }
                    });
                }
                AppLogger.log(context, TAG, "Server closed connection (read returned null)");
                disconnect();
            } catch (IOException e) {
                AppLogger.logException(context, TAG, "Read error", e);
                disconnect();
            }
        }).start();
    }

    // ==================== ОТПРАВКА СООБЩЕНИЙ ====================

    public void sendMessage(String message) {
        AppLogger.log(context, TAG, "📤 Sending message: " + message);
        if (outputWriter == null) {
            AppLogger.log(context, TAG, "❌ Output writer is null");
            if (callback != null) {
                callback.onError("Нет соединения");
            }
            return;
        }
        new Thread(() -> {
            try {
                outputWriter.println(message);
                outputWriter.flush();
                AppLogger.log(context, TAG, "✅ Message sent");
            } catch (Exception e) {
                AppLogger.logException(context, TAG, "Send error", e);
                if (callback != null) {
                    callback.onError("Ошибка отправки: " + e.getMessage());
                }
            }
        }).start();
    }

    // ==================== ОТКЛЮЧЕНИЕ ====================

    public void disconnect() {
        AppLogger.log(context, TAG, "disconnect() called");
        isConnected = false;
        closeClientSocket();
        if (manager != null) {
            manager.removeGroup(channel, null);
        }
        if (callback != null) {
            callback.onDeviceDisconnected();
        }
    }

    private void closeClientSocket() {
        try {
            if (inputReader != null) {
                inputReader.close();
                inputReader = null;
            }
            if (outputWriter != null) {
                outputWriter.close();
                outputWriter = null;
            }
            if (clientSocket != null) {
                clientSocket.close();
                clientSocket = null;
            }
        } catch (IOException e) {
            AppLogger.logException(context, TAG, "Error closing client socket", e);
        }
    }

    // ==================== ДИАГНОСТИКА ====================

    public String getDiagnosticInfo() {
        StringBuilder sb = new StringBuilder();
        sb.append("📡 ДИАГНОСТИКА WiFi Direct\n");
        sb.append("═══════════════════════════════════\n");
        sb.append("Статус менеджера: ").append(manager != null ? "✅ Доступен" : "❌ Недоступен").append("\n");
        sb.append("Ресивер зарегистрирован: ").append(isReceiverRegistered ? "✅" : "❌").append("\n");
        sb.append("Текущее устройство:\n");
        if (thisDevice != null) {
            sb.append("  Имя: ").append(thisDevice.deviceName != null ? thisDevice.deviceName : "Неизвестно").append("\n");
            sb.append("  MAC: ").append(thisDevice.deviceAddress != null ? thisDevice.deviceAddress : "N/A").append("\n");
            sb.append("  Статус: ").append(getDeviceStatus(thisDevice.status)).append("\n");
        } else {
            sb.append("  ❌ Неизвестно\n");
        }
        sb.append("Соединение:\n");
        sb.append("  Группа сформирована: ").append(isConnected ? "✅" : "❌").append("\n");
        sb.append("  Владелец группы: ").append(isGroupOwner ? "✅" : "❌").append("\n");
        if (connectionInfo != null) {
            sb.append("  IP владельца: ").append(connectionInfo.groupOwnerAddress != null ? connectionInfo.groupOwnerAddress.getHostAddress() : "N/A").append("\n");
        }
        sb.append("Количество найденных пиров: ").append(peers.size()).append("\n");
        if (!peers.isEmpty()) {
            sb.append("Список пиров:\n");
            for (WifiP2pDevice p : peers) {
                sb.append("  - ").append(p.deviceName != null ? p.deviceName : "Без имени")
                        .append(" (").append(p.deviceAddress).append(") [")
                        .append(getDeviceStatus(p.status)).append("]\n");
            }
        }
        sb.append("═══════════════════════════════════");
        return sb.toString();
    }

    private String getDeviceStatus(int status) {
        switch (status) {
            case WifiP2pDevice.AVAILABLE: return "Доступно";
            case WifiP2pDevice.INVITED: return "Приглашено";
            case WifiP2pDevice.CONNECTED: return "Подключено";
            case WifiP2pDevice.FAILED: return "Ошибка";
            case WifiP2pDevice.UNAVAILABLE: return "Недоступно";
            default: return "Неизвестно";
        }
    }

    // ==================== ОСТАНОВКА И ОЧИСТКА ====================

    public void stop() {
        AppLogger.log(context, TAG, "stop() called");
        disconnect();
        stopServer();
        if (receiver != null && isReceiverRegistered) {
            try {
                context.unregisterReceiver(receiver);
                isReceiverRegistered = false;
                AppLogger.log(context, TAG, "Receiver unregistered");
            } catch (IllegalArgumentException e) {
                AppLogger.logException(context, TAG, "Unregister error", e);
            }
            receiver = null;
        }
    }

    public List<WifiP2pDevice> getPeers() {
        return peers;
    }

    public boolean isConnected() {
        return isConnected;
    }

    public boolean isGroupOwner() {
        return isGroupOwner;
    }

    public WifiP2pInfo getConnectionInfo() {
        return connectionInfo;
    }
}