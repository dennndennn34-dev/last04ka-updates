package com.last04ka.messenger.ui;

import android.app.Activity;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.media.AudioFormat;
import android.media.AudioManager;
import android.media.AudioTrack;
import android.os.Bundle;
import android.os.Handler;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import com.last04ka.messenger.utils.AppLogger;
import com.last04ka.messenger.utils.GameScores;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class RetroRacerActivity extends Activity {

    private GameView gameView;
    private TextView scoreText, bestText, speedText;
    private Button btnL1, btnL2, btnR1, btnR2, btnRestart;
    private Handler handler = new Handler();

    private int playerLane = 1;
    private int score = 0, best = 0, speed = 3;
    private boolean gameOver = false;
    private int frameCount = 0;
    private List<EnemyCar> cars = new ArrayList<>();
    private Random rand = new Random();
    private float scrollY = 0;
    private int spawnTimer = 0, spawnInterval = 55, maxCarsOnScreen = 4;
    private List<Spark> sparks = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        try {
            AppLogger.log(this, "RetroRacer", "onCreate v5 with animations");
            AppLogger.logTexture(this, "RetroRacer", "Road texture (3 lanes)", true);
            AppLogger.logTexture(this, "RetroRacer", "Car textures (player+enemy)", true);
            AppLogger.logTexture(this, "RetroRacer", "Spark particles", true);

            LinearLayout layout = new LinearLayout(this);
            layout.setOrientation(LinearLayout.VERTICAL);
            layout.setBackgroundColor(Color.BLACK);

            LinearLayout dash = new LinearLayout(this);
            dash.setOrientation(LinearLayout.HORIZONTAL);
            dash.setGravity(Gravity.CENTER);
            dash.setPadding(8, 6, 8, 6);
            dash.setBackgroundColor(0xFF1A1A1A);

            scoreText = new TextView(this);
            scoreText.setText("Счёт: 0"); scoreText.setTextSize(16);
            scoreText.setTextColor(0xFFFFD740); dash.addView(scoreText);
            bestText = new TextView(this);
            best = GameScores.getScore(this, "retroracer");
            bestText.setText("  Рекорд: " + best); bestText.setTextSize(14);
            bestText.setTextColor(0xFFFFFFFF); dash.addView(bestText);
            speedText = new TextView(this);
            speedText.setText("  ⚡" + speed); speedText.setTextSize(14);
            speedText.setTextColor(0xFF4FC3F7); dash.addView(speedText);
            layout.addView(dash);

            gameView = new GameView(this);
            LinearLayout.LayoutParams gp = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1);
            gameView.setLayoutParams(gp);
            layout.addView(gameView);

            LinearLayout controls = new LinearLayout(this);
            controls.setOrientation(LinearLayout.VERTICAL);
            controls.setPadding(4, 6, 4, 12);
            controls.setBackgroundColor(0xFF0D0D0D);

            LinearLayout btnRow = new LinearLayout(this);
            btnRow.setGravity(Gravity.CENTER);
            btnL2 = new Button(this); btnL2.setText("1"); btnL2.setTextSize(16);
            btnL2.setBackgroundColor(0xFF0D47A1); btnL2.setTextColor(Color.WHITE);
            btnL2.setWidth(100); btnL2.setHeight(80);
            btnL2.setOnClickListener(v -> { playerLane = 0; highlightButtons(); }); btnRow.addView(btnL2);
            btnL1 = new Button(this); btnL1.setText("2"); btnL1.setTextSize(16);
            btnL1.setBackgroundColor(0xFF1565C0); btnL1.setTextColor(Color.WHITE);
            btnL1.setWidth(100); btnL1.setHeight(80);
            btnL1.setOnClickListener(v -> { playerLane = 1; highlightButtons(); }); btnRow.addView(btnL1);
            btnR1 = new Button(this); btnR1.setText("3"); btnR1.setTextSize(16);
            btnR1.setBackgroundColor(0xFF1565C0); btnR1.setTextColor(Color.WHITE);
            btnR1.setWidth(100); btnR1.setHeight(80);
            btnR1.setOnClickListener(v -> { playerLane = 2; highlightButtons(); }); btnRow.addView(btnR1);
            btnR2 = new Button(this); btnR2.setText("4"); btnR2.setTextSize(16);
            btnR2.setBackgroundColor(0xFF0D47A1); btnR2.setTextColor(Color.WHITE);
            btnR2.setWidth(100); btnR2.setHeight(80);
            btnR2.setOnClickListener(v -> { playerLane = 3; highlightButtons(); }); btnRow.addView(btnR2);
            controls.addView(btnRow);

            btnRestart = new Button(this);
            btnRestart.setText("🔄 Новая игра"); btnRestart.setTextSize(13);
            btnRestart.setGravity(Gravity.CENTER);
            btnRestart.setOnClickListener(v -> restartGame());
            controls.addView(btnRestart);
            layout.addView(controls);

            setContentView(layout); setTitle("🏎️ Ретро-гонки");
            highlightButtons(); spawnInitialCars(); startGameLoop();
            AppLogger.log(this, "RetroRacer", "onCreate completed, best=" + best);
        } catch (Exception e) { AppLogger.logException(this, "RetroRacer", e); finish(); }
    }

    private void highlightButtons() {
        btnL2.setBackgroundColor(playerLane==0?0xFF4CAF50:0xFF0D47A1);
        btnL1.setBackgroundColor(playerLane==1?0xFF4CAF50:0xFF1565C0);
        btnR1.setBackgroundColor(playerLane==2?0xFF4CAF50:0xFF1565C0);
        btnR2.setBackgroundColor(playerLane==3?0xFF4CAF50:0xFF0D47A1);
    }

    private void spawnInitialCars() { cars.clear(); cars.add(new EnemyCar(0,-200)); cars.add(new EnemyCar(2,-500)); cars.add(new EnemyCar(3,-800)); spawnTimer=0; }

    private void restartGame() { score=0;speed=3;gameOver=false;playerLane=1;sparks.clear();highlightButtons();spawnInitialCars();updateUI();AppLogger.log(this,"RetroRacer","Game restarted"); }

    private void startGameLoop() { new Thread(()->{while(true){try{Thread.sleep(16);update();runOnUiThread(()->gameView.invalidate());}catch(InterruptedException e){break;}}}).start(); }

    private void update() {
        if(gameOver)return;frameCount++;float scrollSpeed=speed*5f;scrollY+=scrollSpeed;
        for(int i=cars.size()-1;i>=0;i--){EnemyCar c=cars.get(i);c.y+=scrollSpeed;if(c.y>getScreenHeight()+250){cars.remove(i);score+=10;updateUI();}}
        int onScreen=0;for(EnemyCar c:cars)if(c.y>-250&&c.y<getScreenHeight()+250)onScreen++;
        spawnTimer++;if(spawnTimer>=spawnInterval&&onScreen<maxCarsOnScreen){spawnTimer=0;List<Integer>free=new ArrayList<>();for(int l=0;l<4;l++){boolean occ=false;for(EnemyCar c:cars)if(c.lane==l&&c.y<0&&c.y>-500){occ=true;break;}if(!occ)free.add(l);}if(!free.isEmpty())cars.add(new EnemyCar(free.get(rand.nextInt(free.size())),-300-rand.nextFloat()*200));}
        for(EnemyCar c:cars)if(c.lane==playerLane&&c.y>getScreenHeight()-320&&c.y<getScreenHeight()-60){gameOver=true;crash();return;}
        for(int i=sparks.size()-1;i>=0;i--){Spark s=sparks.get(i);s.life-=15;s.alpha=Math.max(0,s.life);if(s.life<=0)sparks.remove(i);}
        if(frameCount%400==0&&speed<12){speed++;spawnInterval=Math.max(28,spawnInterval-3);updateUI();}
        updateUI();
    }

    private int getScreenHeight() { return gameView!=null?gameView.getHeight():800; }

    private void updateUI() { handler.post(()->{scoreText.setText("Счёт: "+score);if(score>best){best=score;GameScores.saveScore(RetroRacerActivity.this,"retroracer",best);}bestText.setText("  Рекорд: "+best);speedText.setText("  ⚡"+speed);}); }

    private void crash() { for(int i=0;i<30;i++)sparks.add(new Spark(getWidth()/2f,getScreenHeight()-100f));AppLogger.log(this,"RetroRacer","Crash! Score="+score);playCrashSound();handler.post(()->Toast.makeText(this,"💥 Авария! Счёт: "+score,Toast.LENGTH_LONG).show()); }

    private int getWidth(){return gameView!=null?gameView.getWidth():480;}

    private void playCrashSound(){try{int dur=200,s=8000*dur/1000;byte[]t=new byte[s];for(int i=0;i<s;i++)t[i]=(byte)(Math.sin(2*Math.PI*(200-i/2)*i/8000)*(s-i)/(float)s*100);AudioTrack tr=new AudioTrack(AudioManager.STREAM_MUSIC,8000,AudioFormat.CHANNEL_OUT_MONO,AudioFormat.ENCODING_PCM_8BIT,s,AudioTrack.MODE_STATIC);tr.write(t,0,s);tr.play();handler.postDelayed(()->{try{tr.release();}catch(Exception e){}},dur+10);}catch(Exception ex){}}

    class GameView extends View {
        private Paint paint = new Paint();
        private float[] cx;

        public GameView(Context ctx) { super(ctx); setFocusable(true); }

        @Override
        protected void onDraw(Canvas c) {
            super.onDraw(c);
            int w=getWidth(),h=getHeight();if(w==0||h==0)return;
            float laneW=w/4f;cx=new float[]{laneW*0.5f,laneW*1.5f,laneW*2.5f,laneW*3.5f};

            // Трава с градиентом (имитация)
            paint.setColor(0xFF1B5E20);c.drawRect(0,0,w,h,paint);
            paint.setColor(0xFF2E7D32);c.drawRect(0,h*0.3f,w,h*0.7f,paint);

            // Дорога
            paint.setColor(0xFF424242);c.drawRect(w*0.02f,0,w*0.98f,h,paint);
            paint.setColor(0xFF4A4A4A);c.drawRect(w*0.06f,0,w*0.94f,h,paint);

            // Края
            paint.setColor(0xFFFFFFFF);paint.setStrokeWidth(3);
            c.drawLine(w*0.02f,0,w*0.02f,h,paint);c.drawLine(w*0.98f,0,w*0.98f,h,paint);

            // Разметка
            paint.setColor(0xFFFFFFFF);paint.setStrokeWidth(3);float dashLen=40,gapLen=35;
            for(int line=1;line<=3;line++){float lx=line*laneW;float offset=(scrollY%(dashLen+gapLen));for(float y=-gapLen+offset;y<h+dashLen;y+=dashLen+gapLen)c.drawLine(lx,y,lx,y+dashLen,paint);}

            // Машины
            for(EnemyCar car:cars){if(car.y<-250||car.y>h+250)continue;float x=cx[car.lane];float cw=laneW*0.50f,ch=cw*1.55f;
                paint.setColor(0x44000000);c.drawRoundRect(x-cw/2+3,car.y-ch/2+3,x+cw/2+3,car.y+ch/2+3,8,8,paint);
                paint.setColor(car.color);c.drawRoundRect(x-cw/2,car.y-ch/2,x+cw/2,car.y+ch/2,8,8,paint);
                paint.setColor(0xFF81D4FA);c.drawRect(x-cw/3,car.y-ch/2+ch*0.12f,x+cw/3,car.y-ch/2+ch*0.38f,paint);
                paint.setColor(0xFFFFEB3B);c.drawCircle(x-cw/4,car.y-ch/2+ch*0.15f,3,paint);c.drawCircle(x+cw/4,car.y-ch/2+ch*0.15f,3,paint);
                paint.setColor(0xFFFF5252);c.drawCircle(x-cw/4,car.y+ch/2-ch*0.1f,2.5f,paint);c.drawCircle(x+cw/4,car.y+ch/2-ch*0.1f,2.5f,paint);
            }

            // Игрок с тенью и свечением
            float px=cx[playerLane],py=h-100,pw=laneW*0.55f,ph=pw*1.65f;
            paint.setColor(0x44000000);c.drawRoundRect(px-pw/2+4,py-ph/2+4,px+pw/2+4,py+ph/2+4,10,10,paint);
            paint.setColor(0xFF1976D2);c.drawRoundRect(px-pw/2,py-ph/2,px+pw/2,py+ph/2,10,10,paint);
            paint.setColor(0xFF2196F3);c.drawRoundRect(px-pw/4,py-ph/2+ph*0.05f,px+pw/4,py-ph/2+ph*0.4f,7,7,paint);
            paint.setColor(0xFF81D4FA);c.drawRect(px-pw/3+2,py-ph/2+ph*0.07f,px+pw/3-2,py-ph/2+ph*0.28f,paint);
            paint.setColor(0xFFFFEB3B);c.drawCircle(px-pw/3,py-ph/2+ph*0.12f,5,paint);c.drawCircle(px+pw/3,py-ph/2+ph*0.12f,5,paint);
            // Свечение фар
            paint.setColor(0x44FFEB3B);c.drawCircle(px-pw/3,py-ph/2+ph*0.12f,8,paint);c.drawCircle(px+pw/3,py-ph/2+ph*0.12f,8,paint);
            paint.setColor(0xFFFF5252);c.drawCircle(px-pw/3,py+ph/2-ph*0.1f,4,paint);c.drawCircle(px+pw/3,py+ph/2-ph*0.1f,4,paint);

            // Искры
            for(Spark s:sparks){paint.setColor(0xFFFF9800);paint.setAlpha(s.alpha);c.drawCircle(s.x,s.y,s.size,paint);paint.setColor(0xFFFF5722);paint.setAlpha(s.alpha/2);c.drawCircle(s.x+s.vx*2,s.y+s.vy*2,s.size/2,paint);}
            paint.setAlpha(255);

            if(gameOver){
                paint.setColor(0xCC000000);c.drawRect(0,0,w,h,paint);
                paint.setColor(0x33FF0000);c.drawRect(0,0,w,h,paint);
                Random sr=new Random(score*100L);
                paint.setColor(0xFFFF9800);
                for(int i=0;i<25;i++)c.drawCircle(sr.nextFloat()*w,sr.nextFloat()*h,sr.nextFloat()*6+1,paint);
                paint.setColor(Color.WHITE);paint.setTextSize(46);paint.setTextAlign(Paint.Align.CENTER);
                paint.setShadowLayer(4,2,2,Color.BLACK);c.drawText("АВАРИЯ!",w/2,h/2-20,paint);
                paint.setTextSize(22);c.drawText("Счёт: "+score+"  |  Рекорд: "+best,w/2,h/2+25,paint);
                c.drawText("Нажмите НОВАЯ ИГРА",w/2,h/2+55,paint);
                paint.setShadowLayer(0,0,0,0);paint.setTextAlign(Paint.Align.LEFT);
            }
        }
    }

    static class EnemyCar { int lane; float y; int color;
        private static final int[] C={0xFFE53935,0xFFFF9800,0xFF4CAF50,0xFF9C27B0,0xFF00BCD4,0xFFFFEB3B};
        private static Random r=new Random();EnemyCar(int l,float y){this.lane=l;this.y=y;this.color=C[r.nextInt(C.length)];} }
    static class Spark { float x,y,vx,vy,size; int life=180,alpha=255;
        private static Random r=new Random();Spark(float x,float y){this.x=x;this.y=y;this.vx=(r.nextFloat()-0.5f)*8f;this.vy=(r.nextFloat()-0.5f)*8f-3f;this.size=r.nextFloat()*6+2;} }

    @Override protected void onDestroy() { super.onDestroy(); handler.removeCallbacksAndMessages(null); }
}