package com.last04ka.messenger.ui;

import android.Manifest;
import android.app.Activity;
import android.content.pm.PackageManager;
import android.media.MediaPlayer;
import android.media.MediaRecorder;
import android.os.Bundle;
import android.os.Environment;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import com.last04ka.messenger.utils.AppLogger;
import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class VoiceMemoActivity extends Activity {

    private static final int REQUEST_AUDIO = 300;
    private MediaRecorder recorder;
    private MediaPlayer player;
    private boolean isRecording = false;
    private boolean isPlaying = false;
    private String currentFile;
    private Button btnRecord, btnPlay, btnStop, btnDelete;
    private LinearLayout memosList;
    private List<File> memoFiles = new ArrayList<>();
    private File memoDir;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        try {
            AppLogger.log(this, "VoiceMemo", "onCreate started");

            memoDir = new File(getFilesDir(), "memos");
            if (!memoDir.exists()) memoDir.mkdirs();

            LinearLayout mainLayout = new LinearLayout(this);
            mainLayout.setOrientation(LinearLayout.VERTICAL);
            mainLayout.setPadding(16, 16, 16, 16);
            mainLayout.setBackgroundColor(0xFF1A1A2E);

            TextView title = new TextView(this);
            title.setText("🎙️ Диктофон");
            title.setTextSize(22);
            title.setTextColor(0xFFFFFFFF);
            title.setGravity(Gravity.CENTER);
            mainLayout.addView(title);

            LinearLayout btnRow = new LinearLayout(this);
            btnRow.setOrientation(LinearLayout.HORIZONTAL);
            btnRow.setGravity(Gravity.CENTER);

            btnRecord = new Button(this);
            btnRecord.setText("🔴 Запись");
            btnRecord.setOnClickListener(v -> startRecording());
            btnRow.addView(btnRecord);

            btnPlay = new Button(this);
            btnPlay.setText("▶ Воспр.");
            btnPlay.setEnabled(false);
            btnPlay.setOnClickListener(v -> startPlayback());
            btnRow.addView(btnPlay);

            btnStop = new Button(this);
            btnStop.setText("⏹ Стоп");
            btnStop.setEnabled(false);
            btnStop.setOnClickListener(v -> stopAll());
            btnRow.addView(btnStop);

            btnDelete = new Button(this);
            btnDelete.setText("🗑 Удалить");
            btnDelete.setEnabled(false);
            btnDelete.setOnClickListener(v -> deleteMemo());
            btnRow.addView(btnDelete);

            mainLayout.addView(btnRow);

            memosList = new LinearLayout(this);
            memosList.setOrientation(LinearLayout.VERTICAL);
            ScrollView scrollView = new ScrollView(this);
            scrollView.addView(memosList);
            LinearLayout.LayoutParams scrollParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 1);
            scrollView.setLayoutParams(scrollParams);
            mainLayout.addView(scrollView);

            setContentView(mainLayout);
            setTitle("🎙️ Диктофон");
            loadMemos();
            checkPermissions();
            AppLogger.log(this, "VoiceMemo", "onCreate completed");
        } catch (Exception e) { AppLogger.logException(this, "VoiceMemo", e); finish(); }
    }

    private void checkPermissions() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.RECORD_AUDIO}, REQUEST_AUDIO);
        }
    }

    private void startRecording() {
        if (isRecording) return;
        stopPlayback();
        String fileName = "memo_" + new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(new Date()) + ".3gp";
        currentFile = new File(memoDir, fileName).getAbsolutePath();

        recorder = new MediaRecorder();
        recorder.setAudioSource(MediaRecorder.AudioSource.MIC);
        recorder.setOutputFormat(MediaRecorder.OutputFormat.THREE_GPP);
        recorder.setAudioEncoder(MediaRecorder.AudioEncoder.AMR_NB);
        recorder.setOutputFile(currentFile);

        try {
            recorder.prepare();
            recorder.start();
            isRecording = true;
            btnRecord.setEnabled(false);
            btnStop.setEnabled(true);
            btnPlay.setEnabled(false);
            btnDelete.setEnabled(false);
            Toast.makeText(this, "Запись начата", Toast.LENGTH_SHORT).show();
            AppLogger.log(this, "VoiceMemo", "Recording started: " + currentFile);
        } catch (IOException e) {
            Toast.makeText(this, "Ошибка записи", Toast.LENGTH_SHORT).show();
            AppLogger.logException(this, "VoiceMemo", e);
        }
    }

    private void stopAll() {
        if (isRecording) {
            try { recorder.stop(); recorder.release(); } catch (Exception e) {}
            recorder = null;
            isRecording = false;
            loadMemos();
            Toast.makeText(this, "Запись сохранена", Toast.LENGTH_SHORT).show();
            AppLogger.log(this, "VoiceMemo", "Recording stopped");
        }
        if (isPlaying) {
            stopPlayback();
        }
        btnRecord.setEnabled(true);
        btnStop.setEnabled(false);
        updateButtons();
    }

    private void startPlayback() {
        if (isPlaying) return;
        try {
            player = new MediaPlayer();
            player.setDataSource(currentFile);
            player.prepare();
            player.setOnCompletionListener(mp -> {
                isPlaying = false;
                updateButtons();
            });
            player.start();
            isPlaying = true;
            btnPlay.setEnabled(false);
            btnStop.setEnabled(true);
            btnRecord.setEnabled(false);
            AppLogger.log(this, "VoiceMemo", "Playback started: " + currentFile);
        } catch (IOException e) {
            Toast.makeText(this, "Ошибка воспроизведения", Toast.LENGTH_SHORT).show();
            AppLogger.logException(this, "VoiceMemo", e);
        }
    }

    private void stopPlayback() {
        if (player != null) {
            try { if (player.isPlaying()) player.stop(); player.release(); } catch (Exception e) {}
            player = null;
        }
        isPlaying = false;
    }

    private void deleteMemo() {
        if (currentFile != null) {
            File file = new File(currentFile);
            if (file.exists()) file.delete();
            currentFile = null;
            loadMemos();
            updateButtons();
            Toast.makeText(this, "Запись удалена", Toast.LENGTH_SHORT).show();
            AppLogger.log(this, "VoiceMemo", "Memo deleted");
        }
    }

    private void loadMemos() {
        memosList.removeAllViews();
        memoFiles.clear();
        File[] files = memoDir.listFiles();
        if (files != null) {
            for (File f : files) {
                if (f.getName().endsWith(".3gp")) {
                    memoFiles.add(f);
                    TextView tv = new TextView(this);
                    tv.setText(f.getName().replace("memo_", "").replace(".3gp", ""));
                    tv.setTextSize(14);
                    tv.setTextColor(0xFFFFFFFF);
                    tv.setPadding(12, 8, 12, 8);
                    tv.setBackgroundColor(0xFF333333);
                    LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
                    params.setMargins(0, 0, 0, 4);
                    tv.setLayoutParams(params);
                    final File file = f;
                    tv.setOnClickListener(v -> {
                        stopAll();
                        currentFile = file.getAbsolutePath();
                        btnPlay.setEnabled(true);
                        btnDelete.setEnabled(true);
                    });
                    memosList.addView(tv);
                }
            }
        }
        updateButtons();
    }

    private void updateButtons() {
        if (currentFile == null) {
            btnPlay.setEnabled(false);
            btnDelete.setEnabled(false);
        } else if (!isRecording && !isPlaying) {
            btnPlay.setEnabled(true);
            btnDelete.setEnabled(true);
        }
        btnRecord.setEnabled(!isRecording && !isPlaying);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        stopAll();
    }
}