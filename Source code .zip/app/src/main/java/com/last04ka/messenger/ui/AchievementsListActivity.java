package com.last04ka.messenger.ui;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.last04ka.messenger.R;
import com.last04ka.messenger.utils.AchievementManager;
import com.last04ka.messenger.utils.AppLogger;
import com.last04ka.messenger.utils.ThemeManager;

import java.util.List;

public class AchievementsListActivity extends AppCompatActivity {
    private static final String TAG = "AchievementsList";
    private RecyclerView recyclerView;
    private AchievementAdapter adapter;
    private TextView tvProgress;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        setTheme(ThemeManager.getThemeResource(this));
        super.onCreate(savedInstanceState);
        AppLogger.log(this, TAG, "========== onCreate START ==========");

        try {
            setContentView(R.layout.activity_achievements_list);
            setTitle("🏅 Все достижения");

            recyclerView = findViewById(R.id.recycler_achievements);
            tvProgress = findViewById(R.id.tv_achievement_progress);

            recyclerView.setLayoutManager(new LinearLayoutManager(this));

            List<String[]> achievements = AchievementManager.getUnlocked(this);
            int unlocked = 0;
            for (String[] a : achievements) {
                if (a[2].equals("true")) unlocked++;
            }
            tvProgress.setText("🏆 Получено: " + unlocked + " / 50");

            adapter = new AchievementAdapter(achievements);
            recyclerView.setAdapter(adapter);

            AppLogger.log(this, TAG, "Achievements loaded: " + achievements.size() + ", unlocked: " + unlocked);
            AppLogger.log(this, TAG, "========== onCreate SUCCESS ==========");
        } catch (Exception e) {
            AppLogger.logException(this, TAG, "onCreate error", e);
            finish();
        }
    }

    private class AchievementAdapter extends RecyclerView.Adapter<AchievementAdapter.ViewHolder> {
        private List<String[]> achievements;

        AchievementAdapter(List<String[]> achievements) {
            this.achievements = achievements;
        }

        @Override
        public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            View view = LayoutInflater.from(parent.getContext())
                    .inflate(R.layout.item_achievement, parent, false);
            return new ViewHolder(view);
        }

        @Override
        public void onBindViewHolder(ViewHolder holder, int position) {
            String[] ach = achievements.get(position);
            String name = ach[0];
            String description = ach[1];
            boolean unlocked = ach[2].equals("true");
            String id = ach[3];

            holder.tvName.setText(name);
            holder.tvDescription.setText(description);
            holder.tvStatus.setText(unlocked ? "✅ Получено" : "🔒 Заблокировано");
            holder.tvStatus.setTextColor(unlocked ? 0xFF4CAF50 : 0xFFFF5252);

            // Можно добавить иконку или прогресс, но пока просто статус
            AppLogger.log(AchievementsListActivity.this, TAG, "Bind: " + name + " -> " + (unlocked ? "unlocked" : "locked"));
        }

        @Override
        public int getItemCount() {
            return achievements.size();
        }

        class ViewHolder extends RecyclerView.ViewHolder {
            TextView tvName, tvDescription, tvStatus;

            ViewHolder(View itemView) {
                super(itemView);
                tvName = itemView.findViewById(R.id.tv_ach_name);
                tvDescription = itemView.findViewById(R.id.tv_ach_description);
                tvStatus = itemView.findViewById(R.id.tv_ach_status);
            }
        }
    }
}