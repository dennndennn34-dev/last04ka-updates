package com.last04ka.messenger.game;

import android.graphics.RectF;

import java.util.ArrayList;
import java.util.List;

public class Level {
    public List<RectF> platforms = new ArrayList<>();
    public List<RectF> enemies = new ArrayList<>();          // позиция врага (x, y, width, height)
    public List<Float> enemyMoveLeft = new ArrayList<>();   // левая граница движения
    public List<Float> enemyMoveRight = new ArrayList<>();  // правая граница движения
    public List<RectF> stars = new ArrayList<>();
    public List<RectF> checkpoints = new ArrayList<>();
    public RectF finish;
    public List<RectF> water = new ArrayList<>();
    public float playerStartX, playerStartY;  // стартовая позиция шарика

    public Level(float startX, float startY) {
        this.playerStartX = startX;
        this.playerStartY = startY;
    }
}