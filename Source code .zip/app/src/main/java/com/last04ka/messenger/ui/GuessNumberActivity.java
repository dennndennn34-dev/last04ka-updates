package com.last04ka.messenger.ui;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import com.last04ka.messenger.utils.AppLogger;
import java.util.Random;

public class GuessNumberActivity extends Activity {

    private TextView hintText, attemptsText;
    private EditText inputNumber;
    private Button btnGuess, btnNew;
    private int secretNumber, attempts;
    private Random random = new Random();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        try {
            LinearLayout layout = new LinearLayout(this);
            layout.setOrientation(LinearLayout.VERTICAL);
            layout.setPadding(32,32,32,32);
            layout.setBackgroundColor(0xFF303030);

            TextView title = new TextView(this);
            title.setText("🎯 Угадай число от 1 до 100");
            title.setTextSize(20); title.setTextColor(0xFFFFFFFF); layout.addView(title);

            hintText = new TextView(this);
            hintText.setText("Я загадал число. Попробуй угадать!");
            hintText.setTextSize(16); hintText.setTextColor(0xFFFFFFFF);
            hintText.setPadding(0,16,0,16); layout.addView(hintText);

            attemptsText = new TextView(this);
            attemptsText.setText("Попыток: 0"); attemptsText.setTextSize(14);
            attemptsText.setTextColor(0xFFBDBDBD); layout.addView(attemptsText);

            inputNumber = new EditText(this);
            inputNumber.setHint("Введите число"); inputNumber.setInputType(android.text.InputType.TYPE_CLASS_NUMBER);
            inputNumber.setTextColor(0xFFFFFFFF); inputNumber.setHintTextColor(0xFF9E9E9E); layout.addView(inputNumber);

            btnGuess = new Button(this); btnGuess.setText("Проверить"); layout.addView(btnGuess);
            btnNew = new Button(this); btnNew.setText("Новая игра"); layout.addView(btnNew);

            setContentView(layout);
            setTitle("🎯 Угадай число");
            newGame();

            btnGuess.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    String s = inputNumber.getText().toString();
                    if (s.isEmpty()) return;
                    int guess = Integer.parseInt(s);
                    attempts++;
                    attemptsText.setText("Попыток: " + attempts);
                    if (guess == secretNumber) {
                        hintText.setText("🎉 Правильно! Это число " + secretNumber + "!");
                        hintText.setTextColor(0xFF00FF00);
                        inputNumber.setEnabled(false); btnGuess.setEnabled(false);
                    } else if (guess < secretNumber) hintText.setText("📈 Больше!");
                    else hintText.setText("📉 Меньше!");
                }
            });
            btnNew.setOnClickListener(new View.OnClickListener() { @Override public void onClick(View v) { newGame(); } });
        } catch (Exception e) { AppLogger.logException(this, "GuessNumber", e); finish(); }
    }

    private void newGame() {
        secretNumber = random.nextInt(100)+1; attempts = 0;
        hintText.setText("Я загадал число. Попробуй угадать!");
        hintText.setTextColor(0xFFFFFFFF); attemptsText.setText("Попыток: 0");
        inputNumber.setText(""); inputNumber.setEnabled(true); btnGuess.setEnabled(true);
    }
}