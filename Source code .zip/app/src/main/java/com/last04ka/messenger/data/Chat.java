package com.last04ka.messenger.data;

public class Chat {
    private String id;
    private String name;
    private int type;
    private String address;
    private String deviceAddress;
    private String lastMessage;
    private long lastTime;
    private long timestamp;
    private boolean isFavorite;
    private String avatar;
    private int unreadCount;
    private String theme = "default"; // НОВОЕ ПОЛЕ

    public Chat() {}

    public String getId() { return id; }
    public void setId(String id) { this.id = id; }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public int getType() { return type; }
    public void setType(int type) { this.type = type; }

    public String getAddress() { return address; }
    public void setAddress(String address) { this.address = address; }

    public String getDeviceAddress() { return deviceAddress; }
    public void setDeviceAddress(String deviceAddress) { this.deviceAddress = deviceAddress; }

    public String getLastMessage() { return lastMessage; }
    public void setLastMessage(String lastMessage) { this.lastMessage = lastMessage; }

    public long getLastTime() { return lastTime; }
    public void setLastTime(long lastTime) { this.lastTime = lastTime; }

    public long getTimestamp() { return timestamp; }
    public void setTimestamp(long timestamp) { this.timestamp = timestamp; }

    public boolean isFavorite() { return isFavorite; }
    public void setFavorite(boolean favorite) { isFavorite = favorite; }

    public String getAvatar() { return avatar; }
    public void setAvatar(String avatar) { this.avatar = avatar; }

    public int getUnreadCount() { return unreadCount; }
    public void setUnreadCount(int unreadCount) { this.unreadCount = unreadCount; }

    // ==================== НОВЫЕ МЕТОДЫ ДЛЯ ТЕМЫ ====================
    public String getTheme() { return theme; }
    public void setTheme(String theme) { this.theme = theme != null ? theme : "default"; }
}