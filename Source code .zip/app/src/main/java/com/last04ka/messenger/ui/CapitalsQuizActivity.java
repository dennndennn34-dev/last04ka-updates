package com.last04ka.messenger.ui;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Random;

public class CapitalsQuizActivity extends Activity {

    private TextView questionText, scoreText;
    private Button[] btns = new Button[4];
    private int current = 0, score = 0, total = 20;
    private List<String[]> pool = new ArrayList<>(), selected = new ArrayList<>();
    private Random r = new Random();

    private String[][] data = {
        {"Россия","Москва"},{"США","Вашингтон"},{"Германия","Берлин"},{"Франция","Париж"},
        {"Япония","Токио"},{"Китай","Пекин"},{"Великобритания","Лондон"},{"Италия","Рим"},
        {"Испания","Мадрид"},{"Бразилия","Бразилиа"},{"Канада","Оттава"},{"Австралия","Канберра"},
        {"Индия","Нью-Дели"},{"Мексика","Мехико"},{"Южная Корея","Сеул"},{"Турция","Анкара"},
        {"Аргентина","Буэнос-Айрес"},{"ЮАР","Претория"},{"Египет","Каир"},{"Нигерия","Абуджа"},
        {"Кения","Найроби"},{"Марокко","Рабат"},{"Швеция","Стокгольм"},{"Норвегия","Осло"},
        {"Дания","Копенгаген"},{"Финляндия","Хельсинки"},{"Польша","Варшава"},{"Украина","Киев"},
        {"Чехия","Прага"},{"Нидерланды","Амстердам"},{"Бельгия","Брюссель"},{"Швейцария","Берн"},
        {"Австрия","Вена"},{"Греция","Афины"},{"Португалия","Лиссабон"},{"Ирландия","Дублин"},
        {"Таиланд","Бангкок"},{"Вьетнам","Ханой"},{"Индонезия","Джакарта"},{"Филиппины","Манила"},
        {"Малайзия","Куала-Лумпур"},{"Сингапур","Сингапур"},{"Новая Зеландия","Веллингтон"},
        {"Чили","Сантьяго"},{"Колумбия","Богота"},{"Перу","Лима"},{"Куба","Гавана"},
        {"Израиль","Иерусалим"},{"ОАЭ","Абу-Даби"},{"Иран","Тегеран"},
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL); layout.setPadding(24,24,24,24); layout.setBackgroundColor(0xFF252525);

        scoreText = new TextView(this); scoreText.setText("Счёт: 0 / "+total);
        scoreText.setTextSize(16); scoreText.setTextColor(0xFFFFFFFF); layout.addView(scoreText);

        questionText = new TextView(this); questionText.setTextSize(22); questionText.setTextColor(0xFFFFFFFF);
        questionText.setGravity(android.view.Gravity.CENTER); questionText.setPadding(0,24,0,24); layout.addView(questionText);

        for (int i=0;i<4;i++){ final int idx=i; btns[i]=new Button(this); btns[i].setTextSize(16); btns[i].setAllCaps(false);
            btns[i].setPadding(12,16,12,16); btns[i].setOnClickListener(v->checkAnswer(idx)); layout.addView(btns[i]); }

        pool.addAll(Arrays.asList(data)); Collections.shuffle(pool,r);
        for(int i=0;i<Math.min(total,pool.size());i++) selected.add(pool.get(i));
        setContentView(layout); setTitle("🌍 Столицы мира"); showQuestion();
    }

    private void showQuestion(){
        if(current>=selected.size()){ questionText.setText("🏆 Итог: "+score+" / "+total); for(Button b:btns)b.setVisibility(View.GONE); return; }
        questionText.setText("Столица: "+selected.get(current)[0]+"?");
        List<String> opts=new ArrayList<>(); opts.add(selected.get(current)[1]);
        while(opts.size()<4){ String[] rd=data[r.nextInt(data.length)]; if(!opts.contains(rd[1])) opts.add(rd[1]); }
        Collections.shuffle(opts,r); for(int i=0;i<4;i++) btns[i].setText(opts.get(i));
    }

    private void checkAnswer(int idx){
        if(btns[idx].getText().toString().equals(selected.get(current)[1])){ score++; Toast.makeText(this,"✅",Toast.LENGTH_SHORT).show(); }
        else Toast.makeText(this,"❌ "+selected.get(current)[1],Toast.LENGTH_SHORT).show();
        scoreText.setText("Счёт: "+score+" / "+total); current++; showQuestion();
    }
}