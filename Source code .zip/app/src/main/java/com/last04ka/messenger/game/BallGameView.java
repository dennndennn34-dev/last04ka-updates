package com.last04ka.messenger.game;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.os.Handler;
import android.os.Looper;
import android.os.Vibrator;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;

import com.last04ka.messenger.R;
import com.last04ka.messenger.ui.BallGameActivity;
import com.last04ka.messenger.utils.AppLogger;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class BallGameView extends View {
    private static final String TAG = "BallGameView";

    // Размеры уровня (базовые, будут масштабироваться под экран)
    private float levelWidth = 1200f;
    private float levelHeight = 800f;

    // Параметры шарика
    private float ballX, ballY;
    private float ballRadius = 28f;
    private float ballSpeedX = 0f, ballSpeedY = 0f;
    private float gravity = 0.5f;
    private float friction = 0.98f;
    private float maxSpeed = 10f;
    private float jumpForce = -14f;

    // Управление
    private boolean leftPressed = false;
    private boolean rightPressed = false;
    private boolean jumpPressed = false;
    private boolean jumpAvailable = false;
    private float moveForce = 0.8f;

    // Состояние игры
    private int lives = 3;
    private int starsCollected = 0;
    private int totalStars = 0;
    private boolean levelComplete = false;
    private boolean gameOver = false;
    private boolean isPaused = false;

    // Чекпоинты
    private float checkpointX = -1, checkpointY = -1;
    private boolean checkpointActive = false;

    // Данные уровня
    private Level currentLevel;
    private int levelNumber;

    // Игровые объекты
    private List<Enemy> enemies = new ArrayList<>();
    private List<RectF> platforms = new ArrayList<>();
    private List<RectF> stars = new ArrayList<>();
    private List<RectF> water = new ArrayList<>();
    private List<RectF> checkpoints = new ArrayList<>();
    private RectF finishLine;

    private float rotationAngle = 0f;
    private Handler handler = new Handler(Looper.getMainLooper());

    // Paint
    private Paint paint = new Paint();
    private Paint textPaint = new Paint();
    private Paint waterPaint = new Paint();

    private Bitmap skyBitmap, cloudBitmap;
    private Vibrator vibrator;

    private OnLevelCompleteListener levelCompleteListener;

    public interface OnLevelCompleteListener {
        void onLevelComplete(int level, int stars);
    }

    public BallGameView(Context context) {
        super(context);
        init();
    }

    public BallGameView(Context context, AttributeSet attrs) {
        super(context, attrs);
        init();
    }

    private void init() {
        paint.setAntiAlias(true);
        paint.setStyle(Paint.Style.FILL);
        textPaint.setAntiAlias(true);
        textPaint.setColor(Color.BLACK);
        textPaint.setShadowLayer(4, 2, 2, Color.WHITE);
        textPaint.setTextSize(30);

        waterPaint.setColor(0x8800BFFF);
        waterPaint.setStyle(Paint.Style.FILL_AND_STROKE);
        waterPaint.setStrokeWidth(2);

        skyBitmap = BitmapFactory.decodeResource(getResources(), R.drawable.ic_launcher);
        cloudBitmap = BitmapFactory.decodeResource(getResources(), R.drawable.ic_launcher);

        vibrator = (Vibrator) getContext().getSystemService(Context.VIBRATOR_SERVICE);

        setFocusable(true);
        setFocusableInTouchMode(true);
    }

    public void setLevel(int levelNumber) {
        this.levelNumber = levelNumber;
        loadLevel(levelNumber);
    }

    private void loadLevel(int levelNumber) {
        currentLevel = LevelData.getLevel(levelNumber);

        platforms.clear();
        platforms.addAll(currentLevel.platforms);
        stars.clear();
        stars.addAll(currentLevel.stars);
        water.clear();
        water.addAll(currentLevel.water);
        checkpoints.clear();
        checkpoints.addAll(currentLevel.checkpoints);
        finishLine = currentLevel.finish;

        enemies.clear();
        for (int i = 0; i < currentLevel.enemies.size(); i++) {
            RectF rect = currentLevel.enemies.get(i);
            float leftBound = currentLevel.enemyMoveLeft.get(i);
            float rightBound = currentLevel.enemyMoveRight.get(i);
            float speed = 1.0f + (levelNumber * 0.05f);
            enemies.add(new Enemy(rect, leftBound, rightBound, speed));
        }

        ballX = currentLevel.playerStartX;
        ballY = currentLevel.playerStartY;
        ballSpeedX = 0f;
        ballSpeedY = 0f;
        rotationAngle = 0f;
        lives = 3;
        starsCollected = 0;
        totalStars = stars.size();
        levelComplete = false;
        gameOver = false;
        checkpointActive = false;
        checkpointX = -1;
        checkpointY = -1;
        jumpAvailable = false;

        leftPressed = false;
        rightPressed = false;
        jumpPressed = false;

        recalcLevelDimensions();
        invalidate();
    }

    private void recalcLevelDimensions() {
        int viewWidth = getWidth();
        int viewHeight = getHeight();
        if (viewWidth == 0 || viewHeight == 0) {
            levelWidth = 1200f;
            levelHeight = 800f;
            return;
        }
        levelWidth = viewWidth;
        levelHeight = viewHeight;
    }

    @Override
    protected void onSizeChanged(int w, int h, int oldw, int oldh) {
        super.onSizeChanged(w, h, oldw, oldh);
        recalcLevelDimensions();
        if (currentLevel != null) {
            if (ballY > levelHeight + 100) {
                if (checkpointActive) {
                    ballX = checkpointX + 10;
                    ballY = checkpointY - ballRadius;
                } else {
                    ballX = currentLevel.playerStartX;
                    ballY = currentLevel.playerStartY;
                }
                ballSpeedX = 0;
                ballSpeedY = 0;
            }
            invalidate();
        }
    }

    public void resume() {
        isPaused = false;
    }

    public void pause() {
        isPaused = true;
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        if (currentLevel == null) return;

        int viewWidth = getWidth();
        int viewHeight = getHeight();

        canvas.save();
        canvas.scale(viewWidth / levelWidth, viewHeight / levelHeight);

        // ---- Рисуем игровой мир ----
        paint.setColor(0xFF87CEEB);
        canvas.drawRect(0, 0, levelWidth, levelHeight, paint);

        paint.setColor(0x88FFFFFF);
        for (int i = 0; i < 5; i++) {
            float x = (i * 220 + (System.currentTimeMillis() / 5000) % 300) % levelWidth;
            float y = 50 + i * 40;
            canvas.drawCircle(x, y, 30, paint);
            canvas.drawCircle(x + 40, y - 10, 25, paint);
            canvas.drawCircle(x - 30, y + 5, 20, paint);
        }

        for (RectF waterRect : water) {
            paint.setColor(0x8800BFFF);
            canvas.drawRect(waterRect, paint);
            paint.setColor(0x44FFFFFF);
            canvas.drawRect(waterRect.left + 4, waterRect.top + 2, waterRect.right - 4, waterRect.top + 8, paint);
        }

        paint.setColor(0xFF4CAF50);
        for (RectF p : platforms) {
            canvas.drawRect(p, paint);
            paint.setColor(0xFF388E3C);
            canvas.drawRect(p.left + 2, p.top, p.right - 2, p.top + 4, paint);
            paint.setColor(0xFF4CAF50);
        }

        for (RectF cp : checkpoints) {
            paint.setColor(0xFFFFD740);
            canvas.drawRect(cp.left, cp.top, cp.left + 4, cp.bottom, paint);
            paint.setColor(0xFFFF5252);
            canvas.drawRect(cp.left + 4, cp.top, cp.left + 20, cp.top + 14, paint);
            if (checkpointActive && checkpointX == cp.left && checkpointY == cp.top) {
                paint.setColor(0xCCFFFF00);
                paint.setStyle(Paint.Style.STROKE);
                paint.setStrokeWidth(2);
                canvas.drawRect(cp.left - 4, cp.top - 4, cp.left + 24, cp.bottom + 4, paint);
                paint.setStyle(Paint.Style.FILL);
            }
        }

        for (RectF s : stars) {
            paint.setColor(0x44FFD740);
            canvas.drawCircle(s.centerX(), s.centerY(), 22, paint);
            paint.setColor(0xFFFFD740);
            canvas.drawCircle(s.centerX(), s.centerY(), 14, paint);
            paint.setColor(0xFFFFFF);
            canvas.drawCircle(s.centerX() - 4, s.centerY() - 4, 4, paint);
        }

        for (Enemy e : enemies) {
            paint.setColor(0xFF222222);
            canvas.drawRect(e.rect, paint);
            paint.setColor(0xFF444444);
            canvas.drawRect(e.rect.left + 2, e.rect.top + 2, e.rect.right - 2, e.rect.bottom - 2, paint);
            paint.setColor(0xFFFF0000);
            canvas.drawCircle(e.rect.left + e.rect.width() * 0.3f, e.rect.top + e.rect.height() * 0.35f, 5, paint);
            canvas.drawCircle(e.rect.left + e.rect.width() * 0.7f, e.rect.top + e.rect.height() * 0.35f, 5, paint);
        }

        if (finishLine != null) {
            paint.setColor(0x88FFFFFF);
            int steps = 8;
            float step = finishLine.width() / steps;
            for (int i = 0; i < steps; i++) {
                paint.setColor(i % 2 == 0 ? 0xFFFFFFFF : 0xFF000000);
                canvas.drawRect(finishLine.left + i * step, finishLine.top, finishLine.left + (i + 1) * step, finishLine.bottom, paint);
            }
        }

        drawBall(canvas);
        canvas.restore();

        drawUI(canvas, viewWidth, viewHeight);
        drawControls(canvas, viewWidth, viewHeight);

        if (levelComplete) {
            paint.setColor(0xCC000000);
            canvas.drawRect(0, 0, viewWidth, viewHeight, paint);
            paint.setColor(Color.WHITE);
            paint.setTextSize(60);
            paint.setTextAlign(Paint.Align.CENTER);
            canvas.drawText("УРОВЕНЬ ПРОЙДЕН!", viewWidth / 2, viewHeight / 2 - 40, paint);
            paint.setTextSize(30);
            canvas.drawText("Звёзд: " + starsCollected + "/" + totalStars, viewWidth / 2, viewHeight / 2 + 30, paint);
            paint.setTextAlign(Paint.Align.LEFT);
        } else if (gameOver) {
            paint.setColor(0xCC000000);
            canvas.drawRect(0, 0, viewWidth, viewHeight, paint);
            paint.setColor(Color.RED);
            paint.setTextSize(60);
            paint.setTextAlign(Paint.Align.CENTER);
            canvas.drawText("ПОРАЖЕНИЕ", viewWidth / 2, viewHeight / 2 - 40, paint);
            paint.setTextSize(30);
            canvas.drawText("Жизни кончились", viewWidth / 2, viewHeight / 2 + 30, paint);
            paint.setTextAlign(Paint.Align.LEFT);
        }
    }

    private void drawBall(Canvas canvas) {
        paint.setColor(0x33AAAAAA);
        canvas.drawCircle(ballX + 6, ballY + 8, ballRadius, paint);

        paint.setColor(0xFFFF1744);
        canvas.drawCircle(ballX, ballY, ballRadius, paint);
        paint.setColor(0x88FFFFFF);
        canvas.drawCircle(ballX - 6, ballY - 8, 8, paint);
        paint.setColor(Color.WHITE);
        canvas.drawCircle(ballX - 9, ballY - 6, 8, paint);
        canvas.drawCircle(ballX + 9, ballY - 6, 8, paint);
        paint.setColor(Color.BLACK);
        canvas.drawCircle(ballX - 7 + ballSpeedX * 0.5f, ballY - 4, 4, paint);
        canvas.drawCircle(ballX + 11 + ballSpeedX * 0.5f, ballY - 4, 4, paint);

        float eyeDir = (ballSpeedX > 0.1f) ? 2 : (ballSpeedX < -0.1f) ? -2 : 0;
        canvas.drawCircle(ballX - 7 + eyeDir, ballY - 4, 2, paint);
        canvas.drawCircle(ballX + 11 + eyeDir, ballY - 4, 2, paint);

        paint.setColor(Color.BLACK);
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(3);
        canvas.drawArc(ballX - 8, ballY + 2, ballX + 8, ballY + 14, 0, 180, false, paint);
        paint.setStyle(Paint.Style.FILL);
    }

    private void drawUI(Canvas canvas, int screenW, int screenH) {
        textPaint.setTextSize(30);
        textPaint.setColor(Color.BLACK);
        textPaint.setShadowLayer(4, 2, 2, Color.WHITE);
        canvas.drawText("❤️ x" + lives, 20, 40, textPaint);
        canvas.drawText("⭐ " + starsCollected + "/" + totalStars, 180, 40, textPaint);
    }

    private void drawControls(Canvas canvas, int screenW, int screenH) {
        int leftHalf = screenW / 2;
        int btnSize = 140;
        int bottomMargin = 40;
        int y = screenH - btnSize - bottomMargin;

        int leftX = 20;
        int rightMoveX = leftHalf - btnSize - 20;
        int jumpX = leftHalf + (screenW - leftHalf - btnSize) / 2;

        Paint bgPaint = new Paint();
        bgPaint.setColor(0x88000000);
        bgPaint.setStyle(Paint.Style.FILL);
        bgPaint.setAntiAlias(true);

        Paint iconPaint = new Paint();
        iconPaint.setColor(0xFFFFFFFF);
        iconPaint.setTextSize(90);
        iconPaint.setTextAlign(Paint.Align.CENTER);
        iconPaint.setAntiAlias(true);
        iconPaint.setShadowLayer(12, 3, 3, Color.BLACK);

        canvas.drawCircle(leftX + btnSize/2, y + btnSize/2, btnSize/2, bgPaint);
        canvas.drawText("◄", leftX + btnSize/2, y + btnSize/2 + 32, iconPaint);

        canvas.drawCircle(rightMoveX + btnSize/2, y + btnSize/2, btnSize/2, bgPaint);
        canvas.drawText("►", rightMoveX + btnSize/2, y + btnSize/2 + 32, iconPaint);

        canvas.drawCircle(jumpX + btnSize/2, y + btnSize/2, btnSize/2, bgPaint);
        canvas.drawText("▲", jumpX + btnSize/2, y + btnSize/2 + 40, iconPaint);
    }

    // ==================== ОБНОВЛЕНИЕ (С ИСПРАВЛЕННЫМИ ВРАГАМИ) ====================

    public void update() {
        if (isPaused || levelComplete || gameOver) return;

        float force = 0f;
        if (leftPressed) force -= moveForce;
        if (rightPressed) force += moveForce;
        ballSpeedX += force;
        if (Math.abs(ballSpeedX) > maxSpeed) ballSpeedX = Math.signum(ballSpeedX) * maxSpeed;
        ballSpeedX *= friction;

        ballSpeedY += gravity;
        if (jumpPressed && jumpAvailable) {
            ballSpeedY = jumpForce;
            jumpAvailable = false;
        }

        ballX += ballSpeedX;
        ballY += ballSpeedY;

        // Платформы
        for (RectF p : platforms) {
            if (ballX + ballRadius > p.left && ballX - ballRadius < p.right &&
                ballY + ballRadius > p.top && ballY - ballRadius < p.bottom) {
                float overlapLeft = (ballX + ballRadius) - p.left;
                float overlapRight = p.right - (ballX - ballRadius);
                float overlapTop = (ballY + ballRadius) - p.top;
                float overlapBottom = p.bottom - (ballY - ballRadius);

                float minOverlap = Math.min(Math.min(overlapLeft, overlapRight), Math.min(overlapTop, overlapBottom));
                if (minOverlap == overlapLeft) {
                    ballX = p.left - ballRadius;
                    ballSpeedX = -ballSpeedX * 0.3f;
                } else if (minOverlap == overlapRight) {
                    ballX = p.right + ballRadius;
                    ballSpeedX = -ballSpeedX * 0.3f;
                } else if (minOverlap == overlapTop) {
                    ballY = p.top - ballRadius;
                    ballSpeedY = 0;
                    jumpAvailable = true;
                } else if (minOverlap == overlapBottom) {
                    ballY = p.bottom + ballRadius;
                    ballSpeedY = 0;
                }
            }
        }

        // Вода
        for (RectF waterRect : water) {
            if (ballX + ballRadius > waterRect.left && ballX - ballRadius < waterRect.right &&
                ballY + ballRadius > waterRect.top && ballY - ballRadius < waterRect.bottom) {
                ballSpeedY *= 0.9f;
                ballSpeedX *= 0.98f;
                if (ballY + ballRadius < waterRect.bottom - 5) {
                    ballY += 0.5f;
                }
                jumpAvailable = false;
            }
        }

        // Сбор звёзд
        Iterator<RectF> starIt = stars.iterator();
        while (starIt.hasNext()) {
            RectF s = starIt.next();
            if (ballX + ballRadius > s.left && ballX - ballRadius < s.right &&
                ballY + ballRadius > s.top && ballY - ballRadius < s.bottom) {
                starIt.remove();
                starsCollected++;
                AppLogger.log(getContext(), TAG, "Star collected: " + starsCollected);
            }
        }

        // Чекпоинты
        for (RectF cp : checkpoints) {
            if (ballX + ballRadius > cp.left && ballX - ballRadius < cp.right &&
                ballY + ballRadius > cp.top && ballY - ballRadius < cp.bottom) {
                if (!checkpointActive || checkpointX != cp.left || checkpointY != cp.top) {
                    checkpointActive = true;
                    checkpointX = cp.left;
                    checkpointY = cp.top;
                    AppLogger.log(getContext(), TAG, "Checkpoint activated at (" + checkpointX + "," + checkpointY + ")");
                }
            }
        }

        // ==================== ВРАГИ (ИСПРАВЛЕННАЯ ЛОГИКА) ====================
        for (Enemy e : enemies) {
            e.update();

            // Проверяем столкновение шарика с врагом
            if (ballX + ballRadius > e.rect.left && ballX - ballRadius < e.rect.right &&
                ballY + ballRadius > e.rect.top && ballY - ballRadius < e.rect.bottom) {
                
                // Определяем, с какой стороны произошло столкновение
                float overlapTop = (ballY + ballRadius) - e.rect.top;
                float overlapBottom = e.rect.bottom - (ballY - ballRadius);
                float overlapLeft = (ballX + ballRadius) - e.rect.left;
                float overlapRight = e.rect.right - (ballX - ballRadius);
                
                // Находим минимальное перекрытие (сторона, с которой вошли)
                float minOverlap = Math.min(Math.min(overlapTop, overlapBottom), 
                                            Math.min(overlapLeft, overlapRight));
                
                // Если вошли сверху И скорость падения положительная (или почти ноль)
                if (minOverlap == overlapTop && ballSpeedY > 0.5f) {
                    // Убиваем врага
                    e.alive = false;
                    ballSpeedY = -6f; // отскок
                    AppLogger.log(getContext(), TAG, "Enemy killed!");
                    if (vibrator != null && vibrator.hasVibrator()) {
                        vibrator.vibrate(50);
                    }
                } else {
                    // В любом другом случае — теряем жизнь
                    loseLife();
                    break; // выходим из цикла, чтобы не обрабатывать других врагов
                }
            }
        }

        // Падение в пропасть
        if (ballY > levelHeight + 100) {
            AppLogger.log(getContext(), TAG, "Ball fell off the bottom");
            loseLife();
        }

        // Финиш
        if (finishLine != null && ballX + ballRadius > finishLine.left && ballX - ballRadius < finishLine.right &&
            ballY + ballRadius > finishLine.top && ballY - ballRadius < finishLine.bottom) {
            levelComplete = true;
            AppLogger.log(getContext(), TAG, "Level complete! Stars: " + starsCollected);
            LevelManager.setStarsForLevel(getContext(), levelNumber, starsCollected);
            int unlocked = LevelManager.getUnlockedLevel(getContext());
            if (levelNumber >= unlocked) {
                LevelManager.setUnlockedLevel(getContext(), levelNumber + 1);
            }
            if (levelCompleteListener != null) {
                levelCompleteListener.onLevelComplete(levelNumber, starsCollected);
            }
        }

        rotationAngle += ballSpeedX * 0.5f;
    }

    private void loseLife() {
        lives--;
        AppLogger.log(getContext(), TAG, "Lose life, remaining: " + lives);
        if (vibrator != null && vibrator.hasVibrator()) {
            vibrator.vibrate(200);
        }
        if (lives <= 0) {
            gameOver = true;
            AppLogger.log(getContext(), TAG, "Game over!");
        } else {
            if (checkpointActive) {
                ballX = checkpointX + 10;
                ballY = checkpointY - ballRadius;
            } else {
                ballX = currentLevel.playerStartX;
                ballY = currentLevel.playerStartY;
            }
            ballSpeedX = 0;
            ballSpeedY = 0;
        }
        invalidate();
    }

    // ==================== ОБРАБОТКА КАСАНИЙ ====================

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        if (levelComplete || gameOver) {
            if (event.getAction() == MotionEvent.ACTION_DOWN) {
                if (levelComplete) {
                    ((BallGameActivity) getContext()).finish();
                } else if (gameOver) {
                    loadLevel(levelNumber);
                }
                return true;
            }
            return super.onTouchEvent(event);
        }

        float x = event.getX();
        int w = getWidth();

        switch (event.getAction()) {
            case MotionEvent.ACTION_DOWN:
            case MotionEvent.ACTION_MOVE:
                if (x < w / 4f) {
                    leftPressed = true;
                    rightPressed = false;
                    jumpPressed = false;
                } else if (x < w / 2f) {
                    rightPressed = true;
                    leftPressed = false;
                    jumpPressed = false;
                } else {
                    jumpPressed = true;
                    leftPressed = false;
                    rightPressed = false;
                }
                break;
            case MotionEvent.ACTION_UP:
                leftPressed = false;
                rightPressed = false;
                jumpPressed = false;
                break;
        }
        return true;
    }

    // ==================== ВСПОМОГАТЕЛЬНЫЙ КЛАСС ====================

    private static class Enemy {
        RectF rect;
        float leftBound, rightBound;
        float speed;
        boolean alive = true;
        float direction = 1f;

        Enemy(RectF rect, float leftBound, float rightBound, float speed) {
            this.rect = new RectF(rect);
            this.leftBound = leftBound;
            this.rightBound = rightBound;
            this.speed = speed;
        }

        void update() {
            if (!alive) return;
            rect.offset(speed * direction, 0);
            if (rect.left < leftBound) {
                rect.left = leftBound;
                rect.right = leftBound + rect.width();
                direction = 1f;
            } else if (rect.right > rightBound) {
                rect.right = rightBound;
                rect.left = rightBound - rect.width();
                direction = -1f;
            }
        }
    }

    // ==================== СЕТТЕРЫ И ЖИЗНЕННЫЙ ЦИКЛ ====================

    public void setOnLevelCompleteListener(OnLevelCompleteListener listener) {
        this.levelCompleteListener = listener;
    }

    private Runnable updateRunnable = new Runnable() {
        @Override
        public void run() {
            if (!isPaused) {
                update();
                postInvalidate();
            }
            handler.postDelayed(this, 16);
        }
    };

    @Override
    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        handler.post(updateRunnable);
    }

    @Override
    protected void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        handler.removeCallbacks(updateRunnable);
    }
}