package com.last04ka.messenger.connectivity;

import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothServerSocket;
import android.bluetooth.BluetoothSocket;
import android.content.Context;
import android.os.Handler;
import com.last04ka.messenger.utils.AppLogger;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.lang.reflect.Method;
import java.util.Collections;
import java.util.List;
import java.util.ArrayList;
import java.util.UUID;

public class BluetoothManager {
    private static final String TAG = "BluetoothManager";
    private static final String APP_NAME = "Last04ka";
    private static final UUID MY_UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");
    private static final int BUFFER_SIZE = 32768;

    private final Context context;
    private final BluetoothAdapter bluetoothAdapter;
    private AcceptThread acceptThread;
    private ConnectThread connectThread;
    private ConnectedThread connectedThread;
    private final Handler handler;
    private int state;

    public static final int STATE_NONE = 0;
    public static final int STATE_LISTEN = 1;
    public static final int STATE_CONNECTING = 2;
    public static final int STATE_CONNECTED = 3;

    // === НОВЫЕ ПОЛЯ ДЛЯ ОЧЕРЕДИ И РЕКОННЕКТА ===
    private List<String> pendingMessages = Collections.synchronizedList(new ArrayList<>());
    private boolean reconnecting = false;
    private int reconnectAttempts = 0;
    private static final int MAX_RECONNECT_ATTEMPTS = 3;
    private BluetoothDevice lastDevice;

    public interface MessageCallback {
        void onMessageReceived(String message);
        void onConnectionStateChanged(int state);
        void onDeviceDisconnected();
    }
    private MessageCallback callback;

    public BluetoothManager(Context context, Handler handler) {
        this.context = context;
        this.handler = handler;
        this.bluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
        this.state = STATE_NONE;
        AppLogger.log(context, TAG, "BluetoothManager created. Adapter: " + (bluetoothAdapter != null ? "OK" : "NULL"));
    }

    public void setCallback(MessageCallback callback) {
        this.callback = callback;
        AppLogger.log(context, TAG, "Callback set");
    }

    public synchronized int getState() {
        return state;
    }

    public synchronized void start() {
        AppLogger.log(context, TAG, "start() called");
        if (connectThread != null) {
            connectThread.cancel();
            connectThread = null;
        }
        if (connectedThread != null) {
            connectedThread.cancel();
            connectedThread = null;
        }
        if (acceptThread == null) {
            acceptThread = new AcceptThread();
            acceptThread.start();
            AppLogger.log(context, TAG, "AcceptThread started");
        }
        setState(STATE_LISTEN);
    }

    public synchronized void connect(BluetoothDevice device) {
        this.lastDevice = device;
        AppLogger.log(context, TAG, "connect() called to device: " + (device.getName() != null ? device.getName() : "Unknown"));
        if (state == STATE_CONNECTING) {
            if (connectThread != null) {
                connectThread.cancel();
                connectThread = null;
            }
        }
        if (connectedThread != null) {
            connectedThread.cancel();
            connectedThread = null;
        }
        connectThread = new ConnectThread(device);
        connectThread.start();
        setState(STATE_CONNECTING);
    }

    public synchronized void connected(BluetoothSocket socket, BluetoothDevice device) {
        AppLogger.log(context, TAG, "connected() called. Device: " + (device.getName() != null ? device.getName() : "Unknown"));
        if (connectThread != null) {
            connectThread.cancel();
            connectThread = null;
        }
        if (connectedThread != null) {
            connectedThread.cancel();
            connectedThread = null;
        }
        connectedThread = new ConnectedThread(socket);
        connectedThread.start();
        setState(STATE_CONNECTED);
        AppLogger.log(context, TAG, "ConnectedThread started");

        // === ОТПРАВКА ОТЛОЖЕННЫХ СООБЩЕНИЙ ===
        if (!pendingMessages.isEmpty()) {
            for (String msg : pendingMessages) {
                connectedThread.write(msg.getBytes());
            }
            int count = pendingMessages.size();
            pendingMessages.clear();
            AppLogger.log(context, TAG, "📦 " + count + " queued messages sent");
        }
        reconnectAttempts = 0;
    }

    public synchronized void stop() {
        AppLogger.log(context, TAG, "stop() called");
        if (connectThread != null) {
            connectThread.cancel();
            connectThread = null;
        }
        if (connectedThread != null) {
            connectedThread.cancel();
            connectedThread = null;
        }
        if (acceptThread != null) {
            acceptThread.cancel();
            acceptThread = null;
        }
        pendingMessages.clear();
        reconnecting = false;
        setState(STATE_NONE);
    }

    public void write(byte[] out) {
        ConnectedThread r;
        synchronized (this) {
            if (state != STATE_CONNECTED) {
                AppLogger.log(context, TAG, "write() ignored: not connected (state=" + state + ")");
                return;
            }
            r = connectedThread;
        }
        if (r != null) {
            r.write(out);
        } else {
            AppLogger.log(context, TAG, "write() ignored: connectedThread is null");
        }
    }

    public void write(String message) {
        if (message == null) return;
        if (state == STATE_CONNECTED && connectedThread != null) {
            connectedThread.write(message.getBytes());
            AppLogger.log(context, TAG, "write(String): " + (message.length() > 50 ? message.substring(0, 50) + "..." : message));
        } else {
            pendingMessages.add(message);
            AppLogger.log(context, TAG, "📦 Message queued (offline), size=" + pendingMessages.size());
        }
    }

    private synchronized void setState(int state) {
        this.state = state;
        AppLogger.log(context, TAG, "setState: " + state);
        if (callback != null) {
            handler.post(() -> callback.onConnectionStateChanged(state));
        }
    }

    // ==================== ACCEPT THREAD ====================
    private class AcceptThread extends Thread {
        private final BluetoothServerSocket serverSocket;
        private static final String ACCEPT_TAG = "AcceptThread";

        public AcceptThread() {
            BluetoothServerSocket tmp = null;
            try {
                tmp = bluetoothAdapter.listenUsingInsecureRfcommWithServiceRecord(APP_NAME, MY_UUID);
                AppLogger.log(context, ACCEPT_TAG, "Server socket created (insecure)");
            } catch (IOException e) {
                AppLogger.logException(context, ACCEPT_TAG + " insecure", e);
                try {
                    tmp = bluetoothAdapter.listenUsingRfcommWithServiceRecord(APP_NAME, MY_UUID);
                    AppLogger.log(context, ACCEPT_TAG, "Server socket created (secure)");
                } catch (IOException e2) {
                    AppLogger.logException(context, ACCEPT_TAG + " secure", e2);
                }
            }
            serverSocket = tmp;
        }

        public void run() {
            if (serverSocket == null) {
                AppLogger.log(context, ACCEPT_TAG, "Server socket is null, exiting");
                return;
            }
            AppLogger.log(context, ACCEPT_TAG, "AcceptThread running");
            while (state != STATE_CONNECTED) {
                try {
                    BluetoothSocket socket = serverSocket.accept();
                    if (socket != null) {
                        AppLogger.log(context, ACCEPT_TAG, "Socket accepted: " + socket.getRemoteDevice().getAddress());
                        synchronized (BluetoothManager.this) {
                            switch (state) {
                                case STATE_LISTEN:
                                case STATE_CONNECTING:
                                    connected(socket, socket.getRemoteDevice());
                                    break;
                                default:
                                    try {
                                        socket.close();
                                        AppLogger.log(context, ACCEPT_TAG, "Socket closed (wrong state)");
                                    } catch (IOException e) {
                                        AppLogger.logException(context, ACCEPT_TAG, e);
                                    }
                                    break;
                            }
                        }
                    }
                } catch (IOException e) {
                    AppLogger.logException(context, ACCEPT_TAG, e);
                    break;
                }
            }
            AppLogger.log(context, ACCEPT_TAG, "AcceptThread finished");
        }

        public void cancel() {
            try {
                if (serverSocket != null) {
                    serverSocket.close();
                    AppLogger.log(context, ACCEPT_TAG, "Server socket closed");
                }
            } catch (IOException e) {
                AppLogger.logException(context, ACCEPT_TAG, e);
            }
        }
    }

    // ==================== CONNECT THREAD ====================
    private class ConnectThread extends Thread {
        private final BluetoothDevice device;
        private static final String CONNECT_TAG = "ConnectThread";

        public ConnectThread(BluetoothDevice device) {
            this.device = device;
            AppLogger.log(context, CONNECT_TAG, "ConnectThread created for: " + device.getAddress());
        }

        public void run() {
            AppLogger.log(context, CONNECT_TAG, "ConnectThread running");
            if (bluetoothAdapter != null && bluetoothAdapter.isDiscovering()) {
                bluetoothAdapter.cancelDiscovery();
                AppLogger.log(context, CONNECT_TAG, "Discovery cancelled");
            }

            BluetoothSocket socket = null;
            for (int attempt = 0; attempt < 3; attempt++) {
                try {
                    if (attempt > 0) {
                        try {
                            Thread.sleep(1000);
                        } catch (InterruptedException e) {
                            AppLogger.log(context, CONNECT_TAG, "Sleep interrupted: " + e.getMessage());
                            Thread.currentThread().interrupt();
                            break;
                        }
                    }
                    socket = device.createInsecureRfcommSocketToServiceRecord(MY_UUID);
                    socket.connect();
                    AppLogger.log(context, CONNECT_TAG, "Connected via insecure RFCOMM on attempt " + (attempt + 1));
                    connected(socket, device);
                    return;
                } catch (IOException e) {
                    AppLogger.log(context, CONNECT_TAG, "Insecure attempt " + (attempt + 1) + " failed: " + e.getMessage());
                    if (socket != null) {
                        try { socket.close(); } catch (IOException ex) { }
                        socket = null;
                    }
                }
            }

            try {
                Method m = device.getClass().getMethod("createRfcommSocket", int.class);
                socket = (BluetoothSocket) m.invoke(device, 1);
                socket.connect();
                AppLogger.log(context, CONNECT_TAG, "Connected via createRfcommSocket (channel 1)");
                connected(socket, device);
                return;
            } catch (Exception e) {
                AppLogger.log(context, CONNECT_TAG, "createRfcommSocket failed: " + e.getMessage());
                if (socket != null) {
                    try { socket.close(); } catch (IOException ex) { }
                    socket = null;
                }
            }

            try {
                socket = device.createRfcommSocketToServiceRecord(MY_UUID);
                socket.connect();
                AppLogger.log(context, CONNECT_TAG, "Connected via secure RFCOMM");
                connected(socket, device);
                return;
            } catch (IOException e) {
                AppLogger.log(context, CONNECT_TAG, "Secure RFCOMM failed: " + e.getMessage());
                if (socket != null) {
                    try { socket.close(); } catch (IOException ex) { }
                }
            }

            AppLogger.log(context, CONNECT_TAG, "All connection attempts failed");
            connectionFailed();
        }

        public void cancel() {
            AppLogger.log(context, CONNECT_TAG, "cancel() called");
        }

        private void connectionFailed() {
            setState(STATE_LISTEN);
            if (callback != null) {
                handler.post(() -> {
                    callback.onConnectionStateChanged(STATE_LISTEN);
                    callback.onDeviceDisconnected();
                });
            }
            AppLogger.log(context, CONNECT_TAG, "connectionFailed() - state set to LISTEN");
        }
    }

    // ==================== CONNECTED THREAD ====================
    private class ConnectedThread extends Thread {
        private final BluetoothSocket socket;
        private final InputStream inputStream;
        private final OutputStream outputStream;
        private StringBuilder frameBuffer = new StringBuilder();
        private static final String CONNECTED_TAG = "ConnectedThread";

        public ConnectedThread(BluetoothSocket socket) {
            this.socket = socket;
            InputStream ti = null;
            OutputStream to = null;
            try {
                ti = socket.getInputStream();
                to = socket.getOutputStream();
                AppLogger.log(context, CONNECTED_TAG, "Streams obtained successfully");
            } catch (IOException e) {
                AppLogger.logException(context, CONNECTED_TAG, e);
            }
            inputStream = ti;
            outputStream = to;
        }

        public void run() {
            byte[] buffer = new byte[BUFFER_SIZE];
            int bytes;
            AppLogger.log(context, CONNECTED_TAG, "ConnectedThread running");
            while (true) {
                try {
                    if (inputStream == null) {
                        AppLogger.log(context, CONNECTED_TAG, "InputStream is null, breaking");
                        break;
                    }
                    bytes = inputStream.read(buffer);
                    if (bytes > 0) {
                        String chunk = new String(buffer, 0, bytes);
                        frameBuffer.append(chunk);
                        AppLogger.log(context, CONNECTED_TAG, "Received " + bytes + " bytes, buffer now " + frameBuffer.length() + " chars");

                        int idx;
                        while ((idx = frameBuffer.indexOf("\n")) != -1) {
                            String msg = frameBuffer.substring(0, idx);
                            frameBuffer.delete(0, idx + 1);
                            if (!msg.isEmpty()) {
                                handler.post(() -> {
                                    if (callback != null) {
                                        callback.onMessageReceived(msg);
                                        AppLogger.log(context, CONNECTED_TAG, "Message delivered: " + (msg.length() > 50 ? msg.substring(0, 50) + "..." : msg));
                                    }
                                });
                            }
                        }
                    }
                } catch (IOException e) {
                    AppLogger.logException(context, CONNECTED_TAG, e);
                    connectionLost();
                    break;
                }
            }
            AppLogger.log(context, CONNECTED_TAG, "ConnectedThread finished");
        }

        public void write(byte[] b) {
            try {
                if (outputStream != null) {
                    int offset = 0;
                    while (offset < b.length) {
                        int len = Math.min(4096, b.length - offset);
                        outputStream.write(b, offset, len);
                        offset += len;
                    }
                    outputStream.flush();
                    AppLogger.log(context, CONNECTED_TAG, "Written " + b.length + " bytes");
                } else {
                    AppLogger.log(context, CONNECTED_TAG, "write() failed: outputStream is null");
                }
            } catch (IOException e) {
                AppLogger.logException(context, CONNECTED_TAG, e);
            }
        }

        public void cancel() {
            try {
                socket.close();
                AppLogger.log(context, CONNECTED_TAG, "Socket closed");
            } catch (IOException e) {
                AppLogger.logException(context, CONNECTED_TAG, e);
            }
        }

        // ==================== РЕКОННЕКТ С ПОВТОРАМИ ====================
        private void connectionLost() {
            setState(STATE_LISTEN);
            if (callback != null) {
                handler.post(() -> {
                    callback.onDeviceDisconnected();
                    callback.onConnectionStateChanged(STATE_LISTEN);
                });
            }
            AppLogger.log(context, CONNECTED_TAG, "connectionLost() - state set to LISTEN");

            // Запускаем реконнект
            if (!reconnecting && lastDevice != null) {
                reconnecting = true;
                reconnectAttempts = 0;
                attemptReconnect();
            }
        }
    }

    // ==================== МЕТОД РЕКОННЕКТА С ПОВТОРАМИ ====================
    private void attemptReconnect() {
        if (reconnectAttempts >= MAX_RECONNECT_ATTEMPTS) {
            reconnecting = false;
            AppLogger.log(context, TAG, "❌ Reconnect failed after " + MAX_RECONNECT_ATTEMPTS + " attempts");
            return;
        }
        reconnectAttempts++;
        int delay = 3000 * reconnectAttempts;
        AppLogger.log(context, TAG, "🔄 Reconnect attempt " + reconnectAttempts + " in " + delay + "ms");
        handler.postDelayed(() -> {
            if (state == STATE_LISTEN && bluetoothAdapter != null && bluetoothAdapter.isEnabled() && lastDevice != null) {
                connect(lastDevice);
                // Если не удалось подключиться, connect вызовет connectionFailed,
                // который снова вызовет attemptReconnect
            } else {
                // Если состояние не LISTEN или Bluetooth выключен, пробуем позже
                attemptReconnect();
            }
        }, delay);
    }
}