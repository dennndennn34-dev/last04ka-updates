package com.last04ka.messenger.ui;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;

import com.last04ka.messenger.R;
import com.last04ka.messenger.utils.AchievementManager;
import com.last04ka.messenger.utils.AppLogger;
import com.last04ka.messenger.utils.GameScores;
import com.last04ka.messenger.utils.ThemeManager;

import java.util.List;

public class PlayerProfileActivity extends AppCompatActivity {
    private static final String TAG = "PlayerProfile";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        setTheme(ThemeManager.getThemeResource(this));
        super.onCreate(savedInstanceState);
        AppLogger.log(this, TAG, "========== onCreate START ==========");

        try {
            LinearLayout mainLayout = new LinearLayout(this);
            mainLayout.setOrientation(LinearLayout.VERTICAL);
            mainLayout.setPadding(24, 24, 24, 24);
            mainLayout.setBackgroundColor(ThemeManager.getBackgroundColor(this));

            // Заголовок
            TextView title = new TextView(this);
            title.setText("👤 Профиль игрока");
            title.setTextSize(22);
            title.setTextColor(ThemeManager.getTextColor(this));
            title.setGravity(Gravity.CENTER);
            title.setPadding(0, 0, 0, 24);
            mainLayout.addView(title);

            // Статистика
            int totalScore = GameScores.getTotalScore(this);
            int gamesCount = GameScores.getGamesCount(this);
            int achievementsCount = AchievementManager.getUnlockedCount(this);
            int level = totalScore / 1000 + 1;
            int nextLevel = level * 1000;
            int progress = totalScore % 1000;

            AppLogger.log(this, TAG, "Stats: totalScore=" + totalScore + ", gamesCount=" + gamesCount +
                    ", achievements=" + achievementsCount + ", level=" + level);

            addStatRow(mainLayout, "⭐ Общий счёт", String.valueOf(totalScore));
            addStatRow(mainLayout, "🎮 Игр сыграно", gamesCount + " / 20+");
            addStatRow(mainLayout, "🏆 Достижений", achievementsCount + " / 50");
            addStatRow(mainLayout, "📊 Уровень", level + " (до " + nextLevel + " очков)");

            // Прогресс-бар
            TextView progressLabel = new TextView(this);
            progressLabel.setText("Прогресс до следующего уровня:");
            progressLabel.setTextSize(14);
            progressLabel.setTextColor(ThemeManager.getTextSecondaryColor(this));
            progressLabel.setPadding(0, 16, 0, 4);
            mainLayout.addView(progressLabel);

            ProgressBar progressBar = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
            progressBar.setMax(1000);
            progressBar.setProgress(progress);
            progressBar.setProgressTintList(android.content.res.ColorStateList.valueOf(0xFF4CAF50));

            // ИСПРАВЛЕННАЯ СТРОКА 74: высота преобразована в int
            int progressBarHeight = (int) android.util.TypedValue.applyDimension(
                android.util.TypedValue.COMPLEX_UNIT_DIP, 8, getResources().getDisplayMetrics()
            );
            LinearLayout.LayoutParams pbParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                progressBarHeight
            );
            progressBar.setLayoutParams(pbParams);
            mainLayout.addView(progressBar);

            TextView progressText = new TextView(this);
            progressText.setText(progress + " / 1000");
            progressText.setTextSize(12);
            progressText.setTextColor(ThemeManager.getTextSecondaryColor(this));
            progressText.setGravity(Gravity.END);
            progressText.setPadding(0, 2, 0, 8);
            mainLayout.addView(progressText);

            // Кнопка "Все достижения"
            Button btnAllAchievements = new Button(this);
            btnAllAchievements.setText("🏅 Все достижения");
            btnAllAchievements.setTextSize(16);
            btnAllAchievements.setTextColor(ThemeManager.getTextColor(this));
            btnAllAchievements.setBackgroundColor(ThemeManager.getCardColor(this));
            btnAllAchievements.setPadding(16, 12, 16, 12);
            btnAllAchievements.setOnClickListener(v -> {
                AppLogger.log(PlayerProfileActivity.this, TAG, "All achievements button clicked");
                startActivity(new Intent(PlayerProfileActivity.this, AchievementsListActivity.class));
            });
            LinearLayout.LayoutParams btnParams = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
            );
            btnParams.setMargins(0, 16, 0, 16);
            btnAllAchievements.setLayoutParams(btnParams);
            mainLayout.addView(btnAllAchievements);

            // Последние достижения (полученные)
            TextView achTitle = new TextView(this);
            achTitle.setText("🏆 Последние достижения:");
            achTitle.setTextSize(16);
            achTitle.setTextColor(ThemeManager.getTextColor(this));
            achTitle.setPadding(0, 8, 0, 8);
            mainLayout.addView(achTitle);

            List<String[]> allAchievements = AchievementManager.getUnlocked(this);
            int shown = 0;
            for (String[] ach : allAchievements) {
                if (ach[2].equals("true") && shown < 10) {
                    TextView tv = new TextView(this);
                    tv.setText("✅ " + ach[0] + " — " + ach[1]);
                    tv.setTextColor(0xFF4CAF50);
                    tv.setTextSize(13);
                    tv.setPadding(0, 4, 0, 0);
                    mainLayout.addView(tv);
                    shown++;
                    AppLogger.log(this, TAG, "Achievement shown: " + ach[0]);
                }
            }
            if (shown == 0) {
                TextView empty = new TextView(this);
                empty.setText("Пока нет достижений. Играйте в мини-игры!");
                empty.setTextColor(ThemeManager.getTextSecondaryColor(this));
                empty.setTextSize(13);
                empty.setPadding(0, 4, 0, 0);
                mainLayout.addView(empty);
            }

            ScrollView scrollView = new ScrollView(this);
            scrollView.addView(mainLayout);
            setContentView(scrollView);
            setTitle("👤 Профиль игрока");

            AppLogger.log(this, TAG, "========== onCreate SUCCESS ==========");
        } catch (Exception e) {
            AppLogger.logException(this, TAG, "onCreate error", e);
            finish();
        }
    }

    private void addStatRow(LinearLayout parent, String label, String value) {
        TextView tv = new TextView(this);
        tv.setText(label + ": " + value);
        tv.setTextSize(16);
        tv.setTextColor(ThemeManager.getTextColor(this));
        tv.setPadding(0, 4, 0, 4);
        parent.addView(tv);
        AppLogger.log(this, TAG, "Added stat: " + label + " = " + value);
    }
}