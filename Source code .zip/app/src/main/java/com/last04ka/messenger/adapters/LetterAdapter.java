package com.last04ka.messenger.adapters;

import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.last04ka.messenger.R;
import com.last04ka.messenger.utils.LanguageData;

import java.util.List;

public class LetterAdapter extends RecyclerView.Adapter<LetterAdapter.ViewHolder> {

    private List<LanguageData.Letter> letters;
    private OnLetterClickListener listener;

    public interface OnLetterClickListener {
        void onLetterClick(int position);
        void onLetterLongClick(int position);
    }

    public LetterAdapter(List<LanguageData.Letter> letters, OnLetterClickListener listener) {
        this.letters = letters;
        this.listener = listener;
    }

    public void updateData(List<LanguageData.Letter> newLetters) {
        this.letters = newLetters;
        notifyDataSetChanged();
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_letter, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {
        LanguageData.Letter letter = letters.get(position);
        holder.tvLetter.setText(letter.getLetter());
        holder.tvPronunciation.setText(letter.getPronunciation());

        holder.itemView.setOnClickListener(v -> {
            if (listener != null) {
                listener.onLetterClick(position);
            }
        });

        holder.itemView.setOnLongClickListener(v -> {
            if (listener != null) {
                listener.onLetterLongClick(position);
                return true;
            }
            return false;
        });
    }

    @Override
    public int getItemCount() {
        return letters != null ? letters.size() : 0;
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        TextView tvLetter, tvPronunciation;

        public ViewHolder(View itemView) {
            super(itemView);
            tvLetter = itemView.findViewById(R.id.tv_letter);
            tvPronunciation = itemView.findViewById(R.id.tv_pronunciation);
        }
    }
}