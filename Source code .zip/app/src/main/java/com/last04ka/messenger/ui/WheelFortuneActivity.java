package com.last04ka.messenger.ui;

import android.app.Activity;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import com.last04ka.messenger.utils.AppLogger;
import java.util.Random;

public class WheelFortuneActivity extends Activity {

    private WheelView wheelView;
    private TextView resultText;
    private EditText inputSectors;
    private Button btnSpin, btnUpdate;
    private String[] sectors = {"100","200","300","Пропуск","500","1000","0","Бонус"};
    private int[] colors = {Color.RED, Color.BLUE, Color.GREEN, Color.YELLOW, Color.MAGENTA, Color.CYAN, Color.rgb(255,100,0), Color.rgb(100,255,100)};
    private float spinAngle = 0;
    private Handler handler = new Handler();
    private Random random = new Random();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        try {
            AppLogger.log(this, "WheelFortune", "onCreate started");
            LinearLayout layout = new LinearLayout(this);
            layout.setOrientation(LinearLayout.VERTICAL);
            layout.setPadding(16, 16, 16, 16);
            layout.setBackgroundColor(0xFF1A1A2E);

            wheelView = new WheelView(this);
            LinearLayout.LayoutParams wp = new LinearLayout.LayoutParams(450, 450);
            wp.gravity = android.view.Gravity.CENTER;
            wheelView.setLayoutParams(wp);
            layout.addView(wheelView);

            resultText = new TextView(this);
            resultText.setText("🎯 Крутите колесо!");
            resultText.setTextSize(20); resultText.setTextColor(0xFFFFD740);
            resultText.setGravity(android.view.Gravity.CENTER);
            resultText.setPadding(0, 16, 0, 16);
            layout.addView(resultText);

            inputSectors = new EditText(this);
            inputSectors.setHint("Сектора через запятую");
            inputSectors.setTextColor(0xFFFFFFFF); inputSectors.setHintTextColor(0xFF757575);
            inputSectors.setBackgroundColor(0xFF333333);
            inputSectors.setPadding(12, 12, 12, 12);
            inputSectors.setText("100,200,300,Пропуск,500,1000,0,Бонус");
            layout.addView(inputSectors);

            LinearLayout btns = new LinearLayout(this);
            btns.setOrientation(LinearLayout.HORIZONTAL);
            btns.setGravity(android.view.Gravity.CENTER);

            btnSpin = new Button(this); btnSpin.setText("🎰 Крутить");
            btnSpin.setTextSize(18);
            btnSpin.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) { spin(); }
            });
            btns.addView(btnSpin);

            btnUpdate = new Button(this); btnUpdate.setText("Обновить");
            btnUpdate.setTextSize(18);
            btnUpdate.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) { updateSectors(); }
            });
            btns.addView(btnUpdate);

            layout.addView(btns);
            setContentView(layout);
            setTitle("🎯 Колесо фортуны");
            AppLogger.log(this, "WheelFortune", "onCreate completed");
        } catch (Exception e) { AppLogger.logException(this, "WheelFortune", e); finish(); }
    }

    private void spin() {
        float targetAngle = spinAngle + 720 + random.nextInt(360);
        animateWheel(spinAngle, targetAngle);
        spinAngle = targetAngle;
        AppLogger.log(this, "WheelFortune", "Spin to " + targetAngle);
    }

    private void animateWheel(final float from, final float to) {
        final long start = System.currentTimeMillis();
        final long duration = 2000;
        handler.post(new Runnable() {
            @Override
            public void run() {
                long elapsed = System.currentTimeMillis() - start;
                float progress = Math.min(1f, (float) elapsed / duration);
                float eased = 1 - (1 - progress) * (1 - progress) * (1 - progress);
                float current = from + (to - from) * eased;
                wheelView.setAngle(current);
                wheelView.invalidate();
                if (progress < 1) handler.postDelayed(this, 16);
                else {
                    int idx = wheelView.getSelectedIndex();
                    if (idx >= 0 && idx < sectors.length) {
                        resultText.setText("🎯 Результат: " + sectors[idx] + "!");
                        Toast.makeText(WheelFortuneActivity.this, "Выпало: " + sectors[idx], Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });
    }

    private void updateSectors() {
        String input = inputSectors.getText().toString().trim();
        if (input.isEmpty()) return;
        sectors = input.split(",");
        for (int i = 0; i < sectors.length; i++) sectors[i] = sectors[i].trim();
        Toast.makeText(this, "Обновлено: " + sectors.length + " секторов", Toast.LENGTH_SHORT).show();
        wheelView.invalidate();
        AppLogger.log(this, "WheelFortune", "Sectors updated: " + sectors.length);
    }

    class WheelView extends View {
        private Paint paint = new Paint();

        public WheelView(Context ctx) {
            super(ctx);
            setFocusable(true);
            setFocusableInTouchMode(true);
        }

        public void setAngle(float a) { spinAngle = a; }

        public int getSelectedIndex() {
            float step = 360f / sectors.length;
            float norm = ((spinAngle % 360) + 360) % 360;
            int idx = sectors.length - 1 - (int) (norm / step);
            return Math.max(0, Math.min(sectors.length - 1, idx));
        }

        @Override
        protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            float cx = getWidth() / 2f, cy = getHeight() / 2f;
            float r = Math.min(cx, cy) * 0.9f;
            RectF oval = new RectF(cx - r, cy - r, cx + r, cy + r);
            float step = 360f / sectors.length;

            // Фон колеса
            paint.setColor(Color.rgb(40, 40, 40));
            canvas.drawCircle(cx, cy, r + 10, paint);

            for (int i = 0; i < sectors.length; i++) {
                paint.setColor(colors[i % colors.length]);
                canvas.drawArc(oval, spinAngle + i * step, step, true, paint);

                // Граница сектора
                paint.setColor(Color.BLACK);
                paint.setStyle(Paint.Style.STROKE);
                paint.setStrokeWidth(2);
                canvas.drawArc(oval, spinAngle + i * step, step, true, paint);
                paint.setStyle(Paint.Style.FILL);

                // Текст
                paint.setColor(Color.WHITE);
                paint.setTextSize(18);
                paint.setTextAlign(Paint.Align.CENTER);
                float midAngle = (float) Math.toRadians(spinAngle + i * step + step / 2);
                float tx = cx + (float) Math.cos(midAngle) * r * 0.6f;
                float ty = cy + (float) Math.sin(midAngle) * r * 0.6f;
                canvas.drawText(sectors[i], tx, ty + 6, paint);
            }

            // Обод
            paint.setColor(Color.rgb(200, 150, 50));
            paint.setStyle(Paint.Style.STROKE);
            paint.setStrokeWidth(6);
            canvas.drawCircle(cx, cy, r, paint);
            paint.setStyle(Paint.Style.FILL);

            // Центр
            paint.setColor(Color.rgb(200, 150, 50));
            canvas.drawCircle(cx, cy, 12, paint);

            // Стрелка
            paint.setColor(Color.RED);
            paint.setStrokeWidth(5);
            float px = cx + r * 0.95f, py = cy;
            canvas.drawLine(px - 30, py - 15, px, py, paint);
            canvas.drawLine(px - 30, py + 15, px, py, paint);
        }
    }
}