package com.last04ka.messenger.utils;

import android.content.Context;
import android.content.SharedPreferences;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class LanguageStats {

    private static final String PREFS = "lang_stats";
    private static final String KEY_ACTIONS = "actions_";
    private static final String KEY_QUIZ_SCORE = "quiz_score_";
    private static final String KEY_QUIZ_TOTAL = "quiz_total_";
    private static final String KEY_LAST_ACTIVE = "last_active_";
    private static final String KEY_STREAK = "streak_";

    public static void recordAction(Context context, String language, String action, String value) {
        if (context == null) return;
        SharedPreferences prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);

        String key = KEY_ACTIONS + language + "_" + action;
        int count = prefs.getInt(key, 0) + 1;
        prefs.edit().putInt(key, count).apply();

        // Обновляем последнюю активность
        String dateKey = KEY_LAST_ACTIVE + language;
        String today = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(new Date());
        String lastActive = prefs.getString(dateKey, "");

        if (!today.equals(lastActive)) {
            // Новый день — обновляем серию
            prefs.edit().putString(dateKey, today).apply();
            updateStreak(context, language);
        }

        AppLogger.log(context, "LanguageStats", "Recorded: " + language + " -> " + action + " (" + count + ")");
    }

    public static void recordQuizResult(Context context, String language, int score, int total) {
        if (context == null) return;
        SharedPreferences prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);

        int bestScore = prefs.getInt(KEY_QUIZ_SCORE + language, 0);
        if (score > bestScore) {
            prefs.edit().putInt(KEY_QUIZ_SCORE + language, score).apply();
        }

        int bestTotal = prefs.getInt(KEY_QUIZ_TOTAL + language, 0);
        if (total > bestTotal) {
            prefs.edit().putInt(KEY_QUIZ_TOTAL + language, total).apply();
        }

        AppLogger.log(context, "LanguageStats", "Quiz result: " + language + " -> " + score + "/" + total);
    }

    public static int getQuizScore(Context context, String language) {
        if (context == null) return 0;
        return context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                .getInt(KEY_QUIZ_SCORE + language, 0);
    }

    public static int getQuizTotal(Context context, String language) {
        if (context == null) return 0;
        return context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                .getInt(KEY_QUIZ_TOTAL + language, 0);
    }

    public static int getActionCount(Context context, String language, String action) {
        if (context == null) return 0;
        return context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                .getInt(KEY_ACTIONS + language + "_" + action, 0);
    }

    public static int getStreak(Context context, String language) {
        if (context == null) return 0;
        return context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                .getInt(KEY_STREAK + language, 0);
    }

    private static void updateStreak(Context context, String language) {
        SharedPreferences prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        String key = KEY_STREAK + language;
        int current = prefs.getInt(key, 0);

        // Проверяем, была ли активность вчера
        String yesterday = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
                .format(new Date(System.currentTimeMillis() - 86400000));
        String lastActive = prefs.getString(KEY_LAST_ACTIVE + language, "");

        if (lastActive.equals(yesterday)) {
            prefs.edit().putInt(key, current + 1).apply();
            AppLogger.log(context, "LanguageStats", "Streak updated: " + language + " -> " + (current + 1));
        } else if (!lastActive.isEmpty() && !lastActive.equals(new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(new Date()))) {
            // Пропущен день — сбрасываем серию
            prefs.edit().putInt(key, 1).apply();
            AppLogger.log(context, "LanguageStats", "Streak reset: " + language + " -> 1");
        } else {
            // Первый день или уже сегодня
            if (current == 0) {
                prefs.edit().putInt(key, 1).apply();
                AppLogger.log(context, "LanguageStats", "Streak started: " + language + " -> 1");
            }
        }
    }

    public static void reset(Context context) {
        if (context == null) return;
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().clear().apply();
        AppLogger.log(context, "LanguageStats", "All stats reset");
    }

    public static String getStatsSummary(Context context, String language) {
        if (context == null) return "Нет данных";
        SharedPreferences prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);

        int speak = prefs.getInt(KEY_ACTIONS + language + "_speak", 0);
        int pronounce = prefs.getInt(KEY_ACTIONS + language + "_pronounce", 0);
        int record = prefs.getInt(KEY_ACTIONS + language + "_record", 0);
        int quiz = prefs.getInt(KEY_ACTIONS + language + "_quiz_finish", 0);
        int flashcards = prefs.getInt(KEY_ACTIONS + language + "_flashcards_start", 0);
        int translate = prefs.getInt(KEY_ACTIONS + language + "_translate", 0);
        int streak = prefs.getInt(KEY_STREAK + language, 0);
        int bestScore = prefs.getInt(KEY_QUIZ_SCORE + language, 0);
        int bestTotal = prefs.getInt(KEY_QUIZ_TOTAL + language, 0);

        return "📊 Статистика изучения:\n" +
                "🔊 Произнесено: " + speak + "\n" +
                "📖 Озвучено: " + pronounce + "\n" +
                "🎙️ Записей: " + record + "\n" +
                "🎯 Викторин: " + quiz + "\n" +
                "🃏 Карточек: " + flashcards + "\n" +
                "🔍 Переводов: " + translate + "\n" +
                "🔥 Серия: " + streak + " дней\n" +
                "🏆 Лучший результат: " + bestScore + "/" + bestTotal;
    }
}