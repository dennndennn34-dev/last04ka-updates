package com.last04ka.messenger.ui;

import android.app.Activity;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.os.Bundle;
import android.os.Handler;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import com.last04ka.messenger.utils.AppLogger;
import com.last04ka.messenger.utils.GameScores;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class BattleshipActivity extends Activity {

    private PlayerGridView playerView;
    private BotGridView botView;
    private TextView statusText, scoreText;
    private Button btnRotate;
    private Handler handler = new Handler();
    private int playerHits = 0, botHits = 0;
    private int playerShipsLeft = 10, botShipsLeft = 10;
    private int[][] shipTypes = {{4,1}, {3,2}, {2,3}, {1,4}};
    private List<Integer> availableShips = new ArrayList<>();
    private int selectedShipIndex = 0;
    private boolean horizontal = true;
    private int[][] playerGrid = new int[10][10];
    private int[][] botGrid = new int[10][10];
    private boolean[][] botAttacked = new boolean[10][10];
    private boolean placing = true;
    private Random r = new Random();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        try {
            AppLogger.log(this, "Battleship", "onCreate started");
            initAvailableShips();
            placeBotShips();

            LinearLayout mainLayout = new LinearLayout(this);
            mainLayout.setOrientation(LinearLayout.VERTICAL);
            mainLayout.setBackgroundColor(0xFF1A1A2E);

            scoreText = new TextView(this);
            scoreText.setText("🚢 Вы: 10 | 🛡️ Бот: 10");
            scoreText.setTextSize(13);
            scoreText.setTextColor(0xFFFFD740);
            scoreText.setGravity(Gravity.CENTER);
            scoreText.setPadding(16, 6, 16, 2);
            mainLayout.addView(scoreText);

            statusText = new TextView(this);
            statusText.setText("Выберите корабль и нажмите на клетку");
            statusText.setTextSize(13);
            statusText.setTextColor(0xFFFFFFFF);
            statusText.setGravity(Gravity.CENTER);
            statusText.setPadding(16, 2, 16, 4);
            mainLayout.addView(statusText);

            // ПАНЕЛЬ КОРАБЛЕЙ
            LinearLayout shipPanel = new LinearLayout(this);
            shipPanel.setOrientation(LinearLayout.HORIZONTAL);
            shipPanel.setGravity(Gravity.CENTER);
            shipPanel.setPadding(8, 4, 8, 6);

            for (int i = 0; i < shipTypes.length; i++) {
                final int idx = i;
                Button btn = new Button(this);
                btn.setText("🚢" + shipTypes[i][0] + "×" + shipTypes[i][1]);
                btn.setTextSize(11);
                btn.setAllCaps(false);
                btn.setPadding(6, 4, 6, 4);
                btn.setBackgroundColor(0xFF424242);
                btn.setTextColor(0xFFFFFFFF);
                btn.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if (placing && availableShips.get(idx) > 0) {
                            selectedShipIndex = idx;
                            updateShipPanel(shipPanel);
                            playerView.invalidate();
                        }
                    }
                });
                shipPanel.addView(btn);
            }
            mainLayout.addView(shipPanel);

            // КНОПКА ПОВОРОТА
            btnRotate = new Button(this);
            btnRotate.setText("↻ Горизонтально");
            btnRotate.setTextSize(11);
            btnRotate.setAllCaps(false);
            btnRotate.setBackgroundColor(0xFF1565C0);
            btnRotate.setTextColor(0xFFFFFFFF);
            btnRotate.setGravity(Gravity.CENTER);
            btnRotate.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    horizontal = !horizontal;
                    btnRotate.setText(horizontal ? "↻ Горизонтально" : "↻ Вертикально");
                    playerView.invalidate();
                }
            });
            mainLayout.addView(btnRotate);

            updateShipPanel(shipPanel);

            // Поле игрока
            TextView playerLabel = new TextView(this);
            playerLabel.setText("Ваше поле");
            playerLabel.setTextSize(12); playerLabel.setTextColor(0xFF90CAF9);
            playerLabel.setGravity(Gravity.CENTER);
            mainLayout.addView(playerLabel);

            playerView = new PlayerGridView(this);
            LinearLayout.LayoutParams pp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 1);
            playerView.setLayoutParams(pp);
            mainLayout.addView(playerView);

            // Поле бота
            TextView botLabel = new TextView(this);
            botLabel.setText("Поле бота");
            botLabel.setTextSize(12); botLabel.setTextColor(0xFFFF5252);
            botLabel.setGravity(Gravity.CENTER);
            botLabel.setPadding(0, 2, 0, 0);
            mainLayout.addView(botLabel);

            botView = new BotGridView(this);
            LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 1);
            botView.setLayoutParams(bp);
            mainLayout.addView(botView);

            // Новая игра
            Button btnNewGame = new Button(this);
            btnNewGame.setText("Новая игра");
            btnNewGame.setGravity(Gravity.CENTER);
            btnNewGame.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) { resetGame(); }
            });
            mainLayout.addView(btnNewGame);

            setContentView(mainLayout);
            setTitle("⚔️ Морской бой");
            AppLogger.log(this, "Battleship", "onCreate completed");
        } catch (Exception e) { AppLogger.logException(this, "Battleship", e); finish(); }
    }

    private void initAvailableShips() { availableShips.clear(); for (int[] st : shipTypes) availableShips.add(st[1]); }

    private void updateShipPanel(LinearLayout panel) {
        for (int i = 0; i < shipTypes.length; i++) {
            View v = panel.getChildAt(i);
            if (v instanceof Button) {
                Button btn = (Button) v;
                int rem = availableShips.get(i);
                btn.setText("🚢" + shipTypes[i][0] + "×" + rem);
                btn.setEnabled(rem > 0 && placing);
                btn.setBackgroundColor(i == selectedShipIndex && rem > 0 && placing ? 0xFF1565C0 : 0xFF424242);
            }
        }
    }

    private void updateScore() {
        scoreText.setText("🚢 Вы: " + playerShipsLeft + " | 🛡️ Бот: " + botShipsLeft);
    }

    private void resetGame() {
        playerGrid = new int[10][10]; botGrid = new int[10][10];
        botAttacked = new boolean[10][10]; placing = true;
        initAvailableShips(); selectedShipIndex = 0;
        playerHits = 0; botHits = 0; horizontal = true;
        playerShipsLeft = 10; botShipsLeft = 10;
        placeBotShips();
        updateScore();
        statusText.setText("Выберите корабль и нажмите на клетку");
        btnRotate.setText("↻ Горизонтально");
        playerView.invalidate(); botView.invalidate();
    }

    private void placeBotShips() {
        botGrid = new int[10][10];
        for (int si = 0; si < shipTypes.length; si++) {
            int sz = shipTypes[si][0], cnt = shipTypes[si][1];
            for (int n = 0; n < cnt; n++) {
                boolean placed = false; int att = 0;
                while (!placed && att < 300) {
                    int row = r.nextInt(10), col = r.nextInt(10);
                    boolean horiz = r.nextBoolean();
                    if (canPlace(botGrid, row, col, sz, horiz)) { placeShip(botGrid, row, col, sz, horiz); placed = true; }
                    att++;
                }
                if (!placed) { botGrid = new int[10][10]; placeBotShips(); return; }
            }
        }
    }

    private boolean canPlace(int[][] g, int row, int col, int sz, boolean horiz) {
        if (horiz) { if (col + sz > 10) return false; for (int c = col-1; c <= col+sz; c++) for (int r = row-1; r <= row+1; r++) if (r>=0&&r<10&&c>=0&&c<10&&g[r][c]==1) return false; }
        else { if (row + sz > 10) return false; for (int r = row-1; r <= row+sz; r++) for (int c = col-1; c <= col+1; c++) if (r>=0&&r<10&&c>=0&&c<10&&g[r][c]==1) return false; }
        return true;
    }

    private void placeShip(int[][] g, int row, int col, int sz, boolean horiz) {
        if (horiz) for (int c = col; c < col+sz; c++) g[row][c] = 1;
        else for (int r = row; r < row+sz; r++) g[r][col] = 1;
    }

    private boolean allSunk(int[][] g) { for (int r=0;r<10;r++) for (int c=0;c<10;c++) if (g[r][c]==1) return false; return true; }

    private void checkSunkShips(int[][] grid, boolean isPlayer) {
        boolean[][] visited = new boolean[10][10];
        for (int r = 0; r < 10; r++) {
            for (int c = 0; c < 10; c++) {
                if (grid[r][c] == 2 && !visited[r][c]) {
                    // Нашли попадание — ищем весь корабль
                    int sr = r, sc = c;
                    while (sr > 0 && grid[sr-1][sc] >= 1 && grid[sr-1][sc] != 3) sr--;
                    while (sc > 0 && grid[sr][sc-1] >= 1 && grid[sr][sc-1] != 3) sc--;
                    
                    // Собираем все клетки корабля
                    List<int[]> shipCells = new ArrayList<>();
                    int rr = sr, cc = sc;
                    while (rr < 10 && grid[rr][cc] >= 1 && grid[rr][cc] != 3) {
                        int ccc = cc;
                        while (ccc < 10 && grid[rr][ccc] >= 1 && grid[rr][ccc] != 3) {
                            shipCells.add(new int[]{rr, ccc});
                            visited[rr][ccc] = true;
                            ccc++;
                        }
                        rr++;
                    }
                    
                    // Проверяем все ли клетки корабля подбиты
                    boolean allHit = true;
                    for (int[] cell : shipCells) {
                        if (grid[cell[0]][cell[1]] == 1) { allHit = false; break; }
                    }
                    
                    if (allHit) {
                        // Закрашиваем в чёрный
                        for (int[] cell : shipCells) {
                            grid[cell[0]][cell[1]] = 4; // 4 = уничтожен
                        }
                        if (isPlayer) {
                            playerShipsLeft--;
                            Toast.makeText(this, "💀 Бот потопил ваш корабль!", Toast.LENGTH_SHORT).show();
                        } else {
                            botShipsLeft--;
                            Toast.makeText(this, "🏆 Вы потопили корабль бота!", Toast.LENGTH_SHORT).show();
                        }
                        updateScore();
                    }
                }
            }
        }
    }

    private void botAttack() {
        if (placing) return;
        int row, col, att=0;
        do { row=r.nextInt(10); col=r.nextInt(10); att++; } while (botAttacked[row][col] && att<200);
        if (att>=200) return;
        botAttacked[row][col]=true;
        if (playerGrid[row][col]==1) { playerGrid[row][col]=2; botHits++; checkSunkShips(playerGrid, true); if (allSunk(playerGrid)) { statusText.setText("💀 Бот победил! Счёт: "+botHits); placing=true; } }
        else playerGrid[row][col]=3;
        playerView.invalidate();
    }

    // ==================== ПОЛЕ ИГРОКА ====================
    class PlayerGridView extends View {
        private Paint p = new Paint();

        public PlayerGridView(Context ctx) { super(ctx); setBackgroundColor(Color.rgb(20,20,60)); setFocusable(true); setFocusableInTouchMode(true); }

        @Override
        protected void onDraw(Canvas c) {
            super.onDraw(c);
            float cs = Math.min(getWidth(), getHeight()) / 10f;
            float ox = (getWidth() - cs*10)/2f, oy = (getHeight() - cs*10)/2f;

            // Клетки
            for (int r=0;r<10;r++) for (int cc=0;cc<10;cc++) {
                float x=ox+cc*cs, y=oy+r*cs; int v=playerGrid[r][cc];
                if (v==4) p.setColor(0xFF1A1A1A);
                else if (v==2) p.setColor(0xFFB71C1C);
                else if (v==3) p.setColor(Color.rgb(100,150,255));
                else p.setColor(Color.rgb(30,60,150));
                c.drawRoundRect(x+1,y+1,x+cs-1,y+cs-1,3,3,p);
                p.setColor(Color.rgb(100,120,180)); p.setStrokeWidth(1); p.setStyle(Paint.Style.STROKE);
                c.drawRoundRect(x,y,x+cs,y+cs,3,3,p);
            }
            // Корабли
            boolean[][] vis = new boolean[10][10];
            for (int r=0;r<10;r++) for (int cc=0;cc<10;cc++) {
                if ((playerGrid[r][cc]==1||playerGrid[r][cc]==4) && !vis[r][cc]) {
                    // Размер корабля
                    int len=1; boolean h=false;
                    int ccc=cc+1; while(ccc<10&&(playerGrid[r][ccc]==1||playerGrid[r][ccc]==4)){len++;ccc++;}
                    if (len>1) h=true; else { int rr=r+1; while(rr<10&&(playerGrid[rr][cc]==1||playerGrid[rr][cc]==4)){len++;rr++;} }
                    if (h) for(int i=0;i<len;i++) vis[r][cc+i]=true;
                    else for(int i=0;i<len;i++) vis[r+i][cc]=true;

                    float sx=ox+cc*cs, sy=oy+r*cs;
                    float sw=h?cs*len:cs, sh=h?cs:cs*len;
                    boolean sunk = playerGrid[r][cc]==4;

                    p.setStyle(Paint.Style.FILL);
                    p.setAntiAlias(true);

                    // Корпус
                    p.setColor(sunk?0xFF333333:0xFF90CAF9);
                    c.drawRoundRect(sx+4,sy+4,sx+sw-4,sy+sh-4,cs/3,cs/3,p);
                    p.setColor(sunk?0xFF555555:0xFF42A5F5);
                    p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(2);
                    c.drawRoundRect(sx+4,sy+4,sx+sw-4,sy+sh-4,cs/3,cs/3,p);
                    p.setStyle(Paint.Style.FILL);

                    // Иллюминаторы (только живые)
                    if (!sunk) {
                        Paint pp = new Paint(); pp.setColor(0xFFE3F2FD); pp.setStyle(Paint.Style.FILL); pp.setAntiAlias(true);
                        float pr=cs/6;
                        if (h) for(int i=0;i<len;i++) c.drawCircle(sx+cs*(i+0.5f),sy+cs/2,pr,pp);
                        else for(int i=0;i<len;i++) c.drawCircle(sx+cs/2,sy+cs*(i+0.5f),pr,pp);
                    }
                    // Нос
                    Paint bp = new Paint(); bp.setColor(sunk?0xFF444444:0xFF1565C0); bp.setStyle(Paint.Style.FILL); bp.setAntiAlias(true);
                    Path bow = new Path();
                    if (h) { bow.moveTo(sx+sw,sy+sh/2); bow.lineTo(sx+sw-cs/4,sy+6); bow.lineTo(sx+sw-cs/4,sy+sh-6); bow.close(); }
                    else { bow.moveTo(sx+sw/2,sy+sh); bow.lineTo(sx+6,sy+sh-cs/4); bow.lineTo(sx+sw-6,sy+sh-cs/4); bow.close(); }
                    c.drawPath(bow,bp);
                }
            }
        }

        @Override
        public boolean onTouchEvent(MotionEvent e) {
            if (e.getAction()!=MotionEvent.ACTION_DOWN||!placing) return true;
            float cs=Math.min(getWidth(),getHeight())/10f, ox=(getWidth()-cs*10)/2f, oy=(getHeight()-cs*10)/2f;
            int col=(int)((e.getX()-ox)/cs), row=(int)((e.getY()-oy)/cs);
            if (col<0||col>=10||row<0||row>=10) return true;
            int sz=shipTypes[selectedShipIndex][0], rem=availableShips.get(selectedShipIndex);
            if (rem<=0) return true;
            if (canPlace(playerGrid,row,col,sz,horizontal)) {
                placeShip(playerGrid,row,col,sz,horizontal);
                availableShips.set(selectedShipIndex,rem-1);
                boolean all=true; for(int a:availableShips) if(a>0){all=false;break;}
                if (all) { placing=false; statusText.setText("⚔️ Флот построен! Стреляйте по врагу!"); }
                else { for(int i=0;i<availableShips.size();i++) if(availableShips.get(i)>0){selectedShipIndex=i;break;} }
                invalidate();
            } else Toast.makeText(getContext(),"Нельзя разместить",Toast.LENGTH_SHORT).show();
            return true;
        }
    }

    // ==================== ПОЛЕ БОТА ====================
    class BotGridView extends View {
        private Paint p = new Paint();

        public BotGridView(Context ctx) { super(ctx); setBackgroundColor(Color.rgb(40,0,0)); setFocusable(true); setFocusableInTouchMode(true); }

        @Override
        protected void onDraw(Canvas c) {
            super.onDraw(c);
            float cs=Math.min(getWidth(),getHeight())/10f, ox=(getWidth()-cs*10)/2f, oy=(getHeight()-cs*10)/2f;

            for (int r=0;r<10;r++) for (int cc=0;cc<10;cc++) {
                float x=ox+cc*cs, y=oy+r*cs; int v=botGrid[r][cc];
                if (v==4) p.setColor(0xFF1A1A1A); // Уничтожен
                else if (v==2) p.setColor(0xFFB71C1C);
                else if (v==3) p.setColor(Color.rgb(100,150,255));
                else p.setColor(Color.rgb(60,20,20));
                c.drawRoundRect(x+1,y+1,x+cs-1,y+cs-1,3,3,p);
                p.setColor(Color.rgb(120,80,80)); p.setStrokeWidth(1); p.setStyle(Paint.Style.STROKE);
                c.drawRoundRect(x,y,x+cs,y+cs,3,3,p);
            }

            // Показать корабли бота после победы
            if (placing) {
                boolean[][] vis = new boolean[10][10];
                for (int r=0;r<10;r++) for (int cc=0;cc<10;cc++) {
                    if ((botGrid[r][cc]==1||botGrid[r][cc]==4) && !vis[r][cc]) {
                        int len=1; boolean h=false;
                        int ccc=cc+1; while(ccc<10&&(botGrid[r][ccc]==1||botGrid[r][ccc]==4)){len++;ccc++;}
                        if (len>1) h=true; else { int rr=r+1; while(rr<10&&(botGrid[rr][cc]==1||botGrid[rr][cc]==4)){len++;rr++;} }
                        if (h) for(int i=0;i<len;i++) vis[r][cc+i]=true;
                        else for(int i=0;i<len;i++) vis[r+i][cc]=true;
                        float sx=ox+cc*cs, sy=oy+r*cs, sw=h?cs*len:cs, sh=h?cs:cs*len;
                        p.setStyle(Paint.Style.FILL); p.setAntiAlias(true);
                        p.setColor(botGrid[r][cc]==4?0xFF333333:0x66FF5252);
                        c.drawRoundRect(sx+2,sy+2,sx+sw-2,sy+sh-2,cs/3,cs/3,p);
                    }
                }
            }
        }

        @Override
        public boolean onTouchEvent(MotionEvent e) {
            if (e.getAction()!=MotionEvent.ACTION_DOWN||placing) return true;
            float cs=Math.min(getWidth(),getHeight())/10f, ox=(getWidth()-cs*10)/2f, oy=(getHeight()-cs*10)/2f;
            int col=(int)((e.getX()-ox)/cs), row=(int)((e.getY()-oy)/cs);
            if (col<0||col>=10||row<0||row>=10) return true;
            if (botGrid[row][col]==2||botGrid[row][col]==3||botGrid[row][col]==4) return true;

            if (botGrid[row][col]==1) {
                botGrid[row][col]=2; playerHits++;
                Toast.makeText(getContext(),"💥 Попадание!",Toast.LENGTH_SHORT).show();
                checkSunkShips(botGrid,false);
                if (allSunk(botGrid)) { statusText.setText("🏆 Победа! Флот врага уничтожен!"); GameScores.saveScore(getContext(),"battleship",playerHits); placing=true; }
            } else botGrid[row][col]=3;
            invalidate();
            if (!placing) handler.postDelayed(new Runnable(){@Override public void run(){botAttack();}},500);
            return true;
        }
    }
}