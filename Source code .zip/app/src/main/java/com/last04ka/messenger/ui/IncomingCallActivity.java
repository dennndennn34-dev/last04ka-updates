package com.last04ka.messenger.ui;

import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.os.Vibrator;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.last04ka.messenger.R;
import com.last04ka.messenger.utils.AppLogger;

public class IncomingCallActivity extends android.app.Activity {
    private static final String TAG = "IncomingCall";
    
    private TextView tvCallerName;
    private Button btnAccept, btnDecline;
    private String callerAddress;
    private String callerName;
    private MediaPlayer ringtonePlayer;
    private Vibrator vibrator;
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        AppLogger.log(this, TAG, "onCreate started");
        
        try {
            setContentView(R.layout.activity_incoming_call);
            
            getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
            getWindow().addFlags(WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON);
            
            tvCallerName = findViewById(R.id.tv_caller_name);
            btnAccept = findViewById(R.id.btn_accept_call);
            btnDecline = findViewById(R.id.btn_decline_call);
            
            callerAddress = getIntent().getStringExtra("caller_address");
            callerName = getIntent().getStringExtra("caller_name");
            
            vibrator = (Vibrator) getSystemService(VIBRATOR_SERVICE);
            
            tvCallerName.setText("📞 " + (callerName != null ? callerName : "Входящий звонок"));
            
            // Воспроизведение рингтона
            try {
                ringtonePlayer = MediaPlayer.create(this, android.provider.Settings.System.DEFAULT_RINGTONE_URI);
                if (ringtonePlayer != null) {
                    ringtonePlayer.setLooping(true);
                    ringtonePlayer.start();
                    AppLogger.log(this, TAG, "Ringtone playing");
                }
            } catch (Exception e) {
                AppLogger.logException(this, TAG, "Ringtone error", e);
            }
            
            // Вибрация
            if (vibrator != null && vibrator.hasVibrator()) {
                long[] pattern = {0, 1000, 500, 1000};
                vibrator.vibrate(pattern, 0);
                AppLogger.log(this, TAG, "Vibration started");
            }
            
            btnAccept.setOnClickListener(v -> {
                AppLogger.log(IncomingCallActivity.this, TAG, "Call accepted");
                stopRingtoneAndVibrate();
                BluetoothChatActivity.sendCallResponse("CALL_ACCEPT|" + callerAddress);
                
                Intent intent = new Intent(IncomingCallActivity.this, CallActivity.class);
                intent.putExtra("target_address", callerAddress);
                intent.putExtra("target_name", callerName);
                intent.putExtra("is_initiator", false);
                startActivity(intent);
                finish();
            });
            
            btnDecline.setOnClickListener(v -> {
                AppLogger.log(IncomingCallActivity.this, TAG, "Call declined");
                stopRingtoneAndVibrate();
                BluetoothChatActivity.sendCallResponse("CALL_DECLINE|" + callerAddress);
                finish();
            });
            
            AppLogger.log(this, TAG, "onCreate completed");
        } catch (Exception e) {
            AppLogger.logException(this, TAG, "onCreate error", e);
            finish();
        }
    }
    
    private void stopRingtoneAndVibrate() {
        if (ringtonePlayer != null) {
            try {
                if (ringtonePlayer.isPlaying()) {
                    ringtonePlayer.stop();
                }
                ringtonePlayer.release();
                AppLogger.log(this, TAG, "Ringtone stopped");
            } catch (Exception e) {
                AppLogger.logException(this, TAG, "Ringtone stop error", e);
            }
            ringtonePlayer = null;
        }
        if (vibrator != null) {
            vibrator.cancel();
            AppLogger.log(this, TAG, "Vibration stopped");
        }
    }
    
    @Override
    protected void onDestroy() {
        super.onDestroy();
        AppLogger.log(this, TAG, "onDestroy called");
        stopRingtoneAndVibrate();
    }
}