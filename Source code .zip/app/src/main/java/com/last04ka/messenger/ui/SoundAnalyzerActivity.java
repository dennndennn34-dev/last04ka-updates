package com.last04ka.messenger.ui;

import android.app.Activity;
import android.media.AudioFormat;
import android.media.AudioRecord;
import android.media.MediaRecorder;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import com.last04ka.messenger.utils.AppLogger;

public class SoundAnalyzerActivity extends Activity {

    private TextView freqText, dbText;
    private Button btnStart, btnStop;
    private boolean recording = false;
    private AudioRecord audioRecord;
    private Thread recordingThread;
    private Handler handler = new Handler();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        try {
            AppLogger.log(this, "SoundAnalyzer", "onCreate started");
            LinearLayout layout = new LinearLayout(this);
            layout.setOrientation(LinearLayout.VERTICAL);
            layout.setPadding(24, 24, 24, 24);
            layout.setBackgroundColor(0xFF1A1A2E);
            layout.setGravity(android.view.Gravity.CENTER);

            TextView title = new TextView(this);
            title.setText("🧪 Анализатор звука");
            title.setTextSize(20); title.setTextColor(0xFFFFFFFF);
            title.setGravity(android.view.Gravity.CENTER);
            title.setPadding(0, 0, 0, 32);
            layout.addView(title);

            freqText = new TextView(this);
            freqText.setText("Частота: -- Гц");
            freqText.setTextSize(32); freqText.setTextColor(0xFF00E676);
            freqText.setGravity(android.view.Gravity.CENTER);
            layout.addView(freqText);

            dbText = new TextView(this);
            dbText.setText("Громкость: -- дБ");
            dbText.setTextSize(24); dbText.setTextColor(0xFFFFD740);
            dbText.setGravity(android.view.Gravity.CENTER);
            dbText.setPadding(0, 16, 0, 32);
            layout.addView(dbText);

            LinearLayout btns = new LinearLayout(this);
            btns.setOrientation(LinearLayout.HORIZONTAL);
            btns.setGravity(android.view.Gravity.CENTER);

            btnStart = new Button(this); btnStart.setText("▶ Начать");
            btnStart.setTextSize(18);
            btnStart.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) { startRecording(); }
            });
            btns.addView(btnStart);

            btnStop = new Button(this); btnStop.setText("⏹ Стоп");
            btnStop.setTextSize(18);
            btnStop.setEnabled(false);
            btnStop.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) { stopRecording(); }
            });
            btns.addView(btnStop);

            layout.addView(btns);
            setContentView(layout);
            setTitle("🧪 Анализатор звука");
            AppLogger.log(this, "SoundAnalyzer", "onCreate completed");
        } catch (Exception e) { AppLogger.logException(this, "SoundAnalyzer", e); finish(); }
    }

    private void startRecording() {
        recording = true;
        btnStart.setEnabled(false);
        btnStop.setEnabled(true);

        int bufferSize = AudioRecord.getMinBufferSize(44100, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT);
        audioRecord = new AudioRecord(MediaRecorder.AudioSource.MIC, 44100, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, bufferSize);
        audioRecord.startRecording();

        recordingThread = new Thread(new Runnable() {
            @Override
            public void run() {
                short[] buffer = new short[bufferSize];
                while (recording) {
                    int read = audioRecord.read(buffer, 0, bufferSize);
                    if (read > 0) {
                        // Вычисляем частоту (упрощённо — через zero-crossing)
                        int zeroCrossings = 0;
                        for (int i = 1; i < read; i++) {
                            if ((buffer[i] >= 0 && buffer[i - 1] < 0) || (buffer[i] < 0 && buffer[i - 1] >= 0)) {
                                zeroCrossings++;
                            }
                        }
                        final double freq = (zeroCrossings * 44100.0) / (2.0 * read);

                        // Вычисляем громкость в дБ
                        double sum = 0;
                        for (short s : buffer) sum += s * s;
                        double rms = Math.sqrt(sum / read);
                        final double db = rms > 0 ? 20 * Math.log10(rms / 32768.0) + 90 : 0;

                        handler.post(new Runnable() {
                            @Override
                            public void run() {
                                freqText.setText(String.format("Частота: %.0f Гц", freq));
                                dbText.setText(String.format("Громкость: %.1f дБ", db));
                            }
                        });
                    }
                }
            }
        });
        recordingThread.start();
        AppLogger.log(this, "SoundAnalyzer", "Recording started");
    }

    private void stopRecording() {
        recording = false;
        btnStart.setEnabled(true);
        btnStop.setEnabled(false);
        if (audioRecord != null) {
            audioRecord.stop();
            audioRecord.release();
            audioRecord = null;
        }
        freqText.setText("Частота: -- Гц");
        dbText.setText("Громкость: -- дБ");
        AppLogger.log(this, "SoundAnalyzer", "Recording stopped");
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        stopRecording();
    }
}