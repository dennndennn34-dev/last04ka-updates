package com.last04ka.messenger.utils;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.ColorMatrix;
import android.graphics.ColorMatrixColorFilter;
import android.graphics.Paint;

public class PhotoProcessor {
    private static final String TAG = "PhotoProcessor";
    private Context context;
    
    public PhotoProcessor(Context context) {
        this.context = context;
        AppLogger.log(context, TAG, "PhotoProcessor initialized");
    }
    
    public Bitmap applyVintageFilter(Bitmap source, float intensity) {
        Bitmap result = Bitmap.createBitmap(source.getWidth(), source.getHeight(), Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(result);
        Paint paint = new Paint();
        ColorMatrix cm = new ColorMatrix();
        cm.setSaturation(0.7f);
        cm.setScale(1.2f, 1.1f, 0.9f, 1.0f);
        paint.setColorFilter(new ColorMatrixColorFilter(cm));
        canvas.drawBitmap(source, 0, 0, paint);
        applyVignetteInPlace(result, intensity);
        return result;
    }
    
    public Bitmap applyNoirFilter(Bitmap source) {
        Bitmap result = Bitmap.createBitmap(source.getWidth(), source.getHeight(), Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(result);
        Paint paint = new Paint();
        ColorMatrix cm = new ColorMatrix();
        cm.setSaturation(0);
        float contrast = 1.5f;
        float brightness = -30;
        float[] matrix = {contrast, 0, 0, 0, brightness, 0, contrast, 0, 0, brightness, 0, 0, contrast, 0, brightness, 0, 0, 0, 1, 0};
        cm.postConcat(new ColorMatrix(matrix));
        paint.setColorFilter(new ColorMatrixColorFilter(cm));
        canvas.drawBitmap(source, 0, 0, paint);
        return result;
    }
    
    public Bitmap applySepiaFilter(Bitmap source, float intensity) {
        Bitmap result = Bitmap.createBitmap(source.getWidth(), source.getHeight(), Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(result);
        Paint paint = new Paint();
        float[] sepiaMatrix = {0.393f, 0.769f, 0.189f, 0, 0, 0.349f, 0.686f, 0.168f, 0, 0, 0.272f, 0.534f, 0.131f, 0, 0, 0, 0, 0, 1, 0};
        ColorMatrix cm = new ColorMatrix(sepiaMatrix);
        paint.setColorFilter(new ColorMatrixColorFilter(cm));
        canvas.drawBitmap(source, 0, 0, paint);
        return result;
    }
    
    public Bitmap applyWatercolorFilter(Bitmap source) {
        Bitmap blurred = applyGaussianBlur(source, 5);
        return blurred;
    }
    
    public Bitmap applyOilPaintFilter(Bitmap source) {
        int radius = 3;
        int intensityLevels = 20;
        Bitmap result = Bitmap.createBitmap(source.getWidth(), source.getHeight(), Bitmap.Config.ARGB_8888);
        for (int y = radius; y < source.getHeight() - radius; y++) {
            for (int x = radius; x < source.getWidth() - radius; x++) {
                int[] r = new int[intensityLevels];
                int[] g = new int[intensityLevels];
                int[] b = new int[intensityLevels];
                int[] count = new int[intensityLevels];
                for (int fy = -radius; fy <= radius; fy++) {
                    for (int fx = -radius; fx <= radius; fx++) {
                        int pixel = source.getPixel(x + fx, y + fy);
                        int intensity = (int)(((Color.red(pixel) + Color.green(pixel) + Color.blue(pixel)) / 3.0) / 255.0 * (intensityLevels - 1));
                        if (intensity >= 0 && intensity < intensityLevels) {
                            r[intensity] += Color.red(pixel);
                            g[intensity] += Color.green(pixel);
                            b[intensity] += Color.blue(pixel);
                            count[intensity]++;
                        }
                    }
                }
                int maxIndex = 0;
                for (int i = 1; i < intensityLevels; i++) if (count[i] > count[maxIndex]) maxIndex = i;
                if (count[maxIndex] > 0) result.setPixel(x, y, Color.rgb(r[maxIndex]/count[maxIndex], g[maxIndex]/count[maxIndex], b[maxIndex]/count[maxIndex]));
                else result.setPixel(x, y, source.getPixel(x, y));
            }
        }
        return result;
    }
    
    public Bitmap applyPixelate(Bitmap source, int pixelSize) {
        Bitmap result = Bitmap.createBitmap(source.getWidth(), source.getHeight(), Bitmap.Config.ARGB_8888);
        for (int y = 0; y < source.getHeight(); y += pixelSize) {
            for (int x = 0; x < source.getWidth(); x += pixelSize) {
                int endX = Math.min(x + pixelSize, source.getWidth());
                int endY = Math.min(y + pixelSize, source.getHeight());
                int r = 0, g = 0, b = 0, count = 0;
                for (int py = y; py < endY; py++) {
                    for (int px = x; px < endX; px++) {
                        int pixel = source.getPixel(px, py);
                        r += Color.red(pixel); g += Color.green(pixel); b += Color.blue(pixel); count++;
                    }
                }
                if (count > 0) {
                    int avg = Color.rgb(r/count, g/count, b/count);
                    for (int py = y; py < endY; py++) for (int px = x; px < endX; px++) result.setPixel(px, py, avg);
                }
            }
        }
        return result;
    }
    
    public Bitmap applyGaussianBlur(Bitmap source, int radius) {
        if (radius < 1) return source;
        int width = source.getWidth(), height = source.getHeight();
        Bitmap result = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888);
        int[] pixels = new int[width * height];
        source.getPixels(pixels, 0, width, 0, 0, width, height);
        int[] output = new int[width * height];
        for (int y = 0; y < height; y++) {
            for (int x = 0; x < width; x++) {
                int r = 0, g = 0, b = 0, count = 0;
                for (int dx = -radius; dx <= radius; dx++) {
                    int nx = x + dx;
                    if (nx >= 0 && nx < width) {
                        int pixel = pixels[y * width + nx];
                        r += Color.red(pixel); g += Color.green(pixel); b += Color.blue(pixel); count++;
                    }
                }
                output[y * width + x] = Color.rgb(r/count, g/count, b/count);
            }
        }
        for (int y = 0; y < height; y++) {
            for (int x = 0; x < width; x++) {
                int r = 0, g = 0, b = 0, count = 0;
                for (int dy = -radius; dy <= radius; dy++) {
                    int ny = y + dy;
                    if (ny >= 0 && ny < height) {
                        int pixel = output[ny * width + x];
                        r += Color.red(pixel); g += Color.green(pixel); b += Color.blue(pixel); count++;
                    }
                }
                result.setPixel(x, y, Color.rgb(r/count, g/count, b/count));
            }
        }
        return result;
    }
    
    public Bitmap applySharpen(Bitmap source, float intensity) {
        Bitmap result = Bitmap.createBitmap(source.getWidth(), source.getHeight(), Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(result);
        Paint paint = new Paint();
        float strength = 0.5f + intensity;
        float[] sharpenMatrix = {-strength, -strength, -strength, 0, 0, -strength, 1 + 8*strength, -strength, 0, 0, -strength, -strength, -strength, 0, 0, 0, 0, 0, 1, 0};
        paint.setColorFilter(new ColorMatrixColorFilter(new ColorMatrix(sharpenMatrix)));
        canvas.drawBitmap(source, 0, 0, paint);
        return result;
    }
    
    public Bitmap applyVignette(Bitmap source, float intensity) {
        Bitmap result = source.copy(Bitmap.Config.ARGB_8888, true);
        applyVignetteInPlace(result, intensity);
        return result;
    }
    
    private void applyVignetteInPlace(Bitmap bitmap, float intensity) {
        int w = bitmap.getWidth(), h = bitmap.getHeight();
        int cx = w/2, cy = h/2;
        float maxR = (float) Math.sqrt(cx*cx + cy*cy);
        for (int y = 0; y < h; y++) {
            for (int x = 0; x < w; x++) {
                float dx = x - cx, dy = y - cy;
                float dist = (float) Math.sqrt(dx*dx + dy*dy);
                float factor = Math.max(0.3f, 1 - (dist/maxR) * intensity);
                int p = bitmap.getPixel(x, y);
                bitmap.setPixel(x, y, Color.rgb((int)(Color.red(p)*factor), (int)(Color.green(p)*factor), (int)(Color.blue(p)*factor)));
            }
        }
    }
    
    public Bitmap autoColorBalance(Bitmap source) {
        int w = source.getWidth(), h = source.getHeight();
        Bitmap result = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
        long sumR = 0, sumG = 0, sumB = 0;
        for (int y = 0; y < h; y++) for (int x = 0; x < w; x++) {
            int p = source.getPixel(x, y);
            sumR += Color.red(p); sumG += Color.green(p); sumB += Color.blue(p);
        }
        long total = w * h;
        int avgR = (int)(sumR/total), avgG = (int)(sumG/total), avgB = (int)(sumB/total);
        float scaleR = 128f / avgR, scaleG = 128f / avgG, scaleB = 128f / avgB;
        for (int y = 0; y < h; y++) for (int x = 0; x < w; x++) {
            int p = source.getPixel(x, y);
            result.setPixel(x, y, Color.rgb(Math.min(255, (int)(Color.red(p)*scaleR)), Math.min(255, (int)(Color.green(p)*scaleG)), Math.min(255, (int)(Color.blue(p)*scaleB))));
        }
        return result;
    }
    
    public Bitmap denoise(Bitmap source) {
        return applyGaussianBlur(source, 2);
    }
    
    public Bitmap adjustImage(Bitmap source, float brightness, float contrast, float saturation) {
        Bitmap result = Bitmap.createBitmap(source.getWidth(), source.getHeight(), Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(result);
        Paint paint = new Paint();
        ColorMatrix cm = new ColorMatrix();
        float transformedB = (brightness - 1) * 255;
        float transformedC = contrast;
        float[] bcMatrix = {transformedC, 0, 0, 0, transformedB, 0, transformedC, 0, 0, transformedB, 0, 0, transformedC, 0, transformedB, 0, 0, 0, 1, 0};
        cm.set(bcMatrix);
        if (saturation != 1.0f) {
            ColorMatrix satMatrix = new ColorMatrix();
            satMatrix.setSaturation(saturation);
            cm.postConcat(satMatrix);
        }
        paint.setColorFilter(new ColorMatrixColorFilter(cm));
        canvas.drawBitmap(source, 0, 0, paint);
        return result;
    }
}