package com.last04ka.messenger.ui;

import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;
import com.last04ka.messenger.R;
import com.last04ka.messenger.data.Message;
import com.last04ka.messenger.adapters.MessageAdapter;
import com.last04ka.messenger.utils.AppLogger;
import com.last04ka.messenger.utils.ThemeManager;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Random;
import java.util.UUID;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class ChatBotActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private EditText inputMessage;
    private ImageButton sendButton;
    private MessageAdapter adapter;
    private List<Message> messages = new ArrayList<>();
    private Random random = new Random();
    private Handler handler = new Handler();
    private boolean isSearchingWeb = false;
    private Map<String, String> searchCache = new HashMap<>();

    // База знаний
    private static final String[][] KNOWLEDGE_BASE = {
        {"владимир святославич|князь владимир|владимир красное солнышко|годы жизни князя владимира|владимир крестил", "Владимир Святославич правил 980-1015. Умер в 1015 году. Крестил Русь в 988."},
        {"крещение руси|крестил русь|русь крестил|год крещения руси", "Крещение Руси — 988 год. Князь Владимир Святославич."},
        {"ольга|княгиня ольга|крестил ольгу|крестили ольгу|ольгу крестил|крещение ольги|ольга крещение|ольга правил", "Княгиня Ольга правила 945-960. Крестилась в Константинополе около 957 года. При крещении получила имя Елена. Крёстным отцом был император Константин VII Багрянородный."},
        {"игорь|князь игорь|игорь рюрикович", "Князь Игорь Рюрикович правил 912-945. Убит древлянами. Муж княгини Ольги."},
        {"святослав|святослав игоревич|кто разгромил хазар|разгромил хазар", "Святослав Игоревич правил 945-972. Разгромил Хазарский каганат в 965 году."},
        {"ярослав мудрый|ярослав", "Ярослав Мудрый правил 1019-1054. Расцвет Киевской Руси."},
        {"иларион|иларион киевский", "Иларион — первый русский митрополит (1051-1054). Автор «Слова о законе и благодати»."},
        {"хазар|хазарский каганат", "Хазарский каганат разгромлен Святославом в 965 году."},
        {"гагарин|первый космонавт|полетел в космос", "Юрий Гагарин — первый человек в космосе. 12 апреля 1961."},
        {"тетрис|кто создал тетрис", "Создан Алексеем Пажитновым в 1985 в СССР."},
        {"moba|первая моба", "Aeon of Strife (1998) — первая MOBA. DotA (2003), LoL (2009)."},
        {"столица россии|столица рф", "Москва. Население ~13 млн."},
        {"столица сша|столица америки", "Вашингтон."},
        {"столица китая|столица кнр", "Пекин."},
        {"столица японии", "Токио."},
        {"самый богатый|богатейший человек", "Илон Маск (~$250 млрд, Forbes 2025)."},
        {"сколько планет|планеты солнечной системы", "8: Меркурий, Венера, Земля, Марс, Юпитер, Сатурн, Уран, Нептун."},
        {"last04ka|что такое last04ka", "Офлайн-мессенджер с 90+ мини-приложениями, версия 2.4."},
    };

    private String[] greetings = {"Привет! Чем помочь?", "Здравствуйте!", "Приветствую!"};
    private String[] jokes = {"Oct 31 == Dec 25! Программисты поймут.", "Сколько программистов для лампочки? Ни одного!"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        setTheme(ThemeManager.getThemeResource(this));
        super.onCreate(savedInstanceState);
        try {
            AppLogger.log(this, "ChatBot", "v4.1 priority keys");
            setContentView(R.layout.activity_chat_bot);
            setTitle("Чат-бот v4.1");

            recyclerView = findViewById(R.id.recycler_messages);
            inputMessage = findViewById(R.id.input_message);
            sendButton = findViewById(R.id.btn_send);
            ImageButton callButton = findViewById(R.id.btn_call);
            if (callButton != null) callButton.setVisibility(View.GONE);

            recyclerView.setLayoutManager(new LinearLayoutManager(this));
            adapter = new MessageAdapter(messages, new MessageAdapter.OnMessageLongClickListener() {
                @Override
                public void onMessageLongClick(Message message) {
                    // Ничего не делаем
                }
            });
            recyclerView.setAdapter(adapter);
            sendButton.setOnClickListener(v -> sendMessage());
            applyThemeColors();

            addBotMessage("Привет! Чат-бот v4.1\nЗнаю " + KNOWLEDGE_BASE.length + " тем.\nСпроси про Ольгу, Игоря, Владимира!\nСкажи \"найди [запрос]\" для поиска.");

            AppLogger.log(this, "ChatBot", "v4.1 ready, knowledge=" + KNOWLEDGE_BASE.length);
        } catch (Exception e) { AppLogger.logException(this, "ChatBot", e); finish(); }
    }

    private void sendMessage() {
        String text = inputMessage.getText().toString().trim();
        if (TextUtils.isEmpty(text)) return;
        AppLogger.log(this, "ChatBot", "User: " + text);
        Message um = new Message(); um.setId(UUID.randomUUID().toString()); um.setText(text);
        um.setTimestamp(System.currentTimeMillis()); um.setSent(true);
        messages.add(um); adapter.notifyItemInserted(messages.size()-1);
        recyclerView.scrollToPosition(messages.size()-1); inputMessage.setText("");
        sendButton.setEnabled(false);
        handler.postDelayed(()->{
            addBotMessage(generateResponse(text));
            sendButton.setEnabled(true);
        }, 250+random.nextInt(350));
    }

    private void addBotMessage(String text) {
        Message m = new Message(); m.setId(UUID.randomUUID().toString()); m.setText(text);
        m.setTimestamp(System.currentTimeMillis()); m.setSent(false);
        messages.add(m); adapter.notifyItemInserted(messages.size()-1);
        recyclerView.scrollToPosition(messages.size()-1);
    }

    private String generateResponse(String input) {
        String lower = input.toLowerCase().trim();

        String sq = extractSearchQuery(lower);
        if (sq != null) return doSearch(sq);

        if (containsAny(lower, "привет","здравствуй","хай","hello")) return greetings[random.nextInt(greetings.length)];
        if (containsAny(lower, "шутк","анекдот","joke")) return jokes[random.nextInt(jokes.length)];
        if (containsAny(lower, "время","который час")) return new SimpleDateFormat("HH:mm",Locale.getDefault()).format(new Date());
        if (containsAny(lower, "дата","сегодня")) return new SimpleDateFormat("dd MMMM yyyy",new Locale("ru")).format(new Date());
        if (containsAny(lower, "монет","подбрось")) return random.nextBoolean()?"Орёл!":"Решка!";
        if (lower.matches(".*\\d+\\s*[+\\-*/]\\s*\\d+.*")) return calc(lower.replaceAll("\\s+",""));

        int bestLen = 0;
        String bestAnswer = null;
        for (String[] entry : KNOWLEDGE_BASE) {
            String[] keys = entry[0].split("\\|");
            for (String key : keys) {
                if (lower.contains(key) && key.length() > bestLen) {
                    bestLen = key.length();
                    bestAnswer = entry[1];
                }
            }
        }
        if (bestAnswer != null) return bestAnswer;

        if (containsAny(lower, "пока","bye")) return "До встречи!";
        if (containsAny(lower, "спасибо","спс")) return "Пожалуйста!";

        if (lower.length() > 4) return doSearch(input.trim());

        return "Спросите иначе или начните с \"найди\".";
    }

    private String extractSearchQuery(String lower) {
        String[] prefixes = {"найди", "поиск", "загугли", "google", "search", "find"};
        for (String p : prefixes) {
            if (lower.startsWith(p)) {
                String r = lower.substring(p.length());
                r = r.replaceFirst("^[:\\s]+", "").trim();
                if (r.length() >= 2) return r;
            }
        }
        return null;
    }

    private String doSearch(String query) {
        if (searchCache.containsKey(query)) {
            AppLogger.log(this, "ChatBot", "Cache: " + query);
            return searchCache.get(query);
        }
        if (isSearchingWeb) return "Подождите, обрабатываю предыдущий запрос...";

        isSearchingWeb = true;
        final String q = query;
        new Thread(() -> {
            String result = searchWikipedia(q);
            if (result == null) result = "Ничего не найдено: " + q;
            searchCache.put(q, result);
            AppLogger.log(ChatBotActivity.this, "ChatBot", "Search: " + q + " -> " + (result.startsWith("Ничего")?"FAIL":"OK"));
            final String fr = result;
            handler.post(() -> { addBotMessage(fr); isSearchingWeb = false; });
        }).start();
        return "Ищу: " + query + "...";
    }

    private boolean containsAny(String t, String... kw) { for(String k:kw) if(t.contains(k)) return true; return false; }

    private String calc(String e) {
        try {
            if(e.contains("+")){String[]p=e.split("\\+");return p[0]+"+"+p[1]+"="+(Long.parseLong(p[0])+Long.parseLong(p[1]));}
            if(e.contains("-")){String[]p=e.split("-");return p[0]+"-"+p[1]+"="+(Long.parseLong(p[0])-Long.parseLong(p[1]));}
            if(e.contains("*")){String[]p=e.split("\\*");return p[0]+"x"+p[1]+"="+(Long.parseLong(p[0])*Long.parseLong(p[1]));}
            if(e.contains("/")){String[]p=e.split("/");long b=Long.parseLong(p[1]);if(b==0)return"Нельзя!";return p[0]+"/"+p[1]+"="+(Long.parseLong(p[0])/b);}
            return e;
        } catch(Exception ex){ return "Ошибка."; }
    }

    private String searchWikipedia(String query) {
        try {
            String urlStr = "https://ru.wikipedia.org/w/api.php?action=query&list=search&srsearch="
                + URLEncoder.encode(query, "UTF-8") + "&format=json&srlimit=1&srprop=snippet";
            String json = httpGet(urlStr);
            if (json == null || json.length() < 100) return null;
            int si = json.indexOf("\"snippet\":\"");
            if (si < 0) return null;
            int start = si + 11, end = start;
            while (end < json.length() && !(json.charAt(end) == '"' && (end == start || json.charAt(end-1) != '\\'))) end++;
            if (end <= start) return null;
            String snippet = decodeUnicode(json.substring(start, end));
            snippet = cleanHtml(snippet);
            if (snippet.length() > 15) return "Wiki: " + snippet + "...";
            return null;
        } catch (Exception e) { return null; }
    }

    private String httpGet(String urlStr) {
        try {
            URL url = new URL(urlStr);
            HttpURLConnection c = (HttpURLConnection) url.openConnection();
            c.setConnectTimeout(8000); c.setReadTimeout(8000);
            c.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 10) AppleWebKit/537.36");
            BufferedReader r = new BufferedReader(new InputStreamReader(c.getInputStream(),"UTF-8"));
            StringBuilder sb = new StringBuilder(); String l;
            while ((l = r.readLine()) != null) sb.append(l);
            r.close(); c.disconnect();
            return sb.toString();
        } catch (Exception e) { return null; }
    }

    private String decodeUnicode(String input) {
        Pattern p = Pattern.compile("\\\\u([0-9a-fA-F]{4})");
        Matcher m = p.matcher(input);
        StringBuffer sb = new StringBuffer();
        while (m.find()) m.appendReplacement(sb, String.valueOf((char)Integer.parseInt(m.group(1),16)));
        m.appendTail(sb);
        return sb.toString();
    }

    private String cleanHtml(String html) {
        if (html == null) return "";
        String s = html;
        while (s.contains("<") && s.contains(">")) s = s.replaceAll("<[^>]*>", "");
        s = s.replace("&nbsp;"," ").replace("&amp;","&").replace("&lt;","<")
             .replace("&gt;",">").replace("&quot;","\"").replace("&laquo;","")
             .replace("&raquo;","").replace("&mdash;","-").replace("&ndash;","-");
        s = s.replaceAll("<[^>]*>", "").replaceAll("\\s+"," ").trim();
        return s;
    }

    private void applyThemeColors() {
        int bg=ThemeManager.getBackgroundColor(this), inp=ThemeManager.getInputBgColor(this),
            tc=ThemeManager.getTextColor(this), dc=ThemeManager.getDividerColor(this);
        recyclerView.setBackgroundColor(bg); inputMessage.setTextColor(tc); inputMessage.setHintTextColor(dc);
        GradientDrawable g=new GradientDrawable(); g.setColor(inp); g.setCornerRadius(20); g.setStroke(1,dc);
        inputMessage.setBackground(g);
    }
}