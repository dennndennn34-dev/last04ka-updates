package com.last04ka.messenger.ui;

import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.os.Bundle;
import android.os.Handler;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import com.last04ka.messenger.utils.AppLogger;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class StopwatchActivity extends Activity {

    private TextView display, lapsText;
    private Button btnStartStop, btnLapReset, btnCopy;
    private Handler handler = new Handler();
    private long startTime, pausedTime = 0;
    private boolean running = false, paused = false;
    private List<Long> laps = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        try {
            AppLogger.log(this, "Stopwatch", "onCreate started");

            LinearLayout layout = new LinearLayout(this);
            layout.setOrientation(LinearLayout.VERTICAL);
            layout.setPadding(16, 16, 16, 16);
            layout.setBackgroundColor(0xFF1A1A2E);

            display = new TextView(this);
            display.setText("00:00.00"); display.setTextSize(40);
            display.setTextColor(0xFFFFFFFF); display.setGravity(Gravity.CENTER);
            display.setPadding(16, 32, 16, 32); display.setBackgroundColor(0xFF333333);
            layout.addView(display);

            LinearLayout btnRow = new LinearLayout(this);
            btnRow.setOrientation(LinearLayout.HORIZONTAL);

            btnStartStop = new Button(this); btnStartStop.setText("Старт");
            btnStartStop.setOnClickListener(v -> toggleStartStop()); btnRow.addView(btnStartStop);

            btnLapReset = new Button(this); btnLapReset.setText("Круг");
            btnLapReset.setEnabled(false);
            btnLapReset.setOnClickListener(v -> toggleLapReset()); btnRow.addView(btnLapReset);

            btnCopy = new Button(this); btnCopy.setText("Копир.");
            btnCopy.setOnClickListener(v -> copyLaps()); btnRow.addView(btnCopy);
            layout.addView(btnRow);

            lapsText = new TextView(this);
            lapsText.setTextSize(13); lapsText.setTextColor(0xFFBDBDBD); lapsText.setPadding(8, 8, 8, 8);
            ScrollView sv = new ScrollView(this); sv.addView(lapsText);
            layout.addView(sv);

            setContentView(layout);
            setTitle("⏱️ Секундомер");
            updateTimer();
            AppLogger.log(this, "Stopwatch", "onCreate completed");
        } catch (Exception e) { AppLogger.logException(this, "Stopwatch", e); finish(); }
    }

    private void toggleStartStop() {
        if (!running) {
            running = true; paused = false;
            startTime = System.currentTimeMillis() - pausedTime;
            btnStartStop.setText("Стоп"); btnLapReset.setText("Круг"); btnLapReset.setEnabled(true);
            handler.postDelayed(timerRunnable, 10);
        } else {
            running = false;
            pausedTime = System.currentTimeMillis() - startTime;
            btnStartStop.setText("Старт"); btnLapReset.setText("Сброс");
            handler.removeCallbacks(timerRunnable);
        }
    }

    private void toggleLapReset() {
        if (running) {
            laps.add(0, System.currentTimeMillis() - startTime);
            updateLapsDisplay();
            AppLogger.log(this, "Stopwatch", "Lap: " + formatTime(laps.get(0)));
        } else {
            laps.clear(); pausedTime = 0;
            lapsText.setText("Круги:\n");
            updateTimer();
            btnLapReset.setEnabled(false);
        }
    }

    private void copyLaps() {
        if (laps.isEmpty()) { Toast.makeText(this, "Нет кругов", Toast.LENGTH_SHORT).show(); return; }
        StringBuilder sb = new StringBuilder("Круги:\n");
        for (int i = 0; i < laps.size(); i++) sb.append("Круг ").append(i+1).append(": ").append(formatTime(laps.get(i))).append("\n");
        ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
        cm.setPrimaryClip(ClipData.newPlainText("laps", sb.toString()));
        Toast.makeText(this, "Круги скопированы", Toast.LENGTH_SHORT).show();
    }

    private void updateLapsDisplay() {
        StringBuilder sb = new StringBuilder("Круги:\n");
        for (int i = 0; i < laps.size(); i++) sb.append("Круг ").append(i+1).append(": ").append(formatTime(laps.get(i))).append("\n");
        lapsText.setText(sb.toString());
    }

    private String formatTime(long ms) {
        int mins = (int)(ms / 60000);
        int secs = (int)((ms % 60000) / 1000);
        int cents = (int)((ms % 1000) / 10);
        return String.format(Locale.US, "%02d:%02d.%02d", mins, secs, cents);
    }

    private void updateTimer() {
        long elapsed = paused ? pausedTime : (running ? System.currentTimeMillis() - startTime : pausedTime);
        display.setText(formatTime(elapsed));
    }

    private Runnable timerRunnable = new Runnable() {
        @Override public void run() {
            updateTimer();
            if (running) handler.postDelayed(this, 32);
        }
    };

    @Override protected void onDestroy() { super.onDestroy(); handler.removeCallbacks(timerRunnable); }
}