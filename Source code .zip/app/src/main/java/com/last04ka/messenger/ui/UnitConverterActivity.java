package com.last04ka.messenger.ui;

import android.app.Activity;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;
import com.last04ka.messenger.utils.AppLogger;

public class UnitConverterActivity extends Activity {

    private EditText inputValue;
    private Spinner categorySpinner, fromSpinner, toSpinner;
    private TextView resultText;

    private String[] categories = {"Длина", "Масса", "Объём", "Скорость", "Температура", "Площадь", "Давление", "Энергия"};

    private String[][] units = {
        {"Метр", "Километр", "Сантиметр", "Миллиметр", "Миля", "Фут", "Дюйм", "Ярд"},
        {"Грамм", "Килограмм", "Миллиграмм", "Тонна", "Фунт", "Унция"},
        {"Литр", "Миллилитр", "Галлон (US)", "Кварта", "Пинта", "Куб. метр"},
        {"м/с", "км/ч", "миль/ч", "узел", "фут/с"},
        {"Цельсий", "Фаренгейт", "Кельвин"},
        {"Кв. метр", "Кв. километр", "Гектар", "Акр", "Кв. фут"},
        {"Паскаль", "Бар", "Атмосфера", "мм рт. ст.", "PSI"},
        {"Джоуль", "Калория", "кВт·ч", "Электрон-вольт", "BTU"},
    };

    // Коэффициенты перевода в базовую единицу
    private double[][] factors = {
        {1, 1000, 0.01, 0.001, 1609.344, 0.3048, 0.0254, 0.9144},
        {0.001, 1, 0.000001, 1000, 0.453592, 0.0283495},
        {1, 0.001, 3.78541, 0.946353, 0.473176, 1000},
        {1, 0.277778, 0.44704, 0.514444, 0.3048},
        {1, 1, 1}, // Специальная обработка
        {1, 1000000, 10000, 4046.86, 0.092903},
        {1, 100000, 101325, 133.322, 6894.76},
        {1, 4.184, 3600000, 1.602e-19, 1055.06},
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        try {
            AppLogger.log(this, "UnitConverter", "onCreate v2.0 working");
            AppLogger.logUI(this, "UnitConverter", "8 categories", true);

            LinearLayout layout = new LinearLayout(this);
            layout.setOrientation(LinearLayout.VERTICAL);
            layout.setPadding(16, 16, 16, 16);
            layout.setBackgroundColor(0xFF1A1A2E);

            TextView title = new TextView(this);
            title.setText("📐 Конвертер единиц"); title.setTextSize(20);
            title.setTextColor(0xFFFFFFFF); title.setGravity(Gravity.CENTER);
            title.setPadding(0, 0, 0, 12);
            layout.addView(title);

            categorySpinner = new Spinner(this);
            categorySpinner.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, categories));
            layout.addView(categorySpinner);

            inputValue = new EditText(this);
            inputValue.setText("1"); inputValue.setTextColor(0xFFFFFFFF);
            inputValue.setBackgroundColor(0xFF333333); inputValue.setPadding(12, 10, 12, 10);
            layout.addView(inputValue);

            fromSpinner = new Spinner(this);
            toSpinner = new Spinner(this);
            updateUnitSpinners(0);

            layout.addView(fromSpinner);
            layout.addView(toSpinner);

            resultText = new TextView(this);
            resultText.setTextSize(20); resultText.setTextColor(0xFFFFD740);
            resultText.setGravity(Gravity.CENTER); resultText.setPadding(16, 16, 16, 16);
            resultText.setBackgroundColor(0xFF333333);
            resultText.setMinHeight(80);
            layout.addView(resultText);

            categorySpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                @Override public void onItemSelected(AdapterView<?> p, View v, int pos, long id) { updateUnitSpinners(pos); convert(); }
                @Override public void onNothingSelected(AdapterView<?> p) {}
            });
            inputValue.addTextChangedListener(new TextWatcher() {
                @Override public void beforeTextChanged(CharSequence s, int st, int c, int a) {}
                @Override public void onTextChanged(CharSequence s, int st, int b, int c) { convert(); }
                @Override public void afterTextChanged(Editable s) {}
            });
            fromSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                @Override public void onItemSelected(AdapterView<?> p, View v, int pos, long id) { convert(); }
                @Override public void onNothingSelected(AdapterView<?> p) {}
            });
            toSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                @Override public void onItemSelected(AdapterView<?> p, View v, int pos, long id) { convert(); }
                @Override public void onNothingSelected(AdapterView<?> p) {}
            });

            setContentView(layout);
            setTitle("📐 Конвертер единиц");
            convert();
            AppLogger.log(this, "UnitConverter", "onCreate completed");
        } catch (Exception e) { AppLogger.logException(this, "UnitConverter", e); finish(); }
    }

    private void updateUnitSpinners(int cat) {
        ArrayAdapter<String> ad = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, units[cat]);
        fromSpinner.setAdapter(ad); toSpinner.setAdapter(ad);
        if (units[cat].length > 1) toSpinner.setSelection(1);
    }

    private void convert() {
        try {
            int cat = categorySpinner.getSelectedItemPosition();
            int from = fromSpinner.getSelectedItemPosition();
            int to = toSpinner.getSelectedItemPosition();
            if (from < 0 || to < 0) return;
            double val = Double.parseDouble(inputValue.getText().toString());

            double result;
            if (cat == 4) { // Температура — специальная формула
                double celsius;
                if (from == 0) celsius = val;
                else if (from == 1) celsius = (val - 32) * 5.0 / 9.0;
                else celsius = val - 273.15;
                if (to == 0) result = celsius;
                else if (to == 1) result = celsius * 9.0 / 5.0 + 32;
                else result = celsius + 273.15;
            } else {
                double base = val * factors[cat][from];
                result = base / factors[cat][to];
            }

            resultText.setText(String.format("%.6g %s = %.6g %s", val, units[cat][from], result, units[cat][to]));
            AppLogger.log(this, "UnitConverter", val + " " + units[cat][from] + " = " + result + " " + units[cat][to]);
        } catch (Exception e) {
            resultText.setText("Ошибка ввода");
            AppLogger.logException(this, "UnitConverter", e);
        }
    }
}