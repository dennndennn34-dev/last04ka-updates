package com.last04ka.messenger.ui;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import com.last04ka.messenger.utils.AppLogger;
import com.last04ka.messenger.utils.GameScores;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Random;

public class LiteratureQuizActivity extends Activity {

    private TextView questionText, scoreText;
    private Button[] btns = new Button[5];
    private int current = 0, score = 0, total = 25;
    private List<String[]> pool = new ArrayList<>(), selected = new ArrayList<>();
    private Random r = new Random();

    private String[][] data = {
        {"Кто написал 'Войну и мир'?", "Достоевский", "Толстой", "Пушкин", "Гоголь", "Тургенев", "1"},
        {"Кто написал 'Преступление и наказание'?", "Толстой", "Достоевский", "Чехов", "Гоголь", "Тургенев", "1"},
        {"Кто написал 'Мастера и Маргариту'?", "Булгаков", "Чехов", "Тургенев", "Набоков", "Горький", "0"},
        {"Кто написал 'Евгений Онегин'?", "Лермонтов", "Пушкин", "Грибоедов", "Тургенев", "Гоголь", "1"},
        {"Кто написал 'Герой нашего времени'?", "Пушкин", "Лермонтов", "Гоголь", "Тургенев", "Чехов", "1"},
        {"Кто написал 'Мёртвые души'?", "Пушкин", "Лермонтов", "Гоголь", "Тургенев", "Чехов", "2"},
        {"Кто написал 'Отцы и дети'?", "Толстой", "Достоевский", "Тургенев", "Гончаров", "Чехов", "2"},
        {"Кто написал 'Обломов'?", "Тургенев", "Гончаров", "Толстой", "Достоевский", "Чехов", "1"},
        {"Кто написал 'Вишнёвый сад'?", "Толстой", "Достоевский", "Тургенев", "Чехов", "Горький", "3"},
        {"Кто написал 'На дне'?", "Чехов", "Горький", "Толстой", "Достоевский", "Булгаков", "1"},
        {"Кто написал 'Собачье сердце'?", "Горький", "Чехов", "Булгаков", "Набоков", "Платонов", "2"},
        {"Кто написал 'Лолиту'?", "Булгаков", "Чехов", "Тургенев", "Набоков", "Горький", "3"},
        {"Кто написал 'Тихий Дон'?", "Шолохов", "Булгаков", "Горький", "Чехов", "Толстой", "0"},
        {"Кто написал 'Доктор Живаго'?", "Шолохов", "Пастернак", "Булгаков", "Горький", "Солженицын", "1"},
        {"Кто написал 'Архипелаг ГУЛАГ'?", "Пастернак", "Шолохов", "Солженицын", "Булгаков", "Горький", "2"},
        {"Кто написал '1984'?", "Хаксли", "Оруэлл", "Брэдбери", "Голдинг", "Кларк", "1"},
        {"Кто написал 'Ромео и Джульетту'?", "Диккенс", "Шекспир", "Гюго", "Толстой", "Байрон", "1"},
        {"Кто написал 'Дон Кихот'?", "Сервантес", "Шекспир", "Гюго", "Бальзак", "Диккенс", "0"},
        {"Кто написал 'Отверженные'?", "Бальзак", "Гюго", "Флобер", "Золя", "Стендаль", "1"},
        {"Кто написал 'Анну Каренину'?", "Достоевский", "Тургенев", "Толстой", "Гончаров", "Чехов", "2"},
        {"Кто написал 'Ревизор'?", "Пушкин", "Лермонтов", "Тургенев", "Гоголь", "Чехов", "3"},
        {"Кто написал 'Горе от ума'?", "Пушкин", "Грибоедов", "Лермонтов", "Гоголь", "Тургенев", "1"},
        {"Кто написал 'Капитанскую дочку'?", "Лермонтов", "Пушкин", "Гоголь", "Тургенев", "Толстой", "1"},
        {"Кто написал 'Тарас Бульба'?", "Пушкин", "Лермонтов", "Тургенев", "Гоголь", "Чехов", "3"},
        {"Кто написал 'Дубровский'?", "Лермонтов", "Гоголь", "Пушкин", "Тургенев", "Толстой", "2"},
        // ... ещё 275+ вопросов (формат: {вопрос, отв1, отв2, отв3, отв4, отв5, индекс})
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        try {
            AppLogger.log(this, "LitQuiz", "onCreate started");
            LinearLayout layout = new LinearLayout(this);
            layout.setOrientation(LinearLayout.VERTICAL);
            layout.setPadding(24, 24, 24, 24);
            layout.setBackgroundColor(0xFF252525);

            scoreText = new TextView(this);
            scoreText.setText("Счёт: 0 / " + total + " | Рекорд: " + GameScores.getScore(this, "litquiz"));
            scoreText.setTextSize(14); scoreText.setTextColor(0xFFBDBDBD);
            layout.addView(scoreText);

            questionText = new TextView(this);
            questionText.setTextSize(16); questionText.setTextColor(0xFFFFFFFF);
            questionText.setPadding(0, 16, 0, 16); layout.addView(questionText);

            for (int i = 0; i < 5; i++) {
                final int idx = i;
                btns[i] = new Button(this); btns[i].setTextSize(14); btns[i].setAllCaps(false);
                btns[i].setPadding(8, 12, 8, 12);
                btns[i].setOnClickListener(new View.OnClickListener() {
                    @Override public void onClick(View v) { checkAnswer(idx); }
                });
                layout.addView(btns[i]);
            }

            pool.addAll(Arrays.asList(data));
            Collections.shuffle(pool, r);
            for (int i = 0; i < Math.min(total, pool.size()); i++) selected.add(pool.get(i));

            setContentView(layout);
            setTitle("📚 Литература");
            showQuestion();
            AppLogger.log(this, "LitQuiz", "onCreate completed, questions: " + selected.size());
        } catch (Exception e) { AppLogger.logException(this, "LitQuiz", e); finish(); }
    }

    private void showQuestion() {
        if (current >= selected.size()) {
            questionText.setText("🏆 Итог: " + score + " из " + total);
            for (Button b : btns) b.setVisibility(View.GONE);
            GameScores.saveScore(this, "litquiz", score);
            return;
        }
        String[] q = selected.get(current);
        questionText.setText("Вопрос " + (current + 1) + "/" + total + ": " + q[0]);
        for (int i = 0; i < 5; i++) btns[i].setText(q[i + 1]);
    }

    private void checkAnswer(int idx) {
        if (current >= selected.size()) return;
        String[] q = selected.get(current);
        int correct = Integer.parseInt(q[6]);
        if (idx == correct) { score++; Toast.makeText(this, "✅", Toast.LENGTH_SHORT).show(); }
        else Toast.makeText(this, "❌ " + q[correct + 1], Toast.LENGTH_SHORT).show();
        scoreText.setText("Счёт: " + score + " / " + total + " | Рекорд: " + GameScores.getScore(this, "litquiz"));
        current++;
        showQuestion();
    }
}