package com.last04ka.messenger.utils;

import android.content.Context;
import android.content.SharedPreferences;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class StreakManager {
    private static final String TAG = "StreakManager";
    private static final String PREFS = "streak_prefs";
    private static final String KEY_STREAK_DAYS = "streak_days";
    private static final String KEY_BEST_STREAK = "best_streak";
    private static final String KEY_LAST_ACTIVE_DATE = "last_active_date";
    private static final String KEY_TODAY_TIME = "today_time_minutes";
    private static final String KEY_TOTAL_TIME = "total_time_minutes";

    private static final int MINUTES_REQUIRED = 25;

    public static void updateStreak(Context context) {
        AppLogger.log(context, TAG, "updateStreak() START");

        if (context == null) {
            AppLogger.log(null, TAG, "❌ context is null");
            return;
        }

        SharedPreferences prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        String today = getTodayDate();
        String lastActive = prefs.getString(KEY_LAST_ACTIVE_DATE, "");
        int todayMinutes = prefs.getInt(KEY_TODAY_TIME, 0);

        AppLogger.log(context, TAG, "📅 Today: " + today + ", lastActive: " + lastActive + ", todayMinutes: " + todayMinutes);

        if (!today.equals(lastActive)) {
            AppLogger.log(context, TAG, "📅 New day detected");

            if (!lastActive.isEmpty()) {
                if (isYesterday(lastActive)) {
                    AppLogger.log(context, TAG, "📅 Yesterday was active");
                    if (todayMinutes >= MINUTES_REQUIRED) {
                        int streak = prefs.getInt(KEY_STREAK_DAYS, 0) + 1;
                        prefs.edit().putInt(KEY_STREAK_DAYS, streak).apply();
                        updateBestStreak(context, streak);
                        AppLogger.log(context, TAG, "🔥 Streak increased to " + streak);
                    } else {
                        prefs.edit().putInt(KEY_STREAK_DAYS, 0).apply();
                        AppLogger.log(context, TAG, "❌ Streak reset (not enough time yesterday)");
                    }
                } else {
                    prefs.edit().putInt(KEY_STREAK_DAYS, 0).apply();
                    AppLogger.log(context, TAG, "❌ Streak reset (day skipped)");
                }
            } else {
                // Первый день
                if (todayMinutes >= MINUTES_REQUIRED) {
                    prefs.edit().putInt(KEY_STREAK_DAYS, 1).apply();
                    updateBestStreak(context, 1);
                    AppLogger.log(context, TAG, "🔥 First streak day started");
                } else {
                    AppLogger.log(context, TAG, "⏳ First day but not enough time yet");
                }
            }

            // Сохраняем дату и сбрасываем время для нового дня
            prefs.edit().putString(KEY_LAST_ACTIVE_DATE, today).apply();
            prefs.edit().putInt(KEY_TODAY_TIME, 0).apply();
            AppLogger.log(context, TAG, "📅 Reset today time for new day");

        } else {
            AppLogger.log(context, TAG, "📅 Same day, checking completion");
            if (todayMinutes >= MINUTES_REQUIRED) {
                int currentStreak = prefs.getInt(KEY_STREAK_DAYS, 0);
                if (currentStreak == 0 && !lastActive.isEmpty()) {
                    prefs.edit().putInt(KEY_STREAK_DAYS, 1).apply();
                    updateBestStreak(context, 1);
                    AppLogger.log(context, TAG, "🔥 Streak started today");
                }
            }
        }

        int finalStreak = prefs.getInt(KEY_STREAK_DAYS, 0);
        int finalBest = prefs.getInt(KEY_BEST_STREAK, 0);
        AppLogger.log(context, TAG, "updateStreak() END: streak=" + finalStreak + ", best=" + finalBest);
    }

    private static void updateBestStreak(Context context, int currentStreak) {
        SharedPreferences prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        int best = prefs.getInt(KEY_BEST_STREAK, 0);
        if (currentStreak > best) {
            prefs.edit().putInt(KEY_BEST_STREAK, currentStreak).apply();
            AppLogger.log(context, TAG, "🏆 New best streak: " + currentStreak);
        }
    }

    public static void addTime(Context context, int minutes) {
        AppLogger.log(context, TAG, "addTime() minutes=" + minutes);

        if (context == null) {
            AppLogger.log(null, TAG, "❌ context is null");
            return;
        }

        SharedPreferences prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        int today = prefs.getInt(KEY_TODAY_TIME, 0) + minutes;
        int total = prefs.getInt(KEY_TOTAL_TIME, 0) + minutes;

        prefs.edit().putInt(KEY_TODAY_TIME, today).apply();
        prefs.edit().putInt(KEY_TOTAL_TIME, total).apply();

        AppLogger.log(context, TAG, "⏱ Added " + minutes + " min. Today: " + today + ", Total: " + total);

        // Всегда обновляем серию после добавления времени
        updateStreak(context);
    }

    public static int getStreakDays(Context context) {
        if (context == null) return 0;
        return context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getInt(KEY_STREAK_DAYS, 0);
    }

    public static int getBestStreak(Context context) {
        if (context == null) return 0;
        return context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getInt(KEY_BEST_STREAK, 0);
    }

    public static int getTodayMinutes(Context context) {
        if (context == null) return 0;
        return context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getInt(KEY_TODAY_TIME, 0);
    }

    public static int getTotalMinutes(Context context) {
        if (context == null) return 0;
        return context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getInt(KEY_TOTAL_TIME, 0);
    }

    public static boolean isTodayComplete(Context context) {
        return getTodayMinutes(context) >= MINUTES_REQUIRED;
    }

    public static String getRingColor(int streakDays) {
        if (streakDays >= 100) return "#FF6B6B";
        if (streakDays >= 60) return "#FFD700";
        if (streakDays >= 30) return "#C0C0C0";
        if (streakDays >= 10) return "#CD7F32";
        return "#000000";
    }

    public static String getRingName(int streakDays) {
        if (streakDays >= 100) return "💎 Алмазный";
        if (streakDays >= 60) return "🥇 Золотой";
        if (streakDays >= 30) return "🥈 Серебряный";
        if (streakDays >= 10) return "🥉 Бронзовый";
        return "—";
    }

    private static String getTodayDate() {
        return new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(new Date());
    }

    private static boolean isYesterday(String date) {
        try {
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault());
            Date last = sdf.parse(date);
            Date today = new Date();
            long diff = today.getTime() - last.getTime();
            return diff >= 0 && diff < 48 * 60 * 60 * 1000;
        } catch (Exception e) {
            AppLogger.log(null, TAG, "isYesterday error: " + e.getMessage());
            return false;
        }
    }
}