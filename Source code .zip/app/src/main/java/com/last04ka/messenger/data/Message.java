package com.last04ka.messenger.data;

public class Message {
    private String id;
    private String chatId;
    private String text;
    private long timestamp;
    private boolean isSent;
    private boolean isVoice;
    private String voicePath;
    private int duration;

    // ==================== НОВЫЕ ПОЛЯ ДЛЯ ФАЙЛОВ ====================
    private boolean hasFile;
    private String fileName;
    private String filePath;
    private long fileSize;
    private String mimeType;

    // ==================== ГЕТТЕРЫ И СЕТТЕРЫ ====================

    public String getId() { return id; }
    public void setId(String id) { this.id = id; }

    public String getChatId() { return chatId; }
    public void setChatId(String chatId) { this.chatId = chatId; }

    public String getText() { return text; }
    public void setText(String text) { this.text = text; }

    public long getTimestamp() { return timestamp; }
    public void setTimestamp(long timestamp) { this.timestamp = timestamp; }

    public boolean isSent() { return isSent; }
    public void setSent(boolean sent) { isSent = sent; }

    public boolean isVoice() { return isVoice; }
    public void setVoice(boolean voice) { isVoice = voice; }

    public String getVoicePath() { return voicePath; }
    public void setVoicePath(String voicePath) { this.voicePath = voicePath; }

    public int getDuration() { return duration; }
    public void setDuration(int duration) { this.duration = duration; }

    // ==================== ГЕТТЕРЫ/СЕТТЕРЫ ДЛЯ ФАЙЛОВ ====================

    public boolean hasFile() { return hasFile; }
    public void setHasFile(boolean hasFile) { this.hasFile = hasFile; }

    public String getFileName() { return fileName; }
    public void setFileName(String fileName) { this.fileName = fileName; }

    public String getFilePath() { return filePath; }
    public void setFilePath(String filePath) { this.filePath = filePath; }

    public long getFileSize() { return fileSize; }
    public void setFileSize(long fileSize) { this.fileSize = fileSize; }

    public String getMimeType() { return mimeType; }
    public void setMimeType(String mimeType) { this.mimeType = mimeType; }
}