package com.last04ka.messenger.ui;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.os.Handler;
import android.view.Gravity;
import android.view.View;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import com.last04ka.messenger.utils.AppLogger;
import java.net.HttpURLConnection;
import java.net.URL;

public class SpeedTestActivity extends Activity {

    private WebView webView;
    private TextView statusText;
    private Button btnStart, btnSelectServer;
    private Handler handler = new Handler();

    private String currentUrl = "https://speedtest.rt.ru/";
    private String currentName = "Speedtest (Ростелеком)";

    private String[][] servers = {
        {"https://speedtest.rt.ru/", "Speedtest (Ростелеком)"},
        {"https://yandex.ru/internet/", "Интернетометр (Яндекс)"},
        {"https://www.speedtest.net/", "Speedtest (Ookla)"},
        {"https://fast.com/", "Fast.com (Netflix)"},
        {"https://speedof.me/", "SpeedOf.me"},
        {"https://testmy.net/", "TestMy.net"},
        {"https://openspeedtest.com/", "OpenSpeedTest"},
        {"https://speedtest.telstra.com/", "Telstra Speedtest"},
        {"https://www.bandwidthplace.com/", "Bandwidth Place"},
        {"https://speedtest.ph/", "Speedtest PH"},
        {"https://speedtest.pl/", "Speedtest PL"},
        {"https://www.nperf.com/", "nPerf"},
        {"https://speedtest.vn/", "Speedtest VN"},
        {"https://www.speed.io/", "Speed.io"},
        {"https://internet-svarka.ru/speedtest/", "Интернет-Сварка"},
        {"https://2ip.ru/speed/", "2ip.ru Спидтест"},
        {"https://pr-cy.ru/speed_test/", "PR-CY Спидтест"},
        {"https://www.wifispeedtest.ru/", "WiFi Speedtest"},
    };

    private boolean[] serverStatus = new boolean[servers.length];
    private boolean checkedOnce = false;
    private boolean checkingInProgress = false;
    private AlertDialog currentDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        try {
            AppLogger.log(this, "SpeedTest", "onCreate started");
            LinearLayout layout = new LinearLayout(this);
            layout.setOrientation(LinearLayout.VERTICAL);
            layout.setPadding(8, 8, 8, 8);
            layout.setBackgroundColor(0xFF1A1A2E);

            statusText = new TextView(this);
            statusText.setText("Загрузка " + currentName + "...");
            statusText.setTextSize(12); statusText.setTextColor(0xFFBDBDBD);
            statusText.setGravity(Gravity.CENTER); statusText.setPadding(0, 4, 0, 4);
            layout.addView(statusText);

            webView = new WebView(this);
            webView.getSettings().setJavaScriptEnabled(true);
            webView.getSettings().setDomStorageEnabled(true);
            webView.getSettings().setUseWideViewPort(true);
            webView.getSettings().setLoadWithOverviewMode(true);
            webView.getSettings().setUserAgentString(
                "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36"
            );
            webView.setWebViewClient(new WebViewClient() {
                @Override public void onPageFinished(WebView view, String url) {
                    statusText.setText(currentName + " ✓ Загружено");
                }
                @Override public void onReceivedError(WebView view, int errorCode, String description, String failingUrl) {
                    statusText.setText(currentName + " ✗ Ошибка");
                }
            });
            webView.setWebChromeClient(new WebChromeClient());
            LinearLayout.LayoutParams wp = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1);
            webView.setLayoutParams(wp);
            layout.addView(webView);

            LinearLayout btnRow = new LinearLayout(this);
            btnRow.setOrientation(LinearLayout.HORIZONTAL);
            btnRow.setGravity(Gravity.CENTER);

            btnSelectServer = new Button(this); btnSelectServer.setText("Выбрать сервис"); btnSelectServer.setTextSize(14);
            btnSelectServer.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) { showServerDialog(); }
            });
            btnRow.addView(btnSelectServer);

            btnStart = new Button(this); btnStart.setText("Перезагрузить"); btnStart.setTextSize(14);
            btnStart.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) { loadCurrentServer(); }
            });
            btnRow.addView(btnStart);

            layout.addView(btnRow);
            setContentView(layout);
            setTitle("📶 Спидтест");
            loadCurrentServer();
            AppLogger.log(this, "SpeedTest", "onCreate completed");
        } catch (Exception e) { AppLogger.logException(this, "SpeedTest", e); finish(); }
    }

    private void loadCurrentServer() {
        statusText.setText("Загрузка " + currentName + "...");
        webView.loadUrl(currentUrl);
    }

    private void showServerDialog() {
        final String[] items = new String[servers.length];
        for (int i = 0; i < servers.length; i++) {
            String icon;
            if (servers[i][0].equals(currentUrl)) icon = "★ ";
            else if (!checkedOnce) icon = "○ ";
            else if (serverStatus[i]) icon = "✅ ";
            else icon = "❌ ";
            items[i] = icon + servers[i][1];
        }

        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        int working = 0; for (boolean s : serverStatus) if (s) working++;
        String title = checkedOnce ? ("Выберите сервис (" + working + "/" + servers.length + " работают)") : "Выберите сервис";

        builder.setTitle(title);
        builder.setItems(items, new DialogInterface.OnClickListener() {
            @Override public void onClick(DialogInterface dialog, int which) {
                currentUrl = servers[which][0]; currentName = servers[which][1];
                setTitle("📶 " + currentName); loadCurrentServer();
                currentDialog = null;
            }
        });

        builder.setNeutralButton("🔍 Проверить ВСЕ", new DialogInterface.OnClickListener() {
            @Override public void onClick(DialogInterface dialog, int which) {
                // Не закрываем диалог — вместо этого запускаем проверку с ProgressDialog
                checkAllServersWithProgress();
            }
        });

        builder.setNegativeButton("Закрыть", new DialogInterface.OnClickListener() {
            @Override public void onClick(DialogInterface dialog, int which) {
                currentDialog = null;
            }
        });

        builder.setOnCancelListener(new DialogInterface.OnCancelListener() {
            @Override public void onCancel(DialogInterface dialog) {
                currentDialog = null;
            }
        });

        currentDialog = builder.create();
        currentDialog.show();
    }

    private void checkAllServersWithProgress() {
        if (checkingInProgress) return;
        checkingInProgress = true;

        // Закрываем диалог выбора серверов
        if (currentDialog != null && currentDialog.isShowing()) {
            currentDialog.dismiss();
            currentDialog = null;
        }

        // Показываем ProgressDialog
        final ProgressDialog progressDialog = new ProgressDialog(this);
        progressDialog.setTitle("Проверка сервисов");
        progressDialog.setMessage("Проверка 0/" + servers.length + "...");
        progressDialog.setMax(servers.length);
        progressDialog.setProgressStyle(ProgressDialog.STYLE_HORIZONTAL);
        progressDialog.setCancelable(false);
        progressDialog.setButton(DialogInterface.BUTTON_NEGATIVE, "Отмена", new DialogInterface.OnClickListener() {
            @Override public void onClick(DialogInterface dialog, int which) {
                checkingInProgress = false;
                progressDialog.dismiss();
            }
        });
        progressDialog.show();

        AppLogger.log(this, "SpeedTest", "Starting server check...");

        // Сбрасываем статусы
        for (int i = 0; i < serverStatus.length; i++) serverStatus[i] = false;

        new Thread(new Runnable() {
            @Override public void run() {
                for (int i = 0; i < servers.length; i++) {
                    if (!checkingInProgress) break;

                    final int idx = i;
                    final String url = servers[i][0];
                    final String name = servers[i][1];

                    boolean works = checkUrl(url);
                    serverStatus[idx] = works;

                    final int done = i + 1;
                    final boolean fw = works;

                    handler.post(new Runnable() {
                        @Override public void run() {
                            if (progressDialog.isShowing()) {
                                progressDialog.setProgress(done);
                                progressDialog.setMessage("Проверка " + done + "/" + servers.length +
                                    " | " + name + ": " + (fw ? "✅" : "❌"));
                            }
                        }
                    });
                    AppLogger.log(SpeedTestActivity.this, "SpeedTest",
                        "Server [" + idx + "] " + name + ": " + (works ? "OK" : "FAIL"));
                    try { Thread.sleep(300); } catch (InterruptedException e) {}
                }

                checkedOnce = true;
                checkingInProgress = false;
                final int wc = getWorkingCount();

                handler.post(new Runnable() {
                    @Override public void run() {
                        if (progressDialog.isShowing()) progressDialog.dismiss();
                        statusText.setText("Проверка завершена! " + wc + "/" + servers.length + " работают. Выберите сервис.");
                        // Показываем обновлённый диалог
                        showServerDialog();
                    }
                });
                AppLogger.log(SpeedTestActivity.this, "SpeedTest", "Check done. Working: " + wc + "/" + servers.length);
            }
        }).start();
    }

    private int getWorkingCount() { int c = 0; for (boolean s : serverStatus) if (s) c++; return c; }

    private boolean checkUrl(String urlString) {
        try {
            URL url = new URL(urlString);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setConnectTimeout(7000);
            conn.setReadTimeout(7000);
            conn.setRequestMethod("HEAD");
            conn.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36");
            conn.setInstanceFollowRedirects(true);
            conn.connect();
            int code = conn.getResponseCode();
            conn.disconnect();
            return (code >= 200 && code < 400);
        } catch (Exception e) {
            return false;
        }
    }
}