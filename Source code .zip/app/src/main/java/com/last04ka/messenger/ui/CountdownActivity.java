package com.last04ka.messenger.ui;

import android.app.Activity;
import android.media.AudioManager;
import android.media.ToneGenerator;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import com.last04ka.messenger.utils.AppLogger;

public class CountdownActivity extends Activity {

    private TextView display;
    private EditText inputMin, inputSec;
    private Button btnStart, btnPause, btnReset;
    private CountDownTimer timer;
    private long remaining = 0;
    private boolean running = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        try {
            AppLogger.log(this, "Countdown", "onCreate started");
            LinearLayout layout = new LinearLayout(this);
            layout.setOrientation(LinearLayout.VERTICAL);
            layout.setPadding(16, 16, 16, 16);
            layout.setBackgroundColor(0xFF1A1A2E);

            TextView title = new TextView(this);
            title.setText("⏲ Таймер"); title.setTextSize(20);
            title.setTextColor(0xFFFFFFFF); title.setGravity(Gravity.CENTER);
            layout.addView(title);

            display = new TextView(this);
            display.setText("00:00"); display.setTextSize(48);
            display.setTextColor(0xFFFFD740); display.setGravity(Gravity.CENTER);
            display.setPadding(0, 20, 0, 20);
            layout.addView(display);

            LinearLayout inputRow = new LinearLayout(this);
            inputRow.setGravity(Gravity.CENTER);
            inputMin = new EditText(this); inputMin.setText("0"); inputMin.setTextColor(0xFFFFFFFF);
            inputMin.setBackgroundColor(0xFF333333); inputMin.setWidth(100); inputMin.setTextSize(16);
            inputRow.addView(inputMin);
            TextView colon = new TextView(this); colon.setText(" : "); colon.setTextColor(0xFFFFFFFF); colon.setTextSize(16);
            inputRow.addView(colon);
            inputSec = new EditText(this); inputSec.setText("30"); inputSec.setTextColor(0xFFFFFFFF);
            inputSec.setBackgroundColor(0xFF333333); inputSec.setWidth(100); inputSec.setTextSize(16);
            inputRow.addView(inputSec);
            layout.addView(inputRow);

            LinearLayout btnRow = new LinearLayout(this);
            btnRow.setGravity(Gravity.CENTER);
            btnStart = new Button(this); btnStart.setText("Старт");
            btnStart.setOnClickListener(v -> startTimer()); btnRow.addView(btnStart);
            btnPause = new Button(this); btnPause.setText("Пауза"); btnPause.setEnabled(false);
            btnPause.setOnClickListener(v -> pauseTimer()); btnRow.addView(btnPause);
            btnReset = new Button(this); btnReset.setText("Сброс");
            btnReset.setOnClickListener(v -> resetTimer()); btnRow.addView(btnReset);
            layout.addView(btnRow);

            setContentView(layout); setTitle("⏲ Таймер");
            AppLogger.log(this, "Countdown", "onCreate completed");
        } catch (Exception e) { AppLogger.logException(this, "Countdown", e); finish(); }
    }

    private void startTimer() {
        if (running) return;
        long mins = Long.parseLong(inputMin.getText().toString());
        long secs = Long.parseLong(inputSec.getText().toString());
        remaining = (mins * 60 + secs) * 1000;
        if (remaining <= 0) { Toast.makeText(this, "Введите время", Toast.LENGTH_SHORT).show(); return; }
        running = true; btnStart.setEnabled(false); btnPause.setEnabled(true);
        timer = new CountDownTimer(remaining, 100) {
            @Override public void onTick(long millisUntilFinished) {
                remaining = millisUntilFinished;
                display.setText(String.format("%02d:%02d.%01d", millisUntilFinished/60000, (millisUntilFinished/1000)%60, (millisUntilFinished/100)%10));
            }
            @Override public void onFinish() {
                display.setText("00:00.0"); running = false; btnStart.setEnabled(true); btnPause.setEnabled(false);
                ToneGenerator tg = new ToneGenerator(AudioManager.STREAM_ALARM, 100);
                tg.startTone(ToneGenerator.TONE_CDMA_ALERT_CALL_GUARD, 2000);
                AppLogger.log(CountdownActivity.this, "Countdown", "Timer finished");
            }
        }.start();
        AppLogger.log(this, "Countdown", "Timer started: " + remaining/1000 + "s");
    }

    private void pauseTimer() {
        if (timer != null) { timer.cancel(); running = false; }
        btnStart.setEnabled(true); btnPause.setEnabled(false);
    }

    private void resetTimer() {
        if (timer != null) timer.cancel();
        running = false; remaining = 0;
        display.setText("00:00.0");
        btnStart.setEnabled(true); btnPause.setEnabled(false);
    }

    @Override protected void onDestroy() { super.onDestroy(); if (timer != null) timer.cancel(); }
}