package com.last04ka.messenger.utils;

import android.app.AlertDialog;
import android.app.DownloadManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.support.v4.content.FileProvider;
import android.widget.Toast;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.File;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

public class UpdateManager {
    private static final String TAG = "UpdateManager";
    private static final String UPDATE_URL = "https://dennndennn34-dev.github.io/last04ka-updates/update.json";

    private Context context;
    private Handler mainHandler = new Handler(Looper.getMainLooper());
    private UpdateListener listener;
    private boolean isChecking = false;
    private boolean isDownloading = false;

    public interface UpdateListener {
        void onUpdateAvailable(String versionName, String message, String downloadUrl);
        void onNoUpdate();
        void onError(String error);
        void onUpdateStarted();
    }

    public UpdateManager(Context context) {
        this.context = context;
        AppLogger.log(context, TAG, "UpdateManager initialized");
    }

    public void setListener(UpdateListener listener) {
        this.listener = listener;
    }

    // Обычная проверка (используется в MainActivity для ручной или тихой проверки)
    public void checkForUpdates(boolean showNoUpdateToast) {
        if (isChecking) {
            AppLogger.log(context, TAG, "Already checking for updates");
            return;
        }

        if (!isNetworkAvailable()) {
            AppLogger.log(context, TAG, "No internet connection");
            if (showNoUpdateToast && listener != null) {
                listener.onError("Нет подключения к интернету");
            }
            return;
        }

        isChecking = true;
        AppLogger.log(context, TAG, "🔍 Checking for updates...");

        if (listener != null) {
            listener.onUpdateStarted();
        }

        new Thread(() -> {
            try {
                URL url = new URL(UPDATE_URL);
                HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                connection.setRequestMethod("GET");
                connection.setConnectTimeout(10000);
                connection.setReadTimeout(10000);
                connection.setRequestProperty("User-Agent", "Last04ka Android App");

                int responseCode = connection.getResponseCode();
                AppLogger.log(context, TAG, "Response code: " + responseCode);

                if (responseCode == HttpURLConnection.HTTP_OK) {
                    BufferedReader reader = new BufferedReader(
                            new InputStreamReader(connection.getInputStream())
                    );
                    StringBuilder response = new StringBuilder();
                    String line;
                    while ((line = reader.readLine()) != null) {
                        response.append(line);
                    }
                    reader.close();

                    AppLogger.log(context, TAG, "📥 Received JSON: " + response.toString());

                    JSONObject json = new JSONObject(response.toString());
                    int serverVersion = json.getInt("version_code");
                    String versionName = json.getString("version_name");
                    String downloadUrl = json.getString("download_url");
                    String updateMessage = json.getString("update_message");

                    int currentVersion = getCurrentVersionCode();
                    AppLogger.log(context, TAG, "Current: " + currentVersion + ", Server: " + serverVersion);

                    if (serverVersion > currentVersion) {
                        AppLogger.log(context, TAG, "✅ Update available: " + versionName);
                        mainHandler.post(() -> {
                            if (listener != null) {
                                listener.onUpdateAvailable(versionName, updateMessage, downloadUrl);
                            }
                        });
                    } else {
                        AppLogger.log(context, TAG, "✅ No update needed");
                        if (showNoUpdateToast) {
                            mainHandler.post(() -> {
                                Toast.makeText(context, "У вас последняя версия", Toast.LENGTH_SHORT).show();
                                if (listener != null) {
                                    listener.onNoUpdate();
                                }
                            });
                        } else {
                            if (listener != null) {
                                listener.onNoUpdate();
                            }
                        }
                    }
                } else {
                    AppLogger.log(context, TAG, "❌ Server error: " + responseCode);
                    mainHandler.post(() -> {
                        if (listener != null) {
                            listener.onError("Ошибка сервера: " + responseCode);
                        }
                    });
                }
            } catch (Exception e) {
                AppLogger.logException(context, TAG, "Update check error", e);
                mainHandler.post(() -> {
                    if (listener != null) {
                        listener.onError("Ошибка: " + e.getMessage());
                    }
                });
            } finally {
                isChecking = false;
            }
        }).start();
    }

    // Новый метод: проверка с автоматическим показом уведомления (без тостов)
    public void checkForUpdateWithNotification() {
        if (isChecking) return;
        // Устанавливаем специальный слушатель, который показывает уведомление
        setListener(new UpdateListener() {
            @Override
            public void onUpdateAvailable(String versionName, String message, String downloadUrl) {
                // Показываем уведомление через хелпер
                UpdateNotificationHelper.showUpdateNotification(context, versionName, message, downloadUrl);
            }

            @Override
            public void onNoUpdate() {
                // Ничего не делаем
            }

            @Override
            public void onError(String error) {
                AppLogger.log(context, TAG, "Background update check error: " + error);
            }

            @Override
            public void onUpdateStarted() {
                // Не нужно
            }
        });
        checkForUpdates(false);
    }

    // Скачивание и установка
    public void downloadAndInstall(String downloadUrl) {
        if (isDownloading) {
            AppLogger.log(context, TAG, "Already downloading");
            return;
        }

        AppLogger.log(context, TAG, "📥 Starting download from: " + downloadUrl);

        try {
            File dir = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), "Last04ka");
            if (!dir.exists()) {
                dir.mkdirs();
            }

            String fileName = "Last04ka_update.apk";
            File file = new File(dir, fileName);

            if (file.exists()) {
                file.delete();
            }

            DownloadManager.Request request = new DownloadManager.Request(Uri.parse(downloadUrl));
            request.setTitle("Обновление Last04ka");
            request.setDescription("Скачивание новой версии...");
            request.setDestinationUri(Uri.fromFile(file));
            request.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
            request.setMimeType("application/vnd.android.package-archive");

            DownloadManager downloadManager = (DownloadManager) context.getSystemService(Context.DOWNLOAD_SERVICE);
            if (downloadManager != null) {
                long downloadId = downloadManager.enqueue(request);
                isDownloading = true;
                AppLogger.log(context, TAG, "✅ Download started, ID: " + downloadId);

                new Thread(() -> {
                    boolean finished = false;
                    while (!finished && isDownloading) {
                        try {
                            Thread.sleep(1000);
                            DownloadManager.Query query = new DownloadManager.Query();
                            query.setFilterById(downloadId);
                            android.database.Cursor cursor = downloadManager.query(query);
                            if (cursor.moveToFirst()) {
                                int status = cursor.getInt(cursor.getColumnIndex(DownloadManager.COLUMN_STATUS));
                                if (status == DownloadManager.STATUS_SUCCESSFUL) {
                                    finished = true;
                                    AppLogger.log(context, TAG, "✅ Download completed");
                                    mainHandler.post(() -> {
                                        isDownloading = false;
                                        installAPK(file);
                                    });
                                } else if (status == DownloadManager.STATUS_FAILED) {
                                    finished = true;
                                    isDownloading = false;
                                    AppLogger.log(context, TAG, "❌ Download failed");
                                    mainHandler.post(() -> {
                                        Toast.makeText(context, "Ошибка скачивания", Toast.LENGTH_SHORT).show();
                                    });
                                }
                            }
                            cursor.close();
                        } catch (Exception e) {
                            AppLogger.logException(context, TAG, "Download tracking error", e);
                            break;
                        }
                    }
                    isDownloading = false;
                }).start();
            }
        } catch (Exception e) {
            AppLogger.logException(context, TAG, "Download error", e);
            isDownloading = false;
            mainHandler.post(() -> {
                Toast.makeText(context, "Ошибка: " + e.getMessage(), Toast.LENGTH_SHORT).show();
            });
        }
    }

    private void installAPK(File file) {
        AppLogger.log(context, TAG, "📲 Installing APK: " + file.getAbsolutePath());

        if (!file.exists()) {
            Toast.makeText(context, "Файл не найден", Toast.LENGTH_SHORT).show();
            return;
        }

        try {
            Intent intent = new Intent(Intent.ACTION_VIEW);
            Uri uri;

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                uri = FileProvider.getUriForFile(context,
                        context.getPackageName() + ".provider",
                        file
                );
                intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                intent.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
            } else {
                uri = Uri.fromFile(file);
            }

            intent.setDataAndType(uri, "application/vnd.android.package-archive");
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);

            context.startActivity(intent);
        } catch (Exception e) {
            AppLogger.logException(context, TAG, "Install error", e);
            Toast.makeText(context, "Ошибка установки: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    private int getCurrentVersionCode() {
        try {
            PackageInfo packageInfo = context.getPackageManager().getPackageInfo(context.getPackageName(), 0);
            return packageInfo.versionCode;
        } catch (PackageManager.NameNotFoundException e) {
            return 1;
        }
    }

    private boolean isNetworkAvailable() {
        ConnectivityManager cm = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
        if (cm != null) {
            NetworkInfo ni = cm.getActiveNetworkInfo();
            return ni != null && ni.isConnected();
        }
        return false;
    }

    public void showUpdateDialog(String versionName, String message, String downloadUrl) {
        AlertDialog.Builder builder = new AlertDialog.Builder(context);
        builder.setTitle("📢 Доступно обновление!");
        builder.setMessage("Версия " + versionName + "\n\n" + message);
        builder.setPositiveButton("Обновить", (dialog, which) -> {
            downloadAndInstall(downloadUrl);
        });
        builder.setNegativeButton("Позже", null);
        builder.setCancelable(false);
        builder.show();
    }

    public boolean isChecking() {
        return isChecking;
    }

    public boolean isDownloading() {
        return isDownloading;
    }
}