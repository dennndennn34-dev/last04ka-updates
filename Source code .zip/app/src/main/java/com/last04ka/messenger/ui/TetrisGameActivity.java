package com.last04ka.messenger.ui;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Vibrator;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.FrameLayout;  // ← ДОБАВИТЬ ЭТУ СТРОКУ
import android.widget.TextView;
import android.widget.Toast;

import com.last04ka.messenger.R;
import com.last04ka.messenger.utils.AppLogger;
import com.last04ka.messenger.utils.GameScores;
import com.last04ka.messenger.utils.ThemeManager;

import java.util.Arrays;
import java.util.Random;
import java.util.Timer;
import java.util.TimerTask;

public class TetrisGameActivity extends AppCompatActivity {
    
    private static final String TAG = "TetrisGame";
    
    private static final int COLS = 10;
    private static final int ROWS = 20;
    private static final int CELL_SIZE = 35;
    
    // UI
    private Button btnLeft, btnRight, btnDown, btnRotate, btnDrop, btnPause, btnReset;
    private TextView tvScore, tvLevel, tvLines, tvNext, tvGameOver;
    private GameView gameView;
    
    // Игровое поле
    private int[][] board = new int[ROWS][COLS];
    private int[][] piece;
    private int pieceX, pieceY, pieceType;
    private int nextPieceType;
    private int score = 0;
    private int lines = 0;
    private int level = 1;
    private boolean isGameOver = false;
    private boolean isPaused = false;
    private Timer timer;
    private Handler handler = new Handler(Looper.getMainLooper());
    private Vibrator vibrator;
    private Random random = new Random();
    private int fallDelay = 500;
    
    // Цвета
    private static final int[] COLORS = {
        0,
        Color.rgb(255, 80, 80),   // 1
        Color.rgb(80, 255, 80),   // 2
        Color.rgb(80, 80, 255),   // 3
        Color.rgb(255, 255, 80),  // 4
        Color.rgb(255, 80, 255),  // 5
        Color.rgb(80, 255, 255),  // 6
        Color.rgb(255, 165, 0),   // 7
        Color.rgb(200, 100, 255), // 8
        Color.rgb(100, 255, 200), // 9
        Color.rgb(255, 200, 100), // 10
        Color.rgb(255, 100, 200), // 11
        Color.rgb(150, 200, 255), // 12
        Color.rgb(150, 255, 150), // 13
        Color.rgb(255, 150, 150)  // 14
    };
    
    // Фигуры
    private static final int[][][] SHAPES = {
        {{1,1,1,1}},
        {{1,1},{1,1}},
        {{0,1,0},{1,1,1}},
        {{0,1,1},{1,1,0}},
        {{1,1,0},{0,1,1}},
        {{1,0,0},{1,1,1}},
        {{0,0,1},{1,1,1}}
    };
    
    private static final int[] SHAPE_TYPES = {1,2,3,4,5,6,7};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        setTheme(ThemeManager.getThemeResource(this));
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tetris_game);
        
        initViews();
        initGame();
        setupListeners();
        
        vibrator = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
        
        AppLogger.log(this, TAG, "Tetris Game started");
    }
    
    private void initViews() {
        // Кнопки
        btnLeft = findViewById(R.id.btn_left);
        btnRight = findViewById(R.id.btn_right);
        btnDown = findViewById(R.id.btn_down);
        btnRotate = findViewById(R.id.btn_rotate);
        btnDrop = findViewById(R.id.btn_drop);
        btnPause = findViewById(R.id.btn_pause);
        btnReset = findViewById(R.id.btn_reset);
        
        // Тексты
        tvScore = findViewById(R.id.tv_score);
        tvLevel = findViewById(R.id.tv_level);
        tvLines = findViewById(R.id.tv_lines);
        tvNext = findViewById(R.id.tv_next);
        tvGameOver = findViewById(R.id.tv_game_over);
        
        // Игровое поле - добавляем поверх layout
        gameView = new GameView(this);
        FrameLayout gameFrame = findViewById(R.id.game_frame);
        if (gameFrame != null) {
            gameFrame.addView(gameView, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT));
        }
        
        AppLogger.log(this, TAG, "Views initialized");
    }
    
    private void initGame() {
        for (int i = 0; i < ROWS; i++) {
            Arrays.fill(board[i], 0);
        }
        
        nextPieceType = random.nextInt(SHAPES.length);
        spawnNewPiece();
        
        score = 0;
        lines = 0;
        level = 1;
        isGameOver = false;
        isPaused = false;
        fallDelay = 500;
        
        updateUI();
        startTimer();
        
        if (tvGameOver != null) tvGameOver.setVisibility(View.GONE);
        
        AppLogger.log(this, TAG, "Game initialized");
    }
    
    private void spawnNewPiece() {
        pieceType = nextPieceType;
        nextPieceType = random.nextInt(SHAPES.length);
        
        piece = copyShape(SHAPES[pieceType]);
        pieceX = COLS / 2 - piece[0].length / 2;
        pieceY = 0;
        
        if (collision()) {
            isGameOver = true;
            if (timer != null) timer.cancel();
            if (tvGameOver != null) tvGameOver.setVisibility(View.VISIBLE);
            Toast.makeText(this, "Game Over! Score: " + score, Toast.LENGTH_LONG).show();
            GameScores.saveScore(this, "tetris", score);
            AppLogger.log(this, TAG, "GAME OVER! Score: " + score);
        }
        
        updateNextDisplay();
        if (gameView != null) gameView.invalidate();
    }
    
    private int[][] copyShape(int[][] shape) {
        int[][] copy = new int[shape.length][shape[0].length];
        for (int i = 0; i < shape.length; i++) {
            System.arraycopy(shape[i], 0, copy[i], 0, shape[0].length);
        }
        return copy;
    }
    
    private boolean collision() {
        for (int i = 0; i < piece.length; i++) {
            for (int j = 0; j < piece[0].length; j++) {
                if (piece[i][j] == 1) {
                    int x = pieceX + j;
                    int y = pieceY + i;
                    if (x < 0 || x >= COLS || y >= ROWS) return true;
                    if (y >= 0 && board[y][x] != 0) return true;
                }
            }
        }
        return false;
    }
    
    private void merge() {
        for (int i = 0; i < piece.length; i++) {
            for (int j = 0; j < piece[0].length; j++) {
                if (piece[i][j] == 1) {
                    int x = pieceX + j;
                    int y = pieceY + i;
                    if (y >= 0 && y < ROWS && x >= 0 && x < COLS) {
                        board[y][x] = SHAPE_TYPES[pieceType];
                    }
                }
            }
        }
        
        clearLines();
        spawnNewPiece();
        if (gameView != null) gameView.invalidate();
    }
    
    private void clearLines() {
        int linesCleared = 0;
        
        for (int row = ROWS - 1; row >= 0; row--) {
            boolean full = true;
            for (int col = 0; col < COLS; col++) {
                if (board[row][col] == 0) {
                    full = false;
                    break;
                }
            }
            
            if (full) {
                for (int r = row; r > 0; r--) {
                    System.arraycopy(board[r - 1], 0, board[r], 0, COLS);
                }
                Arrays.fill(board[0], 0);
                linesCleared++;
                row++;
            }
        }
        
        if (linesCleared > 0) {
            lines += linesCleared;
            int addScore = linesCleared * 100 * level;
            score += addScore;
            
            int newLevel = lines / 10 + 1;
            if (newLevel > level) {
                level = newLevel;
                fallDelay = Math.max(100, 500 - (level - 1) * 30);
                restartTimer();
                AppLogger.log(this, TAG, "Level UP! Level: " + level);
            }
            
            updateUI();
            AppLogger.log(this, TAG, "Lines cleared: " + linesCleared + ", Score: " + score);
        }
    }
    
    private void moveLeft() {
        if (isGameOver || isPaused) return;
        pieceX--;
        if (collision()) pieceX++;
        if (gameView != null) gameView.invalidate();
    }
    
    private void moveRight() {
        if (isGameOver || isPaused) return;
        pieceX++;
        if (collision()) pieceX--;
        if (gameView != null) gameView.invalidate();
    }
    
    private void moveDown() {
        if (isGameOver || isPaused) return;
        pieceY++;
        if (collision()) {
            pieceY--;
            merge();
        }
        if (gameView != null) gameView.invalidate();
    }
    
    private void rotate() {
        if (isGameOver || isPaused) return;
        
        int[][] rotated = new int[piece[0].length][piece.length];
        for (int i = 0; i < piece.length; i++) {
            for (int j = 0; j < piece[0].length; j++) {
                rotated[j][piece.length - 1 - i] = piece[i][j];
            }
        }
        
        int oldX = pieceX;
        int oldY = pieceY;
        int[][] oldPiece = piece;
        
        piece = rotated;
        
        if (collision()) {
            piece = oldPiece;
            pieceX = oldX;
            pieceY = oldY;
        }
        
        if (gameView != null) gameView.invalidate();
    }
    
    private void hardDrop() {
        if (isGameOver || isPaused) return;
        while (!collision()) {
            pieceY++;
        }
        pieceY--;
        merge();
        if (gameView != null) gameView.invalidate();
        if (vibrator != null) vibrator.vibrate(50);
    }
    
    private void togglePause() {
        isPaused = !isPaused;
        if (isPaused) {
            if (timer != null) timer.cancel();
            Toast.makeText(this, "Пауза", Toast.LENGTH_SHORT).show();
        } else {
            startTimer();
            Toast.makeText(this, "Продолжаем", Toast.LENGTH_SHORT).show();
        }
        if (gameView != null) gameView.invalidate();
    }
    
    private void resetGame() {
        if (timer != null) timer.cancel();
        initGame();
        startTimer();
        if (gameView != null) gameView.invalidate();
        Toast.makeText(this, "Новая игра", Toast.LENGTH_SHORT).show();
    }
    
    private void startTimer() {
        if (timer != null) timer.cancel();
        timer = new Timer();
        timer.scheduleAtFixedRate(new TimerTask() {
            @Override
            public void run() {
                if (!isGameOver && !isPaused) {
                    handler.post(() -> moveDown());
                }
            }
        }, fallDelay, fallDelay);
    }
    
    private void restartTimer() {
        if (timer != null) timer.cancel();
        startTimer();
    }
    
    private void updateUI() {
        runOnUiThread(() -> {
            if (tvScore != null) tvScore.setText(String.valueOf(score));
            if (tvLevel != null) tvLevel.setText(String.valueOf(level));
            if (tvLines != null) tvLines.setText(String.valueOf(lines));
        });
    }
    
    private void updateNextDisplay() {
        runOnUiThread(() -> {
            if (tvNext != null) {
                int[][] nextShape = SHAPES[nextPieceType];
                StringBuilder sb = new StringBuilder();
                for (int[] row : nextShape) {
                    for (int val : row) {
                        sb.append(val == 1 ? "█" : "░");
                    }
                    sb.append("\n");
                }
                tvNext.setText(sb.toString());
            }
        });
    }
    
    private void setupListeners() {
        if (btnLeft != null) btnLeft.setOnClickListener(v -> moveLeft());
        if (btnRight != null) btnRight.setOnClickListener(v -> moveRight());
        if (btnDown != null) btnDown.setOnClickListener(v -> moveDown());
        if (btnRotate != null) btnRotate.setOnClickListener(v -> rotate());
        if (btnDrop != null) btnDrop.setOnClickListener(v -> hardDrop());
        if (btnPause != null) btnPause.setOnClickListener(v -> togglePause());
        if (btnReset != null) btnReset.setOnClickListener(v -> resetGame());
        
        AppLogger.log(this, TAG, "Listeners configured");
    }
    
    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (timer != null) timer.cancel();
        AppLogger.log(this, TAG, "Tetris Game destroyed, final score: " + score);
    }
    
    // ==================== GAME VIEW ====================
    
    private class GameView extends View {
        private Paint borderPaint, gridPaint;
        private Paint[] blockPaints;
        private RectF rect = new RectF();
        private int offsetX, offsetY;
        
        public GameView(Context context) {
            super(context);
            initPaints();
        }
        
        private void initPaints() {
            borderPaint = new Paint();
            borderPaint.setStyle(Paint.Style.STROKE);
            borderPaint.setStrokeWidth(3);
            borderPaint.setColor(Color.WHITE);
            
            gridPaint = new Paint();
            gridPaint.setColor(Color.argb(40, 255, 255, 255));
            gridPaint.setStrokeWidth(1);
            
            blockPaints = new Paint[COLORS.length];
            for (int i = 1; i < COLORS.length; i++) {
                blockPaints[i] = new Paint();
                blockPaints[i].setColor(COLORS[i]);
            }
        }
        
        @Override
        protected void onSizeChanged(int w, int h, int oldw, int oldh) {
            int viewWidth = getWidth();
            int viewHeight = getHeight();
            offsetX = (viewWidth - COLS * CELL_SIZE) / 2;
            offsetY = (viewHeight - ROWS * CELL_SIZE) / 2;
        }
        
        @Override
        protected void onDraw(Canvas canvas) {
            canvas.drawColor(Color.rgb(20, 20, 40));
            
            // Сетка
            for (int i = 0; i <= ROWS; i++) {
                canvas.drawLine(offsetX, offsetY + i * CELL_SIZE,
                    offsetX + COLS * CELL_SIZE, offsetY + i * CELL_SIZE, gridPaint);
            }
            for (int i = 0; i <= COLS; i++) {
                canvas.drawLine(offsetX + i * CELL_SIZE, offsetY,
                    offsetX + i * CELL_SIZE, offsetY + ROWS * CELL_SIZE, gridPaint);
            }
            
            // Закреплённые блоки
            for (int row = 0; row < ROWS; row++) {
                for (int col = 0; col < COLS; col++) {
                    if (board[row][col] != 0) {
                        int colorIdx = board[row][col] % (COLORS.length - 1);
                        if (colorIdx == 0) colorIdx = 1;
                        drawBlock(canvas, col, row, blockPaints[colorIdx]);
                    }
                }
            }
            
            // Текущая фигура
            if (piece != null) {
                int colorIdx = SHAPE_TYPES[pieceType] % (COLORS.length - 1);
                if (colorIdx == 0) colorIdx = 1;
                for (int i = 0; i < piece.length; i++) {
                    for (int j = 0; j < piece[0].length; j++) {
                        if (piece[i][j] == 1) {
                            drawBlock(canvas, pieceX + j, pieceY + i, blockPaints[colorIdx]);
                        }
                    }
                }
            }
            
            // Граница
            canvas.drawRect(offsetX, offsetY,
                offsetX + COLS * CELL_SIZE, offsetY + ROWS * CELL_SIZE, borderPaint);
        }
        
        private void drawBlock(Canvas canvas, int col, int row, Paint paint) {
            float left = offsetX + col * CELL_SIZE;
            float top = offsetY + row * CELL_SIZE;
            rect.set(left, top, left + CELL_SIZE - 1, top + CELL_SIZE - 1);
            canvas.drawRect(rect, paint);
            
            // Блик
            Paint light = new Paint();
            light.setColor(Color.argb(60, 255, 255, 255));
            rect.set(left + 2, top + 2, left + CELL_SIZE - 3, top + CELL_SIZE / 3);
            canvas.drawRect(rect, light);
        }
    }
}