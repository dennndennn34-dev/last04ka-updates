package com.last04ka.messenger.ui;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.net.wifi.p2p.WifiP2pDevice;
import android.os.Bundle;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import com.last04ka.messenger.R;
import com.last04ka.messenger.adapters.MessageAdapter;
import com.last04ka.messenger.connectivity.NearbyManager;
import com.last04ka.messenger.data.Message;
import com.last04ka.messenger.utils.AppLogger;
import com.last04ka.messenger.utils.ThemeManager;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public class GroupChatActivity extends AppCompatActivity {
    private static final String TAG = "GroupChat";

    private RecyclerView recyclerView;
    private EditText inputMessage;
    private ImageButton sendButton;
    private Button btnCreateGroup, btnDiscover, btnConnect, btnDisconnect, btnDiagnostic;
    private TextView statusText, peersText;

    private MessageAdapter adapter;
    private List<Message> messages = new ArrayList<>();

    private NearbyManager nearbyManager;
    private Handler handler = new Handler();
    private boolean isConnected = false;
    private boolean isGroupOwner = false;

    private String groupCode = "";

    private RecyclerView devicesRecyclerView;
    private DeviceListAdapter deviceAdapter;
    private List<WifiP2pDevice> deviceList = new ArrayList<>();

    public interface OnDeviceClickListener {
        void onDeviceClick(WifiP2pDevice device);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        try {
            setTheme(ThemeManager.getThemeResource(this));
            super.onCreate(savedInstanceState);
            AppLogger.log(this, TAG, "═══════════════════════════════════════════════════════════");
            AppLogger.log(this, TAG, "💬 GroupChatActivity onCreate START (with device list)");
            AppLogger.log(this, TAG, "═══════════════════════════════════════════════════════════");

            groupCode = getIntent().getStringExtra("GROUP_CODE");
            AppLogger.log(this, TAG, "📝 Received GROUP_CODE: '" + groupCode + "'");

            setContentView(R.layout.activity_group_chat);
            AppLogger.log(this, TAG, "✅ Content view set");

            initViews();
            AppLogger.log(this, TAG, "✅ Views initialized");

            setupRecyclerView();
            setupDeviceList();
            AppLogger.log(this, TAG, "✅ RecyclerViews setup");

            applyThemeColors();
            AppLogger.log(this, TAG, "✅ Theme applied");

            if (groupCode != null && !groupCode.isEmpty()) {
                if (statusText != null) {
                    statusText.setText("Код группы: " + groupCode);
                }
            } else {
                if (statusText != null) {
                    statusText.setText("Групповой чат");
                }
            }

            nearbyManager = new NearbyManager(this);
            AppLogger.log(this, TAG, "✅ NearbyManager created");

            nearbyManager.setCallback(new NearbyManager.MessageCallback() {
                @Override
                public void onMessageReceived(String message) {
                    AppLogger.log(GroupChatActivity.this, TAG, "📨 Received: " + message);
                    if (!message.isEmpty()) {
                        addMessageToChat(message, false);
                    }
                }

                @Override
                public void onConnectionStateChanged(boolean connected, boolean groupOwner) {
                    isConnected = connected;
                    isGroupOwner = groupOwner;
                    AppLogger.log(GroupChatActivity.this, TAG, "🔌 State: connected=" + connected + ", owner=" + groupOwner);
                    runOnUiThread(() -> {
                        if (statusText != null) {
                            if (connected) {
                                String base = "Подключено к группе" + (groupOwner ? " (владелец)" : " (участник)");
                                if (groupCode != null && !groupCode.isEmpty()) {
                                    statusText.setText(base + " | Код: " + groupCode);
                                } else {
                                    statusText.setText(base);
                                }
                                Toast.makeText(GroupChatActivity.this, "Соединение установлено", Toast.LENGTH_SHORT).show();
                            } else {
                                statusText.setText("Не подключено");
                                Toast.makeText(GroupChatActivity.this, "Соединение потеряно", Toast.LENGTH_SHORT).show();
                            }
                        }
                        updateDeviceList();
                    });
                }

                @Override
                public void onPeersChanged(List<WifiP2pDevice> peers) {
                    AppLogger.log(GroupChatActivity.this, TAG, "📡 Peers updated: " + peers.size());
                    runOnUiThread(() -> {
                        deviceList.clear();
                        deviceList.addAll(peers);
                        if (deviceAdapter != null) {
                            deviceAdapter.notifyDataSetChanged();
                        }
                        updatePeersText();
                    });
                }

                @Override
                public void onDeviceDisconnected() {
                    isConnected = false;
                    AppLogger.log(GroupChatActivity.this, TAG, "❌ Device disconnected");
                    runOnUiThread(() -> {
                        if (statusText != null) {
                            statusText.setText("Не подключено");
                        }
                        Toast.makeText(GroupChatActivity.this, "Устройство отключено", Toast.LENGTH_SHORT).show();
                        updateDeviceList();
                    });
                }

                @Override
                public void onError(String error) {
                    AppLogger.log(GroupChatActivity.this, TAG, "⚠️ Error: " + error);
                    runOnUiThread(() -> Toast.makeText(GroupChatActivity.this, "Ошибка: " + error, Toast.LENGTH_SHORT).show());
                }

                @Override
                public void onThisDeviceChanged(WifiP2pDevice device) {
                    AppLogger.log(GroupChatActivity.this, TAG, "📱 This device changed: " + (device != null ? device.deviceName : "null"));
                }
            });

            setupListeners();
            AppLogger.log(this, TAG, "✅ Listeners configured");

            nearbyManager.discoverPeers();

            AppLogger.log(this, TAG, "✅ GroupChatActivity onCreate completed");
            AppLogger.log(this, TAG, "═══════════════════════════════════════════════════════════");

        } catch (Exception e) {
            AppLogger.logException(this, TAG, "❌ FATAL: onCreate error", e);
            Toast.makeText(this, "Ошибка: " + e.getMessage(), Toast.LENGTH_LONG).show();
            finish();
        }
    }

    private void initViews() {
        recyclerView = findViewById(R.id.recycler_messages);
        inputMessage = findViewById(R.id.input_message);
        sendButton = findViewById(R.id.btn_send);
        btnCreateGroup = findViewById(R.id.btn_create_group);
        btnDiscover = findViewById(R.id.btn_discover);
        btnConnect = findViewById(R.id.btn_connect);
        btnDisconnect = findViewById(R.id.btn_disconnect);
        btnDiagnostic = findViewById(R.id.btn_diagnostic);
        statusText = findViewById(R.id.tv_status);
        peersText = findViewById(R.id.tv_peers);
        devicesRecyclerView = findViewById(R.id.devices_recycler);
    }

    private void setupRecyclerView() {
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        adapter = new MessageAdapter(messages, new MessageAdapter.OnMessageLongClickListener() {
            @Override
            public void onMessageLongClick(Message message) {
                // Ничего не делаем
            }
        });
        recyclerView.setAdapter(adapter);
    }

    private void setupDeviceList() {
        devicesRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        deviceAdapter = new DeviceListAdapter(deviceList, new OnDeviceClickListener() {
            @Override
            public void onDeviceClick(WifiP2pDevice device) {
                AppLogger.log(GroupChatActivity.this, TAG, "🔗 Device selected: " + device.deviceName);
                nearbyManager.connectToDevice(device);
            }
        });
        devicesRecyclerView.setAdapter(deviceAdapter);
    }

    private void updateDeviceList() {
        if (deviceAdapter != null) {
            deviceAdapter.notifyDataSetChanged();
        }
        updatePeersText();
    }

    private void updatePeersText() {
        if (peersText != null) {
            int count = deviceList.size();
            String status = isConnected ? "Подключено" : "Не подключено";
            peersText.setText("Устройств: " + count + " | " + status);
        }
    }

    private void applyThemeColors() {
        int bg = ThemeManager.getBackgroundColor(this);
        if (recyclerView != null) recyclerView.setBackgroundColor(bg);
        View layout = findViewById(R.id.group_chat_layout);
        if (layout != null) layout.setBackgroundColor(bg);
    }

    private void setupListeners() {
        if (sendButton != null) {
            sendButton.setOnClickListener(v -> {
                String text = inputMessage != null ? inputMessage.getText().toString().trim() : "";
                if (!TextUtils.isEmpty(text) && isConnected) {
                    nearbyManager.sendMessage(text);
                    addMessageToChat(text, true);
                    if (inputMessage != null) inputMessage.setText("");
                    AppLogger.log(GroupChatActivity.this, TAG, "📤 Sent: " + text);
                } else if (!isConnected) {
                    Toast.makeText(GroupChatActivity.this, "Нет подключения", Toast.LENGTH_SHORT).show();
                }
            });
        }

        if (btnCreateGroup != null) {
            btnCreateGroup.setOnClickListener(v -> {
                AppLogger.log(GroupChatActivity.this, TAG, "Create group");
                nearbyManager.createGroup();
            });
        }

        if (btnDiscover != null) {
            btnDiscover.setOnClickListener(v -> {
                AppLogger.log(GroupChatActivity.this, TAG, "Discover peers");
                nearbyManager.discoverPeers();
                Toast.makeText(GroupChatActivity.this, "Поиск устройств...", Toast.LENGTH_SHORT).show();
            });
        }

        if (btnConnect != null) {
            btnConnect.setOnClickListener(v -> {
                AppLogger.log(GroupChatActivity.this, TAG, "Connect to first peer");
                List<WifiP2pDevice> peers = nearbyManager.getPeers();
                if (peers != null && !peers.isEmpty()) {
                    WifiP2pDevice device = peers.get(0);
                    nearbyManager.connectToDevice(device);
                } else {
                    Toast.makeText(GroupChatActivity.this, "Нет устройств", Toast.LENGTH_SHORT).show();
                }
            });
        }

        if (btnDisconnect != null) {
            btnDisconnect.setOnClickListener(v -> {
                AppLogger.log(GroupChatActivity.this, TAG, "Disconnect");
                nearbyManager.disconnect();
            });
        }

        if (btnDiagnostic != null) {
            btnDiagnostic.setOnClickListener(v -> {
                AppLogger.log(GroupChatActivity.this, TAG, "Show diagnostic");
                showDiagnosticDialog();
            });
        }
    }

    private void showDiagnosticDialog() {
        String info = nearbyManager.getDiagnosticInfo();
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("🔍 Диагностика WiFi Direct");
        builder.setMessage(info);
        builder.setPositiveButton("Обновить", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                nearbyManager.discoverPeers();
                dialog.dismiss();
                handler.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        showDiagnosticDialog();
                    }
                }, 1000);
            }
        });
        builder.setNegativeButton("Закрыть", null);
        builder.show();
    }

    private void addMessageToChat(String text, boolean sent) {
        runOnUiThread(() -> {
            Message m = new Message();
            m.setId(UUID.randomUUID().toString());
            m.setChatId("group_" + System.currentTimeMillis());
            m.setText(text);
            m.setTimestamp(System.currentTimeMillis());
            m.setSent(sent);
            messages.add(m);
            if (adapter != null) {
                adapter.notifyItemInserted(messages.size() - 1);
                recyclerView.scrollToPosition(messages.size() - 1);
            }
        });
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (nearbyManager != null) {
            nearbyManager.stop();
        }
        AppLogger.log(this, TAG, "GroupChatActivity destroyed");
    }

    // ==================== ADAPTER ДЛЯ СПИСКА УСТРОЙСТВ ====================

    private class DeviceListAdapter extends RecyclerView.Adapter<DeviceListAdapter.ViewHolder> {
        private List<WifiP2pDevice> devices;
        private OnDeviceClickListener listener;

        DeviceListAdapter(List<WifiP2pDevice> devices, OnDeviceClickListener listener) {
            this.devices = devices;
            this.listener = listener;
        }

        @Override
        public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_wifi_device, parent, false);
            return new ViewHolder(view);
        }

        @Override
        public void onBindViewHolder(ViewHolder holder, int position) {
            WifiP2pDevice device = devices.get(position);
            String name = device.deviceName != null ? device.deviceName : "Без имени";
            holder.deviceName.setText(name);
            holder.deviceAddress.setText(device.deviceAddress);
            String status;
            switch (device.status) {
                case WifiP2pDevice.AVAILABLE: status = "🟢 Доступно"; break;
                case WifiP2pDevice.CONNECTED: status = "🔵 Подключено"; break;
                case WifiP2pDevice.INVITED: status = "🟡 Приглашено"; break;
                case WifiP2pDevice.FAILED: status = "🔴 Ошибка"; break;
                default: status = "⚪ Неизвестно"; break;
            }
            holder.deviceStatus.setText(status);
            holder.itemView.setOnClickListener(v -> {
                if (listener != null) {
                    listener.onDeviceClick(device);
                }
            });
        }

        @Override
        public int getItemCount() {
            return devices != null ? devices.size() : 0;
        }

        class ViewHolder extends RecyclerView.ViewHolder {
            TextView deviceName, deviceAddress, deviceStatus;

            ViewHolder(View itemView) {
                super(itemView);
                deviceName = itemView.findViewById(R.id.device_name);
                deviceAddress = itemView.findViewById(R.id.device_address);
                deviceStatus = itemView.findViewById(R.id.device_status);
            }
        }
    }
}