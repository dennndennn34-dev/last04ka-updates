package com.last04ka.messenger.ui;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.WindowManager;

import com.last04ka.messenger.R;
import com.last04ka.messenger.game.BallGameView;
import com.last04ka.messenger.utils.AppLogger;

public class BallGameActivity extends AppCompatActivity {
    private BallGameView gameView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        AppLogger.log(this, "BallGameActivity", "onCreate");
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        setContentView(R.layout.activity_ball_game);

        gameView = findViewById(R.id.ball_game_view);
        int level = getIntent().getIntExtra("level", 1);
        gameView.setLevel(level);
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (gameView != null) gameView.resume();
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (gameView != null) gameView.pause();
    }
}