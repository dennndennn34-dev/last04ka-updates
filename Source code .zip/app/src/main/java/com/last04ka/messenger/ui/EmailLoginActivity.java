package com.last04ka.messenger.ui;

import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.ArrayAdapter;
import android.widget.Toast;

import com.last04ka.messenger.R;
import com.last04ka.messenger.utils.AppLogger;
import com.last04ka.messenger.utils.EmailManager;
import com.last04ka.messenger.utils.ThemeManager;

public class EmailLoginActivity extends AppCompatActivity {
    private static final String TAG = "EmailLogin";

    private EditText etEmail, etPassword;
    private Spinner spinnerProvider;
    private Button btnLogin, btnCancel;
    private ProgressBar progressBar;
    private TextView tvStatus;

    private EmailManager emailManager;
    private Handler handler = new Handler(Looper.getMainLooper());

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        setTheme(ThemeManager.getThemeResource(this));
        super.onCreate(savedInstanceState);
        AppLogger.log(this, TAG, "═══════════════════════════════════════════════════════════");
        AppLogger.log(this, TAG, "🔐 EmailLoginActivity onCreate START");
        AppLogger.log(this, TAG, "═══════════════════════════════════════════════════════════");

        try {
            setContentView(R.layout.activity_email_login);
            setTitle("🔐 Вход в почту");

            emailManager = new EmailManager(this);

            initViews();
            AppLogger.log(this, TAG, "✅ Views initialized");

            setupSpinner();
            AppLogger.log(this, TAG, "✅ Spinner setup");

            setupListeners();
            AppLogger.log(this, TAG, "✅ Listeners setup");

            AppLogger.log(this, TAG, "═══════════════════════════════════════════════════════════");
            AppLogger.log(this, TAG, "🔐 EmailLoginActivity onCreate SUCCESS");
            AppLogger.log(this, TAG, "═══════════════════════════════════════════════════════════");

        } catch (Exception e) {
            AppLogger.logException(this, TAG, "❌ onCreate error", e);
            Toast.makeText(this, "Ошибка: " + e.getMessage(), Toast.LENGTH_LONG).show();
            finish();
        }
    }

    private void initViews() {
        etEmail = findViewById(R.id.et_email);
        etPassword = findViewById(R.id.et_password);
        spinnerProvider = findViewById(R.id.spinner_provider);
        btnLogin = findViewById(R.id.btn_login);
        btnCancel = findViewById(R.id.btn_cancel);
        progressBar = findViewById(R.id.login_progress);
        tvStatus = findViewById(R.id.tv_status);
    }

    private void setupSpinner() {
        AppLogger.log(this, TAG, "📋 setupSpinner() called");
        String[] providers = new String[EmailManager.PROVIDERS.length];
        for (int i = 0; i < EmailManager.PROVIDERS.length; i++) {
            providers[i] = EmailManager.PROVIDERS[i].name;
        }

        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, providers);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerProvider.setAdapter(adapter);
        AppLogger.log(this, TAG, "✅ Spinner setup: " + providers.length + " providers");
    }

    private void setupListeners() {
        btnLogin.setOnClickListener(v -> login());
        btnCancel.setOnClickListener(v -> finish());
    }

    private void login() {
        String email = etEmail.getText().toString().trim();
        String password = etPassword.getText().toString().trim();

        AppLogger.log(this, TAG, "🔑 login() called");
        AppLogger.log(this, TAG, "   email: " + email);
        AppLogger.log(this, TAG, "   password length: " + (password != null ? password.length() : 0));

        if (email.isEmpty()) {
            Toast.makeText(this, "Введите email", Toast.LENGTH_SHORT).show();
            return;
        }

        if (password.isEmpty()) {
            Toast.makeText(this, "Введите пароль", Toast.LENGTH_SHORT).show();
            return;
        }

        int providerIndex = spinnerProvider.getSelectedItemPosition();
        EmailManager.Provider provider = EmailManager.PROVIDERS[providerIndex];

        AppLogger.log(this, TAG, "   provider: " + provider.name);

        showProgress(true);
        tvStatus.setText("⏳ Проверка подключения...");
        btnLogin.setEnabled(false);

        new Thread(() -> {
            EmailManager.LoginResult result = emailManager.testConnection(email, password, provider);

            handler.post(() -> {
                showProgress(false);
                btnLogin.setEnabled(true);

                if (result.success) {
                    AppLogger.log(EmailLoginActivity.this, TAG, "✅ Login successful for: " + email);

                    // Сохраняем аккаунт
                    EmailManager.Account account = new EmailManager.Account(email, password, provider.name);
                    account.displayName = email;
                    account.isActive = true;
                    emailManager.saveAccount(account);

                    // Делаем активным
                    emailManager.setActiveAccount(account.id);

                    tvStatus.setText("✅ " + result.message);
                    Toast.makeText(EmailLoginActivity.this, "✅ Аккаунт добавлен!", Toast.LENGTH_SHORT).show();

                    // Возвращаемся в почту
                    finish();

                } else {
                    AppLogger.log(EmailLoginActivity.this, TAG, "❌ Login failed: " + result.message);
                    tvStatus.setText(result.message);

                    if (result.isAuthError) {
                        Toast.makeText(EmailLoginActivity.this, "❌ Неверный логин или пароль", Toast.LENGTH_LONG).show();
                    } else {
                        Toast.makeText(EmailLoginActivity.this, "❌ " + result.message, Toast.LENGTH_LONG).show();
                    }
                }
            });
        }).start();
    }

    private void showProgress(boolean show) {
        progressBar.setVisibility(show ? View.VISIBLE : View.GONE);
    }
}