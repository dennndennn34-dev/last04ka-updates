package com.last04ka.messenger.ui;

import android.app.Activity;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.speech.tts.TextToSpeech;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import com.last04ka.messenger.utils.AppLogger;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Random;

public class LanguageTrainerActivity extends Activity {

    private SQLiteDatabase db;
    private TextView questionText, answerText, progressText;
    private Button btnShow, btnNext, btnSpeak, btnAdd;
    private EditText inputWord, inputTranslation;
    private List<String[]> cards;
    private int currentIndex = 0;
    private boolean shown = false;
    private TextToSpeech tts;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        try {
            AppLogger.log(this, "LangTrainer", "onCreate started");
            db = openOrCreateDatabase("langtrainer.db", MODE_PRIVATE, null);
            db.execSQL("CREATE TABLE IF NOT EXISTS words (id INTEGER PRIMARY KEY AUTOINCREMENT, word TEXT, translation TEXT)");

            tts = new TextToSpeech(this, status -> {
                if (status == TextToSpeech.SUCCESS) tts.setLanguage(Locale.ENGLISH);
            });

            LinearLayout layout = new LinearLayout(this);
            layout.setOrientation(LinearLayout.VERTICAL);
            layout.setPadding(16, 16, 16, 16);
            layout.setBackgroundColor(0xFF1A1A2E);

            TextView title = new TextView(this);
            title.setText("🗣 Изучение языков"); title.setTextSize(20);
            title.setTextColor(0xFFFFFFFF); title.setGravity(Gravity.CENTER);
            layout.addView(title);

            progressText = new TextView(this);
            progressText.setText("0/0"); progressText.setTextSize(12);
            progressText.setTextColor(0xFF888888); progressText.setGravity(Gravity.CENTER);
            layout.addView(progressText);

            questionText = new TextView(this);
            questionText.setTextSize(22); questionText.setTextColor(0xFFFFD740);
            questionText.setGravity(Gravity.CENTER); questionText.setPadding(16, 20, 16, 20);
            questionText.setBackgroundColor(0xFF333333); questionText.setMinHeight(80);
            layout.addView(questionText);

            answerText = new TextView(this);
            answerText.setTextSize(18); answerText.setTextColor(0xFF4CAF50);
            answerText.setGravity(Gravity.CENTER); answerText.setPadding(16, 16, 16, 16);
            answerText.setVisibility(View.GONE);
            layout.addView(answerText);

            LinearLayout btnRow = new LinearLayout(this);
            btnRow.setOrientation(LinearLayout.HORIZONTAL);
            btnRow.setGravity(Gravity.CENTER);

            btnShow = new Button(this); btnShow.setText("Показать");
            btnShow.setOnClickListener(v -> reveal()); btnRow.addView(btnShow);
            btnSpeak = new Button(this); btnSpeak.setText("🔊");
            btnSpeak.setOnClickListener(v -> speak()); btnRow.addView(btnSpeak);
            btnNext = new Button(this); btnNext.setText("Далее");
            btnNext.setOnClickListener(v -> next()); btnRow.addView(btnNext);
            layout.addView(btnRow);

            // Добавление слов
            inputWord = new EditText(this);
            inputWord.setHint("Слово (на английском)"); inputWord.setTextColor(0xFFFFFFFF);
            inputWord.setHintTextColor(0xFF888888); inputWord.setBackgroundColor(0xFF333333);
            inputWord.setPadding(12, 8, 12, 8); layout.addView(inputWord);

            inputTranslation = new EditText(this);
            inputTranslation.setHint("Перевод"); inputTranslation.setTextColor(0xFFFFFFFF);
            inputTranslation.setHintTextColor(0xFF888888); inputTranslation.setBackgroundColor(0xFF333333);
            inputTranslation.setPadding(12, 8, 12, 8); layout.addView(inputTranslation);

            btnAdd = new Button(this); btnAdd.setText("Добавить слово");
            btnAdd.setOnClickListener(v -> addWord()); layout.addView(btnAdd);

            setContentView(layout);
            setTitle("🗣 Изучение языков");
            loadCards();
            AppLogger.log(this, "LangTrainer", "onCreate completed");
        } catch (Exception e) { AppLogger.logException(this, "LangTrainer", e); finish(); }
    }

    private void loadCards() {
        cards = new ArrayList<>();
        Cursor c = db.rawQuery("SELECT word, translation FROM words", null);
        while (c.moveToNext()) cards.add(new String[]{c.getString(0), c.getString(1)});
        c.close();
        shuffleCards();
        progressText.setText(cards.isEmpty() ? "0/0" : "1/" + cards.size());
        if (!cards.isEmpty()) { currentIndex = 0; showCard(); }
        else questionText.setText("Добавьте слова");
        answerText.setVisibility(View.GONE);
        shown = false;
    }

    private void shuffleCards() {
        Random r = new Random();
        for (int i = cards.size()-1; i > 0; i--) {
            int j = r.nextInt(i+1);
            String[] tmp = cards.get(i); cards.set(i, cards.get(j)); cards.set(j, tmp);
        }
    }

    private void showCard() {
        if (cards.isEmpty()) return;
        questionText.setText(cards.get(currentIndex)[0]);
        answerText.setText(cards.get(currentIndex)[1]);
        answerText.setVisibility(View.GONE);
        shown = false;
        btnShow.setText("Показать");
        progressText.setText((currentIndex+1) + "/" + cards.size());
    }

    private void reveal() {
        if (shown) { answerText.setVisibility(View.GONE); shown = false; btnShow.setText("Показать"); }
        else { answerText.setVisibility(View.VISIBLE); shown = true; btnShow.setText("Скрыть"); }
    }

    private void speak() {
        if (cards.isEmpty()) return;
        String word = cards.get(currentIndex)[0];
        if (tts != null) tts.speak(word, TextToSpeech.QUEUE_FLUSH, null, null);
        AppLogger.log(this, "LangTrainer", "Speaking: " + word);
    }

    private void next() {
        if (cards.isEmpty()) return;
        currentIndex = (currentIndex + 1) % cards.size();
        showCard();
    }

    private void addWord() {
        String w = inputWord.getText().toString().trim();
        String t = inputTranslation.getText().toString().trim();
        if (w.isEmpty() || t.isEmpty()) { Toast.makeText(this, "Заполните оба поля", Toast.LENGTH_SHORT).show(); return; }
        db.execSQL("INSERT INTO words (word, translation) VALUES (?,?)", new Object[]{w, t});
        inputWord.setText(""); inputTranslation.setText("");
        loadCards();
        Toast.makeText(this, "Слово добавлено", Toast.LENGTH_SHORT).show();
        AppLogger.log(this, "LangTrainer", "Word added: " + w + " -> " + t);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (tts != null) { tts.stop(); tts.shutdown(); }
        if (db != null && db.isOpen()) db.close();
    }
}