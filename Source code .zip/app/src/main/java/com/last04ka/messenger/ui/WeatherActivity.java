package com.last04ka.messenger.ui;

import android.app.Activity;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import com.last04ka.messenger.utils.AppLogger;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

public class WeatherActivity extends Activity {

    private EditText cityInput;
    private TextView resultText;
    private Button btnCheck;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        try {
            AppLogger.log(this, "Weather", "onCreate started");

            LinearLayout layout = new LinearLayout(this);
            layout.setOrientation(LinearLayout.VERTICAL);
            layout.setPadding(20, 20, 20, 20);
            layout.setBackgroundColor(0xFF1A1A2E);

            TextView title = new TextView(this);
            title.setText("🌤 Погода");
            title.setTextSize(22); title.setTextColor(0xFFFFFFFF);
            title.setGravity(Gravity.CENTER); layout.addView(title);

            cityInput = new EditText(this);
            cityInput.setHint("Город (на английском, например Moscow)");
            cityInput.setText("Moscow");
            cityInput.setTextColor(0xFFFFFFFF); cityInput.setHintTextColor(0xFF888888);
            cityInput.setBackgroundColor(0xFF333333); cityInput.setPadding(12, 10, 12, 10);
            layout.addView(cityInput);

            btnCheck = new Button(this);
            btnCheck.setText("Узнать погоду");
            btnCheck.setOnClickListener(v -> fetchWeather());
            layout.addView(btnCheck);

            resultText = new TextView(this);
            resultText.setTextSize(15); resultText.setTextColor(0xFFFFFFFF);
            resultText.setPadding(16, 16, 16, 16); resultText.setBackgroundColor(0xFF333333);
            resultText.setMinHeight(120);
            layout.addView(resultText);

            setContentView(layout);
            setTitle("🌤 Погода");
            AppLogger.log(this, "Weather", "onCreate completed");
        } catch (Exception e) { AppLogger.logException(this, "Weather", e); finish(); }
    }

    private void fetchWeather() {
        String city = cityInput.getText().toString().trim();
        if (city.isEmpty()) { Toast.makeText(this, "Введите город", Toast.LENGTH_SHORT).show(); return; }
        resultText.setText("Загрузка...");
        new Thread(() -> {
            try {
                // wttr.in — бесплатный API
                URL url = new URL("https://wttr.in/" + city + "?format=%C+%t+%w+%h&lang=ru");
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setConnectTimeout(10000); conn.setReadTimeout(10000);
                conn.setRequestProperty("User-Agent", "Last04ka");
                BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream()));
                String result = reader.readLine();
                reader.close(); conn.disconnect();

                String[] parts = result.split(" ");
                StringBuilder output = new StringBuilder();
                output.append("🏙 Город: ").append(city).append("\n");
                if (parts.length >= 1) output.append("🌡 Погода: ").append(parts[0]).append("\n");
                if (parts.length >= 2) output.append("🌡 Температура: ").append(parts[1]).append("\n");
                if (parts.length >= 3) output.append("💨 Ветер: ").append(parts[2]).append("\n");
                if (parts.length >= 4) output.append("💧 Влажность: ").append(parts[3]);

                final String out = output.toString();
                runOnUiThread(() -> resultText.setText(out));
                AppLogger.log(this, "Weather", "Fetched for " + city + ": " + result);
            } catch (Exception e) {
                runOnUiThread(() -> { resultText.setText("Ошибка загрузки.\nПроверьте название города и интернет."); });
                AppLogger.logException(this, "Weather", e);
            }
        }).start();
    }
}