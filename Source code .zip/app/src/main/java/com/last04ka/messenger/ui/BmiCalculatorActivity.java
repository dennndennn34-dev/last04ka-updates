package com.last04ka.messenger.ui;

import android.app.Activity;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import com.last04ka.messenger.utils.AppLogger;

public class BmiCalculatorActivity extends Activity {

    private EditText weightInput, heightInput;
    private TextView resultText, categoryText;
    private Button btnCalc;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        try {
            AppLogger.log(this, "BMI", "onCreate started");
            LinearLayout layout = new LinearLayout(this);
            layout.setOrientation(LinearLayout.VERTICAL);
            layout.setPadding(16, 16, 16, 16);
            layout.setBackgroundColor(0xFF1A1A2E);

            TextView title = new TextView(this);
            title.setText("⚖ Калькулятор ИМТ"); title.setTextSize(20);
            title.setTextColor(0xFFFFFFFF); title.setGravity(Gravity.CENTER);
            layout.addView(title);

            TextView wLabel = new TextView(this);
            wLabel.setText("Вес (кг):"); wLabel.setTextColor(0xFFFFFFFF);
            layout.addView(wLabel);
            weightInput = new EditText(this); weightInput.setText("70");
            weightInput.setTextColor(0xFFFFFFFF); weightInput.setBackgroundColor(0xFF333333);
            layout.addView(weightInput);

            TextView hLabel = new TextView(this);
            hLabel.setText("Рост (см):"); hLabel.setTextColor(0xFFFFFFFF);
            layout.addView(hLabel);
            heightInput = new EditText(this); heightInput.setText("170");
            heightInput.setTextColor(0xFFFFFFFF); heightInput.setBackgroundColor(0xFF333333);
            layout.addView(heightInput);

            btnCalc = new Button(this); btnCalc.setText("Рассчитать");
            btnCalc.setOnClickListener(v -> calculate());
            layout.addView(btnCalc);

            resultText = new TextView(this);
            resultText.setTextSize(32); resultText.setTextColor(0xFFFFD740);
            resultText.setGravity(Gravity.CENTER); resultText.setPadding(0, 16, 0, 8);
            layout.addView(resultText);

            categoryText = new TextView(this);
            categoryText.setTextSize(16); categoryText.setTextColor(0xFFFFFFFF);
            categoryText.setGravity(Gravity.CENTER);
            layout.addView(categoryText);

            setContentView(layout); setTitle("⚖ Калькулятор ИМТ");
            AppLogger.log(this, "BMI", "onCreate completed");
        } catch (Exception e) { AppLogger.logException(this, "BMI", e); finish(); }
    }

    private void calculate() {
        try {
            float weight = Float.parseFloat(weightInput.getText().toString());
            float height = Float.parseFloat(heightInput.getText().toString()) / 100f;
            float bmi = weight / (height * height);
            resultText.setText(String.format("%.2f", bmi));
            String cat; int color;
            if (bmi < 18.5) { cat = "Недостаточный вес"; color = 0xFF4FC3F7; }
            else if (bmi < 25) { cat = "Норма"; color = 0xFF4CAF50; }
            else if (bmi < 30) { cat = "Избыточный вес"; color = 0xFFFFD740; }
            else { cat = "Ожирение"; color = 0xFFFF5252; }
            categoryText.setText(cat); categoryText.setTextColor(color);
            AppLogger.log(this, "BMI", "Calculated: " + bmi + " -> " + cat);
        } catch (Exception e) { resultText.setText("Ошибка"); }
    }
}