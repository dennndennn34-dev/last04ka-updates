package com.last04ka.messenger.ui;

import android.app.Activity;
import android.content.Context;
import android.graphics.Color;
import android.hardware.camera2.CameraAccessException;
import android.hardware.camera2.CameraManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Vibrator;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;
import com.last04ka.messenger.utils.AppLogger;

public class FlashlightActivity extends Activity {

    private CameraManager cameraManager;
    private String cameraId;
    private boolean isFlashOn = false;

    // Режимы
    private int currentMode = 0; // 0=постоянный, 1=стробоскоп, 2=SOS, 3=маяк, 4=пульс, 5=полиция, 6=свеча, 7=диско
    private String[] modeNames = {"Постоянный", "Стробоскоп", "SOS", "Маяк", "Пульс", "Полиция", "Свеча", "Диско"};
    private Handler handler = new Handler();
    private Runnable strobeRunnable;
    private boolean strobeRunning = false;

    // Яркость
    private SeekBar brightnessBar;
    private TextView brightnessText;
    private float brightness = 1.0f; // Для стробоскопа — длительность вспышки

    // Частота
    private SeekBar frequencyBar;
    private TextView frequencyText;
    private int frequency = 200; // мс

    // Счётчик вспышек
    private TextView flashCountText;
    private int flashCount = 0;

    // Кнопки режимов
    private Button[] modeButtons = new Button[8];

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        try {
            AppLogger.log(this, "Flashlight", "onCreate v3.0");
            AppLogger.logUI(this, "Flashlight", "Multi-mode layout", true);
            AppLogger.logTexture(this, "Flashlight", "Mode buttons (8)", true);

            cameraManager = (CameraManager) getSystemService(Context.CAMERA_SERVICE);
            try {
                cameraId = cameraManager.getCameraIdList()[0];
            } catch (Exception e) {
                cameraId = null;
            }

            LinearLayout layout = new LinearLayout(this);
            layout.setOrientation(LinearLayout.VERTICAL);
            layout.setPadding(12, 12, 12, 12);
            layout.setBackgroundColor(0xFF1A1A2E);
            layout.setGravity(Gravity.CENTER_HORIZONTAL);

            // Заголовок
            TextView title = new TextView(this);
            title.setText("🔦 Фонарик v3.0"); title.setTextSize(20);
            title.setTextColor(0xFFFFFFFF); title.setGravity(Gravity.CENTER);
            title.setPadding(0, 0, 0, 12);
            layout.addView(title);

            // Статус
            final TextView statusText = new TextView(this);
            statusText.setText("Выключен"); statusText.setTextSize(14);
            statusText.setTextColor(0xFF888888); statusText.setGravity(Gravity.CENTER);
            statusText.setPadding(0, 0, 0, 8);
            layout.addView(statusText);

            // Счётчик вспышек
            flashCountText = new TextView(this);
            flashCountText.setText("Вспышек: 0"); flashCountText.setTextSize(12);
            flashCountText.setTextColor(0xFFFFD740); flashCountText.setGravity(Gravity.CENTER);
            flashCountText.setPadding(0, 0, 0, 12);
            layout.addView(flashCountText);

            // Кнопка ВКЛ/ВЫКЛ (большая)
            Button btnToggle = new Button(this);
            btnToggle.setText("🔦 ВКЛЮЧИТЬ");
            btnToggle.setTextSize(22);
            btnToggle.setTextColor(Color.WHITE);
            btnToggle.setBackgroundColor(0xFF4CAF50);
            btnToggle.setPadding(40, 20, 40, 20);
            btnToggle.setOnClickListener(v -> {
                if (isFlashOn) {
                    turnOff(statusText, btnToggle);
                } else {
                    turnOn(statusText, btnToggle);
                }
            });
            layout.addView(btnToggle);

            // Режимы (2 ряда по 4 кнопки)
            String[] modeIcons = {"💡", "⚡", "🆘", "🗼", "💓", "🚨", "🕯️", "🪩"};
            for (int row = 0; row < 2; row++) {
                LinearLayout modeRow = new LinearLayout(this);
                modeRow.setGravity(Gravity.CENTER);
                modeRow.setPadding(0, 8, 0, 0);
                for (int col = 0; col < 4; col++) {
                    final int idx = row * 4 + col;
                    Button btn = new Button(this);
                    btn.setText(modeIcons[idx] + " " + modeNames[idx]);
                    btn.setTextSize(11);
                    btn.setTextColor(Color.WHITE);
                    btn.setBackgroundColor(idx == 0 ? 0xFF4CAF50 : 0xFF616161);
                    btn.setPadding(8, 6, 8, 6);
                    btn.setOnClickListener(v -> selectMode(idx, statusText));
                    modeRow.addView(btn);
                    modeButtons[idx] = btn;
                }
                layout.addView(modeRow);
            }

            // Настройка яркости
            TextView brightLabel = new TextView(this);
            brightLabel.setText("Яркость / Длительность"); brightLabel.setTextSize(12);
            brightLabel.setTextColor(0xFFFFFFFF); brightLabel.setPadding(0, 12, 0, 4);
            layout.addView(brightLabel);

            brightnessBar = new SeekBar(this);
            brightnessBar.setMax(100); brightnessBar.setProgress(100);
            brightnessBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
                @Override public void onProgressChanged(SeekBar s, int p, boolean u) { brightness = p / 100f; brightnessText.setText((int)(brightness*100) + "%"); }
                @Override public void onStartTrackingTouch(SeekBar s) {}
                @Override public void onStopTrackingTouch(SeekBar s) {}
            });
            layout.addView(brightnessBar);

            brightnessText = new TextView(this);
            brightnessText.setText("100%"); brightnessText.setTextSize(11);
            brightnessText.setTextColor(0xFF888888); brightnessText.setGravity(Gravity.CENTER);
            layout.addView(brightnessText);

            // Настройка частоты
            TextView freqLabel = new TextView(this);
            freqLabel.setText("Частота (мс)"); freqLabel.setTextSize(12);
            freqLabel.setTextColor(0xFFFFFFFF); freqLabel.setPadding(0, 8, 0, 4);
            layout.addView(freqLabel);

            frequencyBar = new SeekBar(this);
            frequencyBar.setMax(800); frequencyBar.setProgress(200);
            frequencyBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
                @Override public void onProgressChanged(SeekBar s, int p, boolean u) { frequency = Math.max(50, p); frequencyText.setText(frequency + " мс"); }
                @Override public void onStartTrackingTouch(SeekBar s) {}
                @Override public void onStopTrackingTouch(SeekBar s) {}
            });
            layout.addView(frequencyBar);

            frequencyText = new TextView(this);
            frequencyText.setText("200 мс"); frequencyText.setTextSize(11);
            frequencyText.setTextColor(0xFF888888); frequencyText.setGravity(Gravity.CENTER);
            layout.addView(frequencyText);

            setContentView(layout);
            setTitle("🔦 Фонарик");

            AppLogger.log(this, "Flashlight", "Camera: " + (cameraId != null ? "OK" : "NULL"));
        } catch (Exception e) {
            AppLogger.logException(this, "Flashlight", e);
            Toast.makeText(this, "Ошибка: " + e.getMessage(), Toast.LENGTH_LONG).show();
            finish();
        }
    }

    private void selectMode(int mode, TextView statusText) {
        currentMode = mode;
        // Подсветка активной кнопки
        for (int i = 0; i < modeButtons.length; i++) {
            modeButtons[i].setBackgroundColor(i == mode ? 0xFF4CAF50 : 0xFF616161);
        }
        AppLogger.log(this, "Flashlight", "Mode selected: " + modeNames[mode]);

        if (isFlashOn) {
            // Перезапуск с новым режимом
            turnOff(statusText, null);
            handler.postDelayed(() -> turnOn(statusText, null), 100);
        }
    }

    private void turnOn(TextView statusText, Button toggleBtn) {
        if (cameraId == null) {
            Toast.makeText(this, "Нет вспышки на устройстве", Toast.LENGTH_SHORT).show();
            return;
        }
        isFlashOn = true;
        if (toggleBtn != null) {
            toggleBtn.setText("🔦 ВЫКЛЮЧИТЬ");
            toggleBtn.setBackgroundColor(0xFFFF5252);
        }
        statusText.setText(modeNames[currentMode]);
        statusText.setTextColor(0xFFFFD740);
        startStrobeMode();
        AppLogger.log(this, "Flashlight", "ON, mode=" + modeNames[currentMode]);
    }

    private void turnOff(TextView statusText, Button toggleBtn) {
        isFlashOn = false;
        stopStrobeMode();
        turnFlashOff();
        if (toggleBtn != null) {
            toggleBtn.setText("🔦 ВКЛЮЧИТЬ");
            toggleBtn.setBackgroundColor(0xFF4CAF50);
        }
        if (statusText != null) {
            statusText.setText("Выключен");
            statusText.setTextColor(0xFF888888);
        }
        AppLogger.log(this, "Flashlight", "OFF, flashes=" + flashCount);
    }

    private void startStrobeMode() {
        stopStrobeMode();
        strobeRunning = true;

        switch (currentMode) {
            case 0: // Постоянный
                turnFlashOn();
                break;
            case 1: // Стробоскоп
                strobeRunnable = new Runnable() {
                    boolean on = true;
                    @Override public void run() {
                        if (!strobeRunning) return;
                        if (on) { turnFlashOn(); flashCount++; updateFlashCount(); }
                        else turnFlashOff();
                        on = !on;
                        handler.postDelayed(this, frequency);
                    }
                };
                handler.post(strobeRunnable);
                break;
            case 2: // SOS (... --- ...)
                strobeRunnable = new Runnable() {
                    int step = 0;
                    int[] sosPattern = {200,200,200,600,600,600,200,200,200,1000}; // точки-тире-точки + пауза 1с
                    @Override public void run() {
                        if (!strobeRunning) return;
                        turnFlashOn(); flashCount++; updateFlashCount();
                        handler.postDelayed(() -> {
                            if (!strobeRunning) return;
                            turnFlashOff();
                            handler.postDelayed(this, sosPattern[step % sosPattern.length]);
                            step++;
                        }, 120); // короткая вспышка 120мс
                    }
                };
                handler.post(strobeRunnable);
                break;
            case 3: // Маяк (длинная вспышка + пауза)
                strobeRunnable = new Runnable() {
                    @Override public void run() {
                        if (!strobeRunning) return;
                        turnFlashOn(); flashCount++; updateFlashCount();
                        handler.postDelayed(() -> { if (strobeRunning) turnFlashOff(); }, 800);
                        handler.postDelayed(this, 2000);
                    }
                };
                handler.post(strobeRunnable);
                break;
            case 4: // Пульс (плавное нарастание)
                strobeRunnable = new Runnable() {
                    int pulse = 0;
                    @Override public void run() {
                        if (!strobeRunning) return;
                        pulse++;
                        if (pulse % 3 == 0) { turnFlashOn(); flashCount++; updateFlashCount(); }
                        else turnFlashOff();
                        handler.postDelayed(this, frequency / 2);
                    }
                };
                handler.post(strobeRunnable);
                break;
            case 5: // Полиция (красный-синий через фронталку не получится, делаем быстрое мигание)
                strobeRunnable = new Runnable() {
                    @Override public void run() {
                        if (!strobeRunning) return;
                        turnFlashOn(); flashCount++; updateFlashCount();
                        handler.postDelayed(() -> { if (strobeRunning) turnFlashOff(); }, 60);
                        handler.postDelayed(this, 120);
                    }
                };
                handler.post(strobeRunnable);
                break;
            case 6: // Свеча (медленное мерцание)
                strobeRunnable = new Runnable() {
                    @Override public void run() {
                        if (!strobeRunning) return;
                        turnFlashOn(); flashCount++; updateFlashCount();
                        handler.postDelayed(() -> { if (strobeRunning) turnFlashOff(); }, 150 + new java.util.Random().nextInt(100));
                        handler.postDelayed(this, 400 + new java.util.Random().nextInt(300));
                    }
                };
                handler.post(strobeRunnable);
                break;
            case 7: // Диско (случайный ритм)
                strobeRunnable = new Runnable() {
                    @Override public void run() {
                        if (!strobeRunning) return;
                        turnFlashOn(); flashCount++; updateFlashCount();
                        int onTime = 50 + new java.util.Random().nextInt(200);
                        handler.postDelayed(() -> { if (strobeRunning) turnFlashOff(); }, onTime);
                        handler.postDelayed(this, 100 + new java.util.Random().nextInt(400));
                    }
                };
                handler.post(strobeRunnable);
                break;
        }
    }

    private void stopStrobeMode() {
        strobeRunning = false;
        if (strobeRunnable != null) {
            handler.removeCallbacks(strobeRunnable);
            strobeRunnable = null;
        }
    }

    private void updateFlashCount() {
        runOnUiThread(() -> flashCountText.setText("Вспышек: " + flashCount));
    }

    private void turnFlashOn() {
        try {
            if (Build.VERSION.SDK_INT >= 23 && cameraManager != null && cameraId != null) {
                cameraManager.setTorchMode(cameraId, true);
            }
        } catch (CameraAccessException e) {
            AppLogger.logException(this, "Flashlight", e);
        }
    }

    private void turnFlashOff() {
        try {
            if (Build.VERSION.SDK_INT >= 23 && cameraManager != null && cameraId != null) {
                cameraManager.setTorchMode(cameraId, false);
            }
        } catch (CameraAccessException e) {
            AppLogger.logException(this, "Flashlight", e);
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        stopStrobeMode();
        turnFlashOff();
    }
}