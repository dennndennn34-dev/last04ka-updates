package com.last04ka.messenger.ui;

import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.support.annotation.Nullable;
import android.support.v4.content.FileProvider;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.animation.OvershootInterpolator;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import com.last04ka.messenger.R;
import com.last04ka.messenger.data.DatabaseHelper;
import com.last04ka.messenger.utils.AppLogger;
import com.last04ka.messenger.utils.BackupManager;
import com.last04ka.messenger.utils.StreakManager;
import com.last04ka.messenger.utils.ThemeManager;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.IOException;
import java.io.OutputStream;

public class SettingsActivity extends AppCompatActivity {
    private static final String TAG = "Settings";
    private static final int PICK_IMAGE = 1;

    private EditText nameInput;
    private ImageView avatarView;
    private RadioGroup radioGroupTheme;
    private RadioButton radioLight, radioDark, radioAmoled;
    private DatabaseHelper dbHelper;
    private String avatarPath;
    private TextView statsText, versionText, developerText, emailText, tiktokText;
    private TextView tvStreakDays, tvBestStreak, tvTodayTime, tvTotalTime, tvRingName;
    private LinearLayout ringColorContainer;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        setTheme(ThemeManager.getThemeResource(this));
        super.onCreate(savedInstanceState);
        try {
            AppLogger.log(this, TAG, "========== onCreate START ==========");
            setContentView(R.layout.activity_settings);
            dbHelper = new DatabaseHelper(this);

            initViews();
            AppLogger.log(this, TAG, "Views initialized");

            loadProfile();
            AppLogger.log(this, TAG, "Profile loaded");

            loadTheme();
            AppLogger.log(this, TAG, "Theme loaded");

            setupListeners();
            AppLogger.log(this, TAG, "Listeners setup");

            updateStats();
            AppLogger.log(this, TAG, "Stats updated");

            setupRingColors();
            AppLogger.log(this, TAG, "Ring colors setup");

            updateDeviceInfo();
            updateVersionInfo();
            setupDeveloperInfo();

            animateButtons();

            AppLogger.log(this, TAG, "========== onCreate SUCCESS ==========");
        } catch (Exception e) {
            AppLogger.logException(this, TAG, "onCreate error", e);
            Toast.makeText(this, "Ошибка: " + e.getMessage(), Toast.LENGTH_LONG).show();
            finish();
        }
    }

    private void initViews() {
        nameInput = findViewById(R.id.edit_name);
        avatarView = findViewById(R.id.avatar_image);
        radioGroupTheme = findViewById(R.id.radio_group_theme);
        radioLight = findViewById(R.id.radio_light);
        radioDark = findViewById(R.id.radio_dark);
        radioAmoled = findViewById(R.id.radio_amoled);

        tvStreakDays = findViewById(R.id.tv_streak_days);
        tvBestStreak = findViewById(R.id.tv_best_streak);
        tvTodayTime = findViewById(R.id.tv_today_time);
        tvTotalTime = findViewById(R.id.tv_total_time);
        tvRingName = findViewById(R.id.tv_ring_name);
        ringColorContainer = findViewById(R.id.ring_color_container);

        statsText = findViewById(R.id.stats_text);
        versionText = findViewById(R.id.version_text);
        developerText = findViewById(R.id.developer_text);
        emailText = findViewById(R.id.email_text);
        tiktokText = findViewById(R.id.tiktok_text);

        AppLogger.log(this, TAG, "Views initialized successfully");
    }

    private void loadProfile() {
        nameInput.setText(dbHelper.getProfileName());
        nameInput.setTextColor(ThemeManager.getTextColor(this));
        nameInput.setHintTextColor(ThemeManager.getHintColor(this));

        String savedAvatar = dbHelper.getProfileAvatar();
        if (savedAvatar != null && !savedAvatar.isEmpty()) {
            File af = new File(savedAvatar);
            if (af.exists()) {
                Bitmap bm = BitmapFactory.decodeFile(savedAvatar);
                avatarView.setImageBitmap(bm);
                AppLogger.log(this, TAG, "Avatar loaded: " + savedAvatar);
            }
        }

        avatarView.setOnClickListener(v -> {
            AppLogger.log(SettingsActivity.this, TAG, "Avatar clicked");
            startActivityForResult(
                new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI),
                PICK_IMAGE
            );
        });

        AppLogger.log(this, TAG, "Profile loaded");
    }

    private void loadTheme() {
        int st = dbHelper.getTheme();
        switch (st) {
            case ThemeManager.THEME_DARK: radioDark.setChecked(true); break;
            case ThemeManager.THEME_AMOLED: radioAmoled.setChecked(true); break;
            default: radioLight.setChecked(true); break;
        }
        AppLogger.log(this, TAG, "Theme loaded: " + st);
    }

    private void setupListeners() {
        Button saveButton = findViewById(R.id.btn_save);
        saveButton.setOnClickListener(v -> {
            AppLogger.log(SettingsActivity.this, TAG, "Save button clicked");
            saveSettings();
        });

        Button btnStats = findViewById(R.id.btn_stats);
        btnStats.setOnClickListener(v -> {
            AppLogger.log(SettingsActivity.this, TAG, "📊 Stats button clicked");
            startActivity(new Intent(SettingsActivity.this, StreakStatsActivity.class));
        });

        Button btnViewLog = findViewById(R.id.btn_view_log);
        btnViewLog.setOnClickListener(v -> {
            AppLogger.log(SettingsActivity.this, TAG, "View log clicked");
            startActivity(new Intent(this, LogViewerActivity.class));
        });

        Button btnGameStats = findViewById(R.id.btn_game_stats);
        btnGameStats.setOnClickListener(v -> {
            AppLogger.log(SettingsActivity.this, TAG, "Game stats clicked");
            startActivity(new Intent(this, ProfileStatsActivity.class));
        });

        Button btnDailyChallenge = findViewById(R.id.btn_daily_challenge);
        btnDailyChallenge.setOnClickListener(v -> {
            AppLogger.log(SettingsActivity.this, TAG, "Daily challenge clicked");
            startActivity(new Intent(this, DailyChallengeActivity.class));
        });

        Button btnGameRules = findViewById(R.id.btn_game_rules);
        btnGameRules.setOnClickListener(v -> {
            AppLogger.log(SettingsActivity.this, TAG, "Game rules clicked");
            startActivity(new Intent(this, GameRulesActivity.class));
        });

        Button btnChangelog = findViewById(R.id.btn_changelog);
        btnChangelog.setOnClickListener(v -> {
            AppLogger.log(SettingsActivity.this, TAG, "Changelog clicked");
            startActivity(new Intent(this, ChangelogChatActivity.class));
        });

        Button btnExport = findViewById(R.id.btn_export);
        btnExport.setOnClickListener(v -> {
            AppLogger.log(SettingsActivity.this, TAG, "Export clicked");
            exportSettings();
        });

        Button btnClearCache = findViewById(R.id.btn_clear_cache);
        btnClearCache.setOnClickListener(v -> {
            AppLogger.log(SettingsActivity.this, TAG, "Clear cache clicked");
            clearAppCache();
        });

        Button btnBackup = findViewById(R.id.btn_backup);
        btnBackup.setOnClickListener(v -> {
            AppLogger.log(SettingsActivity.this, TAG, "Backup clicked");
            BackupManager.createBackup(this);
            Toast.makeText(this, "Бэкап создан", Toast.LENGTH_SHORT).show();
        });

        Button btnRestore = findViewById(R.id.btn_restore);
        btnRestore.setOnClickListener(v -> {
            AppLogger.log(SettingsActivity.this, TAG, "Restore clicked");
            BackupManager.restoreBackup(this);
            Toast.makeText(this, "Восстановлено", Toast.LENGTH_SHORT).show();
        });

        Button btnShareApp = findViewById(R.id.btn_share_app);
        btnShareApp.setOnClickListener(v -> {
            AppLogger.log(SettingsActivity.this, TAG, "Share app clicked");
            shareApp();
        });

        // ==================== ДРУГИЕ ПРОЕКТЫ ====================
        Button btnOtherProjects = new Button(this);
        btnOtherProjects.setText("📦 Мои другие проекты");
        btnOtherProjects.setTextSize(16);
        btnOtherProjects.setTextColor(ThemeManager.getTextColor(this));
        btnOtherProjects.setBackgroundColor(ThemeManager.getCardColor(this));
        btnOtherProjects.setPadding(32, 16, 32, 16);
        LinearLayout.LayoutParams btnParams = new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        );
        btnParams.setMargins(0, 16, 0, 0);
        btnOtherProjects.setLayoutParams(btnParams);
        btnOtherProjects.setOnClickListener(v -> {
            AppLogger.log(SettingsActivity.this, TAG, "📦 Other Projects button clicked");
            startActivity(new Intent(SettingsActivity.this, OtherProjectsActivity.class));
        });

        // Находим ScrollView и добавляем кнопку в конец
        ScrollView scrollView = findViewById(R.id.settings_layout);
        if (scrollView != null) {
            LinearLayout mainLayout = (LinearLayout) scrollView.getChildAt(0);
            if (mainLayout != null) {
                mainLayout.addView(btnOtherProjects);
                AppLogger.log(this, TAG, "✅ Other Projects button added");
            }
        }

        applyThemeToTexts();
        addDeveloperModeButton();

        AppLogger.log(this, TAG, "Listeners setup complete");
    }

    private void saveSettings() {
        AppLogger.log(this, TAG, "saveSettings() START");

        String nn = nameInput.getText().toString().trim();
        if (!nn.isEmpty()) {
            dbHelper.saveProfileName(nn);
            AppLogger.log(this, TAG, "Name saved: " + nn);
        }

        if (avatarPath != null && !avatarPath.isEmpty()) {
            dbHelper.saveProfileAvatar(avatarPath);
            AppLogger.log(this, TAG, "Avatar saved: " + avatarPath);
        }

        int t = ThemeManager.THEME_LIGHT;
        int tid = radioGroupTheme.getCheckedRadioButtonId();
        if (tid == R.id.radio_dark) t = ThemeManager.THEME_DARK;
        else if (tid == R.id.radio_amoled) t = ThemeManager.THEME_AMOLED;

        dbHelper.saveTheme(t);
        ThemeManager.saveTheme(this, t);
        AppLogger.log(this, TAG, "Theme saved: " + t);

        Toast.makeText(this, "Настройки сохранены. Перезапустите приложение для применения темы.", Toast.LENGTH_LONG).show();
        AppLogger.log(this, TAG, "saveSettings() END");
    }

    private void updateStats() {
        int streak = StreakManager.getStreakDays(this);
        int best = StreakManager.getBestStreak(this);
        int today = StreakManager.getTodayMinutes(this);
        int total = StreakManager.getTotalMinutes(this);
        String ringName = StreakManager.getRingName(streak);
        String ringColor = StreakManager.getRingColor(streak);

        tvStreakDays.setText("🔥 Текущая серия: " + streak + " дней");
        tvBestStreak.setText("🏆 Лучшая серия: " + best + " дней");
        tvTodayTime.setText("⏱ Сегодня: " + today + " мин (нужно 25)");
        tvTotalTime.setText("📅 Всего: " + total + " мин (" + (total / 60) + " ч)");
        tvRingName.setText("💍 Ободок: " + ringName + " (" + ringColor + ")");

        AppLogger.log(this, TAG, "Stats updated: streak=" + streak + ", best=" + best + ", today=" + today + ", total=" + total);
    }

    private void setupRingColors() {
        ringColorContainer.removeAllViews();

        int[] colors = {
            Color.parseColor("#CD7F32"), // Бронза
            Color.parseColor("#C0C0C0"), // Серебро
            Color.parseColor("#FFD700"), // Золото
            Color.parseColor("#FF6B6B"), // Красный
            Color.parseColor("#4FC3F7"), // Голубой
            Color.parseColor("#4CAF50"), // Зелёный
            Color.parseColor("#AB47BC"), // Фиолетовый
            Color.parseColor("#FF9800")  // Оранжевый
        };

        for (int color : colors) {
            View colorView = new View(this);
            int size = getResources().getDimensionPixelSize(android.R.dimen.app_icon_size) / 2;
            LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(size, size);
            params.setMargins(8, 8, 8, 8);
            colorView.setLayoutParams(params);

            GradientDrawable circle = new GradientDrawable();
            circle.setShape(GradientDrawable.OVAL);
            circle.setColor(color);
            circle.setStroke(2, Color.WHITE);
            colorView.setBackground(circle);

            final int finalColor = color;
            colorView.setOnClickListener(v -> {
                AppLogger.log(SettingsActivity.this, TAG, "Ring color selected: " + String.format("#%06X", 0xFFFFFF & finalColor));
                int streak = StreakManager.getStreakDays(SettingsActivity.this);
                if (streak >= 100) {
                    String hex = String.format("#%06X", 0xFFFFFF & finalColor);
                    dbHelper.saveRingColor(hex);
                    Toast.makeText(SettingsActivity.this, "Цвет ободка сохранён!", Toast.LENGTH_SHORT).show();
                    updateStats();
                    AppLogger.log(SettingsActivity.this, TAG, "Ring color saved: " + hex);
                } else {
                    Toast.makeText(SettingsActivity.this, "Доступно только при 100+ днях серии! (сейчас " + streak + ")", Toast.LENGTH_SHORT).show();
                }
            });

            ringColorContainer.addView(colorView);
        }

        AppLogger.log(this, TAG, "Ring colors setup complete");
    }

    private void animateButtons() {
        Button[] buttons = {
            findViewById(R.id.btn_save),
            findViewById(R.id.btn_stats),
            findViewById(R.id.btn_daily_challenge),
            findViewById(R.id.btn_game_stats),
            findViewById(R.id.btn_game_rules),
            findViewById(R.id.btn_changelog),
            findViewById(R.id.btn_export),
            findViewById(R.id.btn_clear_cache),
            findViewById(R.id.btn_view_log),
            findViewById(R.id.btn_backup),
            findViewById(R.id.btn_restore),
            findViewById(R.id.btn_share_app)
        };

        for (int i = 0; i < buttons.length; i++) {
            if (buttons[i] != null) {
                final int delay = 100 + i * 80;
                buttons[i].setTranslationX(300);
                buttons[i].setAlpha(0f);
                buttons[i].animate()
                        .translationX(0f)
                        .alpha(1f)
                        .setDuration(400)
                        .setStartDelay(delay)
                        .setInterpolator(new OvershootInterpolator(0.8f))
                        .start();
            }
        }

        AppLogger.log(this, TAG, "Buttons animated");
    }

    // ==================== ВСПОМОГАТЕЛЬНЫЕ МЕТОДЫ ====================

    private void updateDeviceInfo() {
        if (statsText == null) return;
        StringBuilder sb = new StringBuilder();
        sb.append("Устройство:\n");
        sb.append("Модель: ").append(Build.MODEL).append("\n");
        sb.append("Производитель: ").append(Build.MANUFACTURER).append("\n");
        sb.append("Android: ").append(Build.VERSION.RELEASE).append(" (SDK ").append(Build.VERSION.SDK_INT).append(")\n");
        File dataDir = getFilesDir();
        long freeSpace = dataDir.getFreeSpace() / (1024 * 1024);
        long totalSpace = dataDir.getTotalSpace() / (1024 * 1024);
        sb.append("Память: ").append(freeSpace).append(" МБ свободно из ").append(totalSpace).append(" МБ\n");
        sb.append("Логи: ").append(AppLogger.getStats());
        statsText.setText(sb.toString());
        AppLogger.log(this, TAG, "Device info updated");
    }

    private void updateVersionInfo() {
        try {
            PackageInfo pInfo = getPackageManager().getPackageInfo(getPackageName(), 0);
            String versionName = pInfo.versionName;
            int versionCode = pInfo.versionCode;
            if (versionText != null) {
                versionText.setText("Версия: " + versionName + " (" + versionCode + ")");
            }
            if (developerText != null) {
                developerText.setText("Разработчик: dennndennn34");
            }
        } catch (PackageManager.NameNotFoundException e) {
            AppLogger.logException(this, TAG, e);
        }
    }

    private void setupDeveloperInfo() {
        if (tiktokText != null) {
            tiktokText.setMovementMethod(android.text.method.LinkMovementMethod.getInstance());
            tiktokText.setOnClickListener(v -> {
                String url = "https://www.tiktok.com/@dennndennn34?_r=1&_t=ZS-97jFA2i5EQs";
                Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
                startActivity(intent);
            });
        }

        if (emailText != null) {
            emailText.setMovementMethod(android.text.method.LinkMovementMethod.getInstance());
            emailText.setOnClickListener(v -> {
                Intent intent = new Intent(Intent.ACTION_SENDTO);
                intent.setData(Uri.parse("mailto:dennndennn34@gmail.com"));
                startActivity(intent);
            });
        }
    }

    private void addDeveloperModeButton() {
        AppLogger.log(this, TAG, "🔐 addDeveloperModeButton() called");

        ScrollView scrollView = findViewById(R.id.settings_layout);
        if (scrollView == null) {
            AppLogger.log(this, TAG, "❌ settings_layout not found");
            return;
        }

        LinearLayout mainLayout = (LinearLayout) scrollView.getChildAt(0);
        if (mainLayout == null) {
            AppLogger.log(this, TAG, "❌ LinearLayout not found");
            return;
        }

        View divider = new View(this);
        divider.setLayoutParams(new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 1
        ));
        divider.setBackgroundColor(0xFF30363D);
        mainLayout.addView(divider);

        Button btnDevMode = new Button(this);
        btnDevMode.setText("🔐 Режим разработчика");
        btnDevMode.setTextColor(0xFFE6EDF3);
        btnDevMode.setBackgroundColor(0xFF161B22);
        btnDevMode.setPadding(32, 16, 32, 16);
        btnDevMode.setLayoutParams(new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
        ));
        btnDevMode.setOnClickListener(v -> {
            AppLogger.log(SettingsActivity.this, TAG, "🔐 Developer mode button clicked");
            showPinDialog();
        });

        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
        );
        params.setMargins(0, 24, 0, 0);
        btnDevMode.setLayoutParams(params);
        mainLayout.addView(btnDevMode);

        AppLogger.log(this, TAG, "✅ Developer mode button added");
    }

    private void showPinDialog() {
        AppLogger.log(this, TAG, "🔐 showPinDialog() called");

        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("🔐 Вход в режим разработчика");
        builder.setMessage("Введите 4-значный код");

        final EditText input = new EditText(this);
        input.setInputType(InputType.TYPE_CLASS_NUMBER);
        input.setMaxLines(1);
        input.setHint("_ _ _ _");
        input.setGravity(Gravity.CENTER);
        input.setTextSize(24);
        input.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
        input.setPadding(32, 16, 32, 16);
        builder.setView(input);

        builder.setPositiveButton("Войти", (dialog, which) -> {
            String code = input.getText().toString();
            AppLogger.log(SettingsActivity.this, TAG, "🔐 Code entered: " + code);

            if (code.equals("3629")) {
                AppLogger.log(SettingsActivity.this, TAG, "✅ Correct code! Opening DeveloperMode");
                Toast.makeText(SettingsActivity.this, "✅ Добро пожаловать в режим разработчика!", Toast.LENGTH_LONG).show();
                Intent intent = new Intent(SettingsActivity.this, DeveloperModeActivity.class);
                startActivity(intent);
            } else {
                AppLogger.log(SettingsActivity.this, TAG, "❌ Wrong code entered: " + code);
                Toast.makeText(SettingsActivity.this, "❌ Неверный код", Toast.LENGTH_SHORT).show();
            }
        });

        builder.setNegativeButton("Отмена", null);
        builder.show();
    }

    private void shareApp() {
        AppLogger.log(this, TAG, "📤 shareApp() called");

        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle(R.string.share_warning_title);
        builder.setMessage(R.string.share_warning_message);
        builder.setPositiveButton(R.string.share_button_continue, (dialog, which) -> {
            AppLogger.log(SettingsActivity.this, "ShareApp", "User confirmed share");
            performShareApk();
        });
        builder.setNegativeButton(R.string.share_button_cancel, (dialog, which) -> {
            AppLogger.log(SettingsActivity.this, "ShareApp", "User cancelled share");
            dialog.dismiss();
        });
        builder.show();
        AppLogger.log(this, TAG, "Warning dialog shown");
    }

    private void performShareApk() {
        AppLogger.log(this, TAG, "performShareApk() started");
        try {
            ApplicationInfo appInfo = getPackageManager().getApplicationInfo(getPackageName(), 0);
            String apkPath = appInfo.sourceDir;
            AppLogger.log(this, TAG, "APK source path: " + apkPath);

            File cacheDir = getCacheDir();
            File apkFile = new File(cacheDir, "Last04ka.apk");
            if (apkFile.exists()) {
                apkFile.delete();
                AppLogger.log(this, TAG, "Old APK deleted from cache");
            }

            File src = new File(apkPath);
            if (!src.exists()) {
                AppLogger.log(this, TAG, "❌ Source APK not found");
                Toast.makeText(this, R.string.share_no_apk, Toast.LENGTH_SHORT).show();
                return;
            }

            AppLogger.log(this, TAG, "Copying APK from " + apkPath + " to " + apkFile.getAbsolutePath());
            try (InputStream in = new FileInputStream(src);
                 OutputStream out = new FileOutputStream(apkFile)) {
                byte[] buffer = new byte[8192];
                int length;
                while ((length = in.read(buffer)) > 0) {
                    out.write(buffer, 0, length);
                }
            }
            AppLogger.log(this, TAG, "✅ APK copied to cache, size: " + apkFile.length() + " bytes");

            Uri apkUri = FileProvider.getUriForFile(this, getPackageName() + ".provider", apkFile);
            AppLogger.log(this, TAG, "URI created: " + apkUri.toString());

            Intent shareIntent = new Intent(Intent.ACTION_SEND);
            shareIntent.setType("application/vnd.android.package-archive");
            shareIntent.putExtra(Intent.EXTRA_STREAM, apkUri);
            shareIntent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);

            AppLogger.log(this, TAG, "Share intent created, starting chooser");
            startActivity(Intent.createChooser(shareIntent, "Поделиться приложением"));

        } catch (IOException e) {
            AppLogger.logException(this, TAG, "❌ Copy failed", e);
            Toast.makeText(this, R.string.share_copy_failed, Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            AppLogger.logException(this, TAG, "❌ Share error", e);
            Toast.makeText(this, R.string.share_provider_error, Toast.LENGTH_SHORT).show();
        }
    }

    private void exportSettings() {
        AppLogger.log(this, TAG, "exportSettings() called");
        try {
            StringBuilder sb = new StringBuilder();
            sb.append("{\n");
            sb.append("  \"name\": \"").append(dbHelper.getProfileName()).append("\",\n");
            sb.append("  \"theme\": ").append(dbHelper.getTheme()).append(",\n");
            sb.append("  \"version\": \"").append(getVersionName()).append("\"\n");
            sb.append("}\n");
            File dir = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), "Last04ka");
            if (!dir.exists()) dir.mkdirs();
            File file = new File(dir, "settings_" + System.currentTimeMillis() + ".json");
            FileOutputStream fos = new FileOutputStream(file);
            fos.write(sb.toString().getBytes());
            fos.close();
            Toast.makeText(this, "Экспорт: " + file.getName(), Toast.LENGTH_LONG).show();
            AppLogger.log(this, TAG, "Settings exported to JSON");
        } catch (Exception e) {
            AppLogger.logException(this, TAG, e);
        }
    }

    private String getVersionName() {
        try {
            PackageInfo pInfo = getPackageManager().getPackageInfo(getPackageName(), 0);
            return pInfo.versionName;
        } catch (PackageManager.NameNotFoundException e) {
            return "1.0";
        }
    }

    private void clearAppCache() {
        AppLogger.log(this, TAG, "clearAppCache() called");
        try {
            File cache = getCacheDir();
            deleteRecursive(cache);
            Toast.makeText(this, "Кеш очищен!", Toast.LENGTH_SHORT).show();
            AppLogger.log(this, TAG, "Cache cleared");
        } catch (Exception e) {
            AppLogger.logException(this, TAG, e);
        }
    }

    private void deleteRecursive(File file) {
        if (file.isDirectory())
            for (File child : file.listFiles())
                deleteRecursive(child);
        file.delete();
    }

    private void applyThemeToTexts() {
        int tc = ThemeManager.getTextColor(this);
        int bc = ThemeManager.getBackgroundColor(this);
        findViewById(R.id.settings_layout).setBackgroundColor(bc);
        if (getSupportActionBar() != null)
            getSupportActionBar().setBackgroundDrawable(new ColorDrawable(ThemeManager.isDarkTheme(this) ? 0xFF424242 : 0xFF1565C0));

        for (int id : new int[]{R.id.section_profile, R.id.section_theme, R.id.section_tools, R.id.version_text, R.id.section_device, R.id.developer_text, R.id.email_text, R.id.tiktok_text}) {
            TextView tv = findViewById(id);
            if (tv != null) tv.setTextColor(tc);
        }
    }

    @Override
    protected void onActivityResult(int rq, int rc, @Nullable Intent data) {
        super.onActivityResult(rq, rc, data);
        AppLogger.log(this, TAG, "onActivityResult: rq=" + rq + ", rc=" + rc);

        if (rq == PICK_IMAGE && rc == RESULT_OK && data != null) {
            try {
                Uri u = data.getData();
                InputStream is = getContentResolver().openInputStream(u);
                Bitmap bm = BitmapFactory.decodeStream(is);
                avatarView.setImageBitmap(bm);
                File d = getFilesDir();
                File f = new File(d, "avatar_" + System.currentTimeMillis() + ".jpg");
                FileOutputStream fos = new FileOutputStream(f);
                bm.compress(Bitmap.CompressFormat.JPEG, 90, fos);
                fos.close();
                avatarPath = f.getAbsolutePath();
                AppLogger.log(this, TAG, "Avatar saved: " + avatarPath);
            } catch (Exception e) {
                AppLogger.logException(this, TAG, e);
            }
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        AppLogger.log(this, TAG, "onResume");
        updateStats();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        AppLogger.log(this, TAG, "onDestroy");
    }
}