package com.last04ka.messenger.ui;

import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import com.last04ka.messenger.utils.AppLogger;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class NickGeneratorActivity extends Activity {

    private TextView nickText, historyText;
    private String current = "";
    private List<String> history = new ArrayList<>();
    private List<String> favorites = new ArrayList<>();
    private Random r = new Random();

    private String[] coolPrefix = {"Xx_", "Pro_", "Mr_", "Dr_", "Lord_", "Sir_", "xX_", "The_", "Dark_", "Ultra_"};
    private String[] coolSuffix = {"_xX", "_Pro", "_HD", "_YT", "_tv", "_GG", "_420", "_XD", "_OP", "_V2"};
    private String[] funnyAdj = {"Смешной","Грустный","Сонный","Злой","Весёлый","Голодный","Ленивый","Быстрый","Хитрый","Добрый"};
    private String[] funnyNoun = {"Кот","Хомяк","Пингвин","Банан","Пельмень","Огурец","Кабачок","Енот","Бобёр","Кактус"};
    private String[] animeSyl = {"кира","неко","сэнпай","кун","чан","сакура","ками","юки","хикари","акари","мидзу","цуки"};
    private String[] russianNames = {"Иван_Грозный","Пётр_Первый","Царь_Батюшка","Князь_Владимир","Богатырь","Добрыня","Алёша_Попович"};
    private String[] techNames = {"Cyber","Pixel","Neon","Byte","Glitch","Phantom","Crypto","Matrix","Synth","Vector"};
    private String[] techSuffix = {"_404","_bin","_exe","_dev","_null","_root","_log","_net","_code","_AI"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        try {
            AppLogger.log(this, "NickGen", "onCreate started");
            LinearLayout layout = new LinearLayout(this);
            layout.setOrientation(LinearLayout.VERTICAL); layout.setPadding(24,24,24,24); layout.setBackgroundColor(0xFF1A1A2E);

            TextView title = new TextView(this); title.setText("📋 Генератор ников");
            title.setTextSize(20); title.setTextColor(0xFFFFFFFF); title.setGravity(android.view.Gravity.CENTER); title.setPadding(0,0,0,20); layout.addView(title);

            nickText = new TextView(this); nickText.setText("Выберите стиль");
            nickText.setTextSize(22); nickText.setTextColor(0xFF00E676); nickText.setGravity(android.view.Gravity.CENTER);
            nickText.setPadding(16,24,16,24); nickText.setBackgroundColor(0xFF333333); nickText.setMinHeight(80); layout.addView(nickText);

            String[] styles = {"🎮 Геймерский","😂 Смешной","🌸 Аниме","🇷🇺 Русский","💻 Техно","🤖 Случайный"};
            for (final String style : styles) {
                Button btn = new Button(this); btn.setText(style);
                btn.setOnClickListener(new View.OnClickListener() { @Override public void onClick(View v) { generateNick(style); } });
                layout.addView(btn);
            }

            LinearLayout btns = new LinearLayout(this); btns.setOrientation(LinearLayout.HORIZONTAL);
            Button btnCopy = new Button(this); btnCopy.setText("📋");
            btnCopy.setOnClickListener(new View.OnClickListener() { @Override public void onClick(View v) { copyNick(); } });
            btns.addView(btnCopy);
            Button btnFav = new Button(this); btnFav.setText("⭐");
            btnFav.setOnClickListener(new View.OnClickListener() { @Override public void onClick(View v) { addFavorite(); } });
            btns.addView(btnFav);
            layout.addView(btns);

            ScrollView sv = new ScrollView(this);
            historyText = new TextView(this); historyText.setText(""); historyText.setTextColor(0xFFBDBDBD); historyText.setTextSize(13); historyText.setPadding(0,16,0,0);
            sv.addView(historyText);
            LinearLayout.LayoutParams svp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 150);
            sv.setLayoutParams(svp);
            layout.addView(sv);

            Button btnClear = new Button(this); btnClear.setText("Очистить историю");
            btnClear.setOnClickListener(new View.OnClickListener() { @Override public void onClick(View v) { history.clear(); favorites.clear(); updateHistory(); } });
            layout.addView(btnClear);

            setContentView(layout); setTitle("📋 Генератор ников");
            AppLogger.log(this, "NickGen", "onCreate completed");
        } catch (Exception e) { AppLogger.logException(this, "NickGen", e); finish(); }
    }

    private void generateNick(String style) {
        if (style.contains("Геймер")) current = coolPrefix[r.nextInt(coolPrefix.length)] + randomWord(4,8) + coolSuffix[r.nextInt(coolSuffix.length)];
        else if (style.contains("Смешной")) current = funnyAdj[r.nextInt(funnyAdj.length)] + funnyNoun[r.nextInt(funnyNoun.length)] + r.nextInt(99);
        else if (style.contains("Аниме")) current = animeSyl[r.nextInt(animeSyl.length)] + "_" + animeSyl[r.nextInt(animeSyl.length)] + r.nextInt(99);
        else if (style.contains("Русский")) current = russianNames[r.nextInt(russianNames.length)];
        else if (style.contains("Техно")) current = techNames[r.nextInt(techNames.length)] + techSuffix[r.nextInt(techSuffix.length)];
        else { String[] all = {coolPrefix[r.nextInt(coolPrefix.length)]+randomWord(4,8)+coolSuffix[r.nextInt(coolSuffix.length)], funnyAdj[r.nextInt(funnyAdj.length)]+funnyNoun[r.nextInt(funnyNoun.length)]+r.nextInt(99), animeSyl[r.nextInt(animeSyl.length)]+"_"+animeSyl[r.nextInt(animeSyl.length)]+r.nextInt(99), techNames[r.nextInt(techNames.length)]+techSuffix[r.nextInt(techSuffix.length)]}; current = all[r.nextInt(all.length)]; }
        nickText.setText(current); history.add(0, current); if (history.size() > 10) history.remove(history.size()-1); updateHistory();
    }

    private void copyNick() {
        if (current.isEmpty()) { Toast.makeText(this, "Сгенерируйте ник", Toast.LENGTH_SHORT).show(); return; }
        ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
        cm.setPrimaryClip(ClipData.newPlainText("nick", current));
        Toast.makeText(this, "Скопировано!", Toast.LENGTH_SHORT).show();
    }

    private void addFavorite() {
        if (current.isEmpty()) return;
        if (!favorites.contains(current)) { favorites.add(0, current); updateHistory(); }
        Toast.makeText(this, "⭐ В избранное!", Toast.LENGTH_SHORT).show();
    }

    private void updateHistory() {
        StringBuilder sb = new StringBuilder();
        sb.append("⭐ Избранное:\n");
        for (String f : favorites) sb.append("⭐ ").append(f).append("\n");
        sb.append("\n🕐 История:\n");
        for (String h : history) sb.append(h).append("\n");
        historyText.setText(sb.toString());
    }

    private String randomWord(int min, int max) {
        String cons = "bcdfghjklmnpqrstvwxyz", vows = "aeiou";
        int len = min + r.nextInt(max - min + 1);
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < len; i++) sb.append(i % 2 == 0 ? cons.charAt(r.nextInt(cons.length())) : vows.charAt(r.nextInt(vows.length())));
        return sb.substring(0,1).toUpperCase() + sb.substring(1);
    }
}