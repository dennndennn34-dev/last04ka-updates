package com.last04ka.messenger.ui;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import com.last04ka.messenger.utils.AppLogger;
import java.util.Random;

public class Game24Activity extends Activity {

    private TextView numbersText, historyText, scoreText;
    private EditText input;
    private Button btnCheck, btnNew, btnHint;
    private int[] nums = new int[4];
    private int score = 0;
    private Random r = new Random();
    private StringBuilder history = new StringBuilder();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        try {
            AppLogger.log(this, "Game24", "onCreate started");
            LinearLayout layout = new LinearLayout(this);
            layout.setOrientation(LinearLayout.VERTICAL); layout.setPadding(24,24,24,24); layout.setBackgroundColor(0xFF1A1A2E);

            scoreText = new TextView(this); scoreText.setText("Счёт: 0"); scoreText.setTextSize(16); scoreText.setTextColor(0xFFFFFFFF); layout.addView(scoreText);
            numbersText = new TextView(this); numbersText.setTextSize(32); numbersText.setTextColor(0xFFFFD740);
            numbersText.setGravity(android.view.Gravity.CENTER); numbersText.setPadding(0,16,0,16); layout.addView(numbersText);
            input = new EditText(this); input.setHint("Введите выражение (например 8+8+4+4)");
            input.setTextColor(0xFFFFFFFF); input.setHintTextColor(0xFF757575); input.setTextSize(18); input.setPadding(12,12,12,12); layout.addView(input);

            LinearLayout btns = new LinearLayout(this); btns.setOrientation(LinearLayout.HORIZONTAL);
            btnCheck = new Button(this); btnCheck.setText("Проверить");
            btnCheck.setOnClickListener(new View.OnClickListener() { @Override public void onClick(View v) { checkExpression(); } });
            btns.addView(btnCheck);
            btnNew = new Button(this); btnNew.setText("Новые числа");
            btnNew.setOnClickListener(new View.OnClickListener() { @Override public void onClick(View v) { newNumbers(); } });
            btns.addView(btnNew);
            btnHint = new Button(this); btnHint.setText("💡");
            btnHint.setOnClickListener(new View.OnClickListener() { @Override public void onClick(View v) { showHint(); } });
            btns.addView(btnHint);
            layout.addView(btns);

            historyText = new TextView(this); historyText.setText("История:"); historyText.setTextSize(14); historyText.setTextColor(0xFFBDBDBD); historyText.setPadding(0,16,0,0); layout.addView(historyText);

            setContentView(layout); setTitle("🧮 24 points"); newNumbers();
            AppLogger.log(this, "Game24", "onCreate completed");
        } catch (Exception e) { AppLogger.logException(this, "Game24", e); finish(); }
    }

    private void newNumbers() { for (int i = 0; i < 4; i++) nums[i] = r.nextInt(9) + 1;
        numbersText.setText(nums[0]+"  "+nums[1]+"  "+nums[2]+"  "+nums[3]+"  = 24 ?"); input.setText(""); }

    private void showHint() {
        // Простейшая подсказка: показываем возможные комбинации
        String hint = "Попробуйте: " + nums[0] + "+" + nums[1] + "+" + nums[2] + "+" + nums[3] + " = " + (nums[0]+nums[1]+nums[2]+nums[3]);
        hint += "\nИли перемножайте и складывайте!";
        Toast.makeText(this, hint, Toast.LENGTH_LONG).show();
    }

    private void checkExpression() {
        String expr = input.getText().toString().trim(); if (expr.isEmpty()) return;
        expr = expr.replace("×","*").replace("·","*").replace("x","*").replace("X","*").replace("÷","/").replace(":","/");
        try {
            double result = evaluateExpression(expr); String formatted = formatResult(result);
            if (Math.abs(result - 24.0) < 0.0001) { score += 10; Toast.makeText(this,"✅ = 24!",Toast.LENGTH_SHORT).show();
                history.insert(0, expr + " = 24 ✅\n"); newNumbers(); }
            else { Toast.makeText(this,"❌ = "+formatted,Toast.LENGTH_SHORT).show(); history.insert(0, expr+" = "+formatted+" ❌\n"); }
            scoreText.setText("Счёт: "+score); historyText.setText("История:\n"+history.toString());
        } catch (Exception e) { Toast.makeText(this,"Ошибка в выражении",Toast.LENGTH_SHORT).show(); }
    }

    private double evaluateExpression(String expr) {
        expr = expr.replaceAll("\\s+","");
        while (expr.contains("(")) { int s = expr.lastIndexOf('('), e = expr.indexOf(')',s);
            double v = evalSimple(expr.substring(s+1,e)); expr = expr.substring(0,s) + formatResult(v) + expr.substring(e+1); }
        return evalSimple(expr);
    }

    private double evalSimple(String s) {
        while (s.contains("*") || s.contains("/")) {
            int mi=s.indexOf('*'), di=s.indexOf('/'); int oi=(mi>=0&&(di<0||mi<di))?mi:di; char op=s.charAt(oi);
            int ls=oi-1; while(ls>=0&&(Character.isDigit(s.charAt(ls))||s.charAt(ls)=='.'||(ls>0&&s.charAt(ls)=='-'&&"+−*/".indexOf(s.charAt(ls-1))>=0))) ls--;
            ls++; int re=oi+1; if(re<s.length()&&s.charAt(re)=='-') re++;
            while(re<s.length()&&(Character.isDigit(s.charAt(re))||s.charAt(re)=='.')) re++;
            double a=Double.parseDouble(s.substring(ls,oi)), b=Double.parseDouble(s.substring(oi+1,re));
            double r = op=='*'?a*b:(b==0?0:a/b);
            s = s.substring(0,ls) + formatResult(r) + s.substring(re);
        }
        double total=0; StringBuilder num=new StringBuilder(); char op='+';
        for(int i=0;i<s.length();i++){ char c=s.charAt(i);
            if(Character.isDigit(c)||c=='.'||(c=='-'&&num.length()==0)) num.append(c);
            if("+−-".indexOf(c)>=0&&num.length()>0&&!(c=='-'&&i==0)){
                total=op=='+'?total+Double.parseDouble(num.toString()):total-Double.parseDouble(num.toString()); num=new StringBuilder(); op='+'; }
            else if(i==s.length()-1&&num.length()>0) total=op=='+'?total+Double.parseDouble(num.toString()):total-Double.parseDouble(num.toString());
        }
        return total;
    }

    private String formatResult(double r) { if(r==Math.floor(r)&&!Double.isInfinite(r)) return String.valueOf((long)r);
        String s=String.format("%.2f",r); while(s.contains(".")&&(s.endsWith("0")||s.endsWith("."))) s=s.substring(0,s.length()-1); return s; }
}