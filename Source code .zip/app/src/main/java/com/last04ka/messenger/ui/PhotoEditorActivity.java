package com.last04ka.messenger.ui;

import android.Manifest;
import android.app.AlertDialog;
import android.content.ContentValues;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.provider.MediaStore;
import android.support.annotation.NonNull;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import com.last04ka.messenger.R;
import com.last04ka.messenger.utils.AppLogger;
import com.last04ka.messenger.utils.NeuralEffectEngine;
import com.last04ka.messenger.utils.PhotoProcessor;
import com.last04ka.messenger.utils.ThemeManager;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public class PhotoEditorActivity extends AppCompatActivity {
    private static final String TAG = "PhotoEditor";
    private static final int PICK_IMAGE_REQUEST = 1001;
    private static final int REQUEST_CAMERA = 1002;
    private static final int REQUEST_CAMERA_PERMISSION = 300;

    // UI Components
    private ImageView ivPhoto;
    private DrawingView drawingView;
    private ProgressBar progressBar;
    private TextView tvProgress;
    private LinearLayout bottomSheet;
    
    private Button btnSelectImage, btnTakePhoto, btnSave;
    private ImageButton btnUndo, btnRedo, btnCrop, btnEffects, btnAdjust, btnAITools;
    
    private RecyclerView rvEffects;
    private SeekBar sbIntensity;
    private TextView tvIntensity;

    // Processing
    private Bitmap originalBitmap;
    private Bitmap currentBitmap;
    private PhotoProcessor photoProcessor;
    private NeuralEffectEngine neuralEngine;
    private Handler mainHandler = new Handler(Looper.getMainLooper());
    
    // State
    private List<Bitmap> history = new ArrayList<>();
    private int historyPosition = -1;
    private String currentEffect = "none";
    private float currentIntensity = 0.5f;
    private boolean isDrawingMode = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        setTheme(ThemeManager.getThemeResource(this));
        super.onCreate(savedInstanceState);
        AppLogger.log(this, TAG, "PhotoEditorActivity onCreate START");
        
        try {
            setContentView(R.layout.activity_photo_editor);
            
            initViews();
            initProcessors();
            setupEffectRecyclerView();
            setupListeners();
            applyThemeColors();
            
            AppLogger.log(this, TAG, "PhotoEditorActivity initialized");
        } catch (Exception e) {
            AppLogger.logException(this, TAG, "onCreate error", e);
            Toast.makeText(this, "Ошибка: " + e.getMessage(), Toast.LENGTH_LONG).show();
            finish();
        }
    }
    
    private void initViews() {
        ivPhoto = findViewById(R.id.iv_photo);
        drawingView = findViewById(R.id.drawing_view);
        progressBar = findViewById(R.id.progress_bar);
        tvProgress = findViewById(R.id.tv_progress);
        bottomSheet = findViewById(R.id.bottom_sheet);
        
        btnSelectImage = findViewById(R.id.btn_select_image);
        btnTakePhoto = findViewById(R.id.btn_take_photo);
        btnSave = findViewById(R.id.btn_save);
        
        btnUndo = findViewById(R.id.btn_undo);
        btnRedo = findViewById(R.id.btn_redo);
        btnCrop = findViewById(R.id.btn_crop);
        btnEffects = findViewById(R.id.btn_effects);
        btnAdjust = findViewById(R.id.btn_adjust);
        btnAITools = findViewById(R.id.btn_ai_tools);
        
        rvEffects = findViewById(R.id.rv_effects);
        sbIntensity = findViewById(R.id.sb_intensity);
        tvIntensity = findViewById(R.id.tv_intensity);
        
        // Настройка DrawingView
        if (drawingView != null) {
            drawingView.setDrawingCallback(this::removeObjectWithMask);
            AppLogger.log(this, TAG, "DrawingView callback set");
        } else {
            AppLogger.log(this, TAG, "WARNING: drawingView is null!");
        }
        
        AppLogger.log(this, TAG, "Views initialized");
    }
    
    private void initProcessors() {
        photoProcessor = new PhotoProcessor(this);
        neuralEngine = new NeuralEffectEngine(this);
        AppLogger.log(this, TAG, "Processors initialized");
    }
    
    private void setupEffectRecyclerView() {
        List<EffectItem> effects = new ArrayList<>();
        effects.add(new EffectItem("Оригинал", "none"));
        effects.add(new EffectItem("Винтаж", "vintage"));
        effects.add(new EffectItem("Нуар", "noir"));
        effects.add(new EffectItem("Сепия", "sepia"));
        effects.add(new EffectItem("Акварель", "watercolor"));
        effects.add(new EffectItem("Масло", "oil"));
        effects.add(new EffectItem("Пикселизация", "pixelate"));
        effects.add(new EffectItem("Размытие", "blur"));
        effects.add(new EffectItem("Резкость", "sharpen"));
        effects.add(new EffectItem("Виньетка", "vignette"));
        
        EffectAdapter adapter = new EffectAdapter(effects);
        rvEffects.setLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false));
        rvEffects.setAdapter(adapter);
        AppLogger.log(this, TAG, "Effect RecyclerView setup");
    }
    
    private void setupListeners() {
        btnSelectImage.setOnClickListener(v -> selectImage());
        btnTakePhoto.setOnClickListener(v -> takePhoto());
        btnSave.setOnClickListener(v -> saveImage());
        btnUndo.setOnClickListener(v -> undo());
        btnRedo.setOnClickListener(v -> redo());
        btnEffects.setOnClickListener(v -> toggleBottomSheet());
        btnAITools.setOnClickListener(v -> showAIToolsDialog());
        btnCrop.setOnClickListener(v -> showCropDialog());
        btnAdjust.setOnClickListener(v -> showAdjustDialog());
        
        sbIntensity.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                if (fromUser) {
                    currentIntensity = progress / 100f;
                    tvIntensity.setText(Math.round(currentIntensity * 100) + "%");
                    applyCurrentEffect();
                }
            }
            @Override public void onStartTrackingTouch(SeekBar seekBar) {}
            @Override public void onStopTrackingTouch(SeekBar seekBar) {}
        });
        
        AppLogger.log(this, TAG, "Listeners setup complete");
    }
    
    private void selectImage() {
        Intent intent = new Intent(Intent.ACTION_PICK);
        intent.setType("image/*");
        startActivityForResult(intent, PICK_IMAGE_REQUEST);
        AppLogger.log(this, TAG, "Gallery opened");
    }
    
    private void takePhoto() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.CAMERA}, REQUEST_CAMERA_PERMISSION);
                return;
            }
        }
        Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        if (intent.resolveActivity(getPackageManager()) != null) {
            startActivityForResult(intent, REQUEST_CAMERA);
            AppLogger.log(this, TAG, "Camera opened");
        } else {
            Toast.makeText(this, "Камера не найдена", Toast.LENGTH_SHORT).show();
        }
    }
    
    private void toggleBottomSheet() {
        float translation = bottomSheet.getTranslationY();
        if (translation == 0) {
            bottomSheet.animate().translationY(500).setDuration(300).start();
        } else {
            bottomSheet.animate().translationY(0).setDuration(300).start();
        }
    }
    
    private void showAIToolsDialog() {
        final String[] aiTools = {
            "🗑️ Удалить объект (нарисуйте на нём)",
            "📈 Улучшить качество (AI)",
            "🎭 Нейро-стиль"
        };
        
        new AlertDialog.Builder(this)
            .setTitle("🧠 AI Инструменты")
            .setItems(aiTools, (dialog, which) -> {
                if (which == 0) {
                    enableDrawingMode();
                } else if (which == 1) {
                    enhanceQuality();
                } else if (which == 2) {
                    applyNeuralStyle();
                }
            })
            .show();
    }
    
    private void enableDrawingMode() {
        if (currentBitmap == null) {
            Toast.makeText(this, "Сначала выберите фото", Toast.LENGTH_SHORT).show();
            return;
        }
        
        isDrawingMode = true;
        
        if (drawingView != null) {
            drawingView.clearDrawing();
            drawingView.setDrawingCallback(this::removeObjectWithMask);
            drawingView.startDrawing();
            drawingView.bringToFront();
        }
        
        Toast.makeText(this, "Проведите пальцем по объекту для удаления", Toast.LENGTH_LONG).show();
        AppLogger.log(this, TAG, "Drawing mode enabled");
        
        // Автоматически отключаем через 15 секунд
        mainHandler.postDelayed(() -> {
            if (isDrawingMode && drawingView != null) {
                isDrawingMode = false;
                drawingView.clearDrawing();
                drawingView.setVisibility(View.GONE);
                Toast.makeText(PhotoEditorActivity.this, "Режим удаления выключен", Toast.LENGTH_SHORT).show();
                AppLogger.log(PhotoEditorActivity.this, TAG, "Drawing mode timeout");
            }
        }, 15000);
    }
    
    private void removeObjectWithMask(Bitmap maskBitmap) {
        if (currentBitmap == null || maskBitmap == null) {
            Toast.makeText(this, "Ошибка: нет изображения", Toast.LENGTH_SHORT).show();
            AppLogger.log(this, TAG, "removeObjectWithMask failed: bitmap or mask is null");
            return;
        }
        
        AppLogger.log(this, TAG, "removeObjectWithMask: source=" + currentBitmap.getWidth() + "x" + currentBitmap.getHeight() +
            ", mask=" + maskBitmap.getWidth() + "x" + maskBitmap.getHeight());
        
        // Масштабируем маску под размер фото (с final для лямбды)
        final Bitmap scaledMask;
        try {
            scaledMask = Bitmap.createScaledBitmap(maskBitmap, currentBitmap.getWidth(), currentBitmap.getHeight(), false);
            AppLogger.log(this, TAG, "Mask scaled to: " + scaledMask.getWidth() + "x" + scaledMask.getHeight());
        } catch (Exception e) {
            AppLogger.logException(this, TAG, "Error scaling mask", e);
            Toast.makeText(this, "Ошибка масштабирования маски", Toast.LENGTH_SHORT).show();
            return;
        }
        
        isDrawingMode = false;
        if (drawingView != null) {
            drawingView.setVisibility(View.GONE);
        }
        
        showProgress("Удаление объекта...");
        AppLogger.log(this, TAG, "Starting object removal");
        
        new Thread(() -> {
            try {
                Bitmap result = neuralEngine.removeObject(currentBitmap, scaledMask);
                mainHandler.post(() -> {
                    hideProgress();
                    if (result != null) {
                        updateBitmap(result);
                        Toast.makeText(PhotoEditorActivity.this, "Объект удалён!", Toast.LENGTH_SHORT).show();
                        AppLogger.log(PhotoEditorActivity.this, TAG, "Object removal SUCCESS");
                    } else {
                        Toast.makeText(PhotoEditorActivity.this, "Не удалось удалить объект", Toast.LENGTH_SHORT).show();
                        AppLogger.log(PhotoEditorActivity.this, TAG, "Object removal FAILED");
                    }
                });
            } catch (Exception e) {
                AppLogger.logException(PhotoEditorActivity.this, TAG, "Object removal error", e);
                mainHandler.post(() -> {
                    hideProgress();
                    Toast.makeText(PhotoEditorActivity.this, "Ошибка: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                });
            }
        }).start();
    }
    
    private void enhanceQuality() {
        if (currentBitmap == null) {
            Toast.makeText(this, "Сначала выберите фото", Toast.LENGTH_SHORT).show();
            return;
        }
        
        showProgress("Улучшение качества...");
        
        new Thread(() -> {
            try {
                Bitmap enhanced = neuralEngine.enhanceQuality(currentBitmap);
                mainHandler.post(() -> {
                    hideProgress();
                    if (enhanced != null) {
                        updateBitmap(enhanced);
                        Toast.makeText(PhotoEditorActivity.this, "Качество улучшено!", Toast.LENGTH_SHORT).show();
                    }
                });
            } catch (Exception e) {
                AppLogger.logException(PhotoEditorActivity.this, TAG, "Enhance error", e);
                mainHandler.post(() -> hideProgress());
            }
        }).start();
    }
    
    private void applyNeuralStyle() {
        if (currentBitmap == null) return;
        
        final String[] styles = {"Ван Гог", "Моне", "Пикассо"};
        new AlertDialog.Builder(this)
            .setTitle("Нейро-стиль")
            .setItems(styles, (dialog, which) -> {
                String style = styles[which];
                showProgress("Применение стиля " + style + "...");
                
                new Thread(() -> {
                    try {
                        Bitmap result = neuralEngine.applyStyleTransfer(currentBitmap, style);
                        mainHandler.post(() -> {
                            hideProgress();
                            if (result != null) {
                                updateBitmap(result);
                                Toast.makeText(PhotoEditorActivity.this, "Стиль применён!", Toast.LENGTH_SHORT).show();
                            }
                        });
                    } catch (Exception e) {
                        AppLogger.logException(PhotoEditorActivity.this, TAG, "Style error", e);
                        mainHandler.post(() -> hideProgress());
                    }
                }).start();
            })
            .show();
    }
    
    private void showCropDialog() {
        if (currentBitmap == null) {
            Toast.makeText(this, "Сначала выберите фото", Toast.LENGTH_SHORT).show();
            return;
        }
        
        final String[] cropOptions = {"Квадрат (1:1)", "4:3", "16:9", "9:16"};
        new AlertDialog.Builder(this)
            .setTitle("Обрезка")
            .setItems(cropOptions, (dialog, which) -> {
                switch (which) {
                    case 0: cropImage(1, 1); break;
                    case 1: cropImage(4, 3); break;
                    case 2: cropImage(16, 9); break;
                    case 3: cropImage(9, 16); break;
                }
            })
            .show();
    }
    
    private void cropImage(int ratioW, int ratioH) {
        if (currentBitmap == null) return;
        
        showProgress("Обрезка...");
        
        new Thread(() -> {
            try {
                int w = currentBitmap.getWidth();
                int h = currentBitmap.getHeight();
                float targetRatio = (float) ratioW / ratioH;
                float currentRatio = (float) w / h;
                
                int newW, newH, startX = 0, startY = 0;
                
                if (currentRatio > targetRatio) {
                    newH = h;
                    newW = (int) (h * targetRatio);
                    startX = (w - newW) / 2;
                } else {
                    newW = w;
                    newH = (int) (w / targetRatio);
                    startY = (h - newH) / 2;
                }
                
                Bitmap cropped = Bitmap.createBitmap(currentBitmap, startX, startY, newW, newH);
                mainHandler.post(() -> {
                    hideProgress();
                    if (cropped != null) {
                        updateBitmap(cropped);
                        Toast.makeText(PhotoEditorActivity.this, "Фото обрезано!", Toast.LENGTH_SHORT).show();
                    }
                });
            } catch (Exception e) {
                AppLogger.logException(PhotoEditorActivity.this, TAG, "Crop error", e);
                mainHandler.post(() -> hideProgress());
            }
        }).start();
    }
    
    private void showAdjustDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Настройки");
        
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(40, 40, 40, 40);
        
        final SeekBar sbBrightness = new SeekBar(this);
        sbBrightness.setMax(200);
        sbBrightness.setProgress(100);
        layout.addView(createLabel("Яркость"));
        layout.addView(sbBrightness);
        
        final SeekBar sbContrast = new SeekBar(this);
        sbContrast.setMax(200);
        sbContrast.setProgress(100);
        layout.addView(createLabel("Контраст"));
        layout.addView(sbContrast);
        
        final SeekBar sbSaturation = new SeekBar(this);
        sbSaturation.setMax(200);
        sbSaturation.setProgress(100);
        layout.addView(createLabel("Насыщенность"));
        layout.addView(sbSaturation);
        
        builder.setView(layout);
        builder.setPositiveButton("Применить", (dialog, which) -> {
            float brightness = sbBrightness.getProgress() / 100f;
            float contrast = sbContrast.getProgress() / 100f;
            float saturation = sbSaturation.getProgress() / 100f;
            adjustImage(brightness, contrast, saturation);
        });
        builder.setNegativeButton("Отмена", null);
        builder.show();
    }
    
    private TextView createLabel(String text) {
        TextView tv = new TextView(this);
        tv.setText(text);
        tv.setTextColor(ThemeManager.getTextColor(this));
        tv.setPadding(0, 20, 0, 5);
        return tv;
    }
    
    private void adjustImage(float brightness, float contrast, float saturation) {
        if (currentBitmap == null) return;
        
        showProgress("Применение настроек...");
        
        new Thread(() -> {
            try {
                Bitmap result = photoProcessor.adjustImage(currentBitmap, brightness, contrast, saturation);
                mainHandler.post(() -> {
                    hideProgress();
                    if (result != null) {
                        updateBitmap(result);
                        Toast.makeText(PhotoEditorActivity.this, "Настройки применены!", Toast.LENGTH_SHORT).show();
                    }
                });
            } catch (Exception e) {
                AppLogger.logException(PhotoEditorActivity.this, TAG, "Adjust error", e);
                mainHandler.post(() -> hideProgress());
            }
        }).start();
    }
    
    private void applyEffect(String effect) {
        if (currentBitmap == null) return;
        
        currentEffect = effect;
        showProgress("Применение эффекта...");
        
        new Thread(() -> {
            try {
                Bitmap result = null;
                switch (effect) {
                    case "vintage":
                        result = photoProcessor.applyVintageFilter(currentBitmap, currentIntensity);
                        break;
                    case "noir":
                        result = photoProcessor.applyNoirFilter(currentBitmap);
                        break;
                    case "sepia":
                        result = photoProcessor.applySepiaFilter(currentBitmap, currentIntensity);
                        break;
                    case "watercolor":
                        result = photoProcessor.applyWatercolorFilter(currentBitmap);
                        break;
                    case "oil":
                        result = photoProcessor.applyOilPaintFilter(currentBitmap);
                        break;
                    case "pixelate":
                        result = photoProcessor.applyPixelate(currentBitmap, (int)(20 * currentIntensity));
                        break;
                    case "blur":
                        result = photoProcessor.applyGaussianBlur(currentBitmap, (int)(15 * currentIntensity));
                        break;
                    case "sharpen":
                        result = photoProcessor.applySharpen(currentBitmap, currentIntensity);
                        break;
                    case "vignette":
                        result = photoProcessor.applyVignette(currentBitmap, currentIntensity);
                        break;
                    default:
                        result = currentBitmap;
                        break;
                }
                final Bitmap finalResult = result;
                mainHandler.post(() -> {
                    hideProgress();
                    if (finalResult != null && finalResult != currentBitmap) {
                        updateBitmap(finalResult);
                        Toast.makeText(PhotoEditorActivity.this, "Эффект применён!", Toast.LENGTH_SHORT).show();
                    }
                });
            } catch (Exception e) {
                AppLogger.logException(PhotoEditorActivity.this, TAG, "Effect error", e);
                mainHandler.post(() -> hideProgress());
            }
        }).start();
    }
    
    private void applyCurrentEffect() {
        if (!currentEffect.equals("none")) {
            applyEffect(currentEffect);
        }
    }
    
    private void updateBitmap(Bitmap newBitmap) {
        if (newBitmap == null) return;
        
        if (historyPosition < history.size() - 1) {
            history.subList(historyPosition + 1, history.size()).clear();
        }
        if (currentBitmap != null) {
            history.add(currentBitmap);
        }
        historyPosition++;
        currentBitmap = newBitmap;
        ivPhoto.setImageBitmap(currentBitmap);
        AppLogger.log(this, TAG, "Bitmap updated");
    }
    
    private void undo() {
        if (historyPosition > 0) {
            historyPosition--;
            currentBitmap = history.get(historyPosition);
            ivPhoto.setImageBitmap(currentBitmap);
            Toast.makeText(this, "Отменено", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, "Нечего отменять", Toast.LENGTH_SHORT).show();
        }
    }
    
    private void redo() {
        if (historyPosition < history.size() - 1) {
            historyPosition++;
            currentBitmap = history.get(historyPosition);
            ivPhoto.setImageBitmap(currentBitmap);
            Toast.makeText(this, "Повторено", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, "Нечего повторять", Toast.LENGTH_SHORT).show();
        }
    }
    
    private void saveImage() {
        if (currentBitmap == null) {
            Toast.makeText(this, "Нет изображения", Toast.LENGTH_SHORT).show();
            return;
        }
        
        showProgress("Сохранение...");
        
        new Thread(() -> {
            try {
                String fileName = "edited_" + System.currentTimeMillis() + ".jpg";
                File dir = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES), "Last04ka");
                if (!dir.exists()) dir.mkdirs();
                File file = new File(dir, fileName);
                
                FileOutputStream fos = new FileOutputStream(file);
                currentBitmap.compress(Bitmap.CompressFormat.JPEG, 95, fos);
                fos.close();
                
                ContentValues values = new ContentValues();
                values.put(MediaStore.Images.Media.DISPLAY_NAME, fileName);
                values.put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg");
                values.put(MediaStore.Images.Media.DATA, file.getAbsolutePath());
                getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values);
                
                mainHandler.post(() -> {
                    hideProgress();
                    Toast.makeText(PhotoEditorActivity.this, "Сохранено: " + fileName, Toast.LENGTH_LONG).show();
                });
            } catch (Exception e) {
                AppLogger.logException(PhotoEditorActivity.this, TAG, "Save error", e);
                mainHandler.post(() -> hideProgress());
            }
        }).start();
    }
    
    private void showProgress(String message) {
        progressBar.setVisibility(View.VISIBLE);
        tvProgress.setText(message);
        tvProgress.setVisibility(View.VISIBLE);
    }
    
    private void hideProgress() {
        progressBar.setVisibility(View.GONE);
        tvProgress.setVisibility(View.GONE);
    }
    
    private void applyThemeColors() {
        int bg = ThemeManager.getBackgroundColor(this);
        findViewById(R.id.editor_layout).setBackgroundColor(bg);
        tvIntensity.setTextColor(ThemeManager.getTextColor(this));
    }
    
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        
        if (resultCode == RESULT_OK && data != null) {
            if (requestCode == PICK_IMAGE_REQUEST) {
                try {
                    Uri imageUri = data.getData();
                    if (imageUri != null) {
                        originalBitmap = BitmapFactory.decodeStream(getContentResolver().openInputStream(imageUri));
                        if (originalBitmap != null) {
                            updateBitmap(originalBitmap.copy(Bitmap.Config.ARGB_8888, true));
                            Toast.makeText(this, "Изображение загружено!", Toast.LENGTH_SHORT).show();
                            AppLogger.log(this, TAG, "Image loaded: " + originalBitmap.getWidth() + "x" + originalBitmap.getHeight());
                        }
                    }
                } catch (Exception e) {
                    AppLogger.logException(this, TAG, "Load error", e);
                    Toast.makeText(this, "Ошибка загрузки", Toast.LENGTH_SHORT).show();
                }
            } else if (requestCode == REQUEST_CAMERA) {
                Bundle extras = data.getExtras();
                if (extras != null) {
                    originalBitmap = (Bitmap) extras.get("data");
                    if (originalBitmap != null) {
                        updateBitmap(originalBitmap.copy(Bitmap.Config.ARGB_8888, true));
                        Toast.makeText(this, "Фото сделано!", Toast.LENGTH_SHORT).show();
                        AppLogger.log(this, TAG, "Photo captured");
                    }
                }
            }
        }
    }
    
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQUEST_CAMERA_PERMISSION && grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            takePhoto();
        }
    }
    
    @Override
    protected void onDestroy() {
        super.onDestroy();
        AppLogger.log(this, TAG, "PhotoEditorActivity destroyed");
    }
    
    // ==================== INNER CLASSES ====================
    
    private class EffectItem {
        String name, id;
        EffectItem(String name, String id) { this.name = name; this.id = id; }
    }
    
    private class EffectAdapter extends RecyclerView.Adapter<EffectAdapter.ViewHolder> {
        private List<EffectItem> effects;
        
        EffectAdapter(List<EffectItem> effects) { this.effects = effects; }
        
        @Override
        public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            TextView tv = new TextView(parent.getContext());
            tv.setPadding(32, 16, 32, 16);
            tv.setTextSize(14);
            tv.setTextColor(ThemeManager.getTextColor(PhotoEditorActivity.this));
            return new ViewHolder(tv);
        }
        
        @Override
        public void onBindViewHolder(ViewHolder holder, int position) {
            EffectItem item = effects.get(position);
            holder.textView.setText(item.name);
            holder.itemView.setOnClickListener(v -> {
                applyEffect(item.id);
                toggleBottomSheet();
            });
        }
        
        @Override
        public int getItemCount() { return effects.size(); }
        
        class ViewHolder extends RecyclerView.ViewHolder {
            TextView textView;
            ViewHolder(View v) { super(v); textView = (TextView) v; }
        }
    }
}