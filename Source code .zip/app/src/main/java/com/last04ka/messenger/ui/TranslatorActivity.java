package com.last04ka.messenger.ui;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import com.last04ka.messenger.R;
import com.last04ka.messenger.utils.OfflineTranslator;
import com.last04ka.messenger.utils.ThemeManager;
import com.last04ka.messenger.utils.AppLogger;
import android.graphics.drawable.GradientDrawable;

public class TranslatorActivity extends AppCompatActivity {

    private EditText inputText;
    private TextView outputText;
    private Button btnTranslateRuEn, btnTranslateEnRu, btnClear;
    private TextView directionLabel;

    private boolean isRuToEn = true;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        setTheme(ThemeManager.getThemeResource(this));
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_translator);

        setTitle("📝 Офлайн-переводчик");
        AppLogger.log(this, "Translator", "onCreate started");

        inputText = findViewById(R.id.input_text);
        outputText = findViewById(R.id.output_text);
        btnTranslateRuEn = findViewById(R.id.btn_translate_ru_en);
        btnTranslateEnRu = findViewById(R.id.btn_translate_en_ru);
        btnClear = findViewById(R.id.btn_clear);
        directionLabel = findViewById(R.id.direction_label);

        applyTheme();

        updateDirection();

        btnTranslateRuEn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                isRuToEn = true;
                updateDirection();
                translate();
            }
        });

        btnTranslateEnRu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                isRuToEn = false;
                updateDirection();
                translate();
            }
        });

        btnClear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                inputText.setText("");
                outputText.setText("");
                AppLogger.log(TranslatorActivity.this, "Translator", "Cleared fields");
            }
        });
    }

    private void updateDirection() {
        if (isRuToEn) {
            directionLabel.setText("Русский → Английский");
            inputText.setHint("Введите текст на русском...");
        } else {
            directionLabel.setText("Английский → Русский");
            inputText.setHint("Введите текст на английском...");
        }
        outputText.setText("");
        AppLogger.log(this, "Translator", "Direction: " + (isRuToEn ? "RU→EN" : "EN→RU"));
    }

    private void translate() {
        String text = inputText.getText().toString().trim();
        if (TextUtils.isEmpty(text)) {
            Toast.makeText(this, "Введите текст для перевода", Toast.LENGTH_SHORT).show();
            return;
        }

        AppLogger.log(this, "Translator", "Translating: " + text);
        String result;
        if (isRuToEn) {
            result = OfflineTranslator.translateRuToEn(text);
        } else {
            result = OfflineTranslator.translateEnToRu(text);
        }

        if (result != null) {
            outputText.setText(result);
            AppLogger.log(this, "Translator", "Result: " + result);
        } else {
            outputText.setText("Перевод не найден в офлайн-словаре.\nПопробуйте другие слова.");
            AppLogger.log(this, "Translator", "No translation found");
        }
    }

    private void applyTheme() {
        int bgColor = ThemeManager.getBackgroundColor(this);
        int textColor = ThemeManager.getTextColor(this);
        int inputBgColor = ThemeManager.getInputBgColor(this);
        int dividerColor = ThemeManager.getDividerColor(this);

        findViewById(R.id.translator_layout).setBackgroundColor(bgColor);
        inputText.setTextColor(textColor);
        outputText.setTextColor(textColor);
        directionLabel.setTextColor(textColor);

        GradientDrawable inputBg = new GradientDrawable();
        inputBg.setColor(inputBgColor);
        inputBg.setCornerRadius(16);
        inputBg.setStroke(1, dividerColor);
        inputText.setBackground(inputBg);
        outputText.setBackground(inputBg);

        if (getSupportActionBar() != null) {
            getSupportActionBar().setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(
                ThemeManager.isDarkTheme(this) ? 0xFF424242 : 0xFF1565C0));
        }
    }
}