package com.last04ka.messenger.game;

import android.graphics.RectF;

public class LevelData {

    private static final float W = 1000f;
    private static final float H = 600f;

    public static Level getLevel(int level) {
        switch (level) {
            case 1:  return buildLevel1();
            case 2:  return buildLevel2();
            case 3:  return buildLevel3();
            case 4:  return buildLevel4();
            case 5:  return buildLevel5();
            case 6:  return buildLevel6();
            case 7:  return buildLevel7();
            case 8:  return buildLevel8();
            case 9:  return buildLevel9();
            case 10: return buildLevel10();
            case 11: return buildLevel11();
            case 12: return buildLevel12();
            case 13: return buildLevel13();
            case 14: return buildLevel14();
            case 15: return buildLevel15();
            case 16: return buildLevel16();
            case 17: return buildLevel17();
            case 18: return buildLevel18();
            case 19: return buildLevel19();
            case 20: return buildLevel20();
            case 21: return buildLevel21();
            case 22: return buildLevel22();
            case 23: return buildLevel23();
            case 24: return buildLevel24();
            case 25: return buildLevel25();
            case 26: return buildLevel26();
            case 27: return buildLevel27();
            case 28: return buildLevel28();
            case 29: return buildLevel29();
            case 30: return buildLevel30();
            default: return buildLevel1();
        }
    }

    // ==================== УРОВНИ 1-5 ====================

    private static Level buildLevel1() {
        Level l = new Level(100, 500);
        addGround(l);
        l.platforms.add(rect(150, 460, 250, 500));
        l.platforms.add(rect(400, 400, 500, 500));
        l.platforms.add(rect(650, 340, 750, 500));
        l.finish = rect(920, 320, 980, 340);
        l.stars.add(rect(180, 440, 200, 460));
        l.stars.add(rect(440, 380, 460, 400));
        l.stars.add(rect(680, 320, 700, 340));
        addEnemy(l, 250, 480, 300, 400);
        return l;
    }

    private static Level buildLevel2() {
        Level l = new Level(80, 500);
        addGround(l);
        l.platforms.add(rect(100, 460, 200, 500));
        l.platforms.add(rect(300, 420, 400, 500));
        l.platforms.add(rect(500, 380, 600, 500));
        l.platforms.add(rect(700, 340, 800, 500));
        l.finish = rect(920, 320, 980, 340);
        l.stars.add(rect(140, 440, 160, 460));
        l.stars.add(rect(350, 400, 370, 420));
        l.stars.add(rect(750, 320, 770, 340));
        l.water.add(rect(200, 540, 280, 560));
        addEnemy(l, 400, 460, 450, 350);
        return l;
    }

    private static Level buildLevel3() {
        Level l = new Level(50, 500);
        addGround(l);
        l.platforms.add(rect(80, 460, 180, 500));
        l.platforms.add(rect(240, 400, 340, 500));
        l.platforms.add(rect(400, 360, 500, 500));
        l.platforms.add(rect(560, 320, 660, 500));
        l.platforms.add(rect(720, 280, 820, 500));
        l.finish = rect(920, 260, 980, 280);
        l.stars.add(rect(120, 440, 140, 460));
        l.stars.add(rect(290, 380, 310, 400));
        l.stars.add(rect(600, 300, 620, 320));
        l.water.add(rect(200, 540, 230, 560));
        l.water.add(rect(480, 540, 510, 560));
        addEnemy(l, 160, 480, 200, 100);
        addEnemy(l, 420, 440, 470, 350);
        return l;
    }

    private static Level buildLevel4() {
        Level l = new Level(60, 500);
        addGround(l);
        l.platforms.add(rect(100, 460, 200, 500));
        l.platforms.add(rect(250, 420, 350, 500));
        l.platforms.add(rect(400, 380, 500, 500));
        l.platforms.add(rect(550, 340, 650, 500));
        l.platforms.add(rect(700, 300, 800, 500));
        l.finish = rect(920, 280, 980, 300);
        l.stars.add(rect(140, 440, 160, 460));
        l.stars.add(rect(290, 400, 310, 420));
        l.stars.add(rect(600, 320, 620, 340));
        l.checkpoints.add(rect(250, 400, 270, 420));
        addEnemy(l, 150, 480, 190, 120);
        addEnemy(l, 400, 440, 450, 330);
        return l;
    }

    private static Level buildLevel5() {
        Level l = new Level(50, 500);
        addGround(l);
        l.platforms.add(rect(80, 460, 180, 500));
        l.platforms.add(rect(220, 420, 320, 500));
        l.platforms.add(rect(360, 380, 460, 500));
        l.platforms.add(rect(500, 340, 600, 500));
        l.platforms.add(rect(640, 300, 740, 500));
        l.platforms.add(rect(780, 260, 880, 500));
        l.finish = rect(940, 240, 980, 260);
        l.stars.add(rect(120, 440, 140, 460));
        l.stars.add(rect(260, 400, 280, 420));
        l.stars.add(rect(520, 320, 540, 340));
        l.water.add(rect(200, 540, 230, 560));
        l.water.add(rect(500, 540, 530, 560));
        addEnemy(l, 180, 480, 220, 150);
        addEnemy(l, 420, 440, 470, 300);
        return l;
    }

    // ==================== УРОВНИ 6-29 (ПРОСТЫЕ ВАРИАНТЫ) ====================

    private static Level buildLevel6() { return generateLevel(6, 3, 2); }
    private static Level buildLevel7() { return generateLevel(7, 4, 2); }
    private static Level buildLevel8() { return generateLevel(8, 4, 3); }
    private static Level buildLevel9() { return generateLevel(9, 5, 3); }
    private static Level buildLevel10() { return generateLevel(10, 5, 4); }
    private static Level buildLevel11() { return generateLevel(11, 6, 4); }
    private static Level buildLevel12() { return generateLevel(12, 6, 5); }
    private static Level buildLevel13() { return generateLevel(13, 7, 5); }
    private static Level buildLevel14() { return generateLevel(14, 7, 6); }
    private static Level buildLevel15() { return generateLevel(15, 8, 6); }
    private static Level buildLevel16() { return generateLevel(16, 8, 7); }
    private static Level buildLevel17() { return generateLevel(17, 9, 7); }
    private static Level buildLevel18() { return generateLevel(18, 9, 8); }
    private static Level buildLevel19() { return generateLevel(19, 10, 8); }
    private static Level buildLevel20() { return generateLevel(20, 10, 9); }
    private static Level buildLevel21() { return generateLevel(21, 11, 9); }
    private static Level buildLevel22() { return generateLevel(22, 11, 10); }
    private static Level buildLevel23() { return generateLevel(23, 12, 10); }
    private static Level buildLevel24() { return generateLevel(24, 12, 11); }
    private static Level buildLevel25() { return generateLevel(25, 13, 11); }
    private static Level buildLevel26() { return generateLevel(26, 13, 12); }
    private static Level buildLevel27() { return generateLevel(27, 14, 12); }
    private static Level buildLevel28() { return generateLevel(28, 14, 13); }
    private static Level buildLevel29() { return generateLevel(29, 15, 13); }

    private static Level buildLevel30() {
        Level l = new Level(50, 500);
        addGround(l);
        for (int i = 0; i < 10; i++) {
            float x = 50 + i * 90;
            float y = 500 - i * 20;
            l.platforms.add(rect(x, y, x + 80, y + 40));
        }
        l.finish = rect(920, 300, 980, 320);
        for (int i = 0; i < 3; i++) {
            l.stars.add(rect(100 + i * 300, 440 - i * 60, 120 + i * 300, 460 - i * 60));
        }
        l.water.add(rect(200, 540, 230, 560));
        l.water.add(rect(500, 540, 530, 560));
        addEnemy(l, 150, 480, 200, 80);
        addEnemy(l, 350, 440, 400, 80);
        addEnemy(l, 550, 400, 600, 80);
        return l;
    }

    // ==================== ГЕНЕРАТОР УРОВНЕЙ ====================

    private static Level generateLevel(int num, int platformsCount, int enemiesCount) {
        Level l = new Level(50 + num * 5, 500 - num * 2);
        addGround(l);
        float spacing = (W - 100) / (platformsCount + 1);
        for (int i = 0; i < platformsCount; i++) {
            float x = 50 + (i + 1) * spacing;
            float y = 480 - i * 15 - num * 2;
            if (y < 200) y = 200;
            l.platforms.add(rect(x - 40, y, x + 40, y + 40));
        }
        l.finish = rect(W - 80, 280 - num, W - 20, 300 - num);
        for (int i = 0; i < 3; i++) {
            float x = 150 + i * (W - 300) / 2;
            float y = 440 - i * 20 - num * 2;
            if (y < 200) y = 200;
            l.stars.add(rect(x, y - 20, x + 20, y));
        }
        for (int i = 0; i < enemiesCount; i++) {
            int idx = i % platformsCount;
            RectF p = l.platforms.get(idx);
            float y = p.top - 20;
            float x = p.left + 10 + i * 15;
            addEnemy(l, x, y, p.left, p.right);
        }
        return l;
    }

    // ==================== ВСПОМОГАТЕЛЬНЫЕ МЕТОДЫ ====================

    private static RectF rect(float left, float top, float right, float bottom) {
        return new RectF(left, top, right, bottom);
    }

    private static void addGround(Level l) {
        l.platforms.add(rect(0, 560, W, 600));
    }

    private static void addEnemy(Level l, float x, float y, float leftBound, float rightBound) {
        float size = 20;
        l.enemies.add(rect(x, y - size, x + size, y));
        l.enemyMoveLeft.add(leftBound);
        l.enemyMoveRight.add(rightBound);
    }
}