package com.last04ka.messenger.ui;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import com.last04ka.messenger.utils.AppLogger;

public class GeneticCalculatorActivity extends Activity {

    private RadioGroup rgFather, rgMother, rgFatherRh, rgMotherRh, rgFatherEyes, rgMotherEyes;
    private TextView resultBlood, resultRh, resultEyes;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        try {
            AppLogger.log(this, "GeneticCalc", "onCreate started");
            LinearLayout layout = new LinearLayout(this);
            layout.setOrientation(LinearLayout.VERTICAL);
            layout.setPadding(24, 24, 24, 24);
            layout.setBackgroundColor(0xFF1A1A2E);

            TextView title = new TextView(this);
            title.setText("🧬 Генетический калькулятор");
            title.setTextSize(20); title.setTextColor(0xFFFFFFFF);
            title.setGravity(android.view.Gravity.CENTER);
            title.setPadding(0, 0, 0, 20);
            layout.addView(title);

            // Группа крови отца
            addLabel(layout, "Группа крови отца:");
            rgFather = new RadioGroup(this);
            rgFather.setOrientation(LinearLayout.HORIZONTAL);
            String[] bloods = {"O","A","B","AB"};
            for (int i = 0; i < 4; i++) {
                RadioButton rb = new RadioButton(this);
                rb.setText(bloods[i]); rb.setTextColor(0xFFFFFFFF); rb.setId(i);
                if (i == 0) rb.setChecked(true);
                rgFather.addView(rb);
            }
            layout.addView(rgFather);

            // Группа крови матери
            addLabel(layout, "Группа крови матери:");
            rgMother = new RadioGroup(this);
            rgMother.setOrientation(LinearLayout.HORIZONTAL);
            for (int i = 0; i < 4; i++) {
                RadioButton rb = new RadioButton(this);
                rb.setText(bloods[i]); rb.setTextColor(0xFFFFFFFF); rb.setId(i);
                if (i == 0) rb.setChecked(true);
                rgMother.addView(rb);
            }
            layout.addView(rgMother);

            // Резус-фактор отца
            addLabel(layout, "Резус-фактор отца:");
            rgFatherRh = new RadioGroup(this);
            rgFatherRh.setOrientation(LinearLayout.HORIZONTAL);
            RadioButton fRh1 = new RadioButton(this); fRh1.setText("Rh+"); fRh1.setTextColor(0xFFFFFFFF); fRh1.setId(0); fRh1.setChecked(true);
            RadioButton fRh2 = new RadioButton(this); fRh2.setText("Rh-"); fRh2.setTextColor(0xFFFFFFFF); fRh2.setId(1);
            rgFatherRh.addView(fRh1); rgFatherRh.addView(fRh2);
            layout.addView(rgFatherRh);

            // Резус-фактор матери
            addLabel(layout, "Резус-фактор матери:");
            rgMotherRh = new RadioGroup(this);
            rgMotherRh.setOrientation(LinearLayout.HORIZONTAL);
            RadioButton mRh1 = new RadioButton(this); mRh1.setText("Rh+"); mRh1.setTextColor(0xFFFFFFFF); mRh1.setId(0); mRh1.setChecked(true);
            RadioButton mRh2 = new RadioButton(this); mRh2.setText("Rh-"); mRh2.setTextColor(0xFFFFFFFF); mRh2.setId(1);
            rgMotherRh.addView(mRh1); rgMotherRh.addView(mRh2);
            layout.addView(rgMotherRh);

            // Цвет глаз отца
            addLabel(layout, "Цвет глаз отца:");
            rgFatherEyes = new RadioGroup(this);
            rgFatherEyes.setOrientation(LinearLayout.HORIZONTAL);
            String[] eyes = {"Карий","Голубой","Зелёный"};
            for (int i = 0; i < 3; i++) {
                RadioButton rb = new RadioButton(this);
                rb.setText(eyes[i]); rb.setTextColor(0xFFFFFFFF); rb.setId(i);
                if (i == 0) rb.setChecked(true);
                rgFatherEyes.addView(rb);
            }
            layout.addView(rgFatherEyes);

            // Цвет глаз матери
            addLabel(layout, "Цвет глаз матери:");
            rgMotherEyes = new RadioGroup(this);
            rgMotherEyes.setOrientation(LinearLayout.HORIZONTAL);
            for (int i = 0; i < 3; i++) {
                RadioButton rb = new RadioButton(this);
                rb.setText(eyes[i]); rb.setTextColor(0xFFFFFFFF); rb.setId(i);
                if (i == 0) rb.setChecked(true);
                rgMotherEyes.addView(rb);
            }
            layout.addView(rgMotherEyes);

            Button btnCalculate = new Button(this);
            btnCalculate.setText("Рассчитать");
            btnCalculate.setTextSize(18);
            btnCalculate.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) { calculate(); }
            });
            layout.addView(btnCalculate);

            resultBlood = addResult(layout, "Группа крови ребёнка: --");
            resultRh = addResult(layout, "Резус-фактор: --");
            resultEyes = addResult(layout, "Цвет глаз: --");

            setContentView(layout);
            setTitle("🧬 Генетический калькулятор");
            AppLogger.log(this, "GeneticCalc", "onCreate completed");
        } catch (Exception e) { AppLogger.logException(this, "GeneticCalc", e); finish(); }
    }

    private void addLabel(LinearLayout layout, String text) {
        TextView tv = new TextView(this);
        tv.setText(text); tv.setTextColor(0xFFBDBDBD); tv.setTextSize(14);
        tv.setPadding(0, 12, 0, 4); layout.addView(tv);
    }

    private TextView addResult(LinearLayout layout, String text) {
        TextView tv = new TextView(this);
        tv.setText(text); tv.setTextColor(0xFF00E676); tv.setTextSize(18);
        tv.setGravity(android.view.Gravity.CENTER); tv.setPadding(0, 16, 0, 0);
        layout.addView(tv);
        return tv;
    }

    private void calculate() {
        // Группа крови — получаем id выбранной RadioButton
        int fatherBlood = rgFather.getCheckedRadioButtonId();
        int motherBlood = rgMother.getCheckedRadioButtonId();
        String[] bloods = {"O","A","B","AB"};
        String bloodResult;
        if (fatherBlood == 0 && motherBlood == 0) bloodResult = "O (100%)";
        else if (fatherBlood == 0 || motherBlood == 0) bloodResult = bloods[fatherBlood] + " или O (50/50)";
        else bloodResult = bloods[fatherBlood] + " или " + bloods[motherBlood] + " (зависит от аллелей)";

        // Резус
        int fatherRh = rgFatherRh.getCheckedRadioButtonId();
        int motherRh = rgMotherRh.getCheckedRadioButtonId();
        String rhResult;
        if (fatherRh == 1 && motherRh == 1) rhResult = "Rh- (100%)";
        else if (fatherRh == 1 || motherRh == 1) rhResult = "Rh+ или Rh- (50/50)";
        else rhResult = "Rh+ (100%)";

        // Глаза
        int fatherEyes = rgFatherEyes.getCheckedRadioButtonId();
        int motherEyes = rgMotherEyes.getCheckedRadioButtonId();
        String eyesResult;
        if (fatherEyes == 0 && motherEyes == 0) eyesResult = "Карий (75%), Голубой (25%)";
        else if (fatherEyes == 0 || motherEyes == 0) eyesResult = "Карий (50%), Голубой/Зелёный (50%)";
        else eyesResult = "Голубой (50%), Зелёный (50%)";

        resultBlood.setText("Группа крови ребёнка: " + bloodResult);
        resultRh.setText("Резус-фактор: " + rhResult);
        resultEyes.setText("Цвет глаз: " + eyesResult);
        AppLogger.log(this, "GeneticCalc", "Calculated: blood=" + fatherBlood + "/" + motherBlood + " rh=" + fatherRh + "/" + motherRh + " eyes=" + fatherEyes + "/" + motherEyes);
    }
}