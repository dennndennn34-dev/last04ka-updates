package com.last04ka.messenger.ui;

import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import com.last04ka.messenger.utils.AppLogger;
import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.List;

public class PasswordGeneratorActivity extends Activity {

    private EditText display;
    private TextView strengthText, historyText;
    private CheckBox cbUpper, cbLower, cbDigits, cbSymbols;
    private EditText inputLength;
    private List<String> history = new ArrayList<>();
    private SecureRandom random = new SecureRandom();  // ИСПРАВЛЕНО: SecureRandom вместо Random

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        try {
            AppLogger.log(this, "PassGen", "onCreate started");

            LinearLayout layout = new LinearLayout(this);
            layout.setOrientation(LinearLayout.VERTICAL);
            layout.setPadding(16, 16, 16, 16);
            layout.setBackgroundColor(0xFF1A1A2E);

            TextView title = new TextView(this);
            title.setText("🔑 Генератор паролей");
            title.setTextSize(20); title.setTextColor(0xFFFFFFFF);
            title.setGravity(Gravity.CENTER); layout.addView(title);

            // Длина
            LinearLayout lenRow = new LinearLayout(this);
            lenRow.setOrientation(LinearLayout.HORIZONTAL);
            TextView lenLabel = new TextView(this);
            lenLabel.setText("Длина:"); lenLabel.setTextColor(0xFFFFFFFF);
            lenRow.addView(lenLabel);
            inputLength = new EditText(this);
            inputLength.setText("12"); inputLength.setTextColor(0xFFFFFFFF);
            inputLength.setBackgroundColor(0xFF333333); inputLength.setWidth(100);
            lenRow.addView(inputLength);
            layout.addView(lenRow);

            // Чекбоксы
            cbUpper = new CheckBox(this); cbUpper.setText("A-Z"); cbUpper.setTextColor(0xFFFFFFFF); cbUpper.setChecked(true);
            cbLower = new CheckBox(this); cbLower.setText("a-z"); cbLower.setTextColor(0xFFFFFFFF); cbLower.setChecked(true);
            cbDigits = new CheckBox(this); cbDigits.setText("0-9"); cbDigits.setTextColor(0xFFFFFFFF); cbDigits.setChecked(true);
            cbSymbols = new CheckBox(this); cbSymbols.setText("!@#$"); cbSymbols.setTextColor(0xFFFFFFFF);
            layout.addView(cbUpper); layout.addView(cbLower); layout.addView(cbDigits); layout.addView(cbSymbols);

            // Дисплей
            display = new EditText(this);
            display.setTextSize(18); display.setTextColor(0xFFFFD740);
            display.setBackgroundColor(0xFF333333); display.setPadding(12, 10, 12, 10);
            display.setGravity(Gravity.CENTER); layout.addView(display);

            // Оценка
            strengthText = new TextView(this);
            strengthText.setTextSize(12); strengthText.setTextColor(0xFF888888);
            strengthText.setGravity(Gravity.CENTER); layout.addView(strengthText);

            LinearLayout btnRow = new LinearLayout(this);
            btnRow.setOrientation(LinearLayout.HORIZONTAL);
            Button btnGen = new Button(this); btnGen.setText("Сгенерировать");
            btnGen.setOnClickListener(v -> generate()); btnRow.addView(btnGen);
            Button btnCopy = new Button(this); btnCopy.setText("Копировать");
            btnCopy.setOnClickListener(v -> copyToClipboard()); btnRow.addView(btnCopy);
            layout.addView(btnRow);

            // История
            historyText = new TextView(this);
            historyText.setTextSize(11); historyText.setTextColor(0xFF888888); historyText.setPadding(8, 8, 8, 8);
            ScrollView sv = new ScrollView(this); sv.addView(historyText);
            layout.addView(sv);

            setContentView(layout);
            setTitle("🔑 Генератор паролей");
            AppLogger.log(this, "PassGen", "onCreate completed");
        } catch (Exception e) { AppLogger.logException(this, "PassGen", e); finish(); }
    }

    private void generate() {
        int len;
        try { len = Integer.parseInt(inputLength.getText().toString()); }
        catch (NumberFormatException e) { len = 12; }
        if (len < 4) len = 4; if (len > 64) len = 64;

        StringBuilder chars = new StringBuilder();
        if (cbUpper.isChecked()) chars.append("ABCDEFGHIJKLMNOPQRSTUVWXYZ");
        if (cbLower.isChecked()) chars.append("abcdefghijklmnopqrstuvwxyz");
        if (cbDigits.isChecked()) chars.append("0123456789");
        if (cbSymbols.isChecked()) chars.append("!@#$%^&*()-_=+[]{}|;:,.<>?");

        if (chars.length() == 0) { Toast.makeText(this, "Выберите символы", Toast.LENGTH_SHORT).show(); return; }

        StringBuilder pass = new StringBuilder();
        for (int i = 0; i < len; i++) {
            pass.append(chars.charAt(random.nextInt(chars.length())));  // ИСПРАВЛЕНО: SecureRandom
        }

        display.setText(pass.toString());
        int strength = evaluateStrength(pass.toString());
        String[] ratings = {"Очень слабый", "Слабый", "Средний", "Сильный", "Очень сильный"};
        strengthText.setText("Надёжность: " + ratings[strength]);

        history.add(0, pass.toString());
        if (history.size() > 20) history.remove(history.size() - 1);
        StringBuilder sb = new StringBuilder("История:\n");
        for (String h : history) sb.append(h).append("\n");
        historyText.setText(sb.toString());

        AppLogger.log(this, "PassGen", "Generated, strength=" + strength);
    }

    private int evaluateStrength(String pass) {
        int score = 0;
        if (pass.length() >= 8) score++; if (pass.length() >= 14) score++;
        if (pass.matches(".*[A-Z].*")) score++;
        if (pass.matches(".*[a-z].*")) score++;
        if (pass.matches(".*[0-9].*")) score++;
        if (pass.matches(".*[!@#$%^&*()\\-\\[\\]{}|;:,.<>?].*")) score++;
        return Math.min(4, score / 2);
    }

    private void copyToClipboard() {
        String pass = display.getText().toString();
        if (pass.isEmpty()) { Toast.makeText(this, "Сгенерируйте пароль", Toast.LENGTH_SHORT).show(); return; }
        ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
        cm.setPrimaryClip(ClipData.newPlainText("password", pass));
        Toast.makeText(this, "Скопировано!", Toast.LENGTH_SHORT).show();
    }
}