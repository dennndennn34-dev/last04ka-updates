package com.last04ka.messenger.ui;

import android.app.Activity;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.media.AudioManager;
import android.media.audiofx.BassBoost;
import android.media.audiofx.Equalizer;
import android.media.audiofx.LoudnessEnhancer;
import android.media.audiofx.PresetReverb;
import android.media.audiofx.Virtualizer;
import android.media.audiofx.Visualizer;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;
import com.last04ka.messenger.utils.AchievementManager;
import com.last04ka.messenger.utils.AppLogger;

public class EqualizerActivity extends Activity {

    public static final String ACTION_NEXT_PRESET = "com.last04ka.EQ_NEXT";
    public static final String ACTION_PREV_PRESET = "com.last04ka.EQ_PREV";
    public static final String ACTION_BASS_TOGGLE = "com.last04ka.EQ_BASS";

    private Equalizer equalizer;
    private BassBoost bassBoost;
    private Virtualizer virtualizer;
    private PresetReverb reverb;
    private LoudnessEnhancer loudness;
    private AudioManager audioManager;
    private Visualizer audioVisualizer;

    private SeekBar[] bands;
    private TextView[] bandLabels;
    private SeekBar bassBoostBar, virtualizerBar, reverbBar, balanceBar;
    private TextView bassBoostLabel, virtualizerLabel, reverbLabel, balanceLabel;

    private VisualizerView visualizerView;
    private CircleVisualizerView circleVisualizerView;
    private Handler handler = new Handler();

    private Button btnPreset, btnReset, btnSavePreset, btnLoadPreset;
    private Button btnAutoGenre, btnNotification;
    private TextView statusText;

    private String[] presets = {"Нормальный","Классика","Джаз","Рок","Поп","Басы","Вокал","Голос","Кино","Игры"};
    private String[] customPresets = new String[5];
    private short[][] customPresetValues = new short[5][];
    private int presetIndex = 0;
    private int eqUses = 0;

    private float[] visualizerData = new float[12];
    private BroadcastReceiver notificationReceiver;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        try {
            AppLogger.log(this, "Equalizer", "onCreate started");
            loadCustomPresets();
            eqUses = getSharedPreferences("eq_stats", MODE_PRIVATE).getInt("uses", 0);
            audioManager = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
            setVolumeControlStream(AudioManager.STREAM_MUSIC);

            ScrollView sv = new ScrollView(this);
            LinearLayout layout = new LinearLayout(this);
            layout.setOrientation(LinearLayout.VERTICAL);
            layout.setPadding(16, 16, 16, 16);
            layout.setBackgroundColor(0xFF1A1A2E);

            TextView title = new TextView(this);
            title.setText("🎛️ Эквалайзер");
            title.setTextSize(22); title.setTextColor(0xFFFFFFFF);
            title.setGravity(Gravity.CENTER);
            title.setPadding(0, 0, 0, 16);
            layout.addView(title);

            statusText = new TextView(this);
            statusText.setText("Загрузка...");
            statusText.setTextSize(12); statusText.setTextColor(0xFFBDBDBD);
            statusText.setGravity(Gravity.CENTER);
            statusText.setPadding(0, 0, 0, 8);
            layout.addView(statusText);

            try {
                equalizer = new Equalizer(0, 0);
                equalizer.setEnabled(true);

                // Визуализация — столбики
                visualizerView = new VisualizerView(this);
                LinearLayout.LayoutParams vp = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT, 150);
                visualizerView.setLayoutParams(vp);
                layout.addView(visualizerView);

                // Круговая визуализация
                circleVisualizerView = new CircleVisualizerView(this);
                LinearLayout.LayoutParams cvp = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT, 200);
                circleVisualizerView.setLayoutParams(cvp);
                layout.addView(circleVisualizerView);

                // Ползунки частот
                short numBands = equalizer.getNumberOfBands();
                bands = new SeekBar[numBands];
                bandLabels = new TextView[numBands];

                for (short i = 0; i < numBands; i++) {
                    final short band = i;
                    int[] freqRange = equalizer.getBandFreqRange(band);
                    int centerFreq = freqRange[1] / 1000;

                    TextView label = new TextView(this);
                    label.setText(centerFreq + " Гц: 0 дБ");
                    label.setTextColor(0xFFFFFFFF); label.setTextSize(11);
                    layout.addView(label);
                    bandLabels[i] = label;

                    SeekBar bar = new SeekBar(this);
                    bar.setMax(2000);
                    bar.setProgress(1000);
                    bar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
                        @Override public void onProgressChanged(SeekBar s, int p, boolean u) {
                            int gain = p - 1000;
                            equalizer.setBandLevel(band, (short) gain);
                            bandLabels[band].setText(centerFreq + " Гц: " + String.format("%.1f", gain / 10.0) + " дБ");
                        }
                        @Override public void onStartTrackingTouch(SeekBar s) {}
                        @Override public void onStopTrackingTouch(SeekBar s) {}
                    });
                    layout.addView(bar);
                    bands[i] = bar;
                }

                // Bass Boost
                addSectionTitle(layout, "🔊 Bass Boost");
                try {
                    bassBoost = new BassBoost(0, 0);
                    bassBoost.setEnabled(true);
                    bassBoost.setStrength((short) 0);
                } catch (Exception e) { bassBoost = null; }
                bassBoostBar = new SeekBar(this);
                bassBoostBar.setMax(1000);
                bassBoostBar.setProgress(0);
                bassBoostLabel = new TextView(this);
                bassBoostLabel.setText("Bass Boost: 0%");
                bassBoostLabel.setTextColor(0xFFFFFFFF); bassBoostLabel.setTextSize(12);
                layout.addView(bassBoostLabel);
                bassBoostBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
                    @Override public void onProgressChanged(SeekBar s, int p, boolean u) {
                        if (bassBoost != null) bassBoost.setStrength((short) p);
                        bassBoostLabel.setText("Bass Boost: " + p / 10 + "%");
                    }
                    @Override public void onStartTrackingTouch(SeekBar s) {}
                    @Override public void onStopTrackingTouch(SeekBar s) {}
                });
                layout.addView(bassBoostBar);

                // 3D Surround
                addSectionTitle(layout, "🌐 3D Surround");
                try {
                    virtualizer = new Virtualizer(0, 0);
                    virtualizer.setEnabled(true);
                    virtualizer.setStrength((short) 0);
                } catch (Exception e) { virtualizer = null; }
                virtualizerBar = new SeekBar(this);
                virtualizerBar.setMax(1000);
                virtualizerBar.setProgress(0);
                virtualizerLabel = new TextView(this);
                virtualizerLabel.setText("3D Surround: 0%");
                virtualizerLabel.setTextColor(0xFFFFFFFF); virtualizerLabel.setTextSize(12);
                layout.addView(virtualizerLabel);
                virtualizerBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
                    @Override public void onProgressChanged(SeekBar s, int p, boolean u) {
                        if (virtualizer != null) virtualizer.setStrength((short) p);
                        virtualizerLabel.setText("3D Surround: " + p / 10 + "%");
                    }
                    @Override public void onStartTrackingTouch(SeekBar s) {}
                    @Override public void onStopTrackingTouch(SeekBar s) {}
                });
                layout.addView(virtualizerBar);

                // Баланс L/R
                addSectionTitle(layout, "⚖️ Баланс L/R");
                balanceBar = new SeekBar(this);
                balanceBar.setMax(200);
                balanceBar.setProgress(100);
                balanceLabel = new TextView(this);
                balanceLabel.setText("Баланс: Центр");
                balanceLabel.setTextColor(0xFFFFFFFF); balanceLabel.setTextSize(12);
                layout.addView(balanceLabel);
                balanceBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
                    @Override public void onProgressChanged(SeekBar s, int p, boolean u) {
                        if (p < 95) balanceLabel.setText("Баланс: ← " + (100 - p) + "%");
                        else if (p > 105) balanceLabel.setText("Баланс: → " + (p - 100) + "%");
                        else balanceLabel.setText("Баланс: Центр");
                    }
                    @Override public void onStartTrackingTouch(SeekBar s) {}
                    @Override public void onStopTrackingTouch(SeekBar s) {}
                });
                layout.addView(balanceBar);

                // Лимитер
                addSectionTitle(layout, "🛡️ Лимитер (активен)");
                try {
                    loudness = new LoudnessEnhancer(0);
                    loudness.setEnabled(true);
                    loudness.setTargetGain(0);
                } catch (Exception e) { loudness = null; }

                // Реверберация
                addSectionTitle(layout, "🏠 Реверберация");
                try {
                    reverb = new PresetReverb(0, 0);
                    reverb.setEnabled(true);
                    reverb.setPreset(PresetReverb.PRESET_NONE);
                } catch (Exception e) { reverb = null; }
                reverbBar = new SeekBar(this);
                reverbBar.setMax(6);
                reverbBar.setProgress(0);
                reverbLabel = new TextView(this);
                reverbLabel.setText("Реверберация: Нет");
                reverbLabel.setTextColor(0xFFFFFFFF); reverbLabel.setTextSize(12);
                layout.addView(reverbLabel);
                reverbBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
                    @Override public void onProgressChanged(SeekBar s, int p, boolean u) {
                        if (reverb != null) reverb.setPreset((short) p);
                        String[] rn = {"Нет","Комната","Зал","Плато","Сцена","Церковь","Пещера"};
                        reverbLabel.setText("Реверберация: " + rn[p]);
                    }
                    @Override public void onStartTrackingTouch(SeekBar s) {}
                    @Override public void onStopTrackingTouch(SeekBar s) {}
                });
                layout.addView(reverbBar);

                // Громкость системы
                addSectionTitle(layout, "🔔 Системная громкость");
                SeekBar volumeBar = new SeekBar(this);
                int maxVol = audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC);
                int curVol = audioManager.getStreamVolume(AudioManager.STREAM_MUSIC);
                volumeBar.setMax(maxVol);
                volumeBar.setProgress(curVol);
                final TextView volumeLabel = new TextView(this);
                volumeLabel.setText("Громкость: " + (curVol * 100 / maxVol) + "%");
                volumeLabel.setTextColor(0xFFFFFFFF); volumeLabel.setTextSize(12);
                layout.addView(volumeLabel);
                volumeBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
                    @Override public void onProgressChanged(SeekBar s, int p, boolean u) {
                        audioManager.setStreamVolume(AudioManager.STREAM_MUSIC, p, 0);
                        volumeLabel.setText("Громкость: " + (p * 100 / maxVol) + "%");
                    }
                    @Override public void onStartTrackingTouch(SeekBar s) {}
                    @Override public void onStopTrackingTouch(SeekBar s) {}
                });
                layout.addView(volumeBar);

                // Кнопки
                LinearLayout btnRow1 = new LinearLayout(this);
                btnRow1.setOrientation(LinearLayout.HORIZONTAL);

                btnPreset = new Button(this); btnPreset.setText("Пресет ▶");
                btnPreset.setOnClickListener(new View.OnClickListener() { @Override public void onClick(View v) { cyclePreset(); } });
                btnRow1.addView(btnPreset);

                btnReset = new Button(this); btnReset.setText("Сброс");
                btnReset.setOnClickListener(new View.OnClickListener() { @Override public void onClick(View v) { resetBands(); } });
                btnRow1.addView(btnReset);

                btnSavePreset = new Button(this); btnSavePreset.setText("💾");
                btnSavePreset.setOnClickListener(new View.OnClickListener() { @Override public void onClick(View v) { saveCustomPresetDialog(); } });
                btnRow1.addView(btnSavePreset);

                btnLoadPreset = new Button(this); btnLoadPreset.setText("📂");
                btnLoadPreset.setOnClickListener(new View.OnClickListener() { @Override public void onClick(View v) { loadCustomPresetDialog(); } });
                btnRow1.addView(btnLoadPreset);

                layout.addView(btnRow1);

                LinearLayout btnRow2 = new LinearLayout(this);
                btnRow2.setOrientation(LinearLayout.HORIZONTAL);

                btnAutoGenre = new Button(this); btnAutoGenre.setText("🎵 Авто");
                btnAutoGenre.setOnClickListener(new View.OnClickListener() { @Override public void onClick(View v) { autoDetectGenre(); } });
                btnRow2.addView(btnAutoGenre);

                btnNotification = new Button(this); btnNotification.setText("🔔");
                btnNotification.setOnClickListener(new View.OnClickListener() { @Override public void onClick(View v) { showNotification(); } });
                btnRow2.addView(btnNotification);

                layout.addView(btnRow2);

                eqUses++;
                getSharedPreferences("eq_stats", MODE_PRIVATE).edit().putInt("uses", eqUses).apply();
                statusText.setText("Эквалайзер использован " + eqUses + " раз(а) · Пресет: " + presets[presetIndex]);

                // Запуск аудио-визуализации через Visualizer API
                try {
                    audioVisualizer = new Visualizer(0);
                    audioVisualizer.setCaptureSize(Visualizer.getCaptureSizeRange()[1]);
                    audioVisualizer.setDataCaptureListener(new Visualizer.OnDataCaptureListener() {
                        @Override
                        public void onWaveFormDataCapture(Visualizer visualizer, byte[] waveform, int samplingRate) {
                            for (int i = 0; i < visualizerData.length && i * 2 < waveform.length; i++) {
                                float amp = Math.abs(waveform[i * 2]) / 128f;
                                visualizerData[i] = visualizerData[i] + (amp - visualizerData[i]) * 0.3f;
                            }
                            if (visualizerView != null) visualizerView.postInvalidate();
                            if (circleVisualizerView != null) circleVisualizerView.postInvalidate();
                        }
                        @Override
                        public void onFftDataCapture(Visualizer visualizer, byte[] fft, int samplingRate) {}
                    }, Visualizer.getMaxCaptureRate() / 2, true, false);
                    audioVisualizer.setEnabled(true);
                    statusText.append(" · Визуализация активна");
                } catch (Exception e) {
                    statusText.append(" · Визуализация: эмуляция");
                    handler.postDelayed(emulationRunnable, 100);
                }

            } catch (Exception e) {
                AppLogger.logException(this, "Equalizer", e);
                statusText.setText("Ошибка: " + e.getMessage());
            }

            sv.addView(layout);
            setContentView(sv);
            setTitle("🎛️ Эквалайзер");

            registerNotificationReceiver();
            showNotification();
            AppLogger.log(this, "Equalizer", "onCreate completed");
        } catch (Exception e) {
            AppLogger.logException(this, "Equalizer", e);
            Toast.makeText(this, "Эквалайзер не поддерживается", Toast.LENGTH_SHORT).show();
            finish();
        }
    }

    private Runnable emulationRunnable = new Runnable() {
        @Override
        public void run() {
            if (audioVisualizer == null || !audioVisualizer.getEnabled()) {
                for (int i = 0; i < visualizerData.length; i++) {
                    float target = 0.1f + (float) Math.random() * 0.4f;
                    visualizerData[i] += (target - visualizerData[i]) * 0.15f;
                }
                if (visualizerView != null) visualizerView.invalidate();
                if (circleVisualizerView != null) circleVisualizerView.invalidate();
                handler.postDelayed(this, 100);
            }
        }
    };

    private void registerNotificationReceiver() {
        notificationReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                String action = intent.getAction();
                if (ACTION_NEXT_PRESET.equals(action)) { presetIndex = (presetIndex + 1) % presets.length; applyPreset(presetIndex); }
                else if (ACTION_PREV_PRESET.equals(action)) { presetIndex = (presetIndex - 1 + presets.length) % presets.length; applyPreset(presetIndex); }
                else if (ACTION_BASS_TOGGLE.equals(action)) { bassBoostBar.setProgress(bassBoostBar.getProgress() > 0 ? 0 : 700); }
                showNotification();
            }
        };
        IntentFilter filter = new IntentFilter();
        filter.addAction(ACTION_NEXT_PRESET);
        filter.addAction(ACTION_PREV_PRESET);
        filter.addAction(ACTION_BASS_TOGGLE);
        registerReceiver(notificationReceiver, filter);
    }

    private void cyclePreset() { presetIndex = (presetIndex + 1) % presets.length; applyPreset(presetIndex); }

    private void addSectionTitle(LinearLayout layout, String text) {
        TextView tv = new TextView(this);
        tv.setText(text); tv.setTextColor(0xFFFFD740); tv.setTextSize(14);
        tv.setPadding(0, 20, 0, 4); layout.addView(tv);
    }

    class VisualizerView extends View {
        private Paint paint = new Paint();
        private int[] colors = {Color.RED, Color.rgb(255,100,0), Color.YELLOW, Color.GREEN, Color.CYAN, Color.BLUE, Color.MAGENTA, Color.RED, Color.rgb(255,100,0), Color.YELLOW, Color.GREEN, Color.CYAN};

        public VisualizerView(Context ctx) { super(ctx); setBackgroundColor(Color.rgb(20,20,30)); }

        @Override
        protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            float w = getWidth(), h = getHeight();
            float barW = w / visualizerData.length - 4;
            for (int i = 0; i < visualizerData.length; i++) {
                paint.setColor(colors[i % colors.length]);
                float barH = visualizerData[i] * h;
                float x = i * (w / visualizerData.length) + 2;
                canvas.drawRoundRect(x, h - barH, x + barW, h, 4, 4, paint);
            }
        }
    }

    class CircleVisualizerView extends View {
        private Paint paint = new Paint();
        private int[] colors = {Color.RED, Color.YELLOW, Color.GREEN, Color.CYAN, Color.BLUE, Color.MAGENTA, Color.RED, Color.YELLOW, Color.GREEN, Color.CYAN, Color.BLUE, Color.MAGENTA};

        public CircleVisualizerView(Context ctx) { super(ctx); setBackgroundColor(Color.rgb(20,20,30)); }

        @Override
        protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            float cx = getWidth() / 2f, cy = getHeight() / 2f;
            float maxR = Math.min(cx, cy) * 0.7f;
            for (int i = 0; i < visualizerData.length; i++) {
                paint.setColor(colors[i % colors.length]);
                float angle = (float) (i * 2 * Math.PI / visualizerData.length);
                float r = maxR * visualizerData[i] * 0.5f + maxR * 0.15f;
                float x = cx + (float) Math.cos(angle) * r;
                float y = cy + (float) Math.sin(angle) * r;
                canvas.drawCircle(x, y, 5 + visualizerData[i] * 10, paint);
            }
        }
    }

    private void applyPreset(int idx) {
        AppLogger.log(this, "Equalizer", "Preset: " + presets[idx]);
        short[][] allGains = {
            {0,0,0,0,0,0,0,0,0,0,0,0}, {500,400,200,0,-200,0,300,500,600,700,500,0},
            {500,400,300,100,0,-100,200,500,600,500,400,300}, {500,400,0,-300,-500,-300,0,400,500,600,500,400},
            {0,200,500,700,500,0,-200,0,200,300,200,0}, {1000,800,500,200,0,0,0,0,0,0,0,0},
            {-500,-300,0,300,500,700,800,700,500,300,0,-200}, {-300,0,300,500,700,500,300,0,-300,-500,-400,-300},
            {200,0,0,0,500,500,500,0,0,0,200,300}, {400,300,0,-100,-200,-300,-200,-100,0,300,400,500},
        };
        short[] gains = allGains[idx % allGains.length];
        for (int i = 0; i < Math.min(bands.length, gains.length); i++) { bands[i].setProgress(1000 + gains[i]); equalizer.setBandLevel((short) i, gains[i]); }
        statusText.setText("Эквалайзер использован " + eqUses + " раз(а) · Пресет: " + presets[idx]);
        Toast.makeText(this, "Пресет: " + presets[idx], Toast.LENGTH_SHORT).show();
        showNotification();
    }

    private void resetBands() {
        AppLogger.log(this, "Equalizer", "Reset bands");
        for (SeekBar b : bands) b.setProgress(1000);
        for (short i = 0; i < bands.length; i++) equalizer.setBandLevel(i, (short) 0);
        if (bassBoostBar != null) bassBoostBar.setProgress(0);
        if (virtualizerBar != null) virtualizerBar.setProgress(0);
        if (reverbBar != null) reverbBar.setProgress(0);
        if (balanceBar != null) balanceBar.setProgress(100);
        statusText.setText("Эквалайзер использован " + eqUses + " раз(а) · Сброшено");
        Toast.makeText(this, "Сброшено", Toast.LENGTH_SHORT).show();
    }

    private void saveCustomPresetDialog() {
        final EditText input = new EditText(this);
        input.setHint("Название пресета");
        input.setTextColor(0xFFFFFFFF); input.setHintTextColor(0xFF757575);
        new android.app.AlertDialog.Builder(this).setTitle("Сохранить пресет").setView(input)
            .setPositiveButton("Сохранить", new android.content.DialogInterface.OnClickListener() {
                @Override public void onClick(android.content.DialogInterface d, int w) {
                    String name = input.getText().toString().trim(); if (name.isEmpty()) return;
                    for (int i = 0; i < 5; i++) {
                        if (customPresets[i] == null || customPresets[i].isEmpty()) {
                            customPresets[i] = name;
                            short[] gains = new short[bands.length];
                            for (int j = 0; j < bands.length; j++) gains[j] = (short) (bands[j].getProgress() - 1000);
                            customPresetValues[i] = gains; saveCustomPresets();
                            AppLogger.log(EqualizerActivity.this, "Equalizer", "Saved preset: " + name);
                            Toast.makeText(EqualizerActivity.this, "Сохранено в слот " + (i+1), Toast.LENGTH_SHORT).show(); return;
                        }
                    }
                    Toast.makeText(EqualizerActivity.this, "Все 5 слотов заняты", Toast.LENGTH_SHORT).show();
                }
            }).setNegativeButton("Отмена", null).show();
    }

    private void loadCustomPresetDialog() {
        String[] items = new String[5];
        for (int i = 0; i < 5; i++) items[i] = (customPresets[i] != null && !customPresets[i].isEmpty()) ? customPresets[i] : "Пусто";
        new android.app.AlertDialog.Builder(this).setTitle("Загрузить пресет").setItems(items, new android.content.DialogInterface.OnClickListener() {
            @Override public void onClick(android.content.DialogInterface d, int w) {
                if (customPresetValues[w] != null) {
                    for (int i = 0; i < bands.length && i < customPresetValues[w].length; i++) { bands[i].setProgress(1000 + customPresetValues[w][i]); equalizer.setBandLevel((short) i, customPresetValues[w][i]); }
                    AppLogger.log(EqualizerActivity.this, "Equalizer", "Loaded preset: " + customPresets[w]);
                    Toast.makeText(EqualizerActivity.this, "Загружен: " + customPresets[w], Toast.LENGTH_SHORT).show();
                }
            }
        }).setNegativeButton("Отмена", null).show();
    }

    private void saveCustomPresets() {
        SharedPreferences prefs = getSharedPreferences("eq_presets", MODE_PRIVATE);
        for (int i = 0; i < 5; i++) {
            if (customPresets[i] != null) prefs.edit().putString("name_" + i, customPresets[i]).apply();
            if (customPresetValues[i] != null) { StringBuilder sb = new StringBuilder(); for (short s : customPresetValues[i]) sb.append(s).append(","); prefs.edit().putString("vals_" + i, sb.toString()).apply(); }
        }
    }

    private void loadCustomPresets() {
        SharedPreferences prefs = getSharedPreferences("eq_presets", MODE_PRIVATE);
        for (int i = 0; i < 5; i++) {
            customPresets[i] = prefs.getString("name_" + i, "");
            String vals = prefs.getString("vals_" + i, "");
            if (!vals.isEmpty()) { String[] parts = vals.split(","); customPresetValues[i] = new short[parts.length]; for (int j = 0; j < parts.length; j++) customPresetValues[i][j] = Short.parseShort(parts[j]); }
        }
    }

    private void autoDetectGenre() {
        int bestMatch = 0, bestScore = Integer.MAX_VALUE;
        short[][] gG = {{0,0,0,0,0,0,0,0,0,0,0,0},{500,400,200,0,-200,0,300,500,600,700,500,0},{500,400,300,100,0,-100,200,500,600,500,400,300},{500,400,0,-300,-500,-300,0,400,500,600,500,400},{0,200,500,700,500,0,-200,0,200,300,200,0},{1000,800,500,200,0,0,0,0,0,0,0,0},{-500,-300,0,300,500,700,800,700,500,300,0,-200}};
        String[] gN = {"Норма","Классика","Джаз","Рок","Поп","Басы","Вокал"};
        for (int g = 0; g < gG.length; g++) { int diff = 0; for (int i = 0; i < Math.min(bands.length, gG[g].length); i++) diff += Math.abs((bands[i].getProgress() - 1000) - gG[g][i]); if (diff < bestScore) { bestScore = diff; bestMatch = g; } }
        applyPreset(bestMatch);
        AppLogger.log(this, "Equalizer", "Auto genre: " + gN[bestMatch]);
        Toast.makeText(this, "Жанр: " + gN[bestMatch], Toast.LENGTH_SHORT).show();
    }

    private void showNotification() {
        try {
            String chId = "eq_channel";
            NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) { nm.createNotificationChannel(new NotificationChannel(chId, "Эквалайзер", NotificationManager.IMPORTANCE_LOW)); }
            Intent i = new Intent(this, EqualizerActivity.class);
            PendingIntent pi = PendingIntent.getActivity(this, 0, i, PendingIntent.FLAG_UPDATE_CURRENT);
            PendingIntent prevPI = PendingIntent.getBroadcast(this, 0, new Intent(ACTION_PREV_PRESET), PendingIntent.FLAG_UPDATE_CURRENT);
            PendingIntent nextPI = PendingIntent.getBroadcast(this, 1, new Intent(ACTION_NEXT_PRESET), PendingIntent.FLAG_UPDATE_CURRENT);
            PendingIntent bassPI = PendingIntent.getBroadcast(this, 2, new Intent(ACTION_BASS_TOGGLE), PendingIntent.FLAG_UPDATE_CURRENT);
            Notification n = new Notification.Builder(this, chId).setContentTitle("🎛️ Эквалайзер").setContentText("Пресет: " + presets[presetIndex]).setSmallIcon(android.R.drawable.ic_menu_manage).setContentIntent(pi).setOngoing(true).addAction(android.R.drawable.ic_media_previous, "◀", prevPI).addAction(android.R.drawable.ic_menu_manage, "Bass", bassPI).addAction(android.R.drawable.ic_media_next, "▶", nextPI).build();
            nm.notify(1001, n);
        } catch (Exception e) { AppLogger.logException(this, "Equalizer", e); }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (equalizer != null) { equalizer.setEnabled(false); equalizer.release(); }
        if (bassBoost != null) { bassBoost.setEnabled(false); bassBoost.release(); }
        if (virtualizer != null) { virtualizer.setEnabled(false); virtualizer.release(); }
        if (reverb != null) { reverb.setEnabled(false); reverb.release(); }
        if (loudness != null) { loudness.setEnabled(false); loudness.release(); }
        if (audioVisualizer != null) { audioVisualizer.setEnabled(false); audioVisualizer.release(); }
        handler.removeCallbacks(emulationRunnable);
        if (notificationReceiver != null) { try { unregisterReceiver(notificationReceiver); } catch (Exception e) {} }
        AppLogger.log(this, "Equalizer", "onDestroy");
    }
}