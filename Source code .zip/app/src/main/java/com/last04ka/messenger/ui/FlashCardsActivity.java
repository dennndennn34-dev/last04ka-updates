package com.last04ka.messenger.ui;

import android.app.Activity;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import com.last04ka.messenger.utils.AppLogger;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class FlashCardsActivity extends Activity {

    private SQLiteDatabase db;
    private LinearLayout deckList, cardArea;
    private TextView questionText, answerText;
    private Button btnShowAnswer, btnNext, btnAddCard, btnNewDeck;
    private EditText inputDeck, inputQuestion, inputAnswer;
    private String currentDeck = "";
    private List<String[]> currentCards = new ArrayList<>();
    private int currentIndex = -1;
    private boolean answerShown = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        try {
            AppLogger.log(this, "FlashCards", "onCreate started");

            db = openOrCreateDatabase("flashcards.db", MODE_PRIVATE, null);
            db.execSQL("CREATE TABLE IF NOT EXISTS decks (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT UNIQUE)");
            db.execSQL("CREATE TABLE IF NOT EXISTS cards (id INTEGER PRIMARY KEY AUTOINCREMENT, deck_name TEXT, question TEXT, answer TEXT)");

            LinearLayout mainLayout = new LinearLayout(this);
            mainLayout.setOrientation(LinearLayout.VERTICAL);
            mainLayout.setPadding(16, 16, 16, 16);
            mainLayout.setBackgroundColor(0xFF1A1A2E);

            TextView title = new TextView(this);
            title.setText("🧠 Мнемокарточки");
            title.setTextSize(22);
            title.setTextColor(0xFFFFFFFF);
            title.setGravity(Gravity.CENTER);
            mainLayout.addView(title);

            // Выбор/создание колоды
            inputDeck = new EditText(this);
            inputDeck.setHint("Название колоды");
            inputDeck.setTextColor(0xFFFFFFFF);
            inputDeck.setHintTextColor(0xFF888888);
            inputDeck.setBackgroundColor(0xFF333333);
            mainLayout.addView(inputDeck);

            btnNewDeck = new Button(this);
            btnNewDeck.setText("Создать / Выбрать колоду");
            btnNewDeck.setOnClickListener(v -> selectOrCreateDeck());
            mainLayout.addView(btnNewDeck);

            // Список колод
            deckList = new LinearLayout(this);
            deckList.setOrientation(LinearLayout.VERTICAL);
            mainLayout.addView(deckList);

            // Карточка
            cardArea = new LinearLayout(this);
            cardArea.setOrientation(LinearLayout.VERTICAL);
            cardArea.setPadding(12, 12, 12, 12);
            cardArea.setBackgroundColor(0xFF333333);
            cardArea.setVisibility(View.GONE);

            questionText = new TextView(this);
            questionText.setTextSize(18);
            questionText.setTextColor(0xFFFFD740);
            questionText.setGravity(Gravity.CENTER);
            questionText.setPadding(0, 16, 0, 16);
            cardArea.addView(questionText);

            answerText = new TextView(this);
            answerText.setTextSize(18);
            answerText.setTextColor(0xFF4CAF50);
            answerText.setGravity(Gravity.CENTER);
            answerText.setPadding(0, 16, 0, 16);
            answerText.setVisibility(View.GONE);
            cardArea.addView(answerText);

            LinearLayout btnRow = new LinearLayout(this);
            btnRow.setOrientation(LinearLayout.HORIZONTAL);
            btnRow.setGravity(Gravity.CENTER);

            btnShowAnswer = new Button(this);
            btnShowAnswer.setText("Показать ответ");
            btnShowAnswer.setOnClickListener(v -> revealAnswer());
            btnRow.addView(btnShowAnswer);

            btnNext = new Button(this);
            btnNext.setText("Следующая");
            btnNext.setOnClickListener(v -> nextCard());
            btnRow.addView(btnNext);
            cardArea.addView(btnRow);

            mainLayout.addView(cardArea);

            // Добавление карточки
            inputQuestion = new EditText(this);
            inputQuestion.setHint("Вопрос");
            inputQuestion.setTextColor(0xFFFFFFFF);
            inputQuestion.setHintTextColor(0xFF888888);
            inputQuestion.setBackgroundColor(0xFF333333);
            mainLayout.addView(inputQuestion);

            inputAnswer = new EditText(this);
            inputAnswer.setHint("Ответ");
            inputAnswer.setTextColor(0xFFFFFFFF);
            inputAnswer.setHintTextColor(0xFF888888);
            inputAnswer.setBackgroundColor(0xFF333333);
            mainLayout.addView(inputAnswer);

            btnAddCard = new Button(this);
            btnAddCard.setText("Добавить карточку");
            btnAddCard.setEnabled(false);
            btnAddCard.setOnClickListener(v -> addCard());
            mainLayout.addView(btnAddCard);

            setContentView(mainLayout);
            setTitle("🧠 Мнемокарточки");
            loadDecks();
            AppLogger.log(this, "FlashCards", "onCreate completed");
        } catch (Exception e) { AppLogger.logException(this, "FlashCards", e); finish(); }
    }

    private void selectOrCreateDeck() {
        String name = inputDeck.getText().toString().trim();
        if (name.isEmpty()) {
            Toast.makeText(this, "Введите название колоды", Toast.LENGTH_SHORT).show();
            return;
        }
        try {
            db.execSQL("INSERT OR IGNORE INTO decks (name) VALUES (?)", new Object[]{name});
            currentDeck = name;
            btnAddCard.setEnabled(true);
            loadCards();
            AppLogger.log(this, "FlashCards", "Deck selected: " + name);
            Toast.makeText(this, "Колода '" + name + "' выбрана", Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            Toast.makeText(this, "Ошибка создания колоды", Toast.LENGTH_SHORT).show();
        }
    }

    private void loadDecks() {
        deckList.removeAllViews();
        Cursor cursor = db.rawQuery("SELECT DISTINCT name FROM decks ORDER BY name", null);
        while (cursor.moveToNext()) {
            String name = cursor.getString(0);
            TextView tv = new TextView(this);
            tv.setText("📁 " + name);
            tv.setTextSize(14);
            tv.setTextColor(0xFF90CAF9);
            tv.setPadding(8, 8, 8, 8);
            tv.setOnClickListener(v -> {
                inputDeck.setText(name);
                selectOrCreateDeck();
            });
            deckList.addView(tv);
        }
        cursor.close();
    }

    private void loadCards() {
        currentCards.clear();
        Cursor cursor = db.rawQuery("SELECT question, answer FROM cards WHERE deck_name = ?", new String[]{currentDeck});
        while (cursor.moveToNext()) {
            currentCards.add(new String[]{cursor.getString(0), cursor.getString(1)});
        }
        cursor.close();
        if (currentCards.size() > 0) {
            cardArea.setVisibility(View.VISIBLE);
            shuffleCards();
        } else {
            cardArea.setVisibility(View.GONE);
        }
    }

    private void shuffleCards() {
        Random r = new Random();
        for (int i = currentCards.size() - 1; i > 0; i--) {
            int j = r.nextInt(i + 1);
            String[] temp = currentCards.get(i);
            currentCards.set(i, currentCards.get(j));
            currentCards.set(j, temp);
        }
        currentIndex = 0;
        showCard();
    }

    private void showCard() {
        if (currentIndex < 0 || currentIndex >= currentCards.size()) {
            questionText.setText("Нет карточек");
            answerText.setText("");
            answerText.setVisibility(View.GONE);
            answerShown = false;
            btnShowAnswer.setText("Показать ответ");
            return;
        }
        answerShown = false;
        btnShowAnswer.setText("Показать ответ");
        answerText.setVisibility(View.GONE);
        questionText.setText((currentIndex + 1) + "/" + currentCards.size() + ": " + currentCards.get(currentIndex)[0]);
    }

    private void revealAnswer() {
        if (!answerShown && currentIndex >= 0 && currentIndex < currentCards.size()) {
            answerText.setText(currentCards.get(currentIndex)[1]);
            answerText.setVisibility(View.VISIBLE);
            answerShown = true;
            btnShowAnswer.setText("Скрыть ответ");
        } else {
            answerText.setVisibility(View.GONE);
            answerShown = false;
            btnShowAnswer.setText("Показать ответ");
        }
    }

    private void nextCard() {
        if (currentCards.size() == 0) return;
        currentIndex = (currentIndex + 1) % currentCards.size();
        showCard();
    }

    private void addCard() {
        String q = inputQuestion.getText().toString().trim();
        String a = inputAnswer.getText().toString().trim();
        if (q.isEmpty() || a.isEmpty()) {
            Toast.makeText(this, "Заполните вопрос и ответ", Toast.LENGTH_SHORT).show();
            return;
        }
        db.execSQL("INSERT INTO cards (deck_name, question, answer) VALUES (?, ?, ?)", new Object[]{currentDeck, q, a});
        inputQuestion.setText("");
        inputAnswer.setText("");
        loadCards();
        Toast.makeText(this, "Карточка добавлена", Toast.LENGTH_SHORT).show();
        AppLogger.log(this, "FlashCards", "Card added to deck: " + currentDeck);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (db != null && db.isOpen()) db.close();
    }
}