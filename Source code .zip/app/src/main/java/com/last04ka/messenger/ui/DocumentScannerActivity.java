package com.last04ka.messenger.ui;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.ColorMatrix;
import android.graphics.ColorMatrixColorFilter;
import android.graphics.Paint;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Toast;
import com.last04ka.messenger.utils.AppLogger;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;

public class DocumentScannerActivity extends Activity {

    private ImageView imageView;
    private Bitmap currentBitmap;
    private Button btnPick, btnScan, btnSave;
    private static final int PICK_IMAGE = 1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        try {
            AppLogger.log(this, "DocScanner", "onCreate started");
            LinearLayout layout = new LinearLayout(this);
            layout.setOrientation(LinearLayout.VERTICAL);
            layout.setPadding(16, 16, 16, 16);
            layout.setBackgroundColor(0xFF1A1A2E);

            imageView = new ImageView(this);
            LinearLayout.LayoutParams ip = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 1);
            imageView.setLayoutParams(ip);
            imageView.setScaleType(ImageView.ScaleType.FIT_CENTER);
            imageView.setBackgroundColor(0xFF333333);
            layout.addView(imageView);

            LinearLayout btns = new LinearLayout(this);
            btns.setOrientation(LinearLayout.HORIZONTAL);

            btnPick = new Button(this); btnPick.setText("Выбрать фото");
            btnPick.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) { pickImage(); }
            });
            btns.addView(btnPick);

            btnScan = new Button(this); btnScan.setText("Сканировать");
            btnScan.setEnabled(false);
            btnScan.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) { scanDocument(); }
            });
            btns.addView(btnScan);

            btnSave = new Button(this); btnSave.setText("Сохранить");
            btnSave.setEnabled(false);
            btnSave.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) { saveImage(); }
            });
            btns.addView(btnSave);

            layout.addView(btns);
            setContentView(layout);
            setTitle("📸 Сканер документов");
            AppLogger.log(this, "DocScanner", "onCreate completed");
        } catch (Exception e) { AppLogger.logException(this, "DocScanner", e); finish(); }
    }

    private void pickImage() {
        Intent intent = new Intent(Intent.ACTION_PICK, android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        startActivityForResult(intent, PICK_IMAGE);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PICK_IMAGE && resultCode == RESULT_OK && data != null) {
            try {
                Uri uri = data.getData();
                InputStream is = getContentResolver().openInputStream(uri);
                currentBitmap = BitmapFactory.decodeStream(is);
                is.close();
                imageView.setImageBitmap(currentBitmap);
                btnScan.setEnabled(true);
                btnSave.setEnabled(false);
            } catch (Exception e) { Toast.makeText(this, "Ошибка загрузки", Toast.LENGTH_SHORT).show(); }
        }
    }

    private void scanDocument() {
        if (currentBitmap == null) return;
        Bitmap bw = toGrayscale(currentBitmap);
        Bitmap enhanced = enhanceContrast(bw);
        currentBitmap = enhanced;
        imageView.setImageBitmap(currentBitmap);
        btnSave.setEnabled(true);
        Toast.makeText(this, "Сканирование завершено", Toast.LENGTH_SHORT).show();
    }

    private Bitmap toGrayscale(Bitmap src) {
        Bitmap result = Bitmap.createBitmap(src.getWidth(), src.getHeight(), Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(result);
        Paint paint = new Paint();
        ColorMatrix cm = new ColorMatrix();
        cm.setSaturation(0);
        paint.setColorFilter(new ColorMatrixColorFilter(cm));
        canvas.drawBitmap(src, 0, 0, paint);
        return result;
    }

    private Bitmap enhanceContrast(Bitmap src) {
        int w = src.getWidth(), h = src.getHeight();
        int[] pixels = new int[w * h];
        src.getPixels(pixels, 0, w, 0, 0, w, h);
        for (int i = 0; i < pixels.length; i++) {
            int gray = pixels[i] & 0xFF;
            if (gray > 180) pixels[i] = 0xFFFFFFFF;
            else if (gray < 80) pixels[i] = 0xFF000000;
        }
        Bitmap result = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
        result.setPixels(pixels, 0, w, 0, 0, w, h);
        return result;
    }

    private void saveImage() {
        if (currentBitmap == null) return;
        try {
            File dir = new File(Environment.getExternalStoragePublicDirectory(
                Environment.DIRECTORY_DOWNLOADS), "Last04ka");
            if (!dir.exists()) dir.mkdirs();
            File file = new File(dir, "scan_" + System.currentTimeMillis() + ".jpg");
            FileOutputStream fos = new FileOutputStream(file);
            currentBitmap.compress(Bitmap.CompressFormat.JPEG, 90, fos);
            fos.close();
            Toast.makeText(this, "Сохранено: " + file.getAbsolutePath(), Toast.LENGTH_LONG).show();
            AppLogger.log(this, "DocScanner", "Saved: " + file.getAbsolutePath());
        } catch (Exception e) { Toast.makeText(this, "Ошибка сохранения", Toast.LENGTH_SHORT).show(); }
    }
}