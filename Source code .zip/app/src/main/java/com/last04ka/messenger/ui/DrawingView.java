package com.last04ka.messenger.ui;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;

import com.last04ka.messenger.utils.AppLogger;

public class DrawingView extends View {
    private static final String TAG = "DrawingView";
    
    private Paint paint;
    private Path path;
    private Canvas canvas;
    private Bitmap bitmap;
    private float lastX, lastY;
    private static final float TOUCH_TOLERANCE = 4;
    private boolean isDrawing = false;
    private DrawingCallback callback;
    
    public interface DrawingCallback {
        void onDrawingFinished(Bitmap maskBitmap);
    }
    
    // Конструктор для XML (ВАЖНО!)
    public DrawingView(Context context, AttributeSet attrs) {
        super(context, attrs);
        AppLogger.log(null, TAG, "DrawingView(Context, AttributeSet) constructor called");
        init();
    }
    
    // Конструктор для кода
    public DrawingView(Context context) {
        super(context);
        AppLogger.log(null, TAG, "DrawingView(Context) constructor called");
        init();
    }
    
    private void init() {
        AppLogger.log(null, TAG, "init() started");
        try {
            paint = new Paint();
            paint.setColor(Color.RED);
            paint.setStyle(Paint.Style.STROKE);
            paint.setStrokeJoin(Paint.Join.ROUND);
            paint.setStrokeCap(Paint.Cap.ROUND);
            paint.setStrokeWidth(40f);
            paint.setAntiAlias(true);
            
            path = new Path();
            
            AppLogger.log(null, TAG, "DrawingView initialized SUCCESS");
        } catch (Exception e) {
            AppLogger.logException(null, TAG, "init() error", e);
        }
    }
    
    public void setDrawingCallback(DrawingCallback callback) {
        this.callback = callback;
        AppLogger.log(null, TAG, "DrawingCallback set");
    }
    
    public void startDrawing() {
        AppLogger.log(null, TAG, "startDrawing() called, isDrawing=" + isDrawing);
        isDrawing = true;
        setVisibility(View.VISIBLE);
        
        if (getWidth() > 0 && getHeight() > 0) {
            AppLogger.log(null, TAG, "Creating bitmap: " + getWidth() + "x" + getHeight());
            bitmap = Bitmap.createBitmap(getWidth(), getHeight(), Bitmap.Config.ARGB_8888);
            canvas = new Canvas(bitmap);
        } else {
            AppLogger.log(null, TAG, "WARNING: View size is 0, bitmap not created yet");
        }
        
        path.reset();
        invalidate();
        AppLogger.log(null, TAG, "Drawing started");
    }
    
    public void clearDrawing() {
        AppLogger.log(null, TAG, "clearDrawing() called");
        isDrawing = false;
        if (bitmap != null) {
            bitmap.recycle();
            bitmap = null;
        }
        canvas = null;
        path.reset();
        invalidate();
        AppLogger.log(null, TAG, "Drawing cleared");
    }
    
    @Override
    protected void onSizeChanged(int w, int h, int oldw, int oldh) {
        super.onSizeChanged(w, h, oldw, oldh);
        AppLogger.log(null, TAG, "onSizeChanged: " + w + "x" + h);
        if (isDrawing && (bitmap == null || bitmap.getWidth() != w || bitmap.getHeight() != h)) {
            if (bitmap != null) bitmap.recycle();
            bitmap = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
            canvas = new Canvas(bitmap);
            AppLogger.log(null, TAG, "Bitmap recreated in onSizeChanged");
        }
    }
    
    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        if (bitmap != null) {
            canvas.drawBitmap(bitmap, 0, 0, null);
        }
        canvas.drawPath(path, paint);
    }
    
    @Override
    public boolean onTouchEvent(MotionEvent event) {
        if (!isDrawing) {
            return false;
        }
        
        float x = event.getX();
        float y = event.getY();
        
        switch (event.getAction()) {
            case MotionEvent.ACTION_DOWN:
                AppLogger.log(null, TAG, "ACTION_DOWN at: " + x + ", " + y);
                touchStart(x, y);
                invalidate();
                return true;
            case MotionEvent.ACTION_MOVE:
                touchMove(x, y);
                invalidate();
                return true;
            case MotionEvent.ACTION_UP:
                AppLogger.log(null, TAG, "ACTION_UP at: " + x + ", " + y);
                touchUp();
                invalidate();
                return true;
        }
        return true;
    }
    
    private void touchStart(float x, float y) {
        path.reset();
        path.moveTo(x, y);
        lastX = x;
        lastY = y;
        if (canvas != null) {
            canvas.drawPath(path, paint);
        }
        AppLogger.log(null, TAG, "Touch start");
    }
    
    private void touchMove(float x, float y) {
        float dx = Math.abs(x - lastX);
        float dy = Math.abs(y - lastY);
        if (dx >= TOUCH_TOLERANCE || dy >= TOUCH_TOLERANCE) {
            path.quadTo(lastX, lastY, (x + lastX) / 2, (y + lastY) / 2);
            lastX = x;
            lastY = y;
            
            if (canvas != null) {
                canvas.drawPath(path, paint);
            }
        }
    }
    
    private void touchUp() {
        path.lineTo(lastX, lastY);
        if (canvas != null) {
            canvas.drawPath(path, paint);
        }
        
        AppLogger.log(null, TAG, "touchUp, creating mask");
        
        Bitmap mask = null;
        if (bitmap != null) {
            AppLogger.log(null, TAG, "Creating mask from bitmap: " + bitmap.getWidth() + "x" + bitmap.getHeight());
            mask = Bitmap.createBitmap(bitmap);
        } else {
            AppLogger.log(null, TAG, "WARNING: bitmap is null, cannot create mask");
        }
        
        if (callback != null && mask != null) {
            AppLogger.log(null, TAG, "Calling callback.onDrawingFinished with mask");
            callback.onDrawingFinished(mask);
        } else {
            AppLogger.log(null, TAG, "callback is null or mask is null: callback=" + callback + ", mask=" + mask);
        }
        
        clearDrawing();
        AppLogger.log(null, TAG, "Touch up finished");
    }
}