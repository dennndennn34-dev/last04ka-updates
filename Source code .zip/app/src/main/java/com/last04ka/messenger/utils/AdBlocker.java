package com.last04ka.messenger.utils;

import android.net.Uri;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

public class AdBlocker {

    private static final Set<String> AD_HOSTS = new HashSet<>(Arrays.asList(
        // Рекламные сети
        "doubleclick.net", "googlesyndication.com", "googleadservices.com",
        "googletagmanager.com", "googletagservices.com", "adservice.google.com",
        "adservice.google.ru", "pagead2.googlesyndication.com",
        "yandexadexchange.net",
        
        // Яндекс.Директ (точные домены)
        "an.yandex.ru", "yabs.yandex.ru", "adfox.ru", "adfox.yandex.ru",
        
        // Яндекс статика (НЕ БЛОКИРУЕМ yastatic.net — он нужен для работы сервисов Яндекса)
        
        // Баннерные сети
        "ads.yahoo.com", "advertising.com", "adzerk.net", "adform.net",
        "adnxs.com", "adroll.com", "amazon-adsystem.com", "criteo.com",
        "criteo.net", "openx.net", "pubmatic.com", "rubiconproject.com",
        "sharethrough.com", "smaato.net", "smartadserver.com", "spotxchange.com",
        "taboola.com", "teads.tv", "triplelift.com", "turn.com",
        
        // Российские рекламные сети
        "vk.com/ads", "my.com/ads", "mail.ru/ads", "target.my.com",
        "mediascope.net", "ad.mail.ru", "rs.mail.ru", "top-fwz1.mail.ru",
        
        // Всплывающие окна и попапы
        "popads.net", "popcash.net", "propellerads.com", "propellerads.net",
        "exoclick.com", "adultfriendfinder.com", "trafficjunky.com",
        "trafficfactory.com", "juicyads.com", "eroadvertising.com",
        
        // Трекеры (точные пути)
        "facebook.net", "facebook.com/tr",
        "mc.yandex.ru", "metrika.yandex.ru",
        "statcounter.com", "hotjar.com", "mouseflow.com",
        "chartbeat.com", "crazyegg.com", "mixpanel.com", "amplitude.com",
        "segment.io", "segment.com", "appsflyer.com", "adjust.com",
        "branch.io", "kochava.com", "singular.net",
        
        // Аналитика
        "analytics.google.com", "analytics.yandex.ru",
        
        // Майнеры
        "coinhive.com", "coin-hive.com", "jsecoin.com", "crypto-loot.com",
        "coinerz.com", "minero.cc", "ppoi.org", "webmine.cz",
        
        // Назойливые уведомления
        "onesignal.com", "pushwoosh.com", "pushengage.com", "izooto.com",
        "pushcrew.com", "notix.io", "pushify.net",
        
        // Прочие
        "adsrvr.org", "adtech.com", "advertising.amazon.com",
        "aax.amazon-adsystem.com", "flashtalking.com", "s0.2mdn.net",
        "media.net", "moatads.com", "outbrain.com", "revcontent.com",
        "zemanta.com", "mgid.com", "adtrue.com", "adblade.com",
        "nativeads.com", "bidswitch.net", "casalemedia.com", "contextweb.com",
        "lijit.com", "indexww.com", "sonobi.com"
    ));

    // ТОЧНЫЕ пути, которые нужно блокировать (безопасно, без ложных срабатываний)
    private static final String[] BLOCKED_PATHS = {
        "/banner/", "/banner-", "_banner", "-banner-",
        "/popup/", "/popunder/",
        "/advert/", "/advertise", "/advertisement",
        "/promo/", "/promotion",
        "_ad.", "-ad.", "/ad_", "/ads/", "_ads.", "-ads.",
        "/sponsor/", "/sponsored/",
        "/tracker/", "/tracking/", "/pixel/",
        "/analytics/", "/metrics/",
        "/collect", "/beacon"
    };

    public static boolean isAd(String url) {
        if (url == null || url.isEmpty()) return false;
        
        try {
            Uri uri = Uri.parse(url);
            String host = uri.getHost();
            if (host == null) return false;
            
            String hostLower = host.toLowerCase();
            
            // Убираем www
            if (hostLower.startsWith("www.")) {
                hostLower = hostLower.substring(4);
            }
            
            // Проверяем домен в списке
            String fullUrl = (hostLower + uri.getPath()).toLowerCase();
            
            for (String adHost : AD_HOSTS) {
                // Точное совпадение домена с путём
                if (fullUrl.contains(adHost)) {
                    return true;
                }
                // Точное совпадение домена
                if (hostLower.equals(adHost)) {
                    return true;
                }
                // Поддомен рекламной сети
                if (hostLower.endsWith("." + adHost)) {
                    return true;
                }
            }
            
            // Проверяем пути
            String path = uri.getPath();
            if (path != null) {
                String pathLower = path.toLowerCase();
                for (String blockedPath : BLOCKED_PATHS) {
                    if (pathLower.contains(blockedPath)) {
                        // Исключения для Яндекса
                        if (hostLower.contains("yandex") && !hostLower.contains("an.yandex") && !hostLower.contains("yabs.yandex")) {
                            continue;
                        }
                        if (hostLower.contains("google") && !hostLower.contains("adservice") && !hostLower.contains("googlesyndication") && !hostLower.contains("googleadservices") && !hostLower.contains("pagead2")) {
                            continue;
                        }
                        return true;
                    }
                }
            }
            
        } catch (Exception e) {
        }
        
        return false;
    }
}