package com.last04ka.messenger.ui;

import android.app.Activity;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.media.AudioFormat;
import android.media.AudioManager;
import android.media.AudioTrack;
import android.os.Bundle;
import android.os.Handler;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import com.last04ka.messenger.utils.AppLogger;
import com.last04ka.messenger.utils.GameScores;
import java.util.Random;

public class TimingGameActivity extends Activity {

    private GameView gameView;
    private TextView scoreText, bestText, triesText, accuracyText, avgText;
    private Button btnEasy, btnMedium, btnHard, btnNew;
    private Handler handler = new Handler();

    private int[] zoneSizes = {40, 25, 12};
    private String[] modeNames = {"Лёгкий", "Средний", "Сложный"};
    private int currentMode = 0;

    private int score = 0;
    private int best = 0;
    private int tries = 0;
    private int totalAccuracy = 0;
    private float lastAccuracy = 0;

    // Анимация
    private float currentAngle = 0;
    private float targetAngle = 0;
    private float rotationSpeed = 2.5f;
    private boolean clockwise = true;
    private volatile boolean gameRunning = true;
    private boolean scoredThisRound = false;
    private boolean soundEnabled = true;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        try {
            AppLogger.log(this, "TimingGame", "onCreate started");

            LinearLayout layout = new LinearLayout(this);
            layout.setOrientation(LinearLayout.VERTICAL);
            layout.setPadding(8, 8, 8, 8);
            layout.setBackgroundColor(0xFF1A1A2E);

            // Статистика
            LinearLayout stats1 = new LinearLayout(this);
            stats1.setOrientation(LinearLayout.HORIZONTAL);
            stats1.setGravity(Gravity.CENTER);
            stats1.setPadding(4, 4, 4, 2);

            scoreText = new TextView(this);
            scoreText.setText("Счёт: 0"); scoreText.setTextSize(13);
            scoreText.setTextColor(0xFFFFD740); stats1.addView(scoreText);

            bestText = new TextView(this);
            best = GameScores.getScore(this, "timing");
            bestText.setText("  Рекорд: " + best); bestText.setTextSize(12);
            bestText.setTextColor(0xFFFFFFFF); stats1.addView(bestText);

            triesText = new TextView(this);
            triesText.setText("  Попыток: 0"); triesText.setTextSize(12);
            triesText.setTextColor(0xFFBDBDBD); stats1.addView(triesText);

            layout.addView(stats1);

            LinearLayout stats2 = new LinearLayout(this);
            stats2.setOrientation(LinearLayout.HORIZONTAL);
            stats2.setGravity(Gravity.CENTER);
            stats2.setPadding(4, 0, 4, 4);

            accuracyText = new TextView(this);
            accuracyText.setText("Точность: --"); accuracyText.setTextSize(12);
            accuracyText.setTextColor(0xFF4FC3F7); stats2.addView(accuracyText);

            avgText = new TextView(this);
            avgText.setText("  Среднее: --"); avgText.setTextSize(12);
            avgText.setTextColor(0xFF81C784); stats2.addView(avgText);

            layout.addView(stats2);

            // Игровое поле
            gameView = new GameView(this);
            LinearLayout.LayoutParams gp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 1);
            gameView.setLayoutParams(gp);
            layout.addView(gameView);

            // Кнопки режимов
            LinearLayout modeRow = new LinearLayout(this);
            modeRow.setGravity(Gravity.CENTER);
            modeRow.setPadding(0, 4, 0, 4);

            btnEasy = new Button(this); btnEasy.setText("🟢 Лёгкий"); btnEasy.setTextSize(11);
            btnEasy.setOnClickListener(v -> setMode(0)); modeRow.addView(btnEasy);

            btnMedium = new Button(this); btnMedium.setText("🟡 Средний"); btnMedium.setTextSize(11);
            btnMedium.setOnClickListener(v -> setMode(1)); modeRow.addView(btnMedium);

            btnHard = new Button(this); btnHard.setText("🔴 Сложный"); btnHard.setTextSize(11);
            btnHard.setOnClickListener(v -> setMode(2)); modeRow.addView(btnHard);

            layout.addView(modeRow);

            // Кнопки действий
            LinearLayout actRow = new LinearLayout(this);
            actRow.setGravity(Gravity.CENTER);

            btnNew = new Button(this); btnNew.setText("🔄 Новая"); btnNew.setTextSize(12);
            btnNew.setOnClickListener(v -> resetAll()); actRow.addView(btnNew);

            Button btnSound = new Button(this); btnSound.setText("🔊"); btnSound.setTextSize(12);
            btnSound.setOnClickListener(v -> { soundEnabled = !soundEnabled; btnSound.setText(soundEnabled ? "🔊" : "🔇"); });
            actRow.addView(btnSound);

            layout.addView(actRow);

            setContentView(layout);
            setTitle("⚡ Тайминг");
            setMode(0);
            newTarget();
            updateUI();
            startGameLoop();   // <-- ЗАПУСК ЦИКЛА
            AppLogger.log(this, "TimingGame", "onCreate completed, best=" + best);
        } catch (Exception e) { AppLogger.logException(this, "TimingGame", e); finish(); }
    }

    private void startGameLoop() {
        new Thread(() -> {
            while (gameRunning) {
                try {
                    Thread.sleep(16); // ~60 FPS
                    if (gameView != null) {
                        gameView.update();
                        runOnUiThread(() -> { if (gameView != null) gameView.invalidate(); });
                    }
                } catch (InterruptedException e) { break; }
            }
        }).start();
    }

    private void setMode(int mode) {
        currentMode = mode;
        btnEasy.setTextColor(mode == 0 ? 0xFFFFD740 : 0xFF888888);
        btnMedium.setTextColor(mode == 1 ? 0xFFFFD740 : 0xFF888888);
        btnHard.setTextColor(mode == 2 ? 0xFFFFD740 : 0xFF888888);
        AppLogger.log(this, "TimingGame", "Mode: " + modeNames[mode]);
    }

    private void newTarget() {
        Random rand = new Random();
        int zone = zoneSizes[currentMode];
        targetAngle = rand.nextInt(360 - zone);
        scoredThisRound = false;
    }

    private void resetAll() {
        score = 0;
        tries = 0;
        totalAccuracy = 0;
        lastAccuracy = 0;
        newTarget();
        updateUI();
        AppLogger.log(this, "TimingGame", "Game reset");
    }

    private void updateUI() {
        scoreText.setText("Счёт: " + score);
        if (score > best) {
            best = score;
            GameScores.saveScore(this, "timing", best);
        }
        bestText.setText("  Рекорд: " + best);
        triesText.setText("  Попыток: " + tries);
        if (tries > 0) {
            accuracyText.setText(String.format("Точность: %.1f%%", lastAccuracy));
            avgText.setText(String.format("  Среднее: %.0f%%", totalAccuracy / (float)tries));
        }
    }

    private void playSound(float accuracy) {
        if (!soundEnabled) return;
        int freq = 400 + (int)(accuracy * 6);
        if (accuracy >= 95) freq = 1200;
        try {
            int dur = 60, samples = 8000 * dur / 1000;
            byte[] tone = new byte[samples];
            for (int i = 0; i < samples; i++) tone[i] = (byte)(Math.sin(2 * Math.PI * freq * i / 8000) * 80);
            AudioTrack track = new AudioTrack(AudioManager.STREAM_MUSIC, 8000,
                AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_8BIT, samples, AudioTrack.MODE_STATIC);
            track.write(tone, 0, samples); track.play();
            handler.postDelayed(() -> { try { track.release(); } catch (Exception e) {} }, dur + 10);
        } catch (Exception ex) {}
    }

    class GameView extends View {
        private Paint paint = new Paint();

        public GameView(Context ctx) {
            super(ctx);
            setFocusable(true);
            setFocusableInTouchMode(true);
            setClickable(true);
        }

        @Override
        protected void onDraw(Canvas c) {
            super.onDraw(c);
            int w = getWidth(), h = getHeight();
            float cx = w / 2f, cy = h / 2f;
            float radius = Math.min(w, h) * 0.38f;
            int zone = zoneSizes[currentMode];

            // Фон круга
            paint.setColor(0xFF2A2A3E);
            paint.setStyle(Paint.Style.FILL);
            c.drawCircle(cx, cy, radius, paint);

            // Ободок
            paint.setColor(0xFF555555);
            paint.setStyle(Paint.Style.STROKE);
            paint.setStrokeWidth(4);
            c.drawCircle(cx, cy, radius, paint);
            paint.setStrokeWidth(1);

            // Целевая зона
            paint.setColor(0xFF4CAF50);
            paint.setStyle(Paint.Style.FILL);
            RectF oval = new RectF(cx - radius, cy - radius, cx + radius, cy + radius);
            c.drawArc(oval, targetAngle - 90, zone, true, paint);

            paint.setColor(0xFF81C784);
            paint.setStyle(Paint.Style.STROKE);
            paint.setStrokeWidth(3);
            c.drawArc(oval, targetAngle - 90, zone, true, paint);
            paint.setStrokeWidth(1);
            paint.setStyle(Paint.Style.FILL);

            // Шарик
            float arrowAngle = currentAngle - 90;
            float ax = cx + (float) Math.cos(Math.toRadians(arrowAngle)) * radius * 0.85f;
            float ay = cy + (float) Math.sin(Math.toRadians(arrowAngle)) * radius * 0.85f;

            paint.setColor(0xFF90CAF9);
            paint.setStrokeWidth(2);
            c.drawLine(cx, cy, ax, ay, paint);

            paint.setColor(0xFFFFEB3B);
            c.drawCircle(ax, ay, radius * 0.08f, paint);
            paint.setColor(0xFFFF9800);
            c.drawCircle(ax, ay, radius * 0.04f, paint);

            paint.setColor(0xFFFFFFFF);
            c.drawCircle(cx, cy, radius * 0.04f, paint);

            paint.setTextSize(radius * 0.12f);
            paint.setTextAlign(Paint.Align.CENTER);
            paint.setColor(0xFFFFFFFF);
            c.drawText("Нажмите когда шарик в зоне!", cx, cy + radius + 40, paint);
            paint.setTextAlign(Paint.Align.LEFT);
        }

        public void update() {
            if (!gameRunning) return;

            if (clockwise) {
                currentAngle += rotationSpeed;
                if (currentAngle >= 360) currentAngle -= 360;
            } else {
                currentAngle -= rotationSpeed;
                if (currentAngle < 0) currentAngle += 360;
            }

            if (Math.random() < 0.005) clockwise = !clockwise;
            rotationSpeed = 2.5f + score * 0.15f;
            if (rotationSpeed > 10) rotationSpeed = 10;
        }

        @Override
        public boolean onTouchEvent(MotionEvent e) {
            if (e.getAction() != MotionEvent.ACTION_DOWN) return true;
            if (scoredThisRound) return true;

            int zone = zoneSizes[currentMode];
            float targetCenter = targetAngle + zone / 2f;

            float dist = Math.abs(currentAngle - targetCenter);
            if (dist > 180) dist = 360 - dist;

            float maxDist = zone / 2f;
            lastAccuracy = Math.max(0, 100 - (dist / maxDist) * 100);
            lastAccuracy = Math.min(100, lastAccuracy);

            if (dist <= maxDist) {
                int earned = (int) (lastAccuracy / 10) + 1;
                if (lastAccuracy >= 95) earned += 5;
                score += earned;
                totalAccuracy += (int) lastAccuracy;
                tries++;
                scoredThisRound = true;
                playSound(lastAccuracy);

                if (lastAccuracy >= 98) {
                    Toast.makeText(TimingGameActivity.this, "🔥 ИДЕАЛЬНО! +" + earned, Toast.LENGTH_SHORT).show();
                } else if (lastAccuracy >= 90) {
                    Toast.makeText(TimingGameActivity.this, "👏 Отлично! +" + earned, Toast.LENGTH_SHORT).show();
                }

                handler.postDelayed(() -> {
                    newTarget();
                    scoredThisRound = false;
                    updateUI();
                }, 600);

                AppLogger.log(TimingGameActivity.this, "TimingGame",
                    "Hit! accuracy=" + String.format("%.1f", lastAccuracy) + "% earned=" + earned + " score=" + score);
            } else {
                tries++;
                totalAccuracy += 0;
                lastAccuracy = 0;
                playSound(0);
                Toast.makeText(TimingGameActivity.this, "❌ Мимо!", Toast.LENGTH_SHORT).show();
                handler.postDelayed(() -> {
                    newTarget();
                    scoredThisRound = false;
                    updateUI();
                }, 400);
                AppLogger.log(TimingGameActivity.this, "TimingGame", "Miss! score=" + score);
            }

            updateUI();
            return true;
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        gameRunning = false;
        handler.removeCallbacksAndMessages(null);
    }
}