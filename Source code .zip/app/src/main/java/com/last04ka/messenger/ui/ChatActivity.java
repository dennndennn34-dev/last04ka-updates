package com.last04ka.messenger.ui;

import android.animation.ObjectAnimator;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.os.Environment;
import android.speech.RecognizerIntent;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.animation.AccelerateDecelerateInterpolator;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.last04ka.messenger.R;
import com.last04ka.messenger.adapters.MessageAdapter;
import com.last04ka.messenger.data.DatabaseHelper;
import com.last04ka.messenger.data.Message;
import com.last04ka.messenger.utils.AppLogger;
import com.last04ka.messenger.utils.ThemeManager;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.UUID;

public class ChatActivity extends AppCompatActivity {
    private static final int REQUEST_VOICE_INPUT = 100;
    private static final String TAG = "ChatActivity";

    private RecyclerView recyclerView;
    private EditText inputMessage;
    private ImageButton sendButton, voiceButton, callButton, btnTheme;
    private MessageAdapter adapter;
    private DatabaseHelper dbHelper;
    private List<Message> messages = new ArrayList<>();
    private String chatId;
    private String chatName;

    // ==================== БЫСТРЫЕ ОТВЕТЫ ====================
    private LinearLayout quickRepliesLayout;
    private String[] quickReplies = {"OK", "Спасибо", "Понял", "Иду", "Скоро", "Отлично!"};

    // ==================== ТЕМА ЧАТА ====================
    private int chatThemeColor = 0xFF1A1A2E;
    private int chatBubbleSentColor = 0xFF90CAF9;
    private int chatBubbleReceivedColor = 0xFFFFFFFF;

    // ==================== СТАТУС ОНЛАЙН ====================
    private TextView statusOnline;
    private boolean isOnline = true;

    // ==================== ТИП ЧАТА ====================
    private int chatType = 0; // 0 - Bluetooth, 1 - Интернет

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        setTheme(ThemeManager.getThemeResource(this));
        super.onCreate(savedInstanceState);
        AppLogger.log(this, TAG, "ChatActivity created");
        setContentView(R.layout.activity_chat);

        dbHelper = new DatabaseHelper(this);
        chatId = getIntent().getStringExtra("CHAT_ID");
        chatName = getIntent().getStringExtra("CHAT_NAME");
        chatType = getIntent().getIntExtra("CHAT_TYPE", 0);
        setTitle(chatName);

        // ==================== ИНИЦИАЛИЗАЦИЯ ВСЕХ КНОПОК ====================
        recyclerView = findViewById(R.id.recycler_messages);
        inputMessage = findViewById(R.id.input_message);
        sendButton = findViewById(R.id.btn_send);
        voiceButton = findViewById(R.id.btn_voice);
        callButton = findViewById(R.id.btn_call);
        btnTheme = findViewById(R.id.btn_theme);
        quickRepliesLayout = findViewById(R.id.quick_replies_layout);
        statusOnline = findViewById(R.id.tv_online_status);

        // ==================== ЛОГИРОВАНИЕ ДЛЯ ОТЛАДКИ ====================
        AppLogger.log(this, TAG, "📌 Кнопки инициализированы:");
        AppLogger.log(this, TAG, "   sendButton=" + (sendButton != null ? "✅" : "❌"));
        AppLogger.log(this, TAG, "   voiceButton=" + (voiceButton != null ? "✅" : "❌"));
        AppLogger.log(this, TAG, "   callButton=" + (callButton != null ? "✅" : "❌"));
        AppLogger.log(this, TAG, "   btnTheme=" + (btnTheme != null ? "✅" : "❌"));

        // ==================== ПРИНУДИТЕЛЬНО ПОКАЗЫВАЕМ ВСЕ КНОПКИ ====================
        // Показываем ВСЕ кнопки для всех типов чатов
        if (voiceButton != null) {
            voiceButton.setVisibility(View.VISIBLE);
            AppLogger.log(this, TAG, "✅ voiceButton set VISIBLE");
        }
        if (callButton != null) {
            callButton.setVisibility(View.VISIBLE);
            AppLogger.log(this, TAG, "✅ callButton set VISIBLE");
        }
        if (sendButton != null) {
            sendButton.setVisibility(View.VISIBLE);
            AppLogger.log(this, TAG, "✅ sendButton set VISIBLE");
        }

        // ==================== СТАТУС ОНЛАЙН ====================
        if (statusOnline != null) {
            statusOnline.setText("🟢 Онлайн");
            statusOnline.setTextColor(0xFF4CAF50);
            animateOnlineStatus();
            AppLogger.log(this, TAG, "✅ Online status shown");
        }

        // ==================== БЫСТРЫЕ ОТВЕТЫ ====================
        setupQuickReplies();
        AppLogger.log(this, TAG, "✅ Quick replies setup");

        // ==================== ТЕМА ЧАТА ====================
        if (btnTheme != null) {
            btnTheme.setOnClickListener(v -> {
                AppLogger.log(ChatActivity.this, TAG, "🎨 Theme button clicked");
                showThemeDialog();
            });
        }

        // ==================== ГОЛОСОВОЙ ВВОД ====================
        if (voiceButton != null) {
            voiceButton.setOnClickListener(v -> {
                AppLogger.log(ChatActivity.this, TAG, "🎤 Voice button clicked");
                startVoiceInput();
            });
        } else {
            AppLogger.log(this, TAG, "❌ voiceButton is NULL!");
        }

        // ==================== КНОПКА ЗВОНКА ====================
        if (callButton != null) {
            callButton.setOnClickListener(v -> {
                AppLogger.log(ChatActivity.this, TAG, "📞 Call button clicked");
                Toast.makeText(this, "Звонок в разработке", Toast.LENGTH_SHORT).show();
            });
        } else {
            AppLogger.log(this, TAG, "❌ callButton is NULL!");
        }

        // ==================== НАСТРОЙКА RECYCLER VIEW ====================
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        adapter = new MessageAdapter(messages, new MessageAdapter.OnMessageLongClickListener() {
            @Override
            public void onMessageLongClick(Message message) {
                AppLogger.log(ChatActivity.this, TAG, "📋 Message long click");
                ClipboardManager clipboard = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
                ClipData clip = ClipData.newPlainText("message", message.getText());
                clipboard.setPrimaryClip(clip);
                Toast.makeText(ChatActivity.this, "Скопировано", Toast.LENGTH_SHORT).show();
            }
        });
        adapter.setChatId(chatId);
        recyclerView.setAdapter(adapter);

        // ==================== ПРИМЕНЕНИЕ ТЕМЫ ====================
        applyThemeColors();

        // ==================== ОТПРАВКА СООБЩЕНИЯ ====================
        if (sendButton != null) {
            sendButton.setOnClickListener(v -> {
                AppLogger.log(ChatActivity.this, TAG, "📤 Send button clicked");
                sendMessage();
            });
        } else {
            AppLogger.log(this, TAG, "❌ sendButton is NULL!");
        }

        // ==================== ЗАГРУЗКА ДАННЫХ ====================
        loadChatTheme();
        applyChatTheme();
        loadMessages();
        dbHelper.resetUnreadCount(chatId);

        AppLogger.log(this, TAG, "ChatActivity ready");
    }

    // ==================== СТАТУС ОНЛАЙН ====================
    private void animateOnlineStatus() {
        AppLogger.log(this, TAG, "🟢 animateOnlineStatus() START");
        if (statusOnline == null) return;
        ObjectAnimator pulseAnim = ObjectAnimator.ofFloat(statusOnline, "alpha", 0.5f, 1f);
        pulseAnim.setDuration(800);
        pulseAnim.setRepeatCount(ObjectAnimator.INFINITE);
        pulseAnim.setRepeatMode(ObjectAnimator.REVERSE);
        pulseAnim.setInterpolator(new AccelerateDecelerateInterpolator());
        pulseAnim.start();
        AppLogger.log(this, TAG, "✅ Online status animation started");
    }

    private void setOnlineStatus(boolean online) {
        AppLogger.log(this, TAG, "🟢 setOnlineStatus: " + online);
        isOnline = online;
        if (statusOnline != null) {
            if (online) {
                statusOnline.setText("🟢 Онлайн");
                statusOnline.setTextColor(0xFF4CAF50);
            } else {
                statusOnline.setText("⚪ Офлайн");
                statusOnline.setTextColor(0xFF9E9E9E);
            }
        }
    }

    // ==================== БЫСТРЫЕ ОТВЕТЫ ====================
    private void setupQuickReplies() {
        AppLogger.log(this, TAG, "💬 setupQuickReplies() START");
        if (quickRepliesLayout == null) {
            AppLogger.log(this, TAG, "⚠️ quickRepliesLayout is null");
            return;
        }

        quickRepliesLayout.removeAllViews();
        for (String reply : quickReplies) {
            Button btn = new Button(this);
            btn.setText(reply);
            btn.setTextSize(12);
            btn.setAllCaps(false);
            btn.setPadding(16, 8, 16, 8);
            btn.setBackgroundResource(R.drawable.bubble_sent);
            btn.setTextColor(0xFF212121);
            LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.WRAP_CONTENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
            );
            params.setMargins(4, 4, 4, 4);
            btn.setLayoutParams(params);

            btn.setOnClickListener(v -> {
                AppLogger.log(ChatActivity.this, TAG, "📤 Quick reply: " + reply);
                inputMessage.setText(reply);
                sendMessage();
            });

            quickRepliesLayout.addView(btn);
        }
        AppLogger.log(this, TAG, "✅ Quick replies setup complete: " + quickReplies.length);
    }

    // ==================== ТЕМА ЧАТА ====================
    private void loadChatTheme() {
        AppLogger.log(this, TAG, "🎨 loadChatTheme() START");
        SharedPreferences prefs = getSharedPreferences("chat_themes", MODE_PRIVATE);
        String themeStr = prefs.getString(chatId, "default");
        AppLogger.log(this, TAG, "   Theme: " + themeStr);

        switch (themeStr) {
            case "ocean":
                chatThemeColor = 0xFFE3F2FD;
                chatBubbleSentColor = 0xFF1976D2;
                chatBubbleReceivedColor = 0xFFFFFFFF;
                break;
            case "forest":
                chatThemeColor = 0xFFE8F5E9;
                chatBubbleSentColor = 0xFF388E3C;
                chatBubbleReceivedColor = 0xFFFFFFFF;
                break;
            case "twilight":
                chatThemeColor = 0xFFF3E5F5;
                chatBubbleSentColor = 0xFF8E24AA;
                chatBubbleReceivedColor = 0xFFFFFFFF;
                break;
            case "dark":
                chatThemeColor = 0xFF1A1A2E;
                chatBubbleSentColor = 0xFF1B5E20;
                chatBubbleReceivedColor = 0xFF424242;
                break;
            default:
                chatThemeColor = ThemeManager.getBackgroundColor(this);
                chatBubbleSentColor = ThemeManager.getBubbleSentColor(this);
                chatBubbleReceivedColor = ThemeManager.getBubbleReceivedColor(this);
                break;
        }
    }

    private void applyChatTheme() {
        AppLogger.log(this, TAG, "🎨 applyChatTheme() START");
        findViewById(R.id.chat_layout).setBackgroundColor(chatThemeColor);
        if (recyclerView != null) {
            recyclerView.setBackgroundColor(chatThemeColor);
        }
        if (adapter != null) {
            adapter.notifyDataSetChanged();
        }
        AppLogger.log(this, TAG, "✅ Theme applied: " + Integer.toHexString(chatThemeColor));
    }

    private void showThemeDialog() {
        AppLogger.log(this, TAG, "🎨 showThemeDialog() START");
        final String[] themes = {"По умолчанию", "Океан", "Лес", "Сумерки", "Тёмная"};
        final String[] themeKeys = {"default", "ocean", "forest", "twilight", "dark"};

        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("🎨 Тема чата");
        builder.setItems(themes, (dialog, which) -> {
            AppLogger.log(ChatActivity.this, TAG, "   Theme selected: " + themes[which]);
            SharedPreferences prefs = getSharedPreferences("chat_themes", MODE_PRIVATE);
            prefs.edit().putString(chatId, themeKeys[which]).apply();
            loadChatTheme();
            applyChatTheme();
            Toast.makeText(ChatActivity.this, "Тема изменена", Toast.LENGTH_SHORT).show();
        });
        builder.show();
    }

    // ==================== ОСНОВНЫЕ МЕТОДЫ ====================
    private void applyThemeColors() {
        int bgColor = ThemeManager.getBackgroundColor(this);
        int inputBgColor = ThemeManager.getInputBgColor(this);
        int textColor = ThemeManager.getTextColor(this);
        int hintColor = ThemeManager.getHintColor(this);
        int dividerColor = ThemeManager.getDividerColor(this);

        recyclerView.setBackgroundColor(bgColor);
        inputMessage.setTextColor(textColor);
        inputMessage.setHintTextColor(hintColor);

        GradientDrawable inputBg = new GradientDrawable();
        inputBg.setColor(inputBgColor);
        inputBg.setCornerRadius(16);
        inputBg.setStroke(1, dividerColor);
        inputMessage.setBackground(inputBg);

        View divider = findViewById(R.id.divider);
        divider.setBackgroundColor(dividerColor);

        findViewById(R.id.input_layout).setBackgroundColor(bgColor);

        if (getSupportActionBar() != null) {
            getSupportActionBar().setBackgroundDrawable(new ColorDrawable(
                    ThemeManager.isDarkTheme(this) ? 0xFF424242 : 0xFF1565C0));
        }
    }

    private void sendMessage() {
        String text = inputMessage.getText().toString().trim();
        if (TextUtils.isEmpty(text)) return;
        AppLogger.log(this, TAG, "📤 Sending: " + text);

        Message msg = new Message();
        msg.setId(UUID.randomUUID().toString());
        msg.setChatId(chatId);
        msg.setText(text);
        msg.setTimestamp(System.currentTimeMillis());
        msg.setSent(true);

        dbHelper.addMessage(msg);
        messages.add(msg);
        adapter.notifyItemInserted(messages.size() - 1);
        recyclerView.scrollToPosition(messages.size() - 1);
        inputMessage.setText("");
        AppLogger.log(this, TAG, "✅ Message sent");
    }

    private void loadMessages() {
        messages.clear();
        messages.addAll(dbHelper.getMessagesForChat(chatId));
        adapter.notifyDataSetChanged();
        if (!messages.isEmpty()) {
            recyclerView.scrollToPosition(messages.size() - 1);
        }
        AppLogger.log(this, TAG, "📂 Loaded " + messages.size() + " messages");
    }

    private void startVoiceInput() {
        AppLogger.log(this, TAG, "🎤 startVoiceInput() called");
        Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault());
        intent.putExtra(RecognizerIntent.EXTRA_PROMPT, "Говорите...");
        try {
            AppLogger.log(this, TAG, "🎤 Starting voice recognition intent");
            startActivityForResult(intent, REQUEST_VOICE_INPUT);
            AppLogger.log(this, TAG, "✅ Voice recognition started successfully");
        } catch (Exception e) {
            AppLogger.logException(this, TAG, "🎤 Failed to start voice recognition", e);
            Toast.makeText(this, "Голосовой ввод не поддерживается на этом устройстве", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        AppLogger.log(this, TAG, "📱 onActivityResult: requestCode=" + requestCode + ", resultCode=" + resultCode);

        if (requestCode == REQUEST_VOICE_INPUT) {
            if (resultCode == RESULT_OK && data != null) {
                ArrayList<String> results = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
                if (results != null && !results.isEmpty()) {
                    String spokenText = results.get(0);
                    AppLogger.log(this, TAG, "🎤 Recognized text: " + spokenText);
                    inputMessage.setText(spokenText);
                    AppLogger.log(this, TAG, "✅ Voice text set to input field");
                } else {
                    AppLogger.log(this, TAG, "⚠️ Voice recognition returned empty results");
                }
            } else {
                AppLogger.log(this, TAG, "⚠️ Voice recognition cancelled or failed, resultCode=" + resultCode);
            }
        }
    }

    // ==================== МЕНЮ ====================

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.chat_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        AppLogger.log(this, TAG, "📋 Menu item selected: " + item.getItemId());
        if (item.getItemId() == R.id.menu_search) {
            AppLogger.log(this, TAG, "🔍 Search menu clicked");
            startActivity(new Intent(this, SearchMessagesActivity.class).putExtra("CHAT_ID", chatId));
            return true;
        } else if (item.getItemId() == R.id.menu_export) {
            AppLogger.log(this, TAG, "📤 Export menu clicked");
            exportChat();
            return true;
        } else if (item.getItemId() == R.id.menu_rename) {
            AppLogger.log(this, TAG, "✏️ Rename menu clicked");
            showRenameDialog();
            return true;
        } else if (item.getItemId() == R.id.menu_delete_all) {
            AppLogger.log(this, TAG, "🗑️ Delete all menu clicked");
            showDeleteAllDialog();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    private void showRenameDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Переименовать чат");
        final android.widget.EditText input = new android.widget.EditText(this);
        input.setText(chatName);
        input.setHint("Введите новое имя");
        builder.setView(input);
        builder.setPositiveButton("Сохранить", (dialog, which) -> {
            String newName = input.getText().toString().trim();
            if (!newName.isEmpty()) {
                chatName = newName;
                setTitle(chatName);
                dbHelper.updateChatName(chatId, newName);
                Toast.makeText(ChatActivity.this, "Имя изменено на " + newName, Toast.LENGTH_SHORT).show();
            }
        });
        builder.setNegativeButton("Отмена", null);
        builder.show();
    }

    private void showDeleteAllDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Удалить все сообщения?");
        builder.setMessage("Это действие нельзя отменить. Все сообщения в этом чате будут удалены.");
        builder.setPositiveButton("Удалить", (dialog, which) -> {
            messages.clear();
            adapter.notifyDataSetChanged();
            dbHelper.deleteMessagesForChat(chatId);
            Toast.makeText(ChatActivity.this, "Все сообщения удалены", Toast.LENGTH_SHORT).show();
            AppLogger.log(ChatActivity.this, TAG, "All messages deleted for chat: " + chatId);
        });
        builder.setNegativeButton("Отмена", null);
        builder.show();
    }

    private void exportChat() {
        AppLogger.log(this, TAG, "📤 exportChat() called");
        try {
            File dir = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), "Last04ka");
            if (!dir.exists()) {
                dir.mkdirs();
                AppLogger.log(this, TAG, "📁 Created directory");
            }
            String fileName = "chat_" + chatId + "_" + System.currentTimeMillis() + ".txt";
            File file = new File(dir, fileName);
            AppLogger.log(this, TAG, "📤 Export file: " + file.getAbsolutePath());

            FileWriter writer = new FileWriter(file);
            writer.write("Экспорт чата: " + chatName + "\n");
            writer.write("Дата: " + new SimpleDateFormat("dd.MM.yyyy HH:mm:ss", Locale.getDefault()).format(new Date()) + "\n\n");
            writer.write("Всего сообщений: " + messages.size() + "\n\n");

            for (Message msg : messages) {
                String who = msg.isSent() ? "Я" : chatName;
                String time = new SimpleDateFormat("dd.MM HH:mm", Locale.getDefault()).format(new Date(msg.getTimestamp()));
                writer.write(who + " (" + time + "): " + msg.getText() + "\n");
            }
            writer.close();
            AppLogger.log(this, TAG, "✅ Chat exported");
            Toast.makeText(this, "Чат экспортирован: " + file.getAbsolutePath(), Toast.LENGTH_LONG).show();
        } catch (IOException e) {
            AppLogger.logException(this, TAG, "❌ Export failed", e);
            Toast.makeText(this, "Ошибка экспорта", Toast.LENGTH_SHORT).show();
        }
    }

    // ==================== ON RESUME / PAUSE ====================

    @Override
    protected void onResume() {
        super.onResume();
        AppLogger.log(this, TAG, "onResume");
        setOnlineStatus(true);
        loadMessages();
    }

    @Override
    protected void onPause() {
        super.onPause();
        AppLogger.log(this, TAG, "onPause");
        setOnlineStatus(false);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        AppLogger.log(this, TAG, "onDestroy");
    }
}