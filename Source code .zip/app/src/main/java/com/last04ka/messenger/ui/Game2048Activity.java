package com.last04ka.messenger.ui;

import android.app.Activity;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.os.Bundle;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import com.last04ka.messenger.utils.AppLogger;
import com.last04ka.messenger.utils.GameScores;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class Game2048Activity extends Activity {

    private GameView gameView;
    private TextView scoreText, bestText;
    private Button btnNew, btnUndo;
    private int score = 0, best = 0;
    private int[][] board = new int[4][4];
    private int[][] prevBoard = new int[4][4];
    private int prevScore = 0;
    private Random rand = new Random();
    private boolean gameOver = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        try {
            AppLogger.log(this, "Game2048", "onCreate started");

            LinearLayout layout = new LinearLayout(this);
            layout.setOrientation(LinearLayout.VERTICAL);
            layout.setBackgroundColor(0xFF1A1A2E);
            layout.setPadding(16, 16, 16, 16);

            LinearLayout stats = new LinearLayout(this);
            stats.setOrientation(LinearLayout.HORIZONTAL);
            stats.setGravity(Gravity.CENTER);
            stats.setPadding(0, 0, 0, 12);

            scoreText = new TextView(this);
            scoreText.setText("Счёт: 0"); scoreText.setTextSize(18);
            scoreText.setTextColor(0xFFFFD740); stats.addView(scoreText);

            bestText = new TextView(this);
            best = GameScores.getScore(this, "2048");
            bestText.setText("  Рекорд: " + best); bestText.setTextSize(14);
            bestText.setTextColor(0xFFFFFFFF); stats.addView(bestText);

            layout.addView(stats);

            gameView = new GameView(this);
            LinearLayout.LayoutParams gp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 1);
            gameView.setLayoutParams(gp);
            layout.addView(gameView);

            LinearLayout btnRow = new LinearLayout(this);
            btnRow.setGravity(Gravity.CENTER);
            btnRow.setPadding(0, 12, 0, 0);

            btnNew = new Button(this);
            btnNew.setText("Новая игра"); btnNew.setTextSize(14);
            btnNew.setOnClickListener(v -> newGame());
            btnRow.addView(btnNew);

            btnUndo = new Button(this);
            btnUndo.setText("Отмена"); btnUndo.setTextSize(14);
            btnUndo.setOnClickListener(v -> undo());
            btnRow.addView(btnUndo);

            layout.addView(btnRow);

            setContentView(layout);
            setTitle("🔢 2048");
            newGame();
            AppLogger.log(this, "Game2048", "onCreate completed");
        } catch (Exception e) { AppLogger.logException(this, "Game2048", e); finish(); }
    }

    private void newGame() {
        board = new int[4][4];
        prevBoard = new int[4][4];
        score = 0;
        prevScore = 0;
        gameOver = false;
        addRandomTile();
        addRandomTile();
        updateUI();
        AppLogger.log(this, "Game2048", "New game started");
    }

    private void undo() {
        boolean hasPrev = false;
        for (int r = 0; r < 4; r++)
            for (int c = 0; c < 4; c++)
                if (prevBoard[r][c] != 0 || (board[r][c] == 0 && prevBoard[r][c] == 0)) hasPrev = true;
        // Проверяем что prevBoard реально отличается
        boolean different = false;
        for (int r = 0; r < 4; r++)
            for (int c = 0; c < 4; c++)
                if (prevBoard[r][c] != board[r][c]) different = true;

        if (!different) { Toast.makeText(this, "Нечего отменять", Toast.LENGTH_SHORT).show(); return; }
        for (int r = 0; r < 4; r++) System.arraycopy(prevBoard[r], 0, board[r], 0, 4);
        score = prevScore;
        gameOver = false;
        updateUI();
        Toast.makeText(this, "Ход отменён", Toast.LENGTH_SHORT).show();
        AppLogger.log(this, "Game2048", "Undo: score restored to " + score);
    }

    private void saveState() {
        for (int r = 0; r < 4; r++) System.arraycopy(board[r], 0, prevBoard[r], 0, 4);
        prevScore = score;
    }

    private void addRandomTile() {
        List<int[]> empty = new ArrayList<>();
        for (int r = 0; r < 4; r++)
            for (int c = 0; c < 4; c++)
                if (board[r][c] == 0) empty.add(new int[]{r, c});
        if (empty.isEmpty()) return;
        int[] cell = empty.get(rand.nextInt(empty.size()));
        board[cell[0]][cell[1]] = rand.nextInt(10) < 9 ? 2 : 4;
    }

    private boolean canMove() {
        for (int r = 0; r < 4; r++)
            for (int c = 0; c < 4; c++) {
                if (board[r][c] == 0) return true;
                if (c < 3 && board[r][c] == board[r][c+1]) return true;
                if (r < 3 && board[r][c] == board[r+1][c]) return true;
            }
        return false;
    }

    private boolean move(int direction) {
        boolean moved = false;
        int[][] oldBoard = new int[4][4];
        for (int r = 0; r < 4; r++) System.arraycopy(board[r], 0, oldBoard[r], 0, 4);

        if (direction == 0) moved = moveLeftInternal();
        else if (direction == 1) moved = moveRightInternal();
        else if (direction == 2) moved = moveUpInternal();
        else if (direction == 3) moved = moveDownInternal();

        return moved;
    }

    private boolean moveLeftInternal() {
        boolean moved = false;
        for (int r = 0; r < 4; r++) {
            int[] newRow = mergeLine(board[r].clone());
            if (!java.util.Arrays.equals(board[r], newRow)) moved = true;
            board[r] = newRow;
        }
        return moved;
    }

    private boolean moveRightInternal() {
        boolean moved = false;
        for (int r = 0; r < 4; r++) {
            int[] reversed = reverse(board[r].clone());
            int[] merged = mergeLine(reversed);
            int[] result = reverse(merged);
            if (!java.util.Arrays.equals(board[r], result)) moved = true;
            board[r] = result;
        }
        return moved;
    }

    private boolean moveUpInternal() {
        boolean moved = false;
        for (int c = 0; c < 4; c++) {
            int[] col = {board[0][c], board[1][c], board[2][c], board[3][c]};
            int[] merged = mergeLine(col.clone());
            if (!java.util.Arrays.equals(col, merged)) moved = true;
            for (int r = 0; r < 4; r++) board[r][c] = merged[r];
        }
        return moved;
    }

    private boolean moveDownInternal() {
        boolean moved = false;
        for (int c = 0; c < 4; c++) {
            int[] col = {board[0][c], board[1][c], board[2][c], board[3][c]};
            int[] reversed = reverse(col);
            int[] merged = mergeLine(reversed);
            int[] result = reverse(merged);
            if (!java.util.Arrays.equals(col, result)) moved = true;
            for (int r = 0; r < 4; r++) board[r][c] = result[r];
        }
        return moved;
    }

    private int[] mergeLine(int[] line) {
        int[] result = new int[4];
        int pos = 0;
        boolean[] merged = new boolean[4];
        for (int i = 0; i < 4; i++) {
            if (line[i] != 0) {
                if (pos > 0 && result[pos-1] == line[i] && !merged[pos-1]) {
                    result[pos-1] *= 2;
                    score += result[pos-1];
                    merged[pos-1] = true;
                } else {
                    result[pos++] = line[i];
                }
            }
        }
        return result;
    }

    private int[] reverse(int[] arr) {
        return new int[]{arr[3], arr[2], arr[1], arr[0]};
    }

    private void updateUI() {
        scoreText.setText("Счёт: " + score);
        if (score > best) {
            best = score;
            GameScores.saveScore(this, "2048", best);
            bestText.setText("  Рекорд: " + best);
        }
        gameView.invalidate();
    }

    class GameView extends View {
        private Paint paint = new Paint();
        private float downX, downY;
        private static final int SWIPE_MIN = 40;

        private int[] tileColors = {
            0xFFCDC1B4, 0xFFEEE4DA, 0xFFEDE0C8, 0xFFF2B179, 0xFFF59563,
            0xFFF67C5F, 0xFFF65E3B, 0xFFEDCF72, 0xFFEDCC61, 0xFFEDC850,
            0xFFEDC53F, 0xFFEDC22E, 0xFF3C3A32, 0xFF3C3A32, 0xFF3C3A32
        };

        public GameView(Context ctx) {
            super(ctx);
            setFocusable(true);
            setFocusableInTouchMode(true);
            setClickable(true);
        }

        @Override
        protected void onDraw(Canvas c) {
            super.onDraw(c);
            int w = getWidth(), h = getHeight();
            float size = Math.min(w, h) * 0.95f;
            float cell = size / 4f;
            float ox = (w - size) / 2f;
            float oy = (h - size) / 2f;

            // Фон
            paint.setColor(0xFFBBADA0);
            c.drawRoundRect(ox, oy, ox+size, oy+size, 12, 12, paint);

            for (int r = 0; r < 4; r++) {
                for (int col = 0; col < 4; col++) {
                    float x = ox + col*cell + 5;
                    float y = oy + r*cell + 5;
                    float cs = cell - 10;
                    int val = board[r][col];
                    int idx = 0;
                    if (val > 0) idx = Math.min(14, (int)(Math.log(val)/Math.log(2)));
                    paint.setColor(tileColors[idx]);
                    c.drawRoundRect(x, y, x+cs, y+cs, 8, 8, paint);
                    if (val > 0) {
                        paint.setColor(idx < 3 ? 0xFF776E65 : 0xFFFFFFFF);
                        paint.setTextSize(cs * 0.4f);
                        paint.setTextAlign(Paint.Align.CENTER);
                        paint.setFakeBoldText(true);
                        c.drawText(String.valueOf(val), x+cs/2, y+cs/2 + cs*0.15f, paint);
                        paint.setFakeBoldText(false);
                        paint.setTextAlign(Paint.Align.LEFT);
                    }
                }
            }

            if (gameOver) {
                paint.setColor(0xBBFFFFFF);
                c.drawRoundRect(ox, oy, ox+size, oy+size, 12, 12, paint);
                paint.setColor(0xFF776E65);
                paint.setTextSize(size*0.12f);
                paint.setTextAlign(Paint.Align.CENTER);
                paint.setFakeBoldText(true);
                c.drawText("Game Over", ox+size/2, oy+size/2, paint);
                paint.setFakeBoldText(false);
                paint.setTextAlign(Paint.Align.LEFT);
            }
        }

        @Override
        public boolean onTouchEvent(MotionEvent e) {
            switch (e.getAction()) {
                case MotionEvent.ACTION_DOWN:
                    downX = e.getX();
                    downY = e.getY();
                    return true;
                case MotionEvent.ACTION_UP:
                    if (gameOver) return true;
                    float dx = e.getX() - downX;
                    float dy = e.getY() - downY;
                    if (Math.abs(dx) < SWIPE_MIN && Math.abs(dy) < SWIPE_MIN) return true;

                    saveState();
                    boolean moved = false;
                    if (Math.abs(dx) > Math.abs(dy)) {
                        moved = dx > 0 ? move(1) : move(0);
                    } else {
                        moved = dy > 0 ? move(3) : move(2);
                    }

                    if (moved) {
                        addRandomTile();
                        updateUI();
                        if (!canMove()) {
                            gameOver = true;
                            updateUI();
                            AppLogger.log(Game2048Activity.this, "Game2048", "Game over, score=" + score);
                        }
                        AppLogger.log(Game2048Activity.this, "Game2048", "Move, score=" + score);
                    }
                    return true;
            }
            return super.onTouchEvent(e);
        }
    }
}