package com.last04ka.messenger.ui;

import android.bluetooth.BluetoothAdapter;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.widget.Toast;
import com.last04ka.messenger.utils.AppLogger;
import com.last04ka.messenger.utils.ThemeManager;

public class NewChatActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        setTheme(ThemeManager.getThemeResource(this));
        super.onCreate(savedInstanceState);
        AppLogger.log(this, "NewChatActivity", "═══════════════════════════════════════════════════════════");
        AppLogger.log(this, "NewChatActivity", "🔵 NewChatActivity onCreate START");
        AppLogger.log(this, "NewChatActivity", "═══════════════════════════════════════════════════════════");
        AppLogger.logUI(this, "NewChatActivity", "Dialog layout", true);

        try {
            showChatOptionsDialog();
            AppLogger.log(this, "NewChatActivity", "Dialog shown successfully");
        } catch (Exception e) {
            AppLogger.logException(this, "NewChatActivity", e);
            AppLogger.log(this, "NewChatActivity", "CRASH showing dialog: " + e.toString());
            Toast.makeText(this, "Ошибка: " + e.getMessage(), Toast.LENGTH_LONG).show();
            finish();
        }
        AppLogger.log(this, "NewChatActivity", "═══════════════════════════════════════════════════════════");
    }

    private void showChatOptionsDialog() {
        AppLogger.log(this, "NewChatActivity", "showChatOptionsDialog() called");
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Выберите действие");

        String[] options = {
            "Подключение по WiFi Direct",
            "Подключение по Bluetooth",
            "Создать чат Bluetooth",
            "Создать чат WiFi Direct",
            "Создать групповой чат (WiFi Direct)",
            "Присоединиться к группе по коду"
        };

        builder.setItems(options, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                AppLogger.log(NewChatActivity.this, "NewChatActivity", "📝 Option selected: " + which + " (" + options[which] + ")");
                BluetoothAdapter bluetoothAdapter = BluetoothAdapter.getDefaultAdapter();

                try {
                    switch (which) {
                        case 0:
                            AppLogger.log(NewChatActivity.this, "NewChatActivity", "WiFi Direct — not implemented");
                            Toast.makeText(NewChatActivity.this, "WiFi Direct в разработке", Toast.LENGTH_SHORT).show();
                            finish();
                            break;
                        case 1:
                            AppLogger.log(NewChatActivity.this, "NewChatActivity", "Starting DeviceListActivity for Bluetooth connection");
                            if (bluetoothAdapter == null) {
                                AppLogger.log(NewChatActivity.this, "NewChatActivity", "ERROR: BluetoothAdapter is null!");
                                Toast.makeText(NewChatActivity.this, "Bluetooth не поддерживается", Toast.LENGTH_SHORT).show();
                                finish();
                                return;
                            }
                            if (!bluetoothAdapter.isEnabled()) {
                                AppLogger.log(NewChatActivity.this, "NewChatActivity", "Bluetooth is disabled");
                            }
                            AppLogger.log(NewChatActivity.this, "NewChatActivity", "Creating Intent for DeviceListActivity (client mode)...");
                            Intent intent = new Intent(NewChatActivity.this, DeviceListActivity.class);
                            intent.putExtra(DeviceListActivity.EXTRA_CHAT_TYPE, 1);
                            intent.putExtra(DeviceListActivity.EXTRA_IS_CREATE, false);
                            AppLogger.log(NewChatActivity.this, "NewChatActivity", "Starting DeviceListActivity...");
                            startActivity(intent);
                            AppLogger.log(NewChatActivity.this, "NewChatActivity", "DeviceListActivity started successfully");
                            finish();
                            break;
                        case 2:
                            AppLogger.log(NewChatActivity.this, "NewChatActivity", "Starting DeviceListActivity for Bluetooth server");
                            if (bluetoothAdapter == null) {
                                AppLogger.log(NewChatActivity.this, "NewChatActivity", "ERROR: BluetoothAdapter is null!");
                                Toast.makeText(NewChatActivity.this, "Bluetooth не поддерживается", Toast.LENGTH_SHORT).show();
                                finish();
                                return;
                            }
                            if (!bluetoothAdapter.isEnabled()) {
                                AppLogger.log(NewChatActivity.this, "NewChatActivity", "Bluetooth is disabled");
                            }
                            AppLogger.log(NewChatActivity.this, "NewChatActivity", "Creating Intent for DeviceListActivity (server mode)...");
                            Intent createIntent = new Intent(NewChatActivity.this, DeviceListActivity.class);
                            createIntent.putExtra(DeviceListActivity.EXTRA_CHAT_TYPE, 1);
                            createIntent.putExtra(DeviceListActivity.EXTRA_IS_CREATE, true);
                            AppLogger.log(NewChatActivity.this, "NewChatActivity", "Starting DeviceListActivity...");
                            startActivity(createIntent);
                            AppLogger.log(NewChatActivity.this, "NewChatActivity", "DeviceListActivity started successfully");
                            finish();
                            break;
                        case 3:
                            AppLogger.log(NewChatActivity.this, "NewChatActivity", "WiFi Direct server — not implemented");
                            Toast.makeText(NewChatActivity.this, "WiFi Direct в разработке", Toast.LENGTH_SHORT).show();
                            finish();
                            break;
                        case 4:
                            AppLogger.log(NewChatActivity.this, "NewChatActivity", "🚀 Create group chat");
                            Intent groupIntent = new Intent(NewChatActivity.this, GroupChatActivity.class);
                            AppLogger.log(NewChatActivity.this, "NewChatActivity", "Starting GroupChatActivity with Intent: " + groupIntent);
                            startActivity(groupIntent);
                            AppLogger.log(NewChatActivity.this, "NewChatActivity", "GroupChatActivity started");
                            finish();
                            break;
                        case 5:
                            AppLogger.log(NewChatActivity.this, "NewChatActivity", "🔑 Join group by code");
                            Intent joinIntent = new Intent(NewChatActivity.this, JoinGroupActivity.class);
                            AppLogger.log(NewChatActivity.this, "NewChatActivity", "Starting JoinGroupActivity with Intent: " + joinIntent);
                            startActivity(joinIntent);
                            AppLogger.log(NewChatActivity.this, "NewChatActivity", "JoinGroupActivity started");
                            finish();
                            break;
                        default:
                            AppLogger.log(NewChatActivity.this, "NewChatActivity", "Unknown option: " + which);
                            break;
                    }
                } catch (Exception e) {
                    AppLogger.logException(NewChatActivity.this, "NewChatActivity", e);
                    AppLogger.log(NewChatActivity.this, "NewChatActivity", "CRASH in option " + which + ": " + e.toString());
                    Toast.makeText(NewChatActivity.this, "Ошибка запуска: " + e.getMessage(), Toast.LENGTH_LONG).show();
                    finish();
                }
            }
        });

        builder.setOnCancelListener(new DialogInterface.OnCancelListener() {
            @Override
            public void onCancel(DialogInterface dialog) {
                AppLogger.log(NewChatActivity.this, "NewChatActivity", "Dialog cancelled");
                finish();
            }
        });

        builder.show();
        AppLogger.log(this, "NewChatActivity", "Dialog builder.show() called");
    }
}