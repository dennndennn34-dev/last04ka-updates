package com.last04ka.messenger.ui;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import com.last04ka.messenger.utils.AppLogger;
import com.last04ka.messenger.utils.GameScores;
import java.util.Random;

public class DiceGameActivity extends Activity {

    private TextView dice1Text, dice2Text, scoreText, resultText;
    private Button btnHigh, btnLow, btnNewGame;
    private int score = 0;
    private int streak = 0;
    private Random random = new Random();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        try {
            AppLogger.log(this, "DiceGame", "onCreate started");
            LinearLayout layout = new LinearLayout(this);
            layout.setOrientation(LinearLayout.VERTICAL);
            layout.setPadding(32, 32, 32, 32);
            layout.setBackgroundColor(0xFF303030);

            scoreText = new TextView(this);
            scoreText.setText("Счёт: 0 | Рекорд: " + GameScores.getScore(this, "dice"));
            scoreText.setTextSize(18);
            scoreText.setTextColor(0xFFFFFFFF);
            layout.addView(scoreText);

            resultText = new TextView(this);
            resultText.setText("Угадайте: сумма больше или меньше 7?");
            resultText.setTextSize(16);
            resultText.setTextColor(0xFFBDBDBD);
            resultText.setPadding(0, 16, 0, 16);
            layout.addView(resultText);

            dice1Text = new TextView(this);
            dice1Text.setText("🎲");
            dice1Text.setTextSize(60);
            dice1Text.setGravity(android.view.Gravity.CENTER);
            layout.addView(dice1Text);

            dice2Text = new TextView(this);
            dice2Text.setText("🎲");
            dice2Text.setTextSize(60);
            dice2Text.setGravity(android.view.Gravity.CENTER);
            layout.addView(dice2Text);

            LinearLayout buttonRow = new LinearLayout(this);
            buttonRow.setOrientation(LinearLayout.HORIZONTAL);

            btnHigh = new Button(this);
            btnHigh.setText("📈 Больше 7");
            btnHigh.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) { playGuess(true); }
            });
            buttonRow.addView(btnHigh);

            btnLow = new Button(this);
            btnLow.setText("📉 Меньше 7");
            btnLow.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) { playGuess(false); }
            });
            buttonRow.addView(btnLow);

            layout.addView(buttonRow);

            btnNewGame = new Button(this);
            btnNewGame.setText("Новая игра");
            btnNewGame.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    score = 0; streak = 0;
                    scoreText.setText("Счёт: 0 | Рекорд: " + GameScores.getScore(DiceGameActivity.this, "dice"));
                    resultText.setText("Угадайте: сумма больше или меньше 7?");
                    dice1Text.setText("🎲"); dice2Text.setText("🎲");
                    btnHigh.setEnabled(true); btnLow.setEnabled(true);
                }
            });
            layout.addView(btnNewGame);

            setContentView(layout);
            setTitle("🎲 Кости");
            AppLogger.log(this, "DiceGame", "onCreate completed");
        } catch (Exception e) {
            AppLogger.logException(this, "DiceGame", e);
            finish();
        }
    }

    private void playGuess(boolean guessHigh) {
        try {
            int d1 = random.nextInt(6) + 1;
            int d2 = random.nextInt(6) + 1;
            int total = d1 + d2;
            dice1Text.setText(getDiceEmoji(d1));
            dice2Text.setText(getDiceEmoji(d2));

            boolean isHigh = total > 7;
            boolean isEqual = total == 7;

            if (isEqual) {
                resultText.setText("Ровно 7! Ничья. Бонус +5!");
                score += 5;
            } else if (guessHigh == isHigh) {
                streak++;
                int points = 10 + streak * 2;
                score += points;
                resultText.setText("✅ Правильно! +" + points + " (серия: " + streak + ")");
            } else {
                streak = 0;
                score = Math.max(0, score - 5);
                resultText.setText("❌ Неправильно! Сумма: " + total + " (-5)");
            }

            scoreText.setText("Счёт: " + score + " | Рекорд: " + GameScores.getScore(this, "dice"));
            GameScores.saveScore(this, "dice", score);
        } catch (Exception e) {
            AppLogger.logException(this, "DiceGame", e);
        }
    }

    private String getDiceEmoji(int value) {
        String[] dice = {"", "⚀", "⚁", "⚂", "⚃", "⚄", "⚅"};
        return dice[value];
    }
}