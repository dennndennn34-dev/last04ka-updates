package com.last04ka.messenger.utils;

import android.content.Context;
import android.os.Environment;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;
import java.util.zip.ZipOutputStream;

public class BackupManager {

    private static final String BACKUP_DIR = "Last04ka/backups";

    public static void createBackup(Context ctx) {
        try {
            File dir = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), BACKUP_DIR);
            if (!dir.exists()) dir.mkdirs();
            String fileName = "last04ka_backup_" + System.currentTimeMillis() + ".zip";
            File zipFile = new File(dir, fileName);

            FileOutputStream fos = new FileOutputStream(zipFile);
            ZipOutputStream zos = new ZipOutputStream(fos);

            // Добавляем базу данных
            addFileToZip(zos, new File(ctx.getFilesDir().getParent(), "databases"), "databases");
            // Добавляем настройки
            addFileToZip(zos, new File(ctx.getFilesDir(), "last04ka_app_log.txt"), "log.txt");
            // Добавляем аватар
            addFileToZip(zos, new File(ctx.getFilesDir(), "avatar_"), "avatar");

            zos.close(); fos.close();
            AppLogger.log(ctx, "Backup", "Backup created: " + zipFile.getAbsolutePath() + " (" + zipFile.length()/1024 + " KB)");
        } catch (Exception e) {
            AppLogger.logException(ctx, "Backup", e);
        }
    }

    private static void addFileToZip(ZipOutputStream zos, File source, String entryName) throws Exception {
        if (!source.exists()) {
            if (!entryName.equals("avatar")) return;
            // Для аватара ищем файл по префиксу
            File[] files = source.getParentFile().listFiles((d, n) -> n.startsWith("avatar_"));
            if (files != null && files.length > 0) source = files[0];
            else return;
        }
        if (source.isDirectory()) {
            File[] files = source.listFiles();
            if (files == null) return;
            for (File f : files) {
                addFileToZip(zos, f, entryName + "/" + f.getName());
            }
        } else {
            ZipEntry entry = new ZipEntry(entryName);
            zos.putNextEntry(entry);
            FileInputStream fis = new FileInputStream(source);
            byte[] buffer = new byte[4096]; int len;
            while ((len = fis.read(buffer)) > 0) zos.write(buffer, 0, len);
            fis.close();
            zos.closeEntry();
        }
    }

    public static void restoreBackup(Context ctx) {
        try {
            File dir = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), BACKUP_DIR);
            if (!dir.exists()) { AppLogger.log(ctx, "Backup", "No backup directory"); return; }
            File[] files = dir.listFiles((d, n) -> n.endsWith(".zip"));
            if (files == null || files.length == 0) { AppLogger.log(ctx, "Backup", "No backup files"); return; }
            File latest = files[0];
            for (File f : files) if (f.lastModified() > latest.lastModified()) latest = f;

            ZipInputStream zis = new ZipInputStream(new FileInputStream(latest));
            ZipEntry entry;
            byte[] buffer = new byte[4096];
            while ((entry = zis.getNextEntry()) != null) {
                File outFile = new File(ctx.getFilesDir().getParent(), entry.getName());
                if (entry.isDirectory()) { outFile.mkdirs(); continue; }
                outFile.getParentFile().mkdirs();
                FileOutputStream fos = new FileOutputStream(outFile);
                int len;
                while ((len = zis.read(buffer)) > 0) fos.write(buffer, 0, len);
                fos.close();
                zis.closeEntry();
            }
            zis.close();
            AppLogger.log(ctx, "Backup", "Restored from: " + latest.getName());
        } catch (Exception e) {
            AppLogger.logException(ctx, "Backup", e);
        }
    }
}