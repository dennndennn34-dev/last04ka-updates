package com.last04ka.messenger.utils;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Build;
import android.support.v4.app.NotificationCompat;

import com.last04ka.messenger.R;
import com.last04ka.messenger.ui.MainActivity;

import java.io.File;

public class NotificationHelper {

    private static final String TAG = "NotificationHelper";

    // Каналы уведомлений
    public static final String CHANNEL_MESSAGES = "messages_channel";
    public static final String CHANNEL_FILES = "files_channel";
    public static final String CHANNEL_SYSTEM = "system_channel";
    public static final String CHANNEL_ALERTS = "alerts_channel";

    // ID уведомлений
    public static final int NOTIFICATION_ID_MESSAGE = 1000;
    public static final int NOTIFICATION_ID_FILE = 1001;
    public static final int NOTIFICATION_ID_SYSTEM = 1002;
    public static final int NOTIFICATION_ID_ALERT = 1003;

    private static NotificationManager notificationManager;

    public static void initChannels(Context context) {
        AppLogger.log(context, TAG, "🔔 initChannels() START");

        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) {
            AppLogger.log(context, TAG, "   Android < 8, channels not needed");
            return;
        }

        notificationManager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        if (notificationManager == null) {
            AppLogger.log(context, TAG, "❌ NotificationManager is null");
            return;
        }

        // Канал для сообщений
        NotificationChannel msgChannel = new NotificationChannel(
                CHANNEL_MESSAGES,
                "Новые сообщения",
                NotificationManager.IMPORTANCE_HIGH
        );
        msgChannel.setDescription("Уведомления о новых сообщениях в чатах");
        msgChannel.setShowBadge(true);
        msgChannel.enableLights(true);
        msgChannel.enableVibration(true);
        msgChannel.setLightColor(0xFF4FC3F7);
        notificationManager.createNotificationChannel(msgChannel);
        AppLogger.log(context, TAG, "✅ Messages channel created");

        // Канал для файлов
        NotificationChannel fileChannel = new NotificationChannel(
                CHANNEL_FILES,
                "Передача файлов",
                NotificationManager.IMPORTANCE_LOW
        );
        fileChannel.setDescription("Уведомления о передаче файлов");
        notificationManager.createNotificationChannel(fileChannel);
        AppLogger.log(context, TAG, "✅ Files channel created");

        // Системный канал
        NotificationChannel sysChannel = new NotificationChannel(
                CHANNEL_SYSTEM,
                "Системные уведомления",
                NotificationManager.IMPORTANCE_DEFAULT
        );
        sysChannel.setDescription("Системные уведомления приложения");
        notificationManager.createNotificationChannel(sysChannel);
        AppLogger.log(context, TAG, "✅ System channel created");

        // Канал для оповещений
        NotificationChannel alertChannel = new NotificationChannel(
                CHANNEL_ALERTS,
                "Оповещения",
                NotificationManager.IMPORTANCE_HIGH
        );
        alertChannel.setDescription("Важные оповещения");
        alertChannel.enableLights(true);
        alertChannel.enableVibration(true);
        alertChannel.setLightColor(0xFFFF5252);
        notificationManager.createNotificationChannel(alertChannel);
        AppLogger.log(context, TAG, "✅ Alerts channel created");

        AppLogger.log(context, TAG, "🔔 initChannels() END");
    }

    // ==================== СООБЩЕНИЯ ====================

    public static void showMessageNotification(Context context, String chatName, String sender, String message) {
        AppLogger.log(context, TAG, "🔔 showMessageNotification() START");
        AppLogger.log(context, TAG, "   chatName: " + chatName);
        AppLogger.log(context, TAG, "   sender: " + sender);
        AppLogger.log(context, TAG, "   message: " + (message != null ? message.substring(0, Math.min(50, message.length())) : "null"));

        Intent intent = new Intent(context, MainActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);

        int flags = PendingIntent.FLAG_UPDATE_CURRENT;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            flags |= PendingIntent.FLAG_IMMUTABLE;
        }
        PendingIntent pendingIntent = PendingIntent.getActivity(context, 0, intent, flags);

        NotificationCompat.Builder builder = new NotificationCompat.Builder(context, CHANNEL_MESSAGES)
                .setSmallIcon(R.drawable.ic_launcher)
                .setContentTitle("💬 Новое сообщение от " + sender)
                .setContentText(chatName + ": " + message)
                .setStyle(new NotificationCompat.BigTextStyle().bigText(message))
                .setContentIntent(pendingIntent)
                .setAutoCancel(true)
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setDefaults(NotificationCompat.DEFAULT_ALL)
                .setWhen(System.currentTimeMillis());

        // Добавляем аватарку если есть
        try {
            String avatarPath = context.getSharedPreferences("profile", Context.MODE_PRIVATE)
                    .getString("avatar", null);
            if (avatarPath != null) {
                File avatarFile = new File(avatarPath);
                if (avatarFile.exists()) {
                    Bitmap avatar = BitmapFactory.decodeFile(avatarPath);
                    if (avatar != null) {
                        builder.setLargeIcon(avatar);
                    }
                }
            }
        } catch (Exception e) {
            AppLogger.logException(context, TAG, "   Avatar loading error", e);
        }

        if (notificationManager == null) {
            notificationManager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        }

        if (notificationManager != null) {
            notificationManager.notify(NOTIFICATION_ID_MESSAGE, builder.build());
            AppLogger.log(context, TAG, "✅ Notification shown (ID: " + NOTIFICATION_ID_MESSAGE + ")");
        } else {
            AppLogger.log(context, TAG, "❌ NotificationManager is null");
        }

        AppLogger.log(context, TAG, "🔔 showMessageNotification() END");
    }

    // ==================== ФАЙЛЫ ====================

    public static void showFileProgressNotification(Context context, String fileName, int progress) {
        AppLogger.log(context, TAG, "📊 showFileProgressNotification() START");
        AppLogger.log(context, TAG, "   fileName: " + fileName);
        AppLogger.log(context, TAG, "   progress: " + progress + "%");

        Intent intent = new Intent(context, MainActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);

        int flags = PendingIntent.FLAG_UPDATE_CURRENT;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            flags |= PendingIntent.FLAG_IMMUTABLE;
        }
        PendingIntent pendingIntent = PendingIntent.getActivity(context, 1, intent, flags);

        NotificationCompat.Builder builder = new NotificationCompat.Builder(context, CHANNEL_FILES)
                .setSmallIcon(R.drawable.ic_launcher)
                .setContentTitle("📤 Передача файла")
                .setContentText(fileName + " - " + progress + "%")
                .setProgress(100, progress, progress < 0)
                .setContentIntent(pendingIntent)
                .setOngoing(true)
                .setPriority(NotificationCompat.PRIORITY_LOW);

        if (notificationManager == null) {
            notificationManager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        }

        if (notificationManager != null) {
            notificationManager.notify(NOTIFICATION_ID_FILE, builder.build());
            AppLogger.log(context, TAG, "✅ Progress notification updated");
        }

        AppLogger.log(context, TAG, "📊 showFileProgressNotification() END");
    }

    public static void showFileCompleteNotification(Context context, String fileName, String filePath) {
        AppLogger.log(context, TAG, "✅ showFileCompleteNotification() START");
        AppLogger.log(context, TAG, "   fileName: " + fileName);
        AppLogger.log(context, TAG, "   filePath: " + filePath);

        // Открываем папку с файлом
        Intent intent = new Intent(Intent.ACTION_VIEW);
        intent.setDataAndType(android.net.Uri.parse("file://" + filePath), "file/*");
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);

        int flags = PendingIntent.FLAG_UPDATE_CURRENT;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            flags |= PendingIntent.FLAG_IMMUTABLE;
        }
        PendingIntent pendingIntent = PendingIntent.getActivity(context, 2, intent, flags);

        NotificationCompat.Builder builder = new NotificationCompat.Builder(context, CHANNEL_FILES)
                .setSmallIcon(R.drawable.ic_launcher)
                .setContentTitle("✅ Файл получен")
                .setContentText(fileName + " (нажмите, чтобы открыть)")
                .setContentIntent(pendingIntent)
                .setAutoCancel(true)
                .setPriority(NotificationCompat.PRIORITY_DEFAULT)
                .setDefaults(NotificationCompat.DEFAULT_VIBRATE);

        if (notificationManager == null) {
            notificationManager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        }

        if (notificationManager != null) {
            notificationManager.notify(NOTIFICATION_ID_FILE + 1, builder.build());
            AppLogger.log(context, TAG, "✅ Completion notification shown");
        }

        AppLogger.log(context, TAG, "✅ showFileCompleteNotification() END");
    }

    // ==================== СИСТЕМНЫЕ ====================

    public static void showSystemNotification(Context context, String title, String message) {
        AppLogger.log(context, TAG, "🔔 showSystemNotification() START");
        AppLogger.log(context, TAG, "   title: " + title);
        AppLogger.log(context, TAG, "   message: " + message);

        Intent intent = new Intent(context, MainActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);

        int flags = PendingIntent.FLAG_UPDATE_CURRENT;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            flags |= PendingIntent.FLAG_IMMUTABLE;
        }
        PendingIntent pendingIntent = PendingIntent.getActivity(context, 3, intent, flags);

        NotificationCompat.Builder builder = new NotificationCompat.Builder(context, CHANNEL_SYSTEM)
                .setSmallIcon(R.drawable.ic_launcher)
                .setContentTitle(title)
                .setContentText(message)
                .setContentIntent(pendingIntent)
                .setAutoCancel(true)
                .setPriority(NotificationCompat.PRIORITY_DEFAULT);

        if (notificationManager == null) {
            notificationManager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        }

        if (notificationManager != null) {
            notificationManager.notify(NOTIFICATION_ID_SYSTEM, builder.build());
            AppLogger.log(context, TAG, "✅ System notification shown");
        }

        AppLogger.log(context, TAG, "🔔 showSystemNotification() END");
    }

    // ==================== ВСПОМОГАТЕЛЬНЫЕ ====================

    public static void cancelNotification(Context context, int id) {
        AppLogger.log(context, TAG, "🔕 cancelNotification() ID: " + id);

        if (notificationManager == null) {
            notificationManager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        }

        if (notificationManager != null) {
            notificationManager.cancel(id);
            AppLogger.log(context, TAG, "✅ Notification cancelled");
        }
    }

    public static void cancelAllNotifications(Context context) {
        AppLogger.log(context, TAG, "🔕 cancelAllNotifications()");

        if (notificationManager == null) {
            notificationManager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        }

        if (notificationManager != null) {
            notificationManager.cancelAll();
            AppLogger.log(context, TAG, "✅ All notifications cancelled");
        }
    }
}