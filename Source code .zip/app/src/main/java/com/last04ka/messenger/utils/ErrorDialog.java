package com.last04ka.messenger.utils;

import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Build;
import android.text.method.ScrollingMovementMethod;
import android.widget.TextView;
import android.widget.Toast;
import com.last04ka.messenger.ui.WebViewActivity;
import java.io.PrintWriter;
import java.io.StringWriter;

public class ErrorDialog {

    public static void show(Context context, String title, String message, Throwable throwable) {
        StringBuilder fullLog = new StringBuilder();
        
        fullLog.append("=== ERROR LOG ===\n");
        fullLog.append("Time: ").append(new java.util.Date().toString()).append("\n");
        fullLog.append("App: Last04ka v1.0\n");
        fullLog.append("Android SDK: ").append(Build.VERSION.SDK_INT).append("\n");
        fullLog.append("Device: ").append(Build.MANUFACTURER).append(" ").append(Build.MODEL).append("\n");
        fullLog.append("\n=== TITLE ===\n");
        fullLog.append(title).append("\n");
        fullLog.append("\n=== MESSAGE ===\n");
        fullLog.append(message).append("\n");
        
        if (throwable != null) {
            fullLog.append("\n=== EXCEPTION ===\n");
            fullLog.append(throwable.toString()).append("\n");
            fullLog.append("\n=== STACK TRACE ===\n");
            StringWriter sw = new StringWriter();
            PrintWriter pw = new PrintWriter(sw);
            throwable.printStackTrace(pw);
            fullLog.append(sw.toString());
        }
        
        final String logText = fullLog.toString();
        
        TextView textView = new TextView(context);
        textView.setText(logText);
        textView.setTextSize(12);
        textView.setPadding(32, 32, 32, 32);
        textView.setVerticalScrollBarEnabled(true);
        textView.setMovementMethod(new ScrollingMovementMethod());
        textView.setMaxHeight(800);
        
        AlertDialog.Builder builder = new AlertDialog.Builder(context);
        builder.setTitle("Ошибка");
        builder.setView(textView);
        
        builder.setPositiveButton("Скопировать", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                ClipboardManager clipboard = (ClipboardManager) context.getSystemService(Context.CLIPBOARD_SERVICE);
                ClipData clip = ClipData.newPlainText("error_log", logText);
                clipboard.setPrimaryClip(clip);
                Toast.makeText(context, "Лог скопирован. Отправьте его разработчику.", Toast.LENGTH_LONG).show();
            }
        });
        
        builder.setNegativeButton("OK", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
            }
        });
        
        builder.setNeutralButton("Спросить у ИИ", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                Intent intent = new Intent(context, WebViewActivity.class);
                intent.putExtra("error_log", logText);
                intent.putExtra("error_title", title);
                context.startActivity(intent);
            }
        });
        
        builder.setCancelable(false);
        builder.show();
    }
    
    public static void show(Context context, String title, String message) {
        show(context, title, message, null);
    }
}