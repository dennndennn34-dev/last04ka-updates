package com.last04ka.messenger.ui;

import android.Manifest;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.GradientDrawable;
import android.media.MediaPlayer;
import android.media.MediaRecorder;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.provider.MediaStore;
import android.speech.RecognizerIntent;
import android.support.annotation.NonNull;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v4.content.FileProvider;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.util.Base64;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.animation.AccelerateDecelerateInterpolator;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.last04ka.messenger.R;
import com.last04ka.messenger.adapters.MessageAdapter;
import com.last04ka.messenger.connectivity.BluetoothManager;
import com.last04ka.messenger.data.DatabaseHelper;
import com.last04ka.messenger.data.Message;
import com.last04ka.messenger.utils.AppLogger;
import com.last04ka.messenger.utils.EncryptionManager;
import com.last04ka.messenger.utils.ErrorDialog;
import com.last04ka.messenger.utils.FileTransferManager;
import com.last04ka.messenger.utils.NotificationHelper;
import com.last04ka.messenger.utils.ThemeManager;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.security.KeyPair;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.UUID;

import javax.crypto.SecretKey;

public class BluetoothChatActivity extends AppCompatActivity {
    private static final String TAG = "BluetoothChat";
    private static final int REQUEST_VOICE_INPUT = 102;
    private static final int REQUEST_RECORD_AUDIO = 103;
    private static final int REQUEST_PICK_FILE = 200;

    private RecyclerView recyclerView;
    private EditText inputMessage;
    private ImageButton sendButton, callButton, voiceButton;
    private MessageAdapter adapter;
    private DatabaseHelper dbHelper;
    private List<Message> messages = new ArrayList<>();
    private String chatId, deviceAddress, deviceName;
    private boolean isServer;
    private BluetoothManager bluetoothManager;
    private Handler handler = new Handler(Looper.getMainLooper());
    private boolean isConnected = false;
    private boolean isFinishing = false;

    private Runnable typingStopRunnable;
    private boolean isTyping = false;

    private MediaRecorder mediaRecorder;
    private String voiceFilePath;
    private boolean isRecording = false;
    private MediaPlayer mediaPlayer;

    private boolean encryptionEnabled = true;
    private SecretKey aesKey = null;
    private String myPublicKeyBase64 = null;
    private String myPrivateKeyBase64 = null;
    private boolean keysExchanged = false;

    private ProgressBar fileProgressBar;
    private TextView fileProgressText;
    private String currentFileName = "";

    private boolean isTestMode = false;
    private List<String> testMessages = new ArrayList<>();

    private TextView statusOnline;

    private static BluetoothManager staticBluetoothManager;
    private static CallActivity activeCallActivity;
    private static TicTacToePvPActivity activeTicTacToeActivity;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        setTheme(ThemeManager.getThemeResource(this));
        super.onCreate(savedInstanceState);
        AppLogger.log(this, TAG, "═══════════════════════════════════════════════════════════");
        AppLogger.log(this, TAG, "💬 BluetoothChatActivity onCreate START");
        AppLogger.log(this, TAG, "═══════════════════════════════════════════════════════════");

        try {
            setContentView(R.layout.activity_chat);
            AppLogger.log(this, TAG, "✅ Content view set");

            dbHelper = new DatabaseHelper(this);
            AppLogger.log(this, TAG, "✅ DatabaseHelper created");

            NotificationHelper.initChannels(this);
            AppLogger.log(this, TAG, "✅ Notification channels initialized");

            chatId = getIntent().getStringExtra("CHAT_ID");
            deviceAddress = getIntent().getStringExtra("DEVICE_ADDRESS");
            deviceName = getIntent().getStringExtra("CHAT_NAME");
            isServer = getIntent().getBooleanExtra("IS_SERVER", false);
            isTestMode = getIntent().getBooleanExtra("TEST_MODE", false);

            AppLogger.log(this, TAG, "📋 Intent: chatId=" + chatId + ", deviceAddress=" + deviceAddress + 
                    ", deviceName=" + deviceName + ", isServer=" + isServer + ", isTestMode=" + isTestMode);

            if (isTestMode) {
                setTitle("🧪 Тестовый сервер (эмуляция)");
                Toast.makeText(this, "🧪 Тестовый режим: сообщения не отправляются по Bluetooth", Toast.LENGTH_LONG).show();
                isConnected = true;
                addMessageToChat("🧪 Тестовый сервер запущен", false);
                addMessageToChat("💡 Отправляйте сообщения для тестирования", false);
                addMessageToChat("📎 Файлы сохраняются локально", false);
                AppLogger.log(this, TAG, "🧪 TEST MODE activated");
            }

            if (deviceName == null || deviceName.isEmpty()) {
                deviceName = getIntent().getStringExtra("DEVICE_NAME");
                if (deviceName == null) deviceName = "Bluetooth чат";
                AppLogger.log(this, TAG, "📋 deviceName fallback: " + deviceName);
            }
            setTitle(deviceName);
            AppLogger.log(this, TAG, "📱 Title set to: " + deviceName);

            // ==================== ИНИЦИАЛИЗАЦИЯ ВСЕХ КНОПОК ====================
            recyclerView = findViewById(R.id.recycler_messages);
            inputMessage = findViewById(R.id.input_message);
            sendButton = findViewById(R.id.btn_send);
            callButton = findViewById(R.id.btn_call);
            voiceButton = findViewById(R.id.btn_voice);
            statusOnline = findViewById(R.id.tv_online_status);

            // ==================== ПРИНУДИТЕЛЬНО ПОКАЗЫВАЕМ ВСЕ КНОПКИ ====================
            // Кнопки ВСЕГДА видимы, независимо от режима
            if (voiceButton != null) {
                voiceButton.setVisibility(View.VISIBLE);
                AppLogger.log(this, TAG, "✅ voiceButton set VISIBLE");
            } else {
                AppLogger.log(this, TAG, "❌ voiceButton is NULL!");
            }

            if (callButton != null) {
                callButton.setVisibility(View.VISIBLE);
                AppLogger.log(this, TAG, "✅ callButton set VISIBLE");
            } else {
                AppLogger.log(this, TAG, "❌ callButton is NULL!");
            }

            if (sendButton != null) {
                sendButton.setVisibility(View.VISIBLE);
                AppLogger.log(this, TAG, "✅ sendButton set VISIBLE");
            } else {
                AppLogger.log(this, TAG, "❌ sendButton is NULL!");
            }

            // ==================== СТАТУС ОНЛАЙН ====================
            if (statusOnline != null) {
                statusOnline.setText("🟢 Онлайн");
                statusOnline.setTextColor(0xFF4CAF50);
                animateOnlineStatus();
                AppLogger.log(this, TAG, "✅ Online status shown");
            }

            // ==================== ОБРАБОТЧИКИ КНОПОК ====================

            if (voiceButton != null) {
                voiceButton.setOnClickListener(v -> {
                    AppLogger.log(BluetoothChatActivity.this, TAG, "🎤🎤🎤 VOICE BUTTON CLICKED!");
                    startVoiceInput();
                });
                AppLogger.log(this, TAG, "✅ Voice button listener set");
            }

            if (sendButton != null) {
                sendButton.setOnClickListener(v -> {
                    AppLogger.log(BluetoothChatActivity.this, TAG, "📤📤📤 SEND BUTTON CLICKED!");
                    String text = inputMessage.getText().toString().trim();
                    AppLogger.log(BluetoothChatActivity.this, TAG, "📝 Text: '" + text + "', length=" + text.length() + ", isConnected=" + isConnected);
                    if (!TextUtils.isEmpty(text) && (isConnected || isTestMode)) {
                        if (isTyping) {
                            isTyping = false;
                            sendJsonCommand("typing", "stop");
                        }
                        sendEncryptedMessage(text);
                        inputMessage.setText("");
                        AppLogger.log(BluetoothChatActivity.this, TAG, "✅ Message sent");
                    } else {
                        AppLogger.log(BluetoothChatActivity.this, TAG, "⚠️ Cannot send: empty=" + TextUtils.isEmpty(text) + ", connected=" + isConnected + ", testMode=" + isTestMode);
                        Toast.makeText(BluetoothChatActivity.this, isTestMode ? "Тестовый режим активен" : "Нет подключения или пустое сообщение", Toast.LENGTH_SHORT).show();
                    }
                });
                AppLogger.log(this, TAG, "✅ Send button listener set");
            }

            if (callButton != null) {
                callButton.setOnClickListener(v -> {
                    AppLogger.log(BluetoothChatActivity.this, TAG, "📞📞📞 CALL BUTTON CLICKED! isConnected=" + isConnected);
                    if (!isConnected && !isTestMode) {
                        Toast.makeText(BluetoothChatActivity.this, "Нет подключения", Toast.LENGTH_SHORT).show();
                        return;
                    }
                    if (isTestMode) {
                        Toast.makeText(BluetoothChatActivity.this, "Тестовый режим: звонки недоступны", Toast.LENGTH_SHORT).show();
                        return;
                    }
                    makeCall();
                });
                AppLogger.log(this, TAG, "✅ Call button listener set");
            }

            // ==================== РЕСАЙКЛЕР ====================
            recyclerView.setLayoutManager(new LinearLayoutManager(this));
            adapter = new MessageAdapter(messages,
                    message -> {
                        AppLogger.log(BluetoothChatActivity.this, TAG, "📋📋📋 Message long click: " + message.getId());
                        ClipboardManager clipboard = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
                        ClipData clip = ClipData.newPlainText("message", message.getText());
                        clipboard.setPrimaryClip(clip);
                        Toast.makeText(BluetoothChatActivity.this, "Скопировано", Toast.LENGTH_SHORT).show();
                    },
                    message -> {
                        AppLogger.log(BluetoothChatActivity.this, TAG, "📋📋📋 Message click: " + message.getId());
                        String fullDate = new SimpleDateFormat("dd.MM.yyyy HH:mm:ss", Locale.getDefault())
                                .format(new Date(message.getTimestamp()));
                        new AlertDialog.Builder(BluetoothChatActivity.this)
                                .setTitle("Дата сообщения")
                                .setMessage(fullDate)
                                .setPositiveButton("OK", null)
                                .show();
                    }
            );
            adapter.setChatId(chatId);
            recyclerView.setAdapter(adapter);
            AppLogger.log(this, TAG, "✅ RecyclerView configured");

            applyThemeColors();

            if (chatId != null) {
                List<Message> saved = dbHelper.getMessagesForChat(chatId);
                messages.addAll(saved);
                adapter.notifyDataSetChanged();
                AppLogger.log(this, TAG, "📂 Loaded " + saved.size() + " saved messages");
                if (!messages.isEmpty()) {
                    recyclerView.scrollToPosition(messages.size() - 1);
                }
                dbHelper.resetUnreadCount(chatId);
                AppLogger.log(this, TAG, "📊 Unread count reset");
            }

            bluetoothManager = new BluetoothManager(this, handler);
            staticBluetoothManager = bluetoothManager;
            AppLogger.log(this, TAG, "✅ BluetoothManager created");

            bluetoothManager.setCallback(new BluetoothManager.MessageCallback() {
                @Override
                public void onMessageReceived(String rawMessage) {
                    if (isFinishing || rawMessage == null || rawMessage.isEmpty()) {
                        AppLogger.log(BluetoothChatActivity.this, TAG, "⚠️ onMessageReceived skipped");
                        return;
                    }
                    AppLogger.log(BluetoothChatActivity.this, TAG, "📨📨📨 onMessageReceived: " + (rawMessage.length() > 100 ? rawMessage.substring(0, 100) + "..." : rawMessage));

                    try {
                        JSONObject json = new JSONObject(rawMessage);
                        String type = json.getString("type");
                        String payload = json.getString("payload");
                        AppLogger.log(BluetoothChatActivity.this, TAG, "📨 JSON parsed: type=" + type);
                        handleJsonCommand(type, payload);
                        return;
                    } catch (JSONException e) {
                        AppLogger.log(BluetoothChatActivity.this, TAG, "📨 Not JSON, trying legacy");
                        handleLegacyMessage(rawMessage);
                    }
                }

                @Override
                public void onConnectionStateChanged(int state) {
                    if (isFinishing) return;
                    AppLogger.log(BluetoothChatActivity.this, TAG, "🔌🔌🔌 Connection state changed: " + state);
                    runOnUiThread(() -> {
                        isConnected = (state == BluetoothManager.STATE_CONNECTED);
                        AppLogger.log(BluetoothChatActivity.this, TAG, "🔌 isConnected=" + isConnected);
                        if (isConnected) {
                            String title = getTitle().toString().replace(" (сервер)", "").replace(" (клиент)", "");
                            setTitle(title + " ✓");
                            Toast.makeText(BluetoothChatActivity.this, "Подключено к " + deviceName, Toast.LENGTH_SHORT).show();
                            AppLogger.log(BluetoothChatActivity.this, TAG, "✅ Connected to " + deviceName);
                            if (chatId != null && !chatId.isEmpty()) {
                                initEncryption();
                            }
                            if (!keysExchanged && myPublicKeyBase64 != null) {
                                sendMyPublicKey();
                            }
                        } else {
                            String title = getTitle().toString().replace(" ✓", "").replace(" (печатает...)", "");
                            setTitle(title);
                            AppLogger.log(BluetoothChatActivity.this, TAG, "⚠️ Disconnected");
                            Toast.makeText(BluetoothChatActivity.this, "Соединение потеряно", Toast.LENGTH_SHORT).show();
                        }
                    });
                }

                @Override
                public void onDeviceDisconnected() {
                    if (isFinishing) return;
                    AppLogger.log(BluetoothChatActivity.this, TAG, "🔌🔌🔌 Device disconnected");
                    runOnUiThread(() -> {
                        isConnected = false;
                        Toast.makeText(BluetoothChatActivity.this, "Устройство отключено", Toast.LENGTH_LONG).show();
                    });
                }
            });

            if (inputMessage != null) {
                inputMessage.addTextChangedListener(new TextWatcher() {
                    @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
                    @Override public void onTextChanged(CharSequence s, int start, int before, int count) {
                        if ((isConnected || isTestMode) && !isFinishing) {
                            if (s.length() > 0 && !isTyping) {
                                isTyping = true;
                                AppLogger.log(BluetoothChatActivity.this, TAG, "✍️ User started typing");
                                sendJsonCommand("typing", "start");
                            }
                            if (typingStopRunnable != null) handler.removeCallbacks(typingStopRunnable);
                            typingStopRunnable = () -> {
                                if (isTyping) {
                                    isTyping = false;
                                    AppLogger.log(BluetoothChatActivity.this, TAG, "✍️ User stopped typing (timeout)");
                                    sendJsonCommand("typing", "stop");
                                }
                            };
                            handler.postDelayed(typingStopRunnable, 2000);
                        }
                    }
                    @Override public void afterTextChanged(Editable s) {}
                });
                AppLogger.log(this, TAG, "✅ TextWatcher added");
            }

            if (isServer && !isTestMode) {
                setTitle(getTitle() + " (сервер)");
                bluetoothManager.start();
                AppLogger.log(this, TAG, "🖥️ Started as SERVER");
                Toast.makeText(this, "Ожидание подключения...", Toast.LENGTH_SHORT).show();
            } else if (!isTestMode) {
                setTitle(getTitle() + " (клиент)");
                if (deviceAddress != null && !deviceAddress.isEmpty()) {
                    try {
                        BluetoothDevice device = BluetoothAdapter.getDefaultAdapter().getRemoteDevice(deviceAddress);
                        bluetoothManager.connect(device);
                        AppLogger.log(this, TAG, "📱 Started as CLIENT, connecting to: " + deviceAddress);
                        Toast.makeText(this, "Подключение к " + deviceName + "...", Toast.LENGTH_SHORT).show();
                    } catch (Exception e) {
                        AppLogger.logException(this, TAG, "❌ Failed to get remote device", e);
                        Toast.makeText(this, "Ошибка подключения к устройству", Toast.LENGTH_LONG).show();
                        finish();
                    }
                } else {
                    AppLogger.log(this, TAG, "❌ ERROR: deviceAddress is null or empty");
                    Toast.makeText(this, "Ошибка: адрес устройства не указан", Toast.LENGTH_LONG).show();
                    finish();
                }
            }

            if (chatId != null && !chatId.isEmpty() && !isTestMode) {
                initEncryption();
            } else {
                AppLogger.log(this, TAG, "⚠️ chatId is null or test mode, encryption skipped");
            }

            AppLogger.log(this, TAG, "✅ BluetoothChatActivity onCreate completed");
            AppLogger.log(this, TAG, "═══════════════════════════════════════════════════════════");

        } catch (Exception e) {
            AppLogger.logException(this, TAG, "❌❌❌ FATAL: onCreate error", e);
            ErrorDialog.show(this, "Ошибка инициализации", e.getMessage(), e);
            finish();
        }
    }

    // ==================== СТАТУС ОНЛАЙН ====================
    private void animateOnlineStatus() {
        AppLogger.log(this, TAG, "🟢 animateOnlineStatus() START");
        if (statusOnline == null) return;
        android.animation.ObjectAnimator pulseAnim = android.animation.ObjectAnimator.ofFloat(statusOnline, "alpha", 0.5f, 1f);
        pulseAnim.setDuration(800);
        pulseAnim.setRepeatCount(android.animation.ObjectAnimator.INFINITE);
        pulseAnim.setRepeatMode(android.animation.ObjectAnimator.REVERSE);
        pulseAnim.setInterpolator(new AccelerateDecelerateInterpolator());
        pulseAnim.start();
        AppLogger.log(this, TAG, "✅ Online status animation started");
    }

    private void setOnlineStatus(boolean online) {
        AppLogger.log(this, TAG, "🟢 setOnlineStatus: " + online);
        if (statusOnline != null) {
            if (online) {
                statusOnline.setText("🟢 Онлайн");
                statusOnline.setTextColor(0xFF4CAF50);
            } else {
                statusOnline.setText("⚪ Офлайн");
                statusOnline.setTextColor(0xFF9E9E9E);
            }
        }
    }

    // ==================== КНОПКА ГОЛОСОВОГО ВВОДА ====================
    private void startVoiceInput() {
        AppLogger.log(this, TAG, "🎤🎤🎤 startVoiceInput() called");
        Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault());
        intent.putExtra(RecognizerIntent.EXTRA_PROMPT, "Говорите...");
        try {
            AppLogger.log(this, TAG, "🎤 Starting voice recognition intent");
            startActivityForResult(intent, REQUEST_VOICE_INPUT);
            AppLogger.log(this, TAG, "✅ Voice recognition started");
        } catch (Exception e) {
            AppLogger.logException(this, TAG, "🎤 Failed to start voice recognition", e);
            Toast.makeText(this, "Голосовой ввод не поддерживается", Toast.LENGTH_SHORT).show();
        }
    }

    // ==================== МЕНЮ ====================

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        AppLogger.log(this, TAG, "📋 onCreateOptionsMenu called");
        getMenuInflater().inflate(R.menu.chat_menu, menu);
        AppLogger.log(this, TAG, "✅ Menu inflated");
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        AppLogger.log(this, TAG, "📋📋📋 Menu item selected: id=" + id + ", title=" + item.getTitle());

        if (id == R.id.menu_search) {
            AppLogger.log(this, TAG, "🔍🔍🔍 SEARCH menu clicked");
            Intent intent = new Intent(this, SearchMessagesActivity.class);
            intent.putExtra("CHAT_ID", chatId);
            startActivity(intent);
            AppLogger.log(this, TAG, "✅ Search activity started");
            return true;
        } else if (id == R.id.menu_export) {
            AppLogger.log(this, TAG, "📤📤📤 EXPORT menu clicked");
            exportChat();
            return true;
        } else if (id == R.id.menu_rename) {
            AppLogger.log(this, TAG, "✏️✏️✏️ RENAME menu clicked");
            showRenameDialog();
            return true;
        } else if (id == R.id.menu_delete_all) {
            AppLogger.log(this, TAG, "🗑️🗑️🗑️ DELETE FOR ALL menu clicked");
            showDeleteAllDialog();
            return true;
        }

        AppLogger.log(this, TAG, "⚠️ Unknown menu item: " + id);
        return super.onOptionsItemSelected(item);
    }

    // ==================== ДИАЛОГИ ====================

    private void showRenameDialog() {
        AppLogger.log(this, TAG, "✏️✏️✏️ showRenameDialog() called");
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Переименовать собеседника");
        final EditText input = new EditText(this);
        input.setText(deviceName);
        input.setHint("Введите новое имя");
        builder.setView(input);

        builder.setPositiveButton("Сохранить", (dialog, which) -> {
            String newName = input.getText().toString().trim();
            AppLogger.log(BluetoothChatActivity.this, TAG, "✏️ New name entered: '" + newName + "'");
            if (!newName.isEmpty()) {
                deviceName = newName;
                setTitle(newName);
                dbHelper.updateChatName(chatId, newName);
                AppLogger.log(BluetoothChatActivity.this, TAG, "✅ Name updated in DB to: " + newName);
                if (isConnected || isTestMode) {
                    sendJsonCommand("rename", newName);
                    AppLogger.log(BluetoothChatActivity.this, TAG, "📤 Rename command sent");
                }
                Toast.makeText(BluetoothChatActivity.this, "Имя обновлено на: " + newName, Toast.LENGTH_SHORT).show();
            } else {
                AppLogger.log(BluetoothChatActivity.this, TAG, "⚠️ Empty name, cancelled");
            }
        });
        builder.setNegativeButton("Отмена", (dialog, which) -> {
            AppLogger.log(BluetoothChatActivity.this, TAG, "✏️ Rename cancelled by user");
        });
        builder.show();
        AppLogger.log(this, TAG, "✏️ Rename dialog shown");
    }

    private void showDeleteAllDialog() {
        AppLogger.log(this, TAG, "🗑️🗑️🗑️ showDeleteAllDialog() called");
        final List<Message> ownMessages = new ArrayList<>();
        for (Message m : messages) {
            if (m.isSent()) ownMessages.add(m);
        }
        AppLogger.log(this, TAG, "🗑️ Found " + ownMessages.size() + " own messages");
        if (ownMessages.isEmpty()) {
            AppLogger.log(this, TAG, "⚠️ No own messages to delete");
            Toast.makeText(this, "Нет своих сообщений для удаления", Toast.LENGTH_SHORT).show();
            return;
        }

        String[] items = new String[ownMessages.size()];
        for (int i = 0; i < ownMessages.size(); i++) {
            String text = ownMessages.get(i).isVoice() ? "[Голосовое " + formatDuration(ownMessages.get(i).getDuration()) + "]" : ownMessages.get(i).getText();
            if (ownMessages.get(i).hasFile()) {
                text = "📎 " + ownMessages.get(i).getFileName();
            }
            items[i] = text;
        }

        new AlertDialog.Builder(this)
                .setTitle("Выберите сообщение для удаления")
                .setItems(items, (dialog, which) -> {
                    Message msg = ownMessages.get(which);
                    AppLogger.log(BluetoothChatActivity.this, TAG, "🗑️ User selected message: id=" + msg.getId());
                    deleteMessageForAll(msg);
                })
                .setNegativeButton("Отмена", (dialog, which) -> {
                    AppLogger.log(BluetoothChatActivity.this, TAG, "🗑️ Delete cancelled by user");
                })
                .show();
        AppLogger.log(this, TAG, "🗑️ Delete dialog shown");
    }

    private void deleteMessageForAll(Message msg) {
        AppLogger.log(this, TAG, "🗑️🗑️🗑️ deleteMessageForAll() called, msgId=" + msg.getId());
        if (!isConnected && !isTestMode) {
            AppLogger.log(this, TAG, "❌ Not connected, cannot delete for all");
            Toast.makeText(this, "Нет подключения", Toast.LENGTH_SHORT).show();
            return;
        }
        sendJsonCommand("delete", msg.getId());
        AppLogger.log(this, TAG, "📤 Delete command sent");
        deleteMessageLocally(msg.getId());
        AppLogger.log(this, TAG, "✅ Message deleted locally");
        Toast.makeText(this, "Сообщение удалено для всех", Toast.LENGTH_SHORT).show();
    }

    private void deleteMessageLocally(String messageId) {
        AppLogger.log(this, TAG, "🗑️🗑️🗑️ deleteMessageLocally() called, messageId=" + messageId);
        for (int i = 0; i < messages.size(); i++) {
            if (messages.get(i).getId().equals(messageId)) {
                messages.remove(i);
                adapter.notifyItemRemoved(i);
                AppLogger.log(this, TAG, "✅ Message removed from list at position " + i);
                break;
            }
        }
        dbHelper.deleteMessage(messageId);
        AppLogger.log(this, TAG, "✅ Message deleted from DB");
    }

    private void exportChat() {
        AppLogger.log(this, TAG, "📤📤📤 exportChat() called");
        try {
            File dir = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), "Last04ka");
            if (!dir.exists()) dir.mkdirs();
            String fileName = "chat_" + chatId + "_" + System.currentTimeMillis() + ".txt";
            File file = new File(dir, fileName);
            AppLogger.log(this, TAG, "📤 Export file: " + file.getAbsolutePath());

            FileWriter writer = new FileWriter(file);
            writer.write("Экспорт чата: " + deviceName + "\n");
            writer.write("Дата: " + new SimpleDateFormat("dd.MM.yyyy HH:mm:ss", Locale.getDefault()).format(new Date()) + "\n\n");
            writer.write("Всего сообщений: " + messages.size() + "\n\n");

            for (Message msg : messages) {
                String who = msg.isSent() ? "Я" : deviceName;
                String time = new SimpleDateFormat("dd.MM HH:mm", Locale.getDefault()).format(new Date(msg.getTimestamp()));
                String text = msg.isVoice() ? "[Голосовое " + formatDuration(msg.getDuration()) + "]" : msg.getText();
                if (msg.hasFile()) {
                    text = "📎 " + msg.getFileName() + " (" + formatFileSize(msg.getFileSize()) + ")";
                }
                writer.write(who + " (" + time + "): " + text + "\n");
            }
            writer.close();
            AppLogger.log(this, TAG, "✅ Chat exported to: " + file.getAbsolutePath());
            Toast.makeText(this, "Чат экспортирован: " + file.getAbsolutePath(), Toast.LENGTH_LONG).show();
        } catch (IOException e) {
            AppLogger.logException(this, TAG, "❌ Export failed", e);
            Toast.makeText(this, "Ошибка экспорта: " + e.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }

    // ==================== ВСПОМОГАТЕЛЬНЫЕ МЕТОДЫ ДЛЯ ФОРМАТИРОВАНИЯ ====================

    private String formatDuration(int seconds) {
        if (seconds <= 0) return "0:00";
        int mins = seconds / 60;
        int secs = seconds % 60;
        return mins + ":" + String.format(Locale.getDefault(), "%02d", secs);
    }

    private String formatFileSize(long size) {
        if (size < 1024) return size + " B";
        if (size < 1024 * 1024) return String.format("%.1f KB", size / 1024.0);
        if (size < 1024 * 1024 * 1024) return String.format("%.1f MB", size / (1024.0 * 1024));
        return String.format("%.1f GB", size / (1024.0 * 1024 * 1024));
    }

    // ==================== JSON-ОБРАБОТЧИК ====================

    private void handleJsonCommand(String type, String payload) {
        AppLogger.log(this, TAG, "📨📨📨 handleJsonCommand() type=" + type + ", payload length=" + (payload != null ? payload.length() : 0));
        switch (type) {
            case "text":
                AppLogger.log(this, TAG, "📨 Type: text");
                handleTextMessage(payload);
                break;
            case "typing":
                AppLogger.log(this, TAG, "📨 Type: typing");
                handleTyping(payload.equals("start"));
                break;
            case "delete":
                AppLogger.log(this, TAG, "📨 Type: delete");
                deleteMessageLocally(payload);
                break;
            case "rename":
                AppLogger.log(this, TAG, "📨 Type: rename");
                handleRename(payload);
                break;
            case "pubkey":
                AppLogger.log(this, TAG, "📨 Type: pubkey");
                handlePublicKeyMessage(payload);
                break;
            case "audio":
                AppLogger.log(this, TAG, "📨 Type: audio");
                handleAudioData(payload);
                break;
            case "call_request":
                AppLogger.log(this, TAG, "📨 Type: call_request");
                handleCallRequest(payload);
                break;
            case "call_accept":
                AppLogger.log(this, TAG, "📨 Type: call_accept");
                handleCallAccept();
                break;
            case "call_decline":
                AppLogger.log(this, TAG, "📨 Type: call_decline");
                handleCallDecline();
                break;
            case "call_end":
                AppLogger.log(this, TAG, "📨 Type: call_end");
                handleCallEnd();
                break;
            case "tictactoe_move":
                AppLogger.log(this, TAG, "📨 Type: tictactoe_move");
                handleTicTacToeMove(payload);
                break;
            case "tictactoe_new":
                AppLogger.log(this, TAG, "📨 Type: tictactoe_new");
                handleTicTacToeNew();
                break;
            case "voice":
                AppLogger.log(this, TAG, "📨 Type: voice");
                saveAndPlayVoiceMessage(payload);
                break;
            default:
                AppLogger.log(this, TAG, "⚠️ Unknown JSON type: " + type);
        }
    }

    private void handleLegacyMessage(String raw) {
        AppLogger.log(this, TAG, "📨📨📨 handleLegacyMessage() called, length=" + (raw != null ? raw.length() : 0));
        AppLogger.log(this, TAG, "📨 raw preview: " + (raw != null && raw.length() > 50 ? raw.substring(0, 50) + "..." : raw));

        if (raw.startsWith("FILE|")) {
            AppLogger.log(this, TAG, "📎 FILE message received");
            handleFileMessage(raw.substring(5));
            return;
        }

        if (isLikelyVoiceMessage(raw)) {
            AppLogger.log(this, TAG, "📨 Detected voice message (Base64) in legacy handler");
            saveAndPlayVoiceMessage(raw);
            return;
        }

        if (raw.startsWith("PUB_KEY|")) {
            AppLogger.log(this, TAG, "📨 Legacy: PUB_KEY");
            handlePublicKeyMessage(raw.substring(8));
            return;
        }
        if (raw.startsWith("AUDIO_DATA|")) {
            AppLogger.log(this, TAG, "📨 Legacy: AUDIO_DATA");
            handleAudioData(raw.substring(11));
            return;
        }
        if (raw.startsWith("CALL_REQUEST|")) {
            AppLogger.log(this, TAG, "📨 Legacy: CALL_REQUEST");
            handleCallRequest(raw.substring(13));
            return;
        }
        if (raw.startsWith("CALL_ACCEPT|")) {
            AppLogger.log(this, TAG, "📨 Legacy: CALL_ACCEPT");
            handleCallAccept();
            return;
        }
        if (raw.startsWith("CALL_DECLINE|")) {
            AppLogger.log(this, TAG, "📨 Legacy: CALL_DECLINE");
            handleCallDecline();
            return;
        }
        if (raw.startsWith("CALL_END|")) {
            AppLogger.log(this, TAG, "📨 Legacy: CALL_END");
            handleCallEnd();
            return;
        }
        if (raw.startsWith("TICTACTOE_MOVE|")) {
            AppLogger.log(this, TAG, "📨 Legacy: TICTACTOE_MOVE");
            handleTicTacToeMove(raw.substring(15));
            return;
        }
        if (raw.startsWith("TICTACTOE_NEW|")) {
            AppLogger.log(this, TAG, "📨 Legacy: TICTACTOE_NEW");
            handleTicTacToeNew();
            return;
        }
        if (raw.equals("TYPING|")) {
            AppLogger.log(this, TAG, "📨 Legacy: TYPING");
            handleTyping(true);
            return;
        }
        if (raw.equals("TYPING_STOP|")) {
            AppLogger.log(this, TAG, "📨 Legacy: TYPING_STOP");
            handleTyping(false);
            return;
        }
        if (raw.startsWith("DELETE_MSG|")) {
            AppLogger.log(this, TAG, "📨 Legacy: DELETE_MSG");
            deleteMessageLocally(raw.substring(10));
            return;
        }
        if (raw.startsWith("RENAME|")) {
            AppLogger.log(this, TAG, "📨 Legacy: RENAME");
            handleRename(raw.substring(7));
            return;
        }
        if (raw.startsWith("VOICE|")) {
            AppLogger.log(this, TAG, "📨 Legacy: VOICE");
            saveAndPlayVoiceMessage(raw.substring(6));
            return;
        }

        AppLogger.log(this, TAG, "📨 Legacy: regular text");
        handleTextMessage(raw);
    }

    private boolean isLikelyVoiceMessage(String raw) {
        if (raw == null || raw.length() < 20) {
            AppLogger.log(this, TAG, "isLikelyVoiceMessage: too short (" + (raw != null ? raw.length() : 0) + ") -> false");
            return false;
        }
        for (int i = 0; i < Math.min(raw.length(), 100); i++) {
            char c = raw.charAt(i);
            if (!Character.isLetterOrDigit(c) && c != '+' && c != '/' && c != '=') {
                AppLogger.log(this, TAG, "isLikelyVoiceMessage: invalid Base64 char at pos " + i + ": '" + c + "' -> false");
                return false;
            }
        }
        boolean result = raw.length() > 100;
        AppLogger.log(this, TAG, "isLikelyVoiceMessage: length=" + raw.length() + ", result=" + result);
        return result;
    }

    // ==================== ОТПРАВКА КОМАНД ====================

    private void sendJsonCommand(String type, String payload) {
        AppLogger.log(this, TAG, "📤📤📤 sendJsonCommand() type=" + type + ", payload length=" + (payload != null ? payload.length() : 0));
        AppLogger.log(this, TAG, "📤 payload preview: " + (payload != null && payload.length() > 50 ? payload.substring(0, 50) + "..." : payload));

        if (isTestMode) {
            AppLogger.log(this, TAG, "🧪 TEST MODE: echo message");
            handler.postDelayed(() -> {
                if ("text".equals(type)) {
                    String displayText = payload;
                    if (displayText.startsWith("ENC|")) {
                        displayText = "🔒 <зашифровано>";
                    }
                    addMessageToChat("🧪 [ЭХО] " + displayText, false);
                    AppLogger.log(BluetoothChatActivity.this, TAG, "🧪 Test echo: " + displayText);
                } else if ("voice".equals(type)) {
                    addMessageToChat("🧪 [ЭХО] 🎵 Голосовое сообщение", false);
                } else if ("delete".equals(type)) {
                    deleteMessageLocally(payload);
                } else if ("rename".equals(type)) {
                    handleRename(payload);
                }
            }, 300);
            return;
        }

        try {
            JSONObject json = new JSONObject();
            json.put("type", type);
            json.put("payload", payload);
            String msg = json.toString();
            AppLogger.log(this, TAG, "📤 JSON: " + (msg.length() > 100 ? msg.substring(0, 100) + "..." : msg));

            String finalMsg = msg;
            if (encryptionEnabled && aesKey != null && keysExchanged) {
                AppLogger.log(this, TAG, "🔐 Encrypting message before sending (aesKey=" + (aesKey != null) + ", keysExchanged=" + keysExchanged + ")");
                try {
                    finalMsg = "ENC|" + EncryptionManager.encrypt(msg, aesKey);
                    AppLogger.log(this, TAG, "🔐 Encrypted, length=" + finalMsg.length());
                    AppLogger.log(this, TAG, "🔐 Encrypted preview: " + (finalMsg.length() > 50 ? finalMsg.substring(0, 50) + "..." : finalMsg));
                } catch (Exception e) {
                    AppLogger.logException(this, TAG, "❌ Encryption failed", e);
                }
            } else {
                AppLogger.log(this, TAG, "📤 Sending without encryption (encryptionEnabled=" + encryptionEnabled + ", aesKey=" + (aesKey != null) + ", keysExchanged=" + keysExchanged + ")");
            }
            bluetoothManager.write(finalMsg + "\n");
            AppLogger.log(this, TAG, "✅ Command sent");
        } catch (Exception e) {
            AppLogger.logException(this, TAG, "❌ JSON send error", e);
        }
    }

    // ==================== ТЕКСТОВЫЕ СООБЩЕНИЯ ====================

    private void handleTextMessage(String plainText) {
        AppLogger.log(this, TAG, "📨📨📨 handleTextMessage() START ==================================");
        AppLogger.log(this, TAG, "📨 plainText length: " + (plainText != null ? plainText.length() : 0));
        AppLogger.log(this, TAG, "📨 plainText preview: " + (plainText != null && plainText.length() > 50 ? plainText.substring(0, 50) + "..." : plainText));

        if (plainText != null && plainText.startsWith("ENC|")) {
            String encrypted = plainText.substring(4);
            AppLogger.log(this, TAG, "🔐 Encrypted message detected, encrypted length: " + encrypted.length());
            AppLogger.log(this, TAG, "🔐 encrypted preview: " + (encrypted.length() > 50 ? encrypted.substring(0, 50) + "..." : encrypted));
            AppLogger.log(this, TAG, "🔐 aesKey=" + (aesKey != null ? "OK (exists)" : "NULL") + ", keysExchanged=" + keysExchanged);

            if (aesKey != null && keysExchanged) {
                try {
                    plainText = EncryptionManager.decrypt(encrypted, aesKey);
                    AppLogger.log(this, TAG, "✅ Decrypted successfully");
                    AppLogger.log(this, TAG, "📨 Decrypted text: " + (plainText.length() > 100 ? plainText.substring(0, 100) + "..." : plainText));
                } catch (Exception e) {
                    AppLogger.logException(this, TAG, "❌ Decryption failed", e);
                    plainText = "🔒 <зашифровано, ошибка: " + e.getMessage() + ">";
                }
            } else {
                AppLogger.log(this, TAG, "⚠️ Cannot decrypt: aesKey=" + (aesKey != null) + ", keysExchanged=" + keysExchanged);
                plainText = "🔒 <зашифровано, ключ отсутствует>";
            }
        } else {
            AppLogger.log(this, TAG, "📨 Not encrypted (no ENC| prefix)");
        }

        if (plainText != null && plainText.startsWith("{")) {
            AppLogger.log(this, TAG, "📨 Decrypted text looks like JSON");
            try {
                JSONObject json = new JSONObject(plainText);
                String type = json.getString("type");
                AppLogger.log(this, TAG, "📨 JSON type: " + type);

                if ("text".equals(type)) {
                    String encryptedPayload = json.getString("payload");
                    AppLogger.log(this, TAG, "📨 Encrypted payload: '" + encryptedPayload + "'");

                    String decryptedText;
                    try {
                        decryptedText = EncryptionManager.decrypt(encryptedPayload, aesKey);
                        AppLogger.log(this, TAG, "📨 Decrypted payload: '" + decryptedText + "'");
                    } catch (Exception e) {
                        AppLogger.logException(this, TAG, "❌ Failed to decrypt payload", e);
                        decryptedText = "🔒 <ошибка расшифровки>";
                    }

                    AppLogger.log(this, TAG, "📨 Adding as regular text message (from JSON)");
                    addMessageToChat(decryptedText, false);
                    if (chatId != null) {
                        dbHelper.incrementUnreadCount(chatId);
                        AppLogger.log(this, TAG, "📈 Unread count incremented");
                    }
                    AppLogger.log(this, TAG, "📨📨📨 handleTextMessage() END (text JSON)");
                    return;

                } else if ("voice".equals(type)) {
                    String payload = json.getString("payload");
                    AppLogger.log(this, TAG, "🎵 Processing voice message from JSON, payload length=" + payload.length());
                    saveAndPlayVoiceMessage(payload);
                    AppLogger.log(this, TAG, "📨📨📨 handleTextMessage() END (voice JSON)");
                    return;

                } else if ("typing".equals(type)) {
                    AppLogger.log(this, TAG, "✍️ Typing status ignored in handleTextMessage (already handled)");
                    AppLogger.log(this, TAG, "📨📨📨 handleTextMessage() END (typing JSON)");
                    return;

                } else {
                    AppLogger.log(this, TAG, "⚠️ Unknown JSON type: " + type);
                    addMessageToChat(plainText, false);
                    if (chatId != null) {
                        dbHelper.incrementUnreadCount(chatId);
                    }
                }
            } catch (JSONException e) {
                AppLogger.logException(this, TAG, "❌ Failed to parse JSON, treating as text", e);
                addMessageToChat(plainText, false);
                if (chatId != null) {
                    dbHelper.incrementUnreadCount(chatId);
                }
            }
            AppLogger.log(this, TAG, "📨📨📨 handleTextMessage() END (JSON fallback)");
            return;
        }

        if (plainText != null && isLikelyVoiceMessage(plainText)) {
            AppLogger.log(this, TAG, "🎵 Detected voice message (Base64) in handleTextMessage");
            saveAndPlayVoiceMessage(plainText);
            AppLogger.log(this, TAG, "📨📨📨 handleTextMessage() END (Base64 voice)");
            return;
        }

        AppLogger.log(this, TAG, "📨 Adding as regular text message (final fallback)");
        AppLogger.log(this, TAG, "📨 plainText: " + plainText);
        addMessageToChat(plainText, false);
        if (chatId != null) {
            dbHelper.incrementUnreadCount(chatId);
            AppLogger.log(this, TAG, "📈 Unread count incremented");
        }
        AppLogger.log(this, TAG, "📨📨📨 handleTextMessage() END (fallback)");
    }

    private void handleTyping(boolean start) {
        AppLogger.log(this, TAG, "📨📨📨 handleTyping() start=" + start);
        runOnUiThread(() -> {
            String title = getTitle().toString().replace(" (печатает...)", "").replace(" ✓", "");
            if (start) {
                setTitle(title + " (печатает...)");
                AppLogger.log(BluetoothChatActivity.this, TAG, "✍️ Typing indicator ON");
            } else {
                setTitle(title);
                AppLogger.log(BluetoothChatActivity.this, TAG, "✍️ Typing indicator OFF");
            }
        });
    }

    private void handleRename(String newName) {
        AppLogger.log(this, TAG, "📨📨📨 handleRename() called, newName='" + newName + "'");
        runOnUiThread(() -> {
            deviceName = newName;
            setTitle(newName);
            dbHelper.updateChatName(chatId, newName);
            AppLogger.log(BluetoothChatActivity.this, TAG, "✅ Rename applied: " + newName);
            Toast.makeText(BluetoothChatActivity.this, "Собеседник переименован в " + newName, Toast.LENGTH_SHORT).show();
        });
    }

    private void addMessageToChat(String text, boolean sent) {
        AppLogger.log(this, TAG, "💬💬💬 addMessageToChat() text='" + (text != null && text.length() > 50 ? text.substring(0, 50) + "..." : text) + "', sent=" + sent + ", length=" + (text != null ? text.length() : 0));
        runOnUiThread(() -> {
            Message msg = new Message();
            msg.setId(UUID.randomUUID().toString());
            msg.setChatId(chatId);
            msg.setText(text != null ? text : "");
            msg.setTimestamp(System.currentTimeMillis());
            msg.setSent(sent);
            messages.add(msg);
            adapter.notifyItemInserted(messages.size() - 1);
            recyclerView.scrollToPosition(messages.size() - 1);
            dbHelper.addMessage(msg);
            AppLogger.log(BluetoothChatActivity.this, TAG, "✅ Message added, total=" + messages.size());

            if (!sent && !isFinishing && !isTestMode) {
                String senderName = deviceName != null ? deviceName : "Собеседник";
                NotificationHelper.showMessageNotification(
                        BluetoothChatActivity.this,
                        deviceName != null ? deviceName : "Чат",
                        senderName,
                        text
                );
                AppLogger.log(BluetoothChatActivity.this, TAG, "🔔 Message notification sent");
            }
        });
    }

    // ==================== ГОЛОСОВЫЕ СООБЩЕНИЯ ====================

    private void saveAndPlayVoiceMessage(String base64) {
        AppLogger.log(this, TAG, "🎵🎵🎵 saveAndPlayVoiceMessage() called, base64 length=" + (base64 != null ? base64.length() : 0));
        AppLogger.log(this, TAG, "🎵 base64 preview: " + (base64 != null && base64.length() > 50 ? base64.substring(0, 50) + "..." : base64));

        try {
            if (!isLikelyVoiceMessage(base64)) {
                AppLogger.log(this, TAG, "⚠️ Not a valid Base64 voice message, treating as text");
                handleTextMessage(base64);
                return;
            }

            byte[] bytes = Base64.decode(base64, Base64.DEFAULT);
            AppLogger.log(this, TAG, "📥 Decoded " + (bytes != null ? bytes.length : 0) + " bytes");

            if (bytes == null || bytes.length < 100) {
                AppLogger.log(this, TAG, "⚠️ Decoded bytes are too small (" + (bytes != null ? bytes.length : 0) + "), treating as text");
                handleTextMessage(base64);
                return;
            }

            File dir = new File(getCacheDir(), "voice");
            if (!dir.exists()) dir.mkdirs();
            File file = new File(dir, "voice_" + System.currentTimeMillis() + ".3gp");
            FileOutputStream fos = new FileOutputStream(file);
            fos.write(bytes);
            fos.close();
            AppLogger.log(this, TAG, "✅ Voice file saved: " + file.getAbsolutePath() + ", size=" + file.length());

            int duration = 0;
            try {
                MediaPlayer tmpPlayer = new MediaPlayer();
                tmpPlayer.setDataSource(file.getAbsolutePath());
                tmpPlayer.prepare();
                duration = tmpPlayer.getDuration() / 1000;
                tmpPlayer.release();
                AppLogger.log(this, TAG, "🎵 Received voice duration: " + duration + " sec");
            } catch (Exception e) {
                AppLogger.logException(this, TAG, "Failed to get received voice duration", e);
            }

            Message msg = new Message();
            msg.setId(UUID.randomUUID().toString());
            msg.setChatId(chatId);
            msg.setText("Голосовое");
            msg.setTimestamp(System.currentTimeMillis());
            msg.setSent(false);
            msg.setVoice(true);
            msg.setVoicePath(file.getAbsolutePath());
            msg.setDuration(duration);
            dbHelper.addMessage(msg);
            messages.add(msg);
            adapter.notifyItemInserted(messages.size() - 1);
            recyclerView.scrollToPosition(messages.size() - 1);
            AppLogger.log(this, TAG, "✅ Voice message added to chat");

            MediaPlayer player = new MediaPlayer();
            player.setDataSource(file.getAbsolutePath());
            player.prepare();
            player.start();
            AppLogger.log(this, TAG, "▶️ Playing voice message");
            player.setOnCompletionListener(mp -> {
                mp.release();
                AppLogger.log(BluetoothChatActivity.this, TAG, "⏹️ Voice playback finished");
            });
        } catch (Exception e) {
            AppLogger.logException(this, TAG, "❌ Voice receive failed", e);
            handleTextMessage(base64);
        }
    }

    // ==================== ФАЙЛЫ ====================

    private void handleFileMessage(String fileData) {
        AppLogger.log(this, TAG, "📎 handleFileMessage() START");
        AppLogger.log(this, TAG, "   data length: " + fileData.length());

        String[] parts = fileData.split("\\|", 5);
        if (parts.length < 5) {
            AppLogger.log(this, TAG, "❌ Invalid file data, parts: " + parts.length);
            return;
        }

        String fileName = parts[0];
        String fileSizeStr = parts[1];
        String mimeType = parts[2];
        String base64Data = parts[3];

        AppLogger.log(this, TAG, "   fileName: " + fileName);
        AppLogger.log(this, TAG, "   fileSize: " + fileSizeStr);
        AppLogger.log(this, TAG, "   mimeType: " + mimeType);
        AppLogger.log(this, TAG, "   base64 length: " + base64Data.length());

        runOnUiThread(() -> {
            if (fileProgressBar != null) {
                fileProgressBar.setVisibility(View.VISIBLE);
                fileProgressBar.setProgress(0);
            }
            if (fileProgressText != null) {
                fileProgressText.setVisibility(View.VISIBLE);
                fileProgressText.setText("Получение: 0%");
            }
        });

        NotificationHelper.showFileProgressNotification(this, fileName, 0);

        FileTransferManager.receiveFile(this, chatId, fileName, fileSizeStr, mimeType, base64Data,
            new FileTransferManager.FileTransferCallback() {
                @Override
                public void onProgress(int percent) {
                    AppLogger.log(BluetoothChatActivity.this, TAG, "📊 File receive progress: " + percent + "%");
                    runOnUiThread(() -> {
                        if (fileProgressBar != null) {
                            fileProgressBar.setProgress(percent);
                        }
                        if (fileProgressText != null) {
                            fileProgressText.setText("Получение: " + percent + "%");
                        }
                    });
                    NotificationHelper.showFileProgressNotification(
                            BluetoothChatActivity.this, fileName, percent
                    );
                }

                @Override
                public void onSuccess(String filePath) {
                    AppLogger.log(BluetoothChatActivity.this, TAG, "✅ File received: " + filePath);
                    runOnUiThread(() -> {
                        if (fileProgressBar != null) {
                            fileProgressBar.setVisibility(View.GONE);
                        }
                        if (fileProgressText != null) {
                            fileProgressText.setVisibility(View.GONE);
                        }
                    });

                    String fileMessage = "📎 " + fileName + " (" + fileSizeStr + ")";
                    addMessageToChat(fileMessage, false);

                    if (dbHelper != null) {
                        Message msg = new Message();
                        msg.setId(UUID.randomUUID().toString());
                        msg.setChatId(chatId);
                        msg.setText("📎 " + fileName + " (" + fileSizeStr + ")");
                        msg.setTimestamp(System.currentTimeMillis());
                        msg.setSent(false);
                        msg.setHasFile(true);
                        msg.setFileName(fileName);
                        msg.setFilePath(filePath);
                        msg.setFileSize(Long.parseLong(fileSizeStr));
                        msg.setMimeType(mimeType);
                        dbHelper.addMessage(msg);
                        AppLogger.log(BluetoothChatActivity.this, TAG, "   File saved in DB");
                    }

                    NotificationHelper.cancelNotification(BluetoothChatActivity.this, NotificationHelper.NOTIFICATION_ID_FILE);
                    NotificationHelper.showFileCompleteNotification(
                            BluetoothChatActivity.this, fileName, filePath
                    );

                    Toast.makeText(BluetoothChatActivity.this, "✅ Файл получен: " + fileName, Toast.LENGTH_SHORT).show();
                }

                @Override
                public void onError(String error) {
                    AppLogger.log(BluetoothChatActivity.this, TAG, "❌ File receive error: " + error);
                    runOnUiThread(() -> {
                        if (fileProgressBar != null) {
                            fileProgressBar.setVisibility(View.GONE);
                        }
                        if (fileProgressText != null) {
                            fileProgressText.setVisibility(View.GONE);
                        }
                    });
                    NotificationHelper.cancelNotification(BluetoothChatActivity.this, NotificationHelper.NOTIFICATION_ID_FILE);
                    Toast.makeText(BluetoothChatActivity.this, "❌ " + error, Toast.LENGTH_SHORT).show();
                }
            }
        );

        AppLogger.log(this, TAG, "📎 handleFileMessage() END");
    }

    // ==================== ШИФРОВАНИЕ ====================

    private void initEncryption() {
        AppLogger.log(this, TAG, "🔐🔐🔐 initEncryption() called for chat " + chatId);

        if (chatId == null || chatId.isEmpty() || isTestMode) {
            AppLogger.log(this, TAG, "⚠️ chatId is null or test mode, skipping encryption init");
            return;
        }

        String sharedSecretBase64 = dbHelper.getSharedSecret(chatId);
        if (sharedSecretBase64 != null) {
            AppLogger.log(this, TAG, "📂 Shared secret found in DB, length: " + sharedSecretBase64.length());
            try {
                aesKey = EncryptionManager.secretKeyFromBase64(sharedSecretBase64);
                keysExchanged = true;
                AppLogger.log(this, TAG, "✅ Shared key loaded from DB, keysExchanged=" + keysExchanged);
            } catch (Exception e) {
                AppLogger.logException(this, TAG, "❌ Failed to restore shared key from DB", e);
                aesKey = null;
                keysExchanged = false;
            }
            return;
        }

        String[] deviceKeys = dbHelper.getDeviceKeyPair();
        if (deviceKeys == null) {
            AppLogger.log(this, TAG, "🔑 No device keys found, generating new pair");
            try {
                KeyPair keyPair = EncryptionManager.generateKeyPair();
                myPrivateKeyBase64 = EncryptionManager.encodePrivateKey(keyPair.getPrivate());
                myPublicKeyBase64 = EncryptionManager.encodePublicKey(keyPair.getPublic());
                dbHelper.saveDeviceKeyPair(myPrivateKeyBase64, myPublicKeyBase64);
                AppLogger.log(this, TAG, "✅ New key pair generated and saved");
                AppLogger.log(this, TAG, "🔑 myPublicKeyBase64 length: " + myPublicKeyBase64.length());
            } catch (Exception e) {
                AppLogger.logException(this, TAG, "❌ Keygen failed", e);
                return;
            }
        } else {
            myPrivateKeyBase64 = deviceKeys[0];
            myPublicKeyBase64 = deviceKeys[1];
            AppLogger.log(this, TAG, "📂 Device keys loaded from DB, public key length: " + (myPublicKeyBase64 != null ? myPublicKeyBase64.length() : 0));
        }

        String peerPubKey = dbHelper.getPeerPublicKey(chatId);
        if (peerPubKey != null && myPrivateKeyBase64 != null) {
            AppLogger.log(this, TAG, "📂 Peer public key found in DB, length: " + peerPubKey.length());
            try {
                PrivateKey myPriv = EncryptionManager.decodePrivateKey(myPrivateKeyBase64);
                PublicKey peerPub = EncryptionManager.decodePublicKey(peerPubKey);
                byte[] sharedSecret = EncryptionManager.computeSharedSecret(myPriv, peerPub);
                SecretKey derivedKey = EncryptionManager.deriveAESKey(sharedSecret);
                aesKey = derivedKey;
                keysExchanged = true;
                dbHelper.saveSharedSecret(chatId, EncryptionManager.secretKeyToBase64(aesKey));
                AppLogger.log(this, TAG, "✅ Shared key computed and saved, keysExchanged=" + keysExchanged);
            } catch (Exception e) {
                AppLogger.logException(this, TAG, "❌ Shared secret computation failed", e);
                aesKey = null;
                keysExchanged = false;
            }
        } else {
            AppLogger.log(this, TAG, "⚠️ Peer public key not found, keysExchanged=" + keysExchanged);
            if (isConnected) {
                AppLogger.log(this, TAG, "📤 Sending my public key to peer");
                sendMyPublicKey();
            }
        }
    }

    private void sendMyPublicKey() {
        AppLogger.log(this, TAG, "📤📤📤 sendMyPublicKey() called");
        if (myPublicKeyBase64 == null) {
            AppLogger.log(this, TAG, "⚠️ myPublicKeyBase64 is null");
            return;
        }
        if (!isConnected) {
            AppLogger.log(this, TAG, "⚠️ Not connected, skipping");
            return;
        }
        String avatarBase64 = getAvatarBase64();
        sendJsonCommand("pubkey", myPublicKeyBase64 + "|" + avatarBase64);
        AppLogger.log(this, TAG, "✅ Public key sent, length=" + myPublicKeyBase64.length());
    }

    private String getAvatarBase64() {
        try {
            String avatarPath = dbHelper.getProfileAvatar();
            if (avatarPath == null) return "";
            File f = new File(avatarPath);
            if (!f.exists()) return "";
            Bitmap bm = BitmapFactory.decodeFile(avatarPath);
            if (bm == null) return "";
            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            bm.compress(Bitmap.CompressFormat.JPEG, 80, baos);
            return Base64.encodeToString(baos.toByteArray(), Base64.NO_WRAP);
        } catch (Exception e) {
            AppLogger.logException(this, TAG, "❌ Avatar encoding failed", e);
            return "";
        }
    }

    private void handlePublicKeyMessage(String payload) {
        AppLogger.log(this, TAG, "📨📨📨 handlePublicKeyMessage()");
        String[] parts = payload.split("\\|", 2);
        if (parts.length < 1) return;
        String peerPubKeyBase64 = parts[0];
        String avatarBase64 = parts.length >= 2 ? parts[1] : "";
        AppLogger.log(this, TAG, "📥 Peer public key received, length=" + peerPubKeyBase64.length());

        dbHelper.savePeerPublicKey(chatId, peerPubKeyBase64);
        if (!avatarBase64.isEmpty()) {
            AppLogger.log(this, TAG, "📥 Avatar received, length=" + avatarBase64.length());
            saveAvatar(avatarBase64);
        }

        if (myPrivateKeyBase64 != null) {
            try {
                PrivateKey myPriv = EncryptionManager.decodePrivateKey(myPrivateKeyBase64);
                PublicKey peerPub = EncryptionManager.decodePublicKey(peerPubKeyBase64);
                byte[] sharedSecret = EncryptionManager.computeSharedSecret(myPriv, peerPub);
                SecretKey derivedKey = EncryptionManager.deriveAESKey(sharedSecret);
                aesKey = derivedKey;
                keysExchanged = true;
                dbHelper.saveSharedSecret(chatId, EncryptionManager.secretKeyToBase64(aesKey));
                AppLogger.log(this, TAG, "✅ Shared key computed from peer key, keysExchanged=" + keysExchanged);
                runOnUiThread(() -> Toast.makeText(this, "🔐 Шифрование установлено", Toast.LENGTH_SHORT).show());
            } catch (Exception e) {
                AppLogger.logException(this, TAG, "❌ Shared secret exchange failed", e);
            }
        } else {
            AppLogger.log(this, TAG, "⚠️ myPrivateKeyBase64 is null, cannot compute shared secret");
        }
    }

    private void saveAvatar(String base64) {
        try {
            byte[] bytes = Base64.decode(base64, Base64.DEFAULT);
            Bitmap bm = BitmapFactory.decodeByteArray(bytes, 0, bytes.length);
            if (bm == null) return;
            File cacheDir = getCacheDir();
            String fileName = "chat_avatar_" + chatId + ".jpg";
            File avatarFile = new File(cacheDir, fileName);
            FileOutputStream fos = new FileOutputStream(avatarFile);
            bm.compress(Bitmap.CompressFormat.JPEG, 90, fos);
            fos.close();
            dbHelper.saveChatAvatar(chatId, avatarFile.getAbsolutePath());
            AppLogger.log(this, TAG, "✅ Avatar saved");
        } catch (Exception e) {
            AppLogger.logException(this, TAG, "❌ Avatar save failed", e);
        }
    }

    private void sendEncryptedMessage(String text) {
        AppLogger.log(this, TAG, "📤📤📤 sendEncryptedMessage() text='" + (text.length() > 50 ? text.substring(0, 50) + "..." : text) + "'");
        if (TextUtils.isEmpty(text)) return;
        String payload = text;
        if (encryptionEnabled && aesKey != null && keysExchanged && !isTestMode) {
            try {
                payload = EncryptionManager.encrypt(text, aesKey);
                AppLogger.log(this, TAG, "🔐 Encrypted, length=" + payload.length());
                AppLogger.log(this, TAG, "🔐 Encrypted preview: " + (payload.length() > 50 ? payload.substring(0, 50) + "..." : payload));
            } catch (Exception e) {
                AppLogger.logException(this, TAG, "❌ Encryption failed", e);
            }
        } else {
            AppLogger.log(this, TAG, "📤 Sending without encryption (aesKey=" + (aesKey != null) + ", keysExchanged=" + keysExchanged + ", testMode=" + isTestMode + ")");
        }
        sendJsonCommand("text", payload);
        addMessageToChat(text, true);
        AppLogger.log(this, TAG, "✅ sendEncryptedMessage() END");
    }

    // ==================== ЗВОНКИ ====================

    private void makeCall() {
        AppLogger.log(this, TAG, "📞📞📞 makeCall() called");
        String myAddress = BluetoothAdapter.getDefaultAdapter().getAddress();
        if (myAddress == null) myAddress = "unknown";
        sendJsonCommand("call_request", deviceName + "|" + myAddress);
        Intent i = new Intent(this, CallActivity.class);
        i.putExtra("target_address", deviceAddress);
        i.putExtra("target_name", deviceName);
        i.putExtra("is_initiator", true);
        startActivity(i);
        AppLogger.log(this, TAG, "✅ Call started");
    }

    private void handleCallRequest(String payload) {
        AppLogger.log(this, TAG, "📞📞📞 handleCallRequest()");
        String[] parts = payload.split("\\|");
        if (parts.length >= 2) {
            String callerName = parts[0];
            String callerAddress = parts[1];
            AppLogger.log(this, TAG, "📞 Incoming call from " + callerName);
            Intent i = new Intent(this, IncomingCallActivity.class);
            i.putExtra("caller_address", callerAddress);
            i.putExtra("caller_name", callerName);
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(i);
        }
    }

    private void handleCallAccept() {
        AppLogger.log(this, TAG, "📞📞📞 handleCallAccept()");
        runOnUiThread(() -> Toast.makeText(this, "Звонок принят", Toast.LENGTH_SHORT).show());
    }

    private void handleCallDecline() {
        AppLogger.log(this, TAG, "📞📞📞 handleCallDecline()");
        runOnUiThread(() -> Toast.makeText(this, "Звонок отклонён", Toast.LENGTH_SHORT).show());
    }

    private void handleCallEnd() {
        AppLogger.log(this, TAG, "📞📞📞 handleCallEnd()");
        runOnUiThread(() -> {
            if (activeCallActivity != null) {
                activeCallActivity.finish();
                activeCallActivity = null;
            }
            Toast.makeText(BluetoothChatActivity.this, "Звонок завершён", Toast.LENGTH_SHORT).show();
        });
    }

    private void handleAudioData(String payload) {
        AppLogger.log(this, TAG, "🎵🎵🎵 handleAudioData() called");
        if (activeCallActivity != null) {
            try {
                byte[] audioData = Base64.decode(payload, Base64.DEFAULT);
                activeCallActivity.playAudioData(audioData);
            } catch (Exception e) {
                AppLogger.logException(this, TAG, "❌ Audio decode error", e);
            }
        }
    }

    private void handleTicTacToeMove(String payload) {
        AppLogger.log(this, TAG, "🎮🎮🎮 TicTacToe move: " + payload);
        if (activeTicTacToeActivity != null) {
            activeTicTacToeActivity.receiveOpponentMove(payload);
        }
    }

    private void handleTicTacToeNew() {
        AppLogger.log(this, TAG, "🎮🎮🎮 TicTacToe new game");
        if (activeTicTacToeActivity != null) {
            activeTicTacToeActivity.receiveOpponentMove("NEW");
        }
    }

    // ==================== СТАТИЧЕСКИЕ МЕТОДЫ ====================

    public static void sendCallResponse(String message) {
        if (staticBluetoothManager != null) {
            staticBluetoothManager.write(message + "\n");
        }
    }

    public static void setActiveCallActivity(CallActivity activity) {
        activeCallActivity = activity;
    }

    public static void setActiveTicTacToeActivity(TicTacToePvPActivity activity) {
        activeTicTacToeActivity = activity;
    }

    // ==================== ON DESTROY ====================

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQUEST_RECORD_AUDIO && grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            // Можно запустить запись, если нужно
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        isFinishing = true;
        AppLogger.log(this, TAG, "🔴🔴🔴 BluetoothChatActivity onDestroy");

        if (bluetoothManager != null) {
            bluetoothManager.stop();
        }
        staticBluetoothManager = null;
        activeCallActivity = null;
        activeTicTacToeActivity = null;

        if (mediaRecorder != null) {
            try { mediaRecorder.release(); } catch (Exception e) {}
            mediaRecorder = null;
        }
        if (mediaPlayer != null) {
            try { mediaPlayer.release(); } catch (Exception e) {}
            mediaPlayer = null;
        }
        if (typingStopRunnable != null) {
            handler.removeCallbacks(typingStopRunnable);
        }
        AppLogger.log(this, TAG, "🔴 BluetoothChatActivity destroyed");
    }

    private void applyThemeColors() {
        int bg = ThemeManager.getBackgroundColor(this);
        int inp = ThemeManager.getInputBgColor(this);
        int tc = ThemeManager.getTextColor(this);
        int dc = ThemeManager.getDividerColor(this);
        recyclerView.setBackgroundColor(bg);
        inputMessage.setTextColor(tc);
        inputMessage.setHintTextColor(dc);
        GradientDrawable g = new GradientDrawable();
        g.setColor(inp);
        g.setCornerRadius(16);
        g.setStroke(1, dc);
        inputMessage.setBackground(g);
        findViewById(R.id.input_layout).setBackgroundColor(bg);
        AppLogger.log(this, TAG, "🎨 Theme colors applied");
    }
}