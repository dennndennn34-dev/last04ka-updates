package com.last04ka.messenger.ui;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;

import com.last04ka.messenger.utils.AppLogger;

public class BoardView extends View {
    private static final String TAG = "BoardView";
    private Paint paint = new Paint();
    private int[][] board = new int[3][3];
    private int mySymbol = 1;
    private int currentPlayer = 1;
    private GameCallback callback;

    public interface GameCallback {
        void onCellClick(int row, int col);
    }

    public BoardView(Context context) {
        super(context);
        init();
    }

    public BoardView(Context context, AttributeSet attrs) {
        super(context, attrs);
        init();
    }

    public BoardView(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init();
    }

    private void init() {
        setFocusable(true);
        setFocusableInTouchMode(true);
        setClickable(true);
        AppLogger.log(null, TAG, "✅ BoardView created");
    }

    public void setBoard(int[][] board) {
        this.board = board;
        invalidate();
        AppLogger.log(null, TAG, "📋 Board set");
    }

    public void setMySymbol(int symbol) {
        this.mySymbol = symbol;
        AppLogger.log(null, TAG, "📋 My symbol set: " + symbol);
    }

    public void setCurrentPlayer(int player) {
        this.currentPlayer = player;
        AppLogger.log(null, TAG, "📋 Current player set: " + player);
    }

    public void setGameCallback(GameCallback callback) {
        this.callback = callback;
        AppLogger.log(null, TAG, "📋 Callback set");
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        int w = getWidth();
        int h = getHeight();
        float cell = Math.min(w, h) / 3f;
        float ox = (w - cell * 3) / 2f;
        float oy = (h - cell * 3) / 2f;

        // Фон доски
        paint.setColor(0xFF2E2E3E);
        canvas.drawRoundRect(ox, oy, ox + cell * 3, oy + cell * 3, 12, 12, paint);

        // Линии
        paint.setColor(0xFFFFFFFF);
        paint.setStrokeWidth(4);
        for (int i = 1; i < 3; i++) {
            canvas.drawLine(ox, oy + i * cell, ox + 3 * cell, oy + i * cell, paint);
            canvas.drawLine(ox + i * cell, oy, ox + i * cell, oy + 3 * cell, paint);
        }

        // Фигуры
        for (int r = 0; r < 3; r++) {
            for (int c = 0; c < 3; c++) {
                float cx = ox + c * cell + cell / 2f;
                float cy = oy + r * cell + cell / 2f;

                if (board[r][c] == 0) {
                    continue;
                }

                boolean isMyMove = board[r][c] == mySymbol;

                if (board[r][c] == 1) {
                    // X
                    paint.setColor(isMyMove ? 0xFF4FC3F7 : 0xFFFF5252);
                    paint.setStrokeWidth(10);
                    paint.setStrokeCap(Paint.Cap.ROUND);
                    float margin = cell * 0.25f;
                    canvas.drawLine(cx - margin, cy - margin, cx + margin, cy + margin, paint);
                    canvas.drawLine(cx + margin, cy - margin, cx - margin, cy + margin, paint);
                } else if (board[r][c] == 2) {
                    // O
                    paint.setColor(isMyMove ? 0xFF4FC3F7 : 0xFFFF5252);
                    paint.setStyle(Paint.Style.STROKE);
                    paint.setStrokeWidth(10);
                    canvas.drawCircle(cx, cy, cell * 0.3f, paint);
                    paint.setStyle(Paint.Style.FILL);
                }
            }
        }

        // Индикатор активного игрока
        paint.setColor(Color.WHITE);
        paint.setTextSize(cell * 0.15f);
        paint.setTextAlign(Paint.Align.CENTER);
        String status = (currentPlayer == 1) ? "X" : "O";
        canvas.drawText("Ход: " + status, ox + cell * 1.5f, oy + cell * 3 + 30, paint);
        paint.setTextAlign(Paint.Align.LEFT);
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        if (event.getAction() != MotionEvent.ACTION_DOWN) {
            return true;
        }

        int w = getWidth();
        int h = getHeight();
        float cell = Math.min(w, h) / 3f;
        float ox = (w - cell * 3) / 2f;
        float oy = (h - cell * 3) / 2f;

        int col = (int) ((event.getX() - ox) / cell);
        int row = (int) ((event.getY() - oy) / cell);

        AppLogger.log(null, TAG, "👆 Touch: row=" + row + ", col=" + col);

        if (row < 0 || row >= 3 || col < 0 || col >= 3) {
            AppLogger.log(null, TAG, "⚠️ Touch outside board");
            return true;
        }

        if (callback != null) {
            callback.onCellClick(row, col);
        }

        return true;
    }
}