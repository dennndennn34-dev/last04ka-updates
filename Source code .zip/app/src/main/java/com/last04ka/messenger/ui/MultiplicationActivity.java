package com.last04ka.messenger.ui;

import android.app.Activity;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import java.util.Random;

public class MultiplicationActivity extends Activity {

    private TextView questionText, scoreText, timerText;
    private EditText input;
    private Button btnAnswer, btnStart;
    private int score, total, a, b, correct;
    private CountDownTimer timer;
    private Random r = new Random();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL); layout.setPadding(24,24,24,24); layout.setBackgroundColor(0xFF252525);

        timerText = new TextView(this); timerText.setText("⏱ 30"); timerText.setTextSize(24); timerText.setTextColor(0xFFFF5252);
        timerText.setGravity(android.view.Gravity.CENTER); layout.addView(timerText);

        scoreText = new TextView(this); scoreText.setText("✅ 0 / 0"); scoreText.setTextSize(18); scoreText.setTextColor(0xFFFFFFFF);
        scoreText.setGravity(android.view.Gravity.CENTER); scoreText.setPadding(0,8,0,16); layout.addView(scoreText);

        questionText = new TextView(this); questionText.setTextSize(36); questionText.setTextColor(0xFFFFFFFF);
        questionText.setGravity(android.view.Gravity.CENTER); questionText.setPadding(0,16,0,16); layout.addView(questionText);

        input = new EditText(this); input.setHint("Ответ"); input.setInputType(android.text.InputType.TYPE_CLASS_NUMBER);
        input.setTextColor(0xFFFFFFFF); input.setHintTextColor(0xFF757575); input.setTextSize(24);
        input.setGravity(android.view.Gravity.CENTER); layout.addView(input);

        btnAnswer = new Button(this); btnAnswer.setText("Ответить"); btnAnswer.setEnabled(false);
        btnAnswer.setOnClickListener(v->{ checkAnswer(); }); layout.addView(btnAnswer);

        btnStart = new Button(this); btnStart.setText("Начать");
        btnStart.setOnClickListener(v->{ startGame(); }); layout.addView(btnStart);

        setContentView(layout); setTitle("🧮 Таблица умножения");
    }

    private void startGame() {
        score=0; total=0; correct=0; btnStart.setEnabled(false); btnAnswer.setEnabled(true); input.setEnabled(true);
        timer = new CountDownTimer(30000, 1000) {
            @Override public void onTick(long millis) { timerText.setText("⏱ " + (millis/1000)); }
            @Override public void onFinish() {
                timerText.setText("⏱ 0"); btnAnswer.setEnabled(false); btnStart.setEnabled(true);
                Toast.makeText(MultiplicationActivity.this, "Время! Правильно: " + correct + " из " + total, Toast.LENGTH_LONG).show();
            }
        }.start();
        nextQuestion();
    }

    private void nextQuestion() { a=r.nextInt(10)+2; b=r.nextInt(10)+2; questionText.setText(a+" × "+b+" = ?"); input.setText(""); }

    private void checkAnswer() {
        String s=input.getText().toString(); if(s.isEmpty()) return;
        int ans=Integer.parseInt(s); total++;
        if(ans==a*b){ score+=10; correct++; Toast.makeText(this,"✅",Toast.LENGTH_SHORT).show(); }
        else Toast.makeText(this,"❌ "+a+"×"+b+"="+(a*b),Toast.LENGTH_SHORT).show();
        scoreText.setText("✅ "+correct+" / "+total+" (+"+score+")");
        if(timer!=null&&btnAnswer.isEnabled()) nextQuestion();
    }
}