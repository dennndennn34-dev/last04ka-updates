package com.last04ka.messenger.utils;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.support.v4.app.NotificationCompat;

import com.last04ka.messenger.R;
import com.last04ka.messenger.ui.MainActivity;

public class UpdateNotificationHelper {

    private static final String CHANNEL_ID = "update_channel";
    private static final int NOTIFICATION_ID = 1001;

    public static void showUpdateNotification(Context context, String versionName, String message, String downloadUrl) {
        NotificationManager manager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);

        // Создаём канал для Android 8+
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                    CHANNEL_ID,
                    "Обновления приложения",
                    NotificationManager.IMPORTANCE_HIGH
            );
            channel.setDescription("Уведомления о новых версиях Last04ka");
            manager.createNotificationChannel(channel);
        }

        // Основной Intent – открыть MainActivity
        Intent mainIntent = new Intent(context, MainActivity.class);
        mainIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        
        // Флаг FLAG_IMMUTABLE обязателен для Android 12+ (targetSdk 31)
        int flags = PendingIntent.FLAG_UPDATE_CURRENT;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            flags |= PendingIntent.FLAG_IMMUTABLE;
        }
        PendingIntent pendingMainIntent = PendingIntent.getActivity(context, 0, mainIntent, flags);

        // Intent для кнопки "Обновить" – запускает скачивание через наш ресивер
        Intent downloadIntent = new Intent(context, UpdateCheckReceiver.class);
        downloadIntent.setAction("DOWNLOAD_UPDATE");
        downloadIntent.putExtra("download_url", downloadUrl);
        
        // Для Broadcast тоже нужен флаг IMMUTABLE
        int broadcastFlags = PendingIntent.FLAG_UPDATE_CURRENT;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            broadcastFlags |= PendingIntent.FLAG_IMMUTABLE;
        }
        PendingIntent pendingDownloadIntent = PendingIntent.getBroadcast(context, 1, downloadIntent, broadcastFlags);

        // Строим уведомление
        NotificationCompat.Builder builder = new NotificationCompat.Builder(context, CHANNEL_ID)
                .setSmallIcon(android.R.drawable.stat_sys_download)
                .setContentTitle("Доступно обновление Last04ka")
                .setContentText("Версия " + versionName + " уже ждёт вас!")
                .setStyle(new NotificationCompat.BigTextStyle().bigText(message))
                .setContentIntent(pendingMainIntent)
                .setAutoCancel(true)
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .addAction(android.R.drawable.ic_menu_save, "Обновить", pendingDownloadIntent);

        manager.notify(NOTIFICATION_ID, builder.build());
    }
}