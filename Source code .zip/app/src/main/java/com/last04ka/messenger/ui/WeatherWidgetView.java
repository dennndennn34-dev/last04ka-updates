package com.last04ka.messenger.ui;

import android.Manifest;
import android.app.AlertDialog;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.last04ka.messenger.R;
import com.last04ka.messenger.utils.AppLogger;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class WeatherWidgetView extends LinearLayout {

    private static final String TAG = "WeatherWidget";
    private static final String PREFS = "weather_prefs";
    private static final String KEY_CITY = "city";
    private static final String KEY_TEMP = "temp";
    private static final String KEY_CONDITION = "condition";
    private static final String KEY_WIND = "wind";
    private static final String KEY_HUMIDITY = "humidity";
    private static final String KEY_ICON = "icon";
    private static final String KEY_LAST_UPDATE = "last_update";
    private static final String KEY_USE_GPS = "use_gps";
    private static final long UPDATE_INTERVAL = 30 * 60 * 1000; // 30 минут
    private static final long GPS_TIMEOUT = 30000; // 30 секунд

    private TextView tvTemp, tvCondition, tvCity, tvIcon, tvWind, tvHumidity, tvTime, tvChangeCity;
    private Handler handler = new Handler(Looper.getMainLooper());
    private ExecutorService executor = Executors.newSingleThreadExecutor();
    private AlphaAnimation fadeInAnimation;
    private String currentCity = "Moscow";
    private Context context;
    private boolean useGps = false;
    private LocationManager locationManager;
    private LocationListener gpsListener;
    private boolean isGpsUpdating = false;
    private Handler gpsTimeoutHandler = new Handler(Looper.getMainLooper());

    public WeatherWidgetView(Context context) {
        super(context);
        this.context = context;
        init(context);
    }

    public WeatherWidgetView(Context context, AttributeSet attrs) {
        super(context, attrs);
        this.context = context;
        init(context);
    }

    public WeatherWidgetView(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        this.context = context;
        init(context);
    }

    private void init(Context context) {
        AppLogger.log(context, TAG, "🌤️ WeatherWidgetView init() START");

        try {
            LayoutInflater.from(context).inflate(R.layout.weather_widget, this, true);

            tvTemp = findViewById(R.id.tv_weather_temp);
            tvCondition = findViewById(R.id.tv_weather_condition);
            tvCity = findViewById(R.id.tv_weather_city);
            tvIcon = findViewById(R.id.tv_weather_icon);
            tvWind = findViewById(R.id.tv_weather_wind);
            tvHumidity = findViewById(R.id.tv_weather_humidity);
            tvTime = findViewById(R.id.tv_weather_time);
            tvChangeCity = findViewById(R.id.tv_change_city);

            // Анимация появления
            fadeInAnimation = new AlphaAnimation(0f, 1f);
            fadeInAnimation.setDuration(600);
            this.startAnimation(fadeInAnimation);

            // Загружаем сохранённые данные
            loadSavedWeather(context);

            // Загружаем настройки
            loadSettings(context);

            // Запускаем обновление
            startWeatherUpdates(context);

            // ==================== КЛИК ПО КНОПКЕ СМЕНЫ ГОРОДА ====================
            if (tvChangeCity != null) {
                tvChangeCity.setOnClickListener(v -> {
                    AppLogger.log(context, TAG, "✏️ Change city button clicked");
                    showCitySelector();
                });
            }

            // Обработка клика по городу для быстрой смены
            if (tvCity != null) {
                tvCity.setOnClickListener(v -> {
                    AppLogger.log(context, TAG, "📍 City name clicked, showing city selector");
                    showCitySelector();
                });
            }

            // Обработка клика по виджету для обновления
            setOnClickListener(v -> {
                AppLogger.log(context, TAG, "🔄 Widget clicked, refreshing...");
                refreshWeather();
            });

            AppLogger.log(context, TAG, "✅ WeatherWidgetView init() END");
        } catch (Exception e) {
            AppLogger.logException(context, TAG, "❌ init() error", e);
        }
    }

    private void loadSettings(Context context) {
        SharedPreferences prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        useGps = prefs.getBoolean(KEY_USE_GPS, false);
        AppLogger.log(context, TAG, "📋 GPS mode: " + useGps);
    }

    private void loadSavedWeather(Context context) {
        AppLogger.log(context, TAG, "📂 loadSavedWeather() START");

        SharedPreferences prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        String city = prefs.getString(KEY_CITY, "Moscow");
        String temp = prefs.getString(KEY_TEMP, "--°C");
        String condition = prefs.getString(KEY_CONDITION, "Загрузка...");
        String wind = prefs.getString(KEY_WIND, "--");
        String humidity = prefs.getString(KEY_HUMIDITY, "--%");
        String icon = prefs.getString(KEY_ICON, "🌤️");
        long lastUpdate = prefs.getLong(KEY_LAST_UPDATE, 0);

        currentCity = city;
        tvCity.setText(city);
        tvTemp.setText(temp);
        tvCondition.setText(condition);
        tvIcon.setText(icon);
        tvWind.setText("💨 " + wind);
        tvHumidity.setText("💧 " + humidity);

        if (lastUpdate > 0) {
            String time = new SimpleDateFormat("HH:mm", Locale.getDefault()).format(new Date(lastUpdate));
            tvTime.setText("🕐 " + time);
        }

        AppLogger.log(context, TAG, "✅ Loaded: " + city + ", " + temp + ", " + condition + ", wind=" + wind + ", humidity=" + humidity);
    }

    private void startWeatherUpdates(Context context) {
        AppLogger.log(context, TAG, "🔄 startWeatherUpdates() START");

        // Первое обновление
        if (useGps) {
            getLocationAndUpdate();
        } else {
            updateWeather(context);
        }

        // Периодическое обновление
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                AppLogger.log(context, TAG, "⏰ Scheduled weather update");
                if (useGps) {
                    getLocationAndUpdate();
                } else {
                    updateWeather(context);
                }
                handler.postDelayed(this, UPDATE_INTERVAL);
            }
        }, UPDATE_INTERVAL);

        AppLogger.log(context, TAG, "✅ Weather updates scheduled (interval: " + UPDATE_INTERVAL / 60000 + " min)");
    }

    // ==================== GPS ====================

    private void getLocationAndUpdate() {
        AppLogger.log(context, TAG, "📍 getLocationAndUpdate() START");

        if (isGpsUpdating) {
            AppLogger.log(context, TAG, "⚠️ GPS already updating");
            return;
        }

        if (ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_FINE_LOCATION)
                != PackageManager.PERMISSION_GRANTED) {
            AppLogger.log(context, TAG, "⚠️ No GPS permission");
            tvCity.setText("📍 Нет разрешения");
            return;
        }

        locationManager = (LocationManager) context.getSystemService(Context.LOCATION_SERVICE);
        if (locationManager == null) {
            AppLogger.log(context, TAG, "❌ LocationManager is null");
            return;
        }

        isGpsUpdating = true;
        tvCity.setText("📍 Определяем...");

        gpsListener = new LocationListener() {
            @Override
            public void onLocationChanged(Location location) {
                AppLogger.log(context, TAG, "📍 GPS location: " + location.getLatitude() + ", " + location.getLongitude());
                isGpsUpdating = false;
                gpsTimeoutHandler.removeCallbacks(gpsTimeoutRunnable);

                if (locationManager != null) {
                    try {
                        locationManager.removeUpdates(this);
                    } catch (Exception e) {
                        AppLogger.logException(context, TAG, "GPS remove error", e);
                    }
                }

                getCityFromLocation(location.getLatitude(), location.getLongitude());
            }

            @Override
            public void onStatusChanged(String provider, int status, Bundle extras) {}

            @Override
            public void onProviderEnabled(String provider) {
                AppLogger.log(context, TAG, "📍 GPS enabled");
            }

            @Override
            public void onProviderDisabled(String provider) {
                AppLogger.log(context, TAG, "📍 GPS disabled");
                isGpsUpdating = false;
                tvCity.setText("📍 GPS выключен");
            }
        };

        try {
            locationManager.requestLocationUpdates(
                    LocationManager.GPS_PROVIDER,
                    1000,
                    10,
                    gpsListener
            );

            gpsTimeoutHandler.postDelayed(gpsTimeoutRunnable, GPS_TIMEOUT);

            AppLogger.log(context, TAG, "✅ GPS request sent");

        } catch (SecurityException e) {
            AppLogger.logException(context, TAG, "❌ GPS security error", e);
            isGpsUpdating = false;
            tvCity.setText("📍 Ошибка GPS");
        }
    }

    private Runnable gpsTimeoutRunnable = new Runnable() {
        @Override
        public void run() {
            AppLogger.log(context, TAG, "⏰ GPS timeout");
            isGpsUpdating = false;
            if (locationManager != null && gpsListener != null) {
                try {
                    locationManager.removeUpdates(gpsListener);
                } catch (Exception e) {
                    AppLogger.logException(context, TAG, "GPS remove error", e);
                }
            }
            tvCity.setText("📍 Таймаут GPS");
            if (currentCity != null && !currentCity.isEmpty()) {
                updateWeather(context);
            }
        }
    };

    private void getCityFromLocation(double lat, double lon) {
        AppLogger.log(context, TAG, "📍 getCityFromLocation: " + lat + ", " + lon);

        executor.execute(() -> {
            try {
                String urlStr = "https://geocode.xyz/" + lat + "," + lon + "?json=1&geoit=json";
                AppLogger.log(context, TAG, "   URL: " + urlStr);

                URL url = new URL(urlStr);
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setConnectTimeout(10000);
                conn.setReadTimeout(10000);
                conn.setRequestProperty("User-Agent", "Last04ka/2.8");

                int responseCode = conn.getResponseCode();
                AppLogger.log(context, TAG, "   Response code: " + responseCode);

                if (responseCode == HttpURLConnection.HTTP_OK) {
                    BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream()));
                    StringBuilder sb = new StringBuilder();
                    String line;
                    while ((line = reader.readLine()) != null) {
                        sb.append(line);
                    }
                    reader.close();
                    conn.disconnect();

                    String json = sb.toString();
                    AppLogger.log(context, TAG, "   JSON length: " + json.length());

                    String city = parseCityFromGeocode(json);
                    if (city != null && !city.isEmpty()) {
                        AppLogger.log(context, TAG, "📍 City found: " + city);
                        currentCity = city;
                        saveCity(city);
                        handler.post(() -> {
                            tvCity.setText(city);
                            updateWeather(context);
                        });
                    } else {
                        AppLogger.log(context, TAG, "⚠️ City not found in geocode");
                        handler.post(() -> tvCity.setText("📍 Город не найден"));
                    }
                } else {
                    AppLogger.log(context, TAG, "⚠️ Geocode response: " + responseCode);
                }

            } catch (Exception e) {
                AppLogger.logException(context, TAG, "❌ Geocode error", e);
                handler.post(() -> tvCity.setText("📍 Ошибка геокодинга"));
            }
        });
    }

    private String parseCityFromGeocode(String json) {
        try {
            int cityStart = json.indexOf("\"city\":\"");
            if (cityStart < 0) {
                cityStart = json.indexOf("\"region\":\"");
            }
            if (cityStart < 0) {
                cityStart = json.indexOf("\"town\":\"");
            }
            if (cityStart < 0) return null;

            int start = cityStart + 8;
            int end = start;
            while (end < json.length()) {
                char c = json.charAt(end);
                if (c == '"' && (end == start || json.charAt(end - 1) != '\\')) {
                    break;
                }
                end++;
            }
            if (end <= start) return null;
            return json.substring(start, end);
        } catch (Exception e) {
            AppLogger.logException(context, TAG, "❌ Parse city error", e);
            return null;
        }
    }

    // ==================== ЗАПРОС ПОГОДЫ ====================

    private void updateWeather(Context context) {
        AppLogger.log(context, TAG, "🌐 updateWeather() START for: " + currentCity);

        executor.execute(() -> {
            try {
                String encodedCity = URLEncoder.encode(currentCity, "UTF-8");
                String urlStr = "https://wttr.in/" + encodedCity + "?format=%C+%t+%w+%h&lang=ru";
                AppLogger.log(context, TAG, "   URL: " + urlStr);

                URL url = new URL(urlStr);
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setConnectTimeout(10000);
                conn.setReadTimeout(10000);
                conn.setRequestProperty("User-Agent", "Last04ka/2.8");

                int responseCode = conn.getResponseCode();
                AppLogger.log(context, TAG, "   Response code: " + responseCode);

                if (responseCode == HttpURLConnection.HTTP_OK) {
                    BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream()));
                    String result = reader.readLine();
                    reader.close();
                    conn.disconnect();

                    AppLogger.log(context, TAG, "   Raw data: " + result);

                    if (result != null && !result.isEmpty()) {
                        parseAndSaveWeather(context, result);
                    } else {
                        AppLogger.log(context, TAG, "⚠️ Empty response");
                    }
                } else {
                    AppLogger.log(context, TAG, "⚠️ Bad response: " + responseCode);
                }

            } catch (Exception e) {
                AppLogger.logException(context, TAG, "❌ Weather fetch error", e);
            }
        });
    }

    private void parseAndSaveWeather(Context context, String data) {
        AppLogger.log(context, TAG, "📊 parseAndSaveWeather() START");
        AppLogger.log(context, TAG, "   Raw data: " + data);

        try {
            String[] parts = data.split(" ");
            AppLogger.log(context, TAG, "   Parts: " + parts.length);

            String condition = "";
            String temp = "";
            String wind = "";
            String humidity = "";

            int i = 0;

            StringBuilder conditionSb = new StringBuilder();
            while (i < parts.length) {
                String part = parts[i];
                if (part.contains("°C") || part.contains("°")) {
                    temp = part;
                    i++;
                    continue;
                }
                if (part.contains("km/h") || part.contains("m/s") || part.contains("↑") || part.contains("↓")) {
                    wind = part;
                    i++;
                    continue;
                }
                if (part.contains("%")) {
                    humidity = part;
                    i++;
                    continue;
                }
                if (conditionSb.length() > 0) conditionSb.append(" ");
                conditionSb.append(part);
                i++;
            }

            if (conditionSb.length() == 0 && i < parts.length) {
                while (i < parts.length) {
                    String part = parts[i];
                    if (part.contains("°C") || part.contains("°")) {
                        if (temp.isEmpty()) temp = part;
                    } else if (part.contains("km/h") || part.contains("m/s") || part.contains("↑") || part.contains("↓")) {
                        if (wind.isEmpty()) wind = part;
                    } else if (part.contains("%")) {
                        if (humidity.isEmpty()) humidity = part;
                    } else {
                        if (conditionSb.length() > 0) conditionSb.append(" ");
                        conditionSb.append(part);
                    }
                    i++;
                }
            }

            condition = conditionSb.toString().trim();
            if (condition.isEmpty()) condition = "Неизвестно";

            temp = cleanTemp(temp);
            wind = cleanWind(wind);
            humidity = cleanHumidity(humidity);

            String icon = getWeatherIcon(condition);

            AppLogger.log(context, TAG, "   Parsed: condition=" + condition + ", temp=" + temp + ", wind=" + wind + ", humidity=" + humidity + ", icon=" + icon);

            SharedPreferences prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
            prefs.edit()
                    .putString(KEY_CITY, currentCity)
                    .putString(KEY_TEMP, temp)
                    .putString(KEY_CONDITION, condition)
                    .putString(KEY_WIND, wind)
                    .putString(KEY_HUMIDITY, humidity)
                    .putString(KEY_ICON, icon)
                    .putLong(KEY_LAST_UPDATE, System.currentTimeMillis())
                    .apply();

            final String finalTemp = temp;
            final String finalCondition = condition;
            final String finalWind = wind;
            final String finalHumidity = humidity;
            final String finalIcon = icon;

            handler.post(() -> {
                Animation pulseAnim = AnimationUtils.loadAnimation(context, R.anim.pulse);
                if (pulseAnim != null) {
                    startAnimation(pulseAnim);
                }

                tvTemp.setText(finalTemp);
                tvCondition.setText(finalCondition);
                tvIcon.setText(finalIcon);
                tvWind.setText("💨 " + finalWind);
                tvHumidity.setText("💧 " + finalHumidity);

                String time = new SimpleDateFormat("HH:mm", Locale.getDefault()).format(new Date());
                tvTime.setText("🕐 " + time);

                AppLogger.log(context, TAG, "✅ UI updated: " + finalTemp + ", " + finalCondition);
            });

        } catch (Exception e) {
            AppLogger.logException(context, TAG, "❌ Parse error", e);
            handler.post(() -> {
                tvCondition.setText("Ошибка парсинга");
                AppLogger.log(context, TAG, "⚠️ Parse error displayed");
            });
        }
    }

    private String cleanTemp(String temp) {
        if (temp == null || temp.isEmpty()) return "--°C";
        temp = temp.replaceAll("[^\\d+\\-°C]", "");
        if (temp.isEmpty()) return "--°C";
        return temp;
    }

    private String cleanWind(String wind) {
        if (wind == null || wind.isEmpty()) return "--";
        wind = wind.replace("↑", "").replace("↓", "").replace("→", "").replace("←", "");
        wind = wind.trim();
        if (wind.isEmpty()) return "--";
        return wind;
    }

    private String cleanHumidity(String humidity) {
        if (humidity == null || humidity.isEmpty()) return "--%";
        humidity = humidity.replaceAll("[^\\d%]", "");
        if (humidity.isEmpty()) return "--%";
        return humidity;
    }

    private String getWeatherIcon(String condition) {
        String lower = condition.toLowerCase();
        if (lower.contains("солн") || lower.contains("ясн") || lower.contains("sun")) return "☀️";
        if (lower.contains("обл") || lower.contains("пасмур") || lower.contains("cloud")) return "☁️";
        if (lower.contains("дожд") || lower.contains("ливн") || lower.contains("rain")) return "🌧️";
        if (lower.contains("снег") || lower.contains("snow")) return "❄️";
        if (lower.contains("туман") || lower.contains("fog")) return "🌫️";
        if (lower.contains("гроз") || lower.contains("thunder")) return "⛈️";
        if (lower.contains("ветер") || lower.contains("wind")) return "💨";
        if (lower.contains("град") || lower.contains("hail")) return "🌨️";
        if (lower.contains("ясно") || lower.contains("clear")) return "☀️";
        if (lower.contains("переменная облачность")) return "⛅";
        if (lower.contains("небольшая облачность")) return "🌤️";
        return "🌤️";
    }

    // ==================== ВЫБОР ГОРОДА ====================

    private void showCitySelector() {
        AppLogger.log(context, TAG, "📍 showCitySelector() START");

        AlertDialog.Builder builder = new AlertDialog.Builder(context);
        builder.setTitle("🌍 Выберите город");

        final EditText input = new EditText(context);
        input.setHint("Введите город");
        input.setText(currentCity);
        input.setSelectAllOnFocus(true);
        builder.setView(input);

        builder.setPositiveButton("OK", (dialog, which) -> {
            String city = input.getText().toString().trim();
            if (!city.isEmpty()) {
                AppLogger.log(context, TAG, "📍 City selected: " + city);
                currentCity = city;
                saveCity(city);
                tvCity.setText(city);
                useGps = false;
                saveGpsMode(false);
                updateWeather(context);
                Toast.makeText(context, "🌍 Город: " + city, Toast.LENGTH_SHORT).show();
            }
        });

        builder.setNeutralButton("📍 GPS", (dialog, which) -> {
            AppLogger.log(context, TAG, "📍 GPS mode selected");
            useGps = true;
            saveGpsMode(true);
            getLocationAndUpdate();
            Toast.makeText(context, "📍 Определение по GPS...", Toast.LENGTH_SHORT).show();
        });

        builder.setNegativeButton("Отмена", null);
        builder.show();
    }

    private void saveCity(String city) {
        SharedPreferences prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        prefs.edit().putString(KEY_CITY, city).apply();
        AppLogger.log(context, TAG, "✅ City saved: " + city);
    }

    private void saveGpsMode(boolean enabled) {
        SharedPreferences prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        prefs.edit().putBoolean(KEY_USE_GPS, enabled).apply();
        AppLogger.log(context, TAG, "✅ GPS mode saved: " + enabled);
    }

    public void refreshWeather() {
        AppLogger.log(getContext(), TAG, "🔄 refreshWeather() called");
        if (useGps) {
            getLocationAndUpdate();
        } else {
            updateWeather(getContext());
        }
    }

    public void setCity(String city) {
        AppLogger.log(getContext(), TAG, "📍 setCity: " + city);
        currentCity = city;
        useGps = false;
        saveCity(city);
        saveGpsMode(false);
        tvCity.setText(city);
        refreshWeather();
        Toast.makeText(context, "🌍 Город: " + city, Toast.LENGTH_SHORT).show();
    }

    @Override
    protected void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        handler.removeCallbacksAndMessages(null);
        gpsTimeoutHandler.removeCallbacksAndMessages(null);
        executor.shutdown();
        if (locationManager != null && gpsListener != null) {
            try {
                locationManager.removeUpdates(gpsListener);
            } catch (Exception e) {
                AppLogger.logException(getContext(), TAG, "GPS remove error", e);
            }
        }
        AppLogger.log(getContext(), TAG, "⏹️ WeatherWidget destroyed");
    }
}