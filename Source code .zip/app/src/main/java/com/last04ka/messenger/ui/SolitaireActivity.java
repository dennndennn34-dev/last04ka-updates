package com.last04ka.messenger.ui;

import android.app.Activity;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Toast;
import com.last04ka.messenger.utils.AppLogger;
import com.last04ka.messenger.utils.GameScores;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Random;
import java.util.Stack;

public class SolitaireActivity extends Activity {

    private SolitaireView gameView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        try {
            AppLogger.log(this, "Solitaire", "onCreate started");
            gameView = new SolitaireView(this);
            setContentView(gameView);
            setTitle("🃏 Пасьянс Косынка | Рекорд: " + GameScores.getScore(this, "solitaire"));
            AppLogger.log(this, "Solitaire", "onCreate completed");
        } catch (Exception e) { AppLogger.logException(this, "Solitaire", e); finish(); }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (gameView != null) GameScores.saveScore(this, "solitaire", gameView.score);
    }

    class SolitaireView extends View {
        private List<Card> deck = new ArrayList<>();
        private List<Card>[] columns = new List[7];
        private List<Card>[] foundations = new List[4];
        private Stack<Card> stock = new Stack<>();
        private List<Card> waste = new ArrayList<>();
        private Card draggedCard = null;
        private List<Card> draggedStack = new ArrayList<>();
        private float dragX, dragY, lastX, lastY;
        private int score = 0;
        private Paint paint = new Paint();
        private Random random = new Random();
        private float cardW = 70, cardH = 100;
        private int stockX = 10, stockY = 10;
        private int wasteX = 90, wasteY = 10;
        private int foundationStartX = 300;

        public SolitaireView(Context ctx) {
            super(ctx);
            setFocusable(true);
            for (int i = 0; i < 7; i++) columns[i] = new ArrayList<>();
            for (int i = 0; i < 4; i++) foundations[i] = new ArrayList<>();
            initGame();
        }

        private void initGame() {
            deck.clear(); stock.clear(); waste.clear();
            for (int i = 0; i < 7; i++) columns[i].clear();
            for (int i = 0; i < 4; i++) foundations[i].clear();
            score = 0;

            for (int suit = 0; suit < 4; suit++)
                for (int rank = 1; rank <= 13; rank++)
                    deck.add(new Card(suit, rank));
            Collections.shuffle(deck, random);

            for (int col = 0; col < 7; col++) {
                for (int row = 0; row <= col; row++) {
                    Card c = deck.remove(0);
                    c.faceUp = (row == col);
                    columns[col].add(c);
                }
            }
            while (!deck.isEmpty()) stock.push(deck.remove(0));
        }

        @Override
        protected void onSizeChanged(int w, int h, int oldw, int oldh) {
            super.onSizeChanged(w, h, oldw, oldh);
            cardW = Math.min(80, w / 8f);
            cardH = cardW * 1.4f;
            foundationStartX = (int) (w - cardW * 4 - 40);
        }

        @Override
        protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            canvas.drawColor(Color.rgb(0, 100, 0));

            // Stock
            drawCardBack(canvas, stockX, stockY, !stock.isEmpty());
            // Waste
            if (!waste.isEmpty()) {
                Card top = waste.get(waste.size() - 1);
                drawCard(canvas, wasteX, wasteY, top);
            }
            // Foundations
            for (int i = 0; i < 4; i++) {
                float x = foundationStartX + i * (cardW + 10);
                if (foundations[i].isEmpty()) drawEmptySlot(canvas, x, stockY);
                else drawCard(canvas, x, stockY, foundations[i].get(foundations[i].size() - 1));
            }
            // Columns
            for (int col = 0; col < 7; col++) {
                float x = 10 + col * (cardW + 10);
                float y = stockY + cardH + 30;
                if (columns[col].isEmpty()) drawEmptySlot(canvas, x, y);
                else {
                    for (int row = 0; row < columns[col].size(); row++) {
                        Card c = columns[col].get(row);
                        float cy = y + row * (c.faceUp ? 30 : 20);
                        if (c == draggedCard && draggedStack.contains(c)) continue;
                        if (c.faceUp) drawCard(canvas, x, cy, c);
                        else drawCardBack(canvas, x, cy, true);
                    }
                }
            }
            // Dragged cards
            if (draggedCard != null) {
                for (int i = 0; i < draggedStack.size(); i++) {
                    Card c = draggedStack.get(i);
                    drawCard(canvas, dragX, dragY + i * 30, c);
                }
            }
            // Score
            paint.setColor(Color.WHITE);
            paint.setTextSize(24);
            canvas.drawText("Score: " + score, 10, getHeight() - 20, paint);
        }

        private void drawCard(Canvas canvas, float x, float y, Card c) {
            paint.setColor(Color.WHITE);
            canvas.drawRoundRect(x, y, x + cardW, y + cardH, 6, 6, paint);
            paint.setColor(c.suit < 2 ? Color.RED : Color.BLACK);
            paint.setTextSize(20);
            canvas.drawText(getRankStr(c.rank), x + 5, y + 22, paint);
            String[] suits = {"♥","♦","♣","♠"};
            canvas.drawText(suits[c.suit], x + 5, y + 42, paint);
            paint.setColor(Color.BLACK);
            paint.setStyle(Paint.Style.STROKE);
            canvas.drawRoundRect(x, y, x + cardW, y + cardH, 6, 6, paint);
            paint.setStyle(Paint.Style.FILL);
        }

        private void drawCardBack(Canvas canvas, float x, float y, boolean hasCard) {
            if (!hasCard) {
                drawEmptySlot(canvas, x, y);
                return;
            }
            paint.setColor(Color.rgb(0, 80, 180));
            canvas.drawRoundRect(x, y, x + cardW, y + cardH, 6, 6, paint);
            paint.setColor(Color.rgb(0, 60, 140));
            for (int i = 0; i < 5; i++) {
                canvas.drawLine(x + 8, y + 15 + i * 15, x + cardW - 8, y + 15 + i * 15, paint);
            }
        }

        private void drawEmptySlot(Canvas canvas, float x, float y) {
            paint.setColor(Color.rgb(0, 60, 0));
            canvas.drawRoundRect(x, y, x + cardW, y + cardH, 6, 6, paint);
            paint.setColor(Color.rgb(0, 120, 0));
            paint.setStyle(Paint.Style.STROKE);
            canvas.drawRoundRect(x, y, x + cardW, y + cardH, 6, 6, paint);
            paint.setStyle(Paint.Style.FILL);
        }

        private String getRankStr(int r) {
            if (r == 1) return "A"; if (r == 11) return "J";
            if (r == 12) return "Q"; if (r == 13) return "K";
            return String.valueOf(r);
        }

        private int getColFromX(float x) { return (int) ((x - 10) / (cardW + 10)); }
        private int getRowFromY(float y, int col) {
            float startY = stockY + cardH + 30;
            return (int) ((y - startY) / 25);
        }

        @Override
        public boolean onTouchEvent(MotionEvent event) {
            float x = event.getX(), y = event.getY();
            switch (event.getAction()) {
                case MotionEvent.ACTION_DOWN:
                    // Stock
                    if (x >= stockX && x <= stockX + cardW && y >= stockY && y <= stockY + cardH) {
                        if (!stock.isEmpty()) {
                            Card c = stock.pop();
                            c.faceUp = true;
                            waste.add(c);
                            score++;
                        } else {
                            while (!waste.isEmpty()) { Card c = waste.remove(waste.size() - 1); c.faceUp = false; stock.push(c); }
                            score = Math.max(0, score - 3);
                        }
                        invalidate();
                        return true;
                    }
                    // Waste
                    if (!waste.isEmpty() && x >= wasteX && x <= wasteX + cardW && y >= wasteY && y <= wasteY + cardH) {
                        draggedCard = waste.get(waste.size() - 1);
                        draggedStack.clear(); draggedStack.add(draggedCard);
                        dragX = x - cardW / 2; dragY = y - cardH / 2;
                        invalidate();
                        return true;
                    }
                    // Foundations
                    for (int i = 0; i < 4; i++) {
                        float fx = foundationStartX + i * (cardW + 10);
                        if (!foundations[i].isEmpty() && x >= fx && x <= fx + cardW && y >= stockY && y <= stockY + cardH) {
                            Card top = foundations[i].get(foundations[i].size() - 1);
                            draggedCard = top; draggedStack.clear(); draggedStack.add(top);
                            dragX = x - cardW / 2; dragY = y - cardH / 2;
                            invalidate();
                            return true;
                        }
                    }
                    // Columns
                    for (int col = 0; col < 7; col++) {
                        float cx = 10 + col * (cardW + 10);
                        float cy = stockY + cardH + 30;
                        for (int row = columns[col].size() - 1; row >= 0; row--) {
                            Card c = columns[col].get(row);
                            float cardY = cy + (columns[col].get(row).faceUp ? row * 30 : row * 20);
                            if (c.faceUp && x >= cx && x <= cx + cardW && y >= cardY && y <= cardY + cardH) {
                                draggedCard = c;
                                draggedStack.clear();
                                for (int r = row; r < columns[col].size(); r++) draggedStack.add(columns[col].get(r));
                                dragX = x - cardW / 2; dragY = y - cardH / 2;
                                lastX = cx; lastY = cardY;
                                invalidate();
                                return true;
                            }
                            if (!c.faceUp) break;
                        }
                    }
                    break;

                case MotionEvent.ACTION_MOVE:
                    if (draggedCard != null) { dragX = x - cardW / 2; dragY = y - cardH / 2; invalidate(); }
                    break;

                case MotionEvent.ACTION_UP:
                    if (draggedCard != null) {
                        boolean placed = false;
                        // Try columns
                        int col = getColFromX(x);
                        if (col >= 0 && col < 7) {
                            if (columns[col].isEmpty()) {
                                if (draggedCard.rank == 13) {
                                    moveStackTo(columns[col]); placed = true; score += 5;
                                }
                            } else {
                                Card bottom = columns[col].get(columns[col].size() - 1);
                                if (bottom.faceUp && bottom.suit % 2 != draggedCard.suit % 2 && bottom.rank == draggedCard.rank + 1) {
                                    moveStackTo(columns[col]); placed = true;
                                }
                            }
                        }
                        // Try foundations
                        if (!placed) {
                            for (int i = 0; i < 4; i++) {
                                float fx = foundationStartX + i * (cardW + 10);
                                if (x >= fx && x <= fx + cardW && y >= stockY && y <= stockY + cardH) {
                                    if (draggedStack.size() == 1) {
                                        if (foundations[i].isEmpty() && draggedCard.rank == 1) {
                                            moveStackTo(foundations[i]); placed = true; score += 10;
                                        } else if (!foundations[i].isEmpty()) {
                                            Card top = foundations[i].get(foundations[i].size() - 1);
                                            if (draggedCard.suit == top.suit && draggedCard.rank == top.rank + 1) {
                                                moveStackTo(foundations[i]); placed = true; score += 10;
                                            }
                                        }
                                    }
                                    break;
                                }
                            }
                        }
                        if (!placed) {
                            // Return to original
                            int origCol = getColFromX(lastX);
                            if (origCol >= 0 && origCol < 7) moveStackTo(columns[origCol]);
                            else if (draggedStack.size() == 1) waste.add(draggedCard);
                        }
                        draggedCard = null; draggedStack.clear();
                        GameScores.saveScore(getContext(), "solitaire", score);
                        invalidate();
                    }
                    break;
            }
            return true;
        }

        private void moveStackTo(List<Card> target) {
            int sourceCol = -1;
            for (int i = 0; i < 7; i++) {
                if (columns[i].contains(draggedCard)) { sourceCol = i; columns[i].removeAll(draggedStack); break; }
            }
            for (int i = 0; i < 4; i++) {
                if (foundations[i].contains(draggedCard)) { foundations[i].removeAll(draggedStack); break; }
            }
            if (waste.contains(draggedCard)) waste.removeAll(draggedStack);
            target.addAll(draggedStack);
        }
    }

    class Card {
        int suit, rank;
        boolean faceUp;
        Card(int s, int r) { suit = s; rank = r; faceUp = false; }
    }
}