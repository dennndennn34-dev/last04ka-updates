package com.last04ka.messenger.ui;

import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.last04ka.messenger.R;
import com.last04ka.messenger.utils.AppLogger;
import com.last04ka.messenger.utils.ThemeManager;

import java.util.ArrayList;
import java.util.List;

public class ChangelogChatActivity extends AppCompatActivity {

    private static final String TAG = "ChangelogChat";

    private RecyclerView recyclerView;
    private ChangelogAdapter adapter;
    private List<ChangelogEntry> entries = new ArrayList<>();

    // ==================== ТОЛЬКО ПОСЛЕДНЕЕ ОБНОВЛЕНИЕ ====================
    private static final ChangelogEntry CURRENT_UPDATE = new ChangelogEntry(
        "v2.5 — Шарик-приключение",
        "📅 20 июля 2026",
        "🎮 НОВАЯ ИГРА: ШАРИК-ПРИКЛЮЧЕНИЕ\n" +
        "   — 30 уровней с уникальным дизайном\n" +
        "   — Сбор звёзд и уничтожение врагов\n" +
        "   — Чекпоинты и система жизней\n" +
        "   — Интуитивное сенсорное управление\n" +
        "   — Сохранение прогресса и разблокировка уровней\n\n" +
        "🐛 ИСПРАВЛЕНИЯ БАГОВ:\n" +
        "   — Исправлена логика столкновения с врагами\n" +
        "   — Исправлено управление\n" +
        "   — Устранены проблемы с масштабированием\n" +
        "   — Оптимизировано логирование\n\n" +
        "💬 НОВОВВЕДЕНИЯ В ЧАТЕ:\n" +
        "   — Ободки для аватаров в чате\n" +
        "   — Настройка цвета ободка\n" +
        "   — Отображение серии в статистике\n\n" +
        "🔧 УЛУЧШЕНИЯ:\n" +
        "   — Увеличен размер кнопок управления\n" +
        "   — Добавлена вибрация\n" +
        "   — Улучшена плавность анимации\n" +
        "   — Обновлены цветовые схемы"
    );

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        setTheme(ThemeManager.getThemeResource(this));
        super.onCreate(savedInstanceState);
        AppLogger.log(this, TAG, "═══════════════════════════════════════════════════════════");
        AppLogger.log(this, TAG, "📋 ChangelogChatActivity onCreate START");
        AppLogger.log(this, TAG, "═══════════════════════════════════════════════════════════");

        try {
            setContentView(R.layout.activity_changelog_chat);
            AppLogger.log(this, TAG, "✅ Content view set");

            setTitle("📋 История изменений");

            initData();
            AppLogger.log(this, TAG, "✅ Data initialized");

            initRecyclerView();
            AppLogger.log(this, TAG, "✅ RecyclerView initialized");

            AppLogger.log(this, TAG, "═══════════════════════════════════════════════════════════");
            AppLogger.log(this, TAG, "📋 ChangelogChatActivity onCreate SUCCESS");
            AppLogger.log(this, TAG, "═══════════════════════════════════════════════════════════");

        } catch (Exception e) {
            AppLogger.logException(this, TAG, "❌ FATAL: onCreate error", e);
            Toast.makeText(this, "Ошибка: " + e.getMessage(), Toast.LENGTH_LONG).show();
            finish();
        }
    }

    private void initData() {
        AppLogger.log(this, TAG, "📊 initData() START");

        entries.clear();

        // Добавляем только текущую версию
        entries.add(CURRENT_UPDATE);
        AppLogger.log(this, TAG, "   Added: " + CURRENT_UPDATE.version);

        // Добавляем информацию о текущей установленной версии
        try {
            PackageInfo packageInfo = getPackageManager().getPackageInfo(getPackageName(), 0);
            String currentVersion = packageInfo.versionName + " (" + packageInfo.versionCode + ")";
            AppLogger.log(this, TAG, "   Current installed version: " + currentVersion);

            // Добавляем информацию о текущей версии в описание
            String firstEntry = entries.get(0).description;
            entries.get(0).description = firstEntry +
                    "\n\n📌 ТЕКУЩАЯ УСТАНОВЛЕННАЯ ВЕРСИЯ: " + currentVersion;
        } catch (PackageManager.NameNotFoundException e) {
            AppLogger.logException(this, TAG, "❌ Version info error", e);
        }

        AppLogger.log(this, TAG, "📊 initData() END: " + entries.size() + " entry");
    }

    private void initRecyclerView() {
        recyclerView = findViewById(R.id.recycler_changelog);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        adapter = new ChangelogAdapter(entries);
        recyclerView.setAdapter(adapter);

        AppLogger.log(this, TAG, "✅ RecyclerView configured");
    }

    // ==================== ADAPTER ====================

    private static class ChangelogAdapter extends RecyclerView.Adapter<ChangelogAdapter.ViewHolder> {

        private List<ChangelogEntry> entries;

        ChangelogAdapter(List<ChangelogEntry> entries) {
            this.entries = entries;
        }

        @Override
        public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            View view = LayoutInflater.from(parent.getContext())
                    .inflate(R.layout.item_changelog, parent, false);
            return new ViewHolder(view);
        }

        @Override
        public void onBindViewHolder(ViewHolder holder, int position) {
            ChangelogEntry entry = entries.get(position);
            holder.tvVersion.setText(entry.version);
            holder.tvDate.setText(entry.date);
            holder.tvDescription.setText(entry.description);

            AppLogger.log(null, "ChangelogAdapter", "📋 Bound: " + entry.version);
        }

        @Override
        public int getItemCount() {
            return entries.size();
        }

        static class ViewHolder extends RecyclerView.ViewHolder {
            TextView tvVersion, tvDate, tvDescription;

            ViewHolder(View itemView) {
                super(itemView);
                tvVersion = itemView.findViewById(R.id.tv_changelog_version);
                tvDate = itemView.findViewById(R.id.tv_changelog_date);
                tvDescription = itemView.findViewById(R.id.tv_changelog_description);
            }
        }
    }

    // ==================== DATA CLASS ====================

    private static class ChangelogEntry {
        String version;
        String date;
        String description;

        ChangelogEntry(String version, String date, String description) {
            this.version = version;
            this.date = date;
            this.description = description;
        }
    }
}