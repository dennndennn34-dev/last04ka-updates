package com.last04ka.messenger.ui;

import android.app.Activity;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.os.Bundle;
import android.os.Handler;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Toast;
import com.last04ka.messenger.utils.AppLogger;
import com.last04ka.messenger.utils.GameScores;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Random;

public class MemoryGameActivity extends Activity {

    private MemoryView memoryView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        try {
            memoryView = new MemoryView(this);
            memoryView.setFocusable(true); memoryView.setFocusableInTouchMode(true); memoryView.requestFocus();
            setContentView(memoryView);
            setTitle("🧠 Память | Рекорд: " + GameScores.getScore(this, "memory"));
        } catch (Exception e) { AppLogger.logException(this, "MemoryGame", e); finish(); }
    }

    @Override protected void onDestroy() { super.onDestroy(); if(memoryView!=null) GameScores.saveScore(this,"memory",memoryView.score); }

    class MemoryView extends View {
        private int cols=4, rows=4;
        private int[] cards=new int[cols*rows]; private boolean[] flipped=new boolean[cols*rows], matched=new boolean[cols*rows];
        private int firstCard=-1, secondCard=-1, score=0; private boolean locked; private Paint paint=new Paint();
        private Random random=new Random(); private Handler handler=new Handler();

        public MemoryView(Context context) {
            super(context);
            setFocusable(true); setFocusableInTouchMode(true);
            initGame();
        }

        private void initGame() {
            ArrayList<Integer> v=new ArrayList<>();
            for(int i=0;i<(cols*rows)/2;i++){int val=i%8;v.add(val);v.add(val);}
            Collections.shuffle(v,random);
            for(int i=0;i<v.size();i++) cards[i]=v.get(i);
        }

        private int[] getCardColors(int v){int[][] cc={{0xFFE53935,0xFFEF5350},{0xFF1E88E5,0xFF42A5F5},{0xFF43A047,0xFF66BB6A},{0xFFFB8C00,0xFFFFA726},{0xFF8E24AA,0xFFAB47BC},{0xFF00ACC1,0xFF26C6DA},{0xFFF4511E,0xFFFF7043},{0xFF3949AB,0xFF5C6BC0}};return cc[v%8];}

        @Override
        public boolean onTouchEvent(MotionEvent event) {
            if(event.getAction()==MotionEvent.ACTION_DOWN&&!locked){
                float cw=getWidth()/(float)cols, ch=getHeight()/(float)rows;
                int c=(int)(event.getX()/cw), r=(int)(event.getY()/ch), idx=r*cols+c;
                if(idx<0||idx>=cards.length||matched[idx]||flipped[idx])return true;
                flipped[idx]=true; invalidate();
                if(firstCard==-1) firstCard=idx;
                else if(secondCard==-1){secondCard=idx;locked=true;
                    handler.postDelayed(()->{if(cards[firstCard]==cards[secondCard]){matched[firstCard]=true;matched[secondCard]=true;score+=10;checkWin();}else{flipped[firstCard]=false;flipped[secondCard]=false;}firstCard=-1;secondCard=-1;locked=false;invalidate();},800);
                }
            } return true;
        }

        private void checkWin(){for(boolean m:matched)if(!m)return;score+=50;GameScores.saveScore(getContext(),"memory",score);Toast.makeText(getContext(),"Победа! Счёт: "+score,Toast.LENGTH_LONG).show();}

        @Override
        protected void onDraw(Canvas canvas) {
            float cw=getWidth()/(float)cols, ch=getHeight()/(float)rows;
            canvas.drawColor(Color.rgb(40,40,40));
            for(int r=0;r<rows;r++)for(int c=0;c<cols;c++){int idx=r*cols+c;float x=c*cw,y=r*ch;
                if(matched[idx]||flipped[idx]){int[] cc=getCardColors(cards[idx]);paint.setColor(cc[0]);canvas.drawRoundRect(x+4,y+4,x+cw-4,y+ch-4,8,8,paint);paint.setColor(cc[1]);canvas.drawCircle(x+cw/2,y+ch/2,cw/5,paint);}
                else{paint.setColor(Color.rgb(100,100,100));canvas.drawRoundRect(x+4,y+4,x+cw-4,y+ch-4,8,8,paint);paint.setColor(Color.WHITE);paint.setTextSize(30);paint.setTextAlign(Paint.Align.CENTER);canvas.drawText("?",x+cw/2,y+ch/2+10,paint);}
            }
            paint.setColor(Color.WHITE);paint.setTextSize(40);paint.setTextAlign(Paint.Align.CENTER);canvas.drawText("Счёт: "+score,getWidth()/2,getHeight()-20,paint);
        }
    }
}