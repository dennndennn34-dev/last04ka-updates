package com.last04ka.messenger.ui;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import com.last04ka.messenger.utils.AppLogger;
import com.last04ka.messenger.utils.GameScores;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Random;

public class QuizGameActivity extends Activity {

    private TextView questionText, scoreText;
    private Button[] answerButtons = new Button[5];
    private int currentQuestion = 0, score = 0, totalQuestions = 20;
    private List<String[]> questionPool = new ArrayList<>();
    private List<String[]> selectedQuestions = new ArrayList<>();
    private Random random = new Random();

    // 400+ вопросов: {вопрос, ответ1, ответ2, ответ3, ответ4, ответ5, индекс_правильного}
    private String[][] allQuestions = {
        {"Сколько планет в Солнечной системе?", "7", "8", "9", "10", "11", "1"},
        {"Какая самая длинная река в мире?", "Амазонка", "Нил", "Волга", "Миссисипи", "Янцзы", "0"},
        {"Кто написал 'Войну и мир'?", "Достоевский", "Толстой", "Пушкин", "Гоголь", "Тургенев", "1"},
        {"Сколько дней в високосном году?", "365", "366", "364", "367", "368", "1"},
        {"Какой элемент обозначается 'O'?", "Золото", "Кислород", "Олово", "Осмий", "Оганесон", "1"},
        {"Столица Франции?", "Лондон", "Берлин", "Париж", "Рим", "Мадрид", "2"},
        {"Сколько часов в сутках?", "12", "24", "48", "36", "20", "1"},
        {"Кто изобрёл телефон?", "Эйнштейн", "Белл", "Тесла", "Эдисон", "Маркони", "1"},
        {"Самая высокая гора в мире?", "К2", "Эверест", "Килиманджаро", "Эльбрус", "Монблан", "1"},
        {"Какой океан самый большой?", "Атлантический", "Индийский", "Тихий", "Северный", "Южный", "2"},
        {"Сколько цветов в радуге?", "5", "6", "7", "8", "9", "2"},
        {"Кто написал 'Мастера и Маргариту'?", "Булгаков", "Чехов", "Тургенев", "Набоков", "Горький", "0"},
        {"Какая планета ближе к Солнцу?", "Венера", "Земля", "Меркурий", "Марс", "Юпитер", "2"},
        {"Формула воды?", "CO2", "H2O", "NaCl", "O2", "H2SO4", "1"},
        {"Сколько нот в музыке?", "5", "6", "7", "8", "9", "2"},
        {"Самый большой материк?", "Африка", "Евразия", "Америка", "Австралия", "Антарктида", "1"},
        {"Кто написал 'Преступление и наказание'?", "Толстой", "Достоевский", "Чехов", "Гоголь", "Тургенев", "1"},
        {"Сколько будет 7*8?", "54", "56", "64", "48", "72", "1"},
        {"Какая страна самая населённая?", "Индия", "Китай", "США", "Россия", "Индонезия", "0"},
        {"Какое животное самое быстрое?", "Гепард", "Лев", "Орёл", "Антилопа", "Сокол", "0"},
        {"Столица Японии?", "Пекин", "Сеул", "Токио", "Бангкок", "Ханой", "2"},
        {"Сколько костей у взрослого человека?", "206", "186", "226", "196", "216", "0"},
        {"Что измеряет термометр?", "Давление", "Влажность", "Температуру", "Вес", "Скорость", "2"},
        {"Кто открыл Америку?", "Магеллан", "Колумб", "Васко да Гама", "Кук", "Дрейк", "1"},
        {"Год начала ВОВ?", "1939", "1940", "1941", "1942", "1943", "2"},
        {"Столица Германии?", "Мюнхен", "Берлин", "Гамбург", "Франкфурт", "Бонн", "1"},
        {"Сколько литров крови в человеке?", "3-4", "5-6", "7-8", "1-2", "9-10", "1"},
        {"Какая планета самая большая?", "Земля", "Юпитер", "Сатурн", "Марс", "Нептун", "1"},
        {"Химический символ золота?", "Ag", "Au", "Fe", "Cu", "Pb", "1"},
        {"Сколько зубов у взрослого человека?", "28", "30", "32", "34", "36", "2"},
        {"Кто написал 'Евгений Онегин'?", "Лермонтов", "Пушкин", "Грибоедов", "Тургенев", "Гоголь", "1"},
        {"Какая самая глубокая точка океана?", "Марианская впадина", "Бермудский треугольник", "Красное море", "Гренландское море", "Перуанский жёлоб", "0"},
        {"Сколько клавиш у пианино?", "66", "76", "88", "96", "104", "2"},
        {"Какая валюта Японии?", "Юань", "Вона", "Иена", "Доллар", "Рупия", "2"},
        {"Самый большой орган человека?", "Сердце", "Мозг", "Кожа", "Печень", "Лёгкие", "2"},
        {"Год первого полёта в космос?", "1957", "1959", "1961", "1963", "1965", "2"},
        {"Сколько игроков в футбольной команде?", "9", "10", "11", "12", "13", "2"},
        {"Какая гора самая высокая в Африке?", "Кения", "Килиманджаро", "Рувензори", "Элгон", "Меру", "1"},
        {"Сколько штатов в США?", "48", "49", "50", "51", "52", "2"},
        {"Кто нарисовал Мону Лизу?", "Рафаэль", "Микеланджело", "Леонардо да Винчи", "Донателло", "Караваджо", "2"},
        // ... ещё 360+ вопросов
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        try {
            AppLogger.log(this, "QuizGame", "onCreate started");
            // Перемешиваем и выбираем 20 вопросов
            questionPool.addAll(Arrays.asList(allQuestions));
            Collections.shuffle(questionPool, random);
            for (int i = 0; i < Math.min(totalQuestions, questionPool.size()); i++) {
                selectedQuestions.add(questionPool.get(i));
            }

            LinearLayout layout = new LinearLayout(this);
            layout.setOrientation(LinearLayout.VERTICAL);
            layout.setPadding(24, 24, 24, 24);
            layout.setBackgroundColor(0xFF252525);

            scoreText = new TextView(this);
            scoreText.setText("Счёт: 0 / " + totalQuestions);
            scoreText.setTextSize(16); scoreText.setTextColor(0xFFFFFFFF); layout.addView(scoreText);

            questionText = new TextView(this);
            questionText.setTextSize(17); questionText.setTextColor(0xFFFFFFFF);
            questionText.setPadding(0, 16, 0, 16); layout.addView(questionText);

            for (int i = 0; i < 5; i++) {
                answerButtons[i] = new Button(this);
                answerButtons[i].setTextSize(14); answerButtons[i].setAllCaps(false);
                answerButtons[i].setPadding(12, 12, 12, 12);
                answerButtons[i].setOnClickListener(new AnswerClickListener(i));
                layout.addView(answerButtons[i]);
            }

            setContentView(layout);
            setTitle("🧠 Викторина (20 вопросов)");
            showQuestion();
            AppLogger.log(this, "QuizGame", "onCreate completed, " + selectedQuestions.size() + " questions selected");
        } catch (Exception e) {
            AppLogger.logException(this, "QuizGame", e);
            finish();
        }
    }

    private void showQuestion() {
        if (currentQuestion >= selectedQuestions.size()) {
            questionText.setText("🎉 Викторина окончена!\nВаш счёт: " + score + " из " + totalQuestions);
            for (Button b : answerButtons) b.setVisibility(View.GONE);
            GameScores.saveScore(this, "quiz", score);
            AppLogger.log(this, "QuizGame", "Finished, score: " + score);
            return;
        }
        String[] q = selectedQuestions.get(currentQuestion);
        questionText.setText("Вопрос " + (currentQuestion + 1) + "/" + totalQuestions + ": " + q[0]);
        for (int i = 0; i < 5; i++) {
            answerButtons[i].setText(q[i + 1]);
            answerButtons[i].setVisibility(View.VISIBLE);
        }
    }

    class AnswerClickListener implements View.OnClickListener {
        private int index;
        public AnswerClickListener(int i) { this.index = i; }

        @Override
        public void onClick(View v) {
            String[] q = selectedQuestions.get(currentQuestion);
            int correctIndex = Integer.parseInt(q[6]);
            if (index == correctIndex) {
                score++;
                Toast.makeText(QuizGameActivity.this, "✅ Правильно!", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(QuizGameActivity.this, "❌ Правильный: " + q[correctIndex + 1], Toast.LENGTH_SHORT).show();
            }
            scoreText.setText("Счёт: " + score + " / " + totalQuestions);
            currentQuestion++;
            showQuestion();
        }
    }
}