package com.last04ka.messenger.ui;

import android.app.Activity;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import com.last04ka.messenger.utils.AppLogger;
import com.last04ka.messenger.utils.GameScores;
import java.util.Random;

public class MathBlitzActivity extends Activity {

    private TextView questionText, scoreText, timerText;
    private EditText input;
    private Button btnAnswer, btnStart;
    private int score, total, correct, a, b, answer;
    private char op;
    private CountDownTimer timer;
    private Random r = new Random();
    private boolean gameActive = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        try {
            LinearLayout layout = new LinearLayout(this);
            layout.setOrientation(LinearLayout.VERTICAL);
            layout.setPadding(24, 24, 24, 24);
            layout.setBackgroundColor(0xFF1A1A2E);

            timerText = new TextView(this);
            timerText.setText("⏱ 60");
            timerText.setTextSize(28);
            timerText.setTextColor(0xFFFF5252);
            timerText.setGravity(android.view.Gravity.CENTER);
            layout.addView(timerText);

            scoreText = new TextView(this);
            scoreText.setText("✅ 0 / 0 | Рекорд: " + GameScores.getScore(this, "mathblitz"));
            scoreText.setTextSize(16);
            scoreText.setTextColor(0xFFBDBDBD);
            scoreText.setGravity(android.view.Gravity.CENTER);
            scoreText.setPadding(0, 8, 0, 16);
            layout.addView(scoreText);

            questionText = new TextView(this);
            questionText.setTextSize(40);
            questionText.setTextColor(0xFFFFFFFF);
            questionText.setGravity(android.view.Gravity.CENTER);
            questionText.setPadding(0, 24, 0, 24);
            layout.addView(questionText);

            input = new EditText(this);
            input.setHint("Ответ");
            input.setInputType(android.text.InputType.TYPE_CLASS_NUMBER | android.text.InputType.TYPE_NUMBER_FLAG_SIGNED);
            input.setTextColor(0xFFFFFFFF);
            input.setHintTextColor(0xFF757575);
            input.setTextSize(28);
            input.setGravity(android.view.Gravity.CENTER);
            input.setEnabled(false);
            layout.addView(input);

            btnAnswer = new Button(this);
            btnAnswer.setText("Ответить");
            btnAnswer.setEnabled(false);
            btnAnswer.setTextSize(18);
            btnAnswer.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    checkAnswer();
                }
            });
            layout.addView(btnAnswer);

            btnStart = new Button(this);
            btnStart.setText("Начать (30 примеров)");
            btnStart.setTextSize(18);
            btnStart.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    startGame();
                }
            });
            layout.addView(btnStart);

            setContentView(layout);
            setTitle("🧠 Математический блиц");
        } catch (Exception e) {
            AppLogger.logException(this, "MathBlitz", e);
            finish();
        }
    }

    private void startGame() {
        score = 0;
        total = 0;
        correct = 0;
        gameActive = true;
        btnStart.setEnabled(false);
        btnAnswer.setEnabled(true);
        input.setEnabled(true);
        input.requestFocus();

        timer = new CountDownTimer(60000, 1000) {
            @Override
            public void onTick(long millis) {
                timerText.setText("⏱ " + (millis / 1000));
            }
            @Override
            public void onFinish() {
                timerText.setText("⏱ 0");
                endGame();
            }
        }.start();

        nextQuestion();
    }

    private void endGame() {
        gameActive = false;
        btnAnswer.setEnabled(false);
        input.setEnabled(false);
        btnStart.setEnabled(true);
        btnStart.setText("Начать заново");
        questionText.setText("🏆 Итог: " + correct + " / " + total);
        GameScores.saveScore(this, "mathblitz", correct);
        scoreText.setText("✅ " + correct + " / " + total + " | Рекорд: " + GameScores.getScore(this, "mathblitz"));
        Toast.makeText(this, "Время! Правильно: " + correct + " из " + total, Toast.LENGTH_LONG).show();
    }

    private void nextQuestion() {
        if (!gameActive) return;
        op = "+-×÷".charAt(r.nextInt(4));
        a = r.nextInt(20) + 1;
        b = r.nextInt(20) + 1;

        switch (op) {
            case '+': answer = a + b; break;
            case '-':
                if (a < b) { int t = a; a = b; b = t; }
                answer = a - b;
                break;
            case '×': answer = a * b; break;
            case '÷':
                answer = b;
                a = answer * (r.nextInt(10) + 1);
                break;
        }

        questionText.setText(a + " " + op + " " + b + " = ?");
        input.setText("");
        input.requestFocus();
    }

    private void checkAnswer() {
        String s = input.getText().toString().trim();
        if (s.isEmpty()) return;

        total++;
        int userAnswer;
        try {
            userAnswer = Integer.parseInt(s);
        } catch (NumberFormatException e) {
            Toast.makeText(this, "Введите число", Toast.LENGTH_SHORT).show();
            return;
        }

        if (userAnswer == answer) {
            correct++;
            score += 10;
            Toast.makeText(this, "✅", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, "❌ " + a + op + b + "=" + answer, Toast.LENGTH_SHORT).show();
        }

        scoreText.setText("✅ " + correct + " / " + total + " | Рекорд: " + GameScores.getScore(this, "mathblitz"));
        nextQuestion();
    }
}