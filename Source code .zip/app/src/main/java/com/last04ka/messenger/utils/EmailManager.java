package com.last04ka.messenger.utils;

import android.content.Context;
import android.content.SharedPreferences;
import android.util.Base64;

import com.last04ka.messenger.data.DatabaseHelper;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.security.SecureRandom;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Properties;
import java.util.UUID;

import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.SecretKeySpec;
import javax.mail.Flags;
import javax.mail.Folder;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Multipart;
import javax.mail.Part;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Store;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;

public class EmailManager {
    private static final String TAG = "EmailManager";
    private static final String PREFS = "email_prefs";
    private static final String KEY_ENCRYPTION_KEY = "encryption_key";

    private Context context;
    private DatabaseHelper dbHelper;
    private SecretKey encryptionKey;

    // Текущий аккаунт
    private Account currentAccount;
    private Store currentStore;
    private Folder currentFolder;

    // ==================== ПРОВАЙДЕРЫ ====================
    public static final Provider[] PROVIDERS = {
        new Provider("Gmail", "imap.gmail.com", 993, true, "smtp.gmail.com", 587, true),
        new Provider("Mail.ru", "imap.mail.ru", 993, true, "smtp.mail.ru", 465, true)
    };

    // ==================== МОДЕЛИ ====================
    public static class Account {
        public String id;
        public String email;
        public String password; // зашифрован
        public String displayName;
        public String provider;
        public String imapServer;
        public int imapPort;
        public boolean imapSsl;
        public String smtpServer;
        public int smtpPort;
        public boolean smtpSsl;
        public boolean isActive;
        public long createdAt;

        public Account() {}

        public Account(String email, String password, String provider) {
            this.id = UUID.randomUUID().toString();
            this.email = email;
            this.password = password;
            this.provider = provider;
            this.displayName = email;
            this.isActive = false;
            this.createdAt = System.currentTimeMillis();

            // Настройки по умолчанию для провайдера
            for (Provider p : PROVIDERS) {
                if (p.name.equals(provider)) {
                    this.imapServer = p.imapServer;
                    this.imapPort = p.imapPort;
                    this.imapSsl = p.imapSsl;
                    this.smtpServer = p.smtpServer;
                    this.smtpPort = p.smtpPort;
                    this.smtpSsl = p.smtpSsl;
                    break;
                }
            }
        }
    }

    public static class Provider {
        public String name;
        public String imapServer;
        public int imapPort;
        public boolean imapSsl;
        public String smtpServer;
        public int smtpPort;
        public boolean smtpSsl;

        public Provider(String name, String imapServer, int imapPort, boolean imapSsl,
                       String smtpServer, int smtpPort, boolean smtpSsl) {
            this.name = name;
            this.imapServer = imapServer;
            this.imapPort = imapPort;
            this.imapSsl = imapSsl;
            this.smtpServer = smtpServer;
            this.smtpPort = smtpPort;
            this.smtpSsl = smtpSsl;
        }
    }

    public static class EmailMessage {
        public String id;
        public String from;
        public String fromName;
        public String to;
        public String subject;
        public String body;
        public String bodyHtml;
        public long date;
        public boolean isRead;
        public boolean isStarred;
        public String folder;
        public boolean hasAttachments;

        public EmailMessage() {}

        public String getDateFormatted() {
            return new SimpleDateFormat("dd.MM.yyyy HH:mm", Locale.getDefault()).format(new Date(date));
        }

        public String getShortDate() {
            long now = System.currentTimeMillis();
            long diff = now - date;
            if (diff < 60000) return "только что";
            if (diff < 3600000) return (diff / 60000) + " мин";
            if (diff < 86400000) return (diff / 3600000) + " ч";
            return new SimpleDateFormat("dd.MM", Locale.getDefault()).format(new Date(date));
        }
    }

    // ==================== КОНСТРУКТОР ====================

    public EmailManager(Context context) {
        this.context = context;
        this.dbHelper = new DatabaseHelper(context);
        AppLogger.log(context, TAG, "📧 EmailManager initialized");
        initEncryption();
        createEmailTables();
    }

    // ==================== ШИФРОВАНИЕ ====================

    private void initEncryption() {
        AppLogger.log(context, TAG, "🔐 initEncryption() START");
        SharedPreferences prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        String keyBase64 = prefs.getString(KEY_ENCRYPTION_KEY, "");

        try {
            if (keyBase64.isEmpty()) {
                AppLogger.log(context, TAG, "   Generating new encryption key...");
                KeyGenerator keyGen = KeyGenerator.getInstance("AES");
                keyGen.init(256, new SecureRandom());
                SecretKey key = keyGen.generateKey();
                byte[] keyBytes = key.getEncoded();
                keyBase64 = Base64.encodeToString(keyBytes, Base64.DEFAULT);
                prefs.edit().putString(KEY_ENCRYPTION_KEY, keyBase64).apply();
                AppLogger.log(context, TAG, "✅ New encryption key generated");
            }

            byte[] keyBytes = Base64.decode(keyBase64, Base64.DEFAULT);
            encryptionKey = new SecretKeySpec(keyBytes, "AES");
            AppLogger.log(context, TAG, "✅ Encryption key loaded");
        } catch (Exception e) {
            AppLogger.logException(context, TAG, "❌ Encryption init error", e);
        }
    }

    public String encrypt(String data) {
        if (data == null || data.isEmpty()) return data;
        try {
            Cipher cipher = Cipher.getInstance("AES/ECB/PKCS5Padding");
            cipher.init(Cipher.ENCRYPT_MODE, encryptionKey);
            byte[] encrypted = cipher.doFinal(data.getBytes("UTF-8"));
            return Base64.encodeToString(encrypted, Base64.DEFAULT);
        } catch (Exception e) {
            AppLogger.logException(context, TAG, "❌ Encryption error", e);
            return data;
        }
    }

    public String decrypt(String data) {
        if (data == null || data.isEmpty()) return data;
        try {
            byte[] encrypted = Base64.decode(data, Base64.DEFAULT);
            Cipher cipher = Cipher.getInstance("AES/ECB/PKCS5Padding");
            cipher.init(Cipher.DECRYPT_MODE, encryptionKey);
            byte[] decrypted = cipher.doFinal(encrypted);
            return new String(decrypted, "UTF-8");
        } catch (Exception e) {
            AppLogger.logException(context, TAG, "❌ Decryption error", e);
            return data;
        }
    }

    // ==================== БАЗА ДАННЫХ ====================

    private void createEmailTables() {
        AppLogger.log(context, TAG, "📊 createEmailTables() START");
        try {
            dbHelper.getWritableDatabase().execSQL(
                "CREATE TABLE IF NOT EXISTS email_accounts (" +
                "id TEXT PRIMARY KEY, " +
                "email TEXT NOT NULL, " +
                "password TEXT NOT NULL, " +
                "display_name TEXT, " +
                "provider TEXT, " +
                "imap_server TEXT, " +
                "imap_port INTEGER, " +
                "imap_ssl INTEGER, " +
                "smtp_server TEXT, " +
                "smtp_port INTEGER, " +
                "smtp_ssl INTEGER, " +
                "is_active INTEGER DEFAULT 0, " +
                "created_at INTEGER DEFAULT 0" +
                ")"
            );
            AppLogger.log(context, TAG, "✅ Email tables created/checked");
        } catch (Exception e) {
            AppLogger.logException(context, TAG, "❌ Create table error", e);
        }
    }

    // ==================== УПРАВЛЕНИЕ АККАУНТАМИ ====================

    public void saveAccount(Account account) {
        AppLogger.log(context, TAG, "💾 saveAccount() called: " + account.email);
        try {
            android.content.ContentValues cv = new android.content.ContentValues();
            cv.put("id", account.id);
            cv.put("email", account.email);
            cv.put("password", encrypt(account.password));
            cv.put("display_name", account.displayName != null ? account.displayName : account.email);
            cv.put("provider", account.provider);
            cv.put("imap_server", account.imapServer);
            cv.put("imap_port", account.imapPort);
            cv.put("imap_ssl", account.imapSsl ? 1 : 0);
            cv.put("smtp_server", account.smtpServer);
            cv.put("smtp_port", account.smtpPort);
            cv.put("smtp_ssl", account.smtpSsl ? 1 : 0);
            cv.put("is_active", account.isActive ? 1 : 0);
            cv.put("created_at", account.createdAt);

            dbHelper.getWritableDatabase().insertWithOnConflict(
                "email_accounts", null, cv, android.database.sqlite.SQLiteDatabase.CONFLICT_REPLACE
            );
            AppLogger.log(context, TAG, "✅ Account saved: " + account.email);
        } catch (Exception e) {
            AppLogger.logException(context, TAG, "❌ saveAccount error", e);
        }
    }

    public List<Account> getAccounts() {
        AppLogger.log(context, TAG, "📂 getAccounts() called");
        List<Account> accounts = new ArrayList<>();
        try {
            android.database.Cursor c = dbHelper.getReadableDatabase().rawQuery(
                "SELECT * FROM email_accounts ORDER BY is_active DESC, created_at DESC", null
            );
            while (c.moveToNext()) {
                Account a = new Account();
                a.id = c.getString(0);
                a.email = c.getString(1);
                a.password = decrypt(c.getString(2));
                a.displayName = c.getString(3);
                a.provider = c.getString(4);
                a.imapServer = c.getString(5);
                a.imapPort = c.getInt(6);
                a.imapSsl = c.getInt(7) == 1;
                a.smtpServer = c.getString(8);
                a.smtpPort = c.getInt(9);
                a.smtpSsl = c.getInt(10) == 1;
                a.isActive = c.getInt(11) == 1;
                a.createdAt = c.getLong(12);
                accounts.add(a);
            }
            c.close();
            AppLogger.log(context, TAG, "   Found " + accounts.size() + " accounts");
        } catch (Exception e) {
            AppLogger.logException(context, TAG, "❌ getAccounts error", e);
        }
        return accounts;
    }

    public Account getActiveAccount() {
        AppLogger.log(context, TAG, "📂 getActiveAccount() called");
        List<Account> accounts = getAccounts();
        for (Account a : accounts) {
            if (a.isActive) {
                AppLogger.log(context, TAG, "   Active account: " + a.email);
                return a;
            }
        }
        if (!accounts.isEmpty()) {
            AppLogger.log(context, TAG, "   No active account, returning first: " + accounts.get(0).email);
            return accounts.get(0);
        }
        AppLogger.log(context, TAG, "   No accounts found");
        return null;
    }

    public void setActiveAccount(String accountId) {
        AppLogger.log(context, TAG, "📂 setActiveAccount() called: " + accountId);
        try {
            dbHelper.getWritableDatabase().execSQL(
                "UPDATE email_accounts SET is_active = 0"
            );
            dbHelper.getWritableDatabase().execSQL(
                "UPDATE email_accounts SET is_active = 1 WHERE id = ?",
                new String[]{accountId}
            );
            AppLogger.log(context, TAG, "✅ Active account set: " + accountId);
        } catch (Exception e) {
            AppLogger.logException(context, TAG, "❌ setActiveAccount error", e);
        }
    }

    public void deleteAccount(String accountId) {
        AppLogger.log(context, TAG, "🗑️ deleteAccount() called: " + accountId);
        try {
            dbHelper.getWritableDatabase().delete("email_accounts", "id=?", new String[]{accountId});
            AppLogger.log(context, TAG, "✅ Account deleted: " + accountId);
        } catch (Exception e) {
            AppLogger.logException(context, TAG, "❌ deleteAccount error", e);
        }
    }

    // ==================== ПРОВЕРКА ПОДКЛЮЧЕНИЯ ====================

    public LoginResult testConnection(String email, String password, Provider provider) {
        AppLogger.log(context, TAG, "🔌 testConnection() START");
        AppLogger.log(context, TAG, "   email: " + email);
        AppLogger.log(context, TAG, "   provider: " + provider.name);

        LoginResult result = new LoginResult();

        try {
            // Настройки IMAP
            Properties props = new Properties();
            props.put("mail.imap.host", provider.imapServer);
            props.put("mail.imap.port", String.valueOf(provider.imapPort));
            props.put("mail.imap.ssl.enable", String.valueOf(provider.imapSsl));
            props.put("mail.imap.connectiontimeout", "10000");
            props.put("mail.imap.timeout", "10000");

            Session session = Session.getInstance(props, new javax.mail.Authenticator() {
                protected PasswordAuthentication getPasswordAuthentication() {
                    return new PasswordAuthentication(email, password);
                }
            });

            AppLogger.log(context, TAG, "   Connecting to IMAP: " + provider.imapServer + ":" + provider.imapPort);
            Store store = session.getStore("imap");
            store.connect(provider.imapServer, provider.imapPort, email, password);

            AppLogger.log(context, TAG, "✅ IMAP connection successful");
            store.close();

            result.success = true;
            result.message = "Подключение успешно!";

            // Проверяем SMTP
            try {
                AppLogger.log(context, TAG, "   Testing SMTP...");
                Properties smtpProps = new Properties();
                smtpProps.put("mail.smtp.host", provider.smtpServer);
                smtpProps.put("mail.smtp.port", String.valueOf(provider.smtpPort));
                smtpProps.put("mail.smtp.ssl.enable", String.valueOf(provider.smtpSsl));
                smtpProps.put("mail.smtp.auth", "true");
                smtpProps.put("mail.smtp.connectiontimeout", "10000");

                Session smtpSession = Session.getInstance(smtpProps, new javax.mail.Authenticator() {
                    protected PasswordAuthentication getPasswordAuthentication() {
                        return new PasswordAuthentication(email, password);
                    }
                });

                Transport transport = smtpSession.getTransport("smtp");
                transport.connect(provider.smtpServer, provider.smtpPort, email, password);
                transport.close();

                AppLogger.log(context, TAG, "✅ SMTP connection successful");
                result.message = "Подключение успешно! IMAP + SMTP работают.";
            } catch (Exception smtpError) {
                AppLogger.log(context, TAG, "⚠️ SMTP failed but IMAP works: " + smtpError.getMessage());
                result.message = "IMAP работает, но SMTP не доступен (отправка будет недоступна)";
            }

        } catch (javax.mail.AuthenticationFailedException e) {
            AppLogger.logException(context, TAG, "❌ Authentication failed", e);
            result.success = false;
            result.message = "❌ Неверный логин или пароль. Проверьте данные.";
            result.isAuthError = true;

            // Проверяем, может быть нужен пароль приложения
            if (email.endsWith("@gmail.com")) {
                result.message += "\n\n💡 Для Gmail с двухфакторной аутентификацией используйте ПАРОЛЬ ПРИЛОЖЕНИЯ.\nСоздайте его в настройках Google Account → Безопасность → Пароли приложений.";
            }

        } catch (javax.mail.MessagingException e) {
            AppLogger.logException(context, TAG, "❌ Messaging error", e);
            result.success = false;
            result.message = "❌ Ошибка соединения: " + e.getMessage();
        } catch (Exception e) {
            AppLogger.logException(context, TAG, "❌ Unknown error", e);
            result.success = false;
            result.message = "❌ Ошибка: " + e.getMessage();
        }

        AppLogger.log(context, TAG, "   Result: success=" + result.success + ", message=" + result.message);
        return result;
    }

    public static class LoginResult {
        public boolean success;
        public String message;
        public boolean isAuthError;
    }

    // ==================== РАБОТА С ПОЧТОЙ ====================

    private Store connectToStore(Account account) throws Exception {
        AppLogger.log(context, TAG, "🔌 connectToStore() for: " + account.email);

        Properties props = new Properties();
        props.put("mail.imap.host", account.imapServer);
        props.put("mail.imap.port", String.valueOf(account.imapPort));
        props.put("mail.imap.ssl.enable", String.valueOf(account.imapSsl));
        props.put("mail.imap.connectiontimeout", "15000");
        props.put("mail.imap.timeout", "15000");

        Session session = Session.getInstance(props, new javax.mail.Authenticator() {
            protected PasswordAuthentication getPasswordAuthentication() {
                return new PasswordAuthentication(account.email, account.password);
            }
        });

        Store store = session.getStore("imap");
        store.connect(account.imapServer, account.imapPort, account.email, account.password);

        AppLogger.log(context, TAG, "✅ Store connected for: " + account.email);
        return store;
    }

    public List<String> getFolders() {
        AppLogger.log(context, TAG, "📂 getFolders() called");
        List<String> folders = new ArrayList<>();

        try {
            if (currentStore == null || !currentStore.isConnected()) {
                Account account = getActiveAccount();
                if (account == null) {
                    AppLogger.log(context, TAG, "   No active account");
                    return folders;
                }
                currentStore = connectToStore(account);
            }

            Folder[] defaultFolders = currentStore.getDefaultFolder().list();
            for (Folder f : defaultFolders) {
                if ((f.getType() & Folder.HOLDS_MESSAGES) != 0) {
                    String name = f.getName();
                    // Оставляем только нужные папки
                    if (name.equalsIgnoreCase("INBOX") ||
                        name.equalsIgnoreCase("[Gmail]/Sent Mail") ||
                        name.equalsIgnoreCase("Sent") ||
                        name.equalsIgnoreCase("Отправленные") ||
                        name.equalsIgnoreCase("[Gmail]/Trash") ||
                        name.equalsIgnoreCase("Trash") ||
                        name.equalsIgnoreCase("Корзина") ||
                        name.equalsIgnoreCase("[Gmail]/Spam") ||
                        name.equalsIgnoreCase("Spam") ||
                        name.equalsIgnoreCase("Спам") ||
                        name.equalsIgnoreCase("Drafts") ||
                        name.equalsIgnoreCase("Черновики") ||
                        name.equalsIgnoreCase("[Gmail]/Drafts")) {
                        folders.add(name);
                    }
                }
            }

            // Если папок мало, добавляем стандартные
            if (folders.isEmpty()) {
                folders.add("INBOX");
                folders.add("Sent");
                folders.add("Trash");
                folders.add("Spam");
                folders.add("Drafts");
            }

            AppLogger.log(context, TAG, "   Found " + folders.size() + " folders");

        } catch (Exception e) {
            AppLogger.logException(context, TAG, "❌ getFolders error", e);
        }

        return folders;
    }

    public List<EmailMessage> getMessages(String folderName, int limit) {
        AppLogger.log(context, TAG, "📨 getMessages() called: folder=" + folderName + ", limit=" + limit);
        List<EmailMessage> messages = new ArrayList<>();

        try {
            if (currentStore == null || !currentStore.isConnected()) {
                Account account = getActiveAccount();
                if (account == null) {
                    AppLogger.log(context, TAG, "   No active account");
                    return messages;
                }
                currentStore = connectToStore(account);
            }

            Folder folder = currentStore.getFolder(folderName);
            if (folder == null || !folder.exists()) {
                AppLogger.log(context, TAG, "   Folder not found: " + folderName);
                // Пробуем найти альтернативное имя
                String[] alternatives = getFolderAlternatives(folderName);
                for (String alt : alternatives) {
                    folder = currentStore.getFolder(alt);
                    if (folder != null && folder.exists()) {
                        AppLogger.log(context, TAG, "   Found alternative: " + alt);
                        break;
                    }
                }
                if (folder == null || !folder.exists()) {
                    AppLogger.log(context, TAG, "   Still not found, returning empty");
                    return messages;
                }
            }

            folder.open(Folder.READ_ONLY);

            int total = folder.getMessageCount();
            int start = Math.max(1, total - limit + 1);
            int end = total;

            AppLogger.log(context, TAG, "   Total messages: " + total + ", fetching " + start + "-" + end);

            Message[] msgs = folder.getMessages(start, end);

            for (int i = msgs.length - 1; i >= 0; i--) {
                Message msg = msgs[i];
                try {
                    EmailMessage em = new EmailMessage();
                    em.id = UUID.randomUUID().toString();
                    em.folder = folderName;

                    // Дата
                    Date date = msg.getSentDate();
                    em.date = date != null ? date.getTime() : System.currentTimeMillis();

                    // Отправитель
                    javax.mail.Address[] from = msg.getFrom();
                    if (from != null && from.length > 0) {
                        InternetAddress addr = (InternetAddress) from[0];
                        em.from = addr.getAddress();
                        em.fromName = addr.getPersonal() != null ? addr.getPersonal() : addr.getAddress();
                    }

                    // Тема
                    em.subject = msg.getSubject();
                    if (em.subject == null) em.subject = "(без темы)";

                    // Флаги
                    em.isRead = msg.isSet(Flags.Flag.SEEN);
                    em.isStarred = msg.isSet(Flags.Flag.FLAGGED);

                    // Тело
                    Object content = msg.getContent();
                    if (content instanceof String) {
                        em.body = (String) content;
                    } else if (content instanceof Multipart) {
                        Multipart multipart = (Multipart) content;
                        for (int j = 0; j < multipart.getCount(); j++) {
                            Part part = multipart.getBodyPart(j);
                            String disposition = part.getDisposition();
                            String contentType = part.getContentType();

                            if (disposition != null && disposition.equals(Part.ATTACHMENT)) {
                                em.hasAttachments = true;
                            }

                            if (part.isMimeType("text/plain") && em.body == null) {
                                em.body = (String) part.getContent();
                            } else if (part.isMimeType("text/html") && em.bodyHtml == null) {
                                em.bodyHtml = (String) part.getContent();
                            } else if (part.getContent() instanceof Multipart) {
                                // Вложенный multipart
                                Multipart inner = (Multipart) part.getContent();
                                for (int k = 0; k < inner.getCount(); k++) {
                                    Part innerPart = inner.getBodyPart(k);
                                    if (innerPart.isMimeType("text/plain") && em.body == null) {
                                        em.body = (String) innerPart.getContent();
                                    } else if (innerPart.isMimeType("text/html") && em.bodyHtml == null) {
                                        em.bodyHtml = (String) innerPart.getContent();
                                    }
                                }
                            }
                        }
                    }

                    if (em.body == null && em.bodyHtml != null) {
                        em.body = htmlToText(em.bodyHtml);
                    }
                    if (em.body == null) em.body = "(нет содержимого)";

                    messages.add(em);

                } catch (Exception e) {
                    AppLogger.logException(context, TAG, "❌ Error processing message", e);
                }
            }

            folder.close(false);

            AppLogger.log(context, TAG, "✅ Loaded " + messages.size() + " messages");

        } catch (Exception e) {
            AppLogger.logException(context, TAG, "❌ getMessages error", e);
        }

        return messages;
    }

    private String[] getFolderAlternatives(String name) {
        if (name.equalsIgnoreCase("INBOX")) return new String[]{"INBOX"};
        if (name.equalsIgnoreCase("Sent") || name.equalsIgnoreCase("Отправленные")) {
            return new String[]{"Sent", "Отправленные", "[Gmail]/Sent Mail"};
        }
        if (name.equalsIgnoreCase("Trash") || name.equalsIgnoreCase("Корзина")) {
            return new String[]{"Trash", "Корзина", "[Gmail]/Trash"};
        }
        if (name.equalsIgnoreCase("Spam") || name.equalsIgnoreCase("Спам")) {
            return new String[]{"Spam", "Спам", "[Gmail]/Spam"};
        }
        if (name.equalsIgnoreCase("Drafts") || name.equalsIgnoreCase("Черновики")) {
            return new String[]{"Drafts", "Черновики", "[Gmail]/Drafts"};
        }
        return new String[]{name};
    }

    public boolean markAsRead(String messageId, boolean read) {
        AppLogger.log(context, TAG, "📨 markAsRead() called: id=" + messageId + ", read=" + read);
        // Для упрощения — пока не реализуем
        return false;
    }

    public boolean deleteMessage(String messageId) {
        AppLogger.log(context, TAG, "🗑️ deleteMessage() called: id=" + messageId);
        // Для упрощения — пока не реализуем
        return false;
    }

    // ==================== ОТПРАВКА ПИСЬМА ====================

    public boolean sendEmail(String to, String subject, String body) {
        AppLogger.log(context, TAG, "📤 sendEmail() called");
        AppLogger.log(context, TAG, "   to: " + to);
        AppLogger.log(context, TAG, "   subject: " + subject);
        AppLogger.log(context, TAG, "   body length: " + (body != null ? body.length() : 0));

        try {
            Account account = getActiveAccount();
            if (account == null) {
                AppLogger.log(context, TAG, "❌ No active account");
                return false;
            }

            Properties props = new Properties();
            props.put("mail.smtp.host", account.smtpServer);
            props.put("mail.smtp.port", String.valueOf(account.smtpPort));
            props.put("mail.smtp.ssl.enable", String.valueOf(account.smtpSsl));
            props.put("mail.smtp.auth", "true");
            props.put("mail.smtp.connectiontimeout", "15000");

            Session session = Session.getInstance(props, new javax.mail.Authenticator() {
                protected PasswordAuthentication getPasswordAuthentication() {
                    return new PasswordAuthentication(account.email, account.password);
                }
            });

            MimeMessage message = new MimeMessage(session);
            message.setFrom(new InternetAddress(account.email, account.displayName));
            message.setRecipients(MimeMessage.RecipientType.TO, InternetAddress.parse(to));
            message.setSubject(subject);

            MimeBodyPart bodyPart = new MimeBodyPart();
            bodyPart.setText(body);

            Multipart multipart = new MimeMultipart();
            multipart.addBodyPart(bodyPart);
            message.setContent(multipart);

            Transport.send(message);

            AppLogger.log(context, TAG, "✅ Email sent to: " + to);
            return true;

        } catch (Exception e) {
            AppLogger.logException(context, TAG, "❌ sendEmail error", e);
            return false;
        }
    }

    // ==================== ВСПОМОГАТЕЛЬНЫЕ МЕТОДЫ ====================

    private String htmlToText(String html) {
        if (html == null) return "";
        String text = html.replaceAll("<[^>]*>", " ");
        text = text.replaceAll("&nbsp;", " ");
        text = text.replaceAll("&amp;", "&");
        text = text.replaceAll("&lt;", "<");
        text = text.replaceAll("&gt;", ">");
        text = text.replaceAll("&quot;", "\"");
        text = text.replaceAll("\\s+", " ").trim();
        return text;
    }

    public void disconnect() {
        AppLogger.log(context, TAG, "🔌 disconnect() called");
        try {
            if (currentStore != null && currentStore.isConnected()) {
                currentStore.close();
                AppLogger.log(context, TAG, "✅ Store disconnected");
            }
        } catch (Exception e) {
            AppLogger.logException(context, TAG, "❌ Disconnect error", e);
        }
        currentStore = null;
    }
}