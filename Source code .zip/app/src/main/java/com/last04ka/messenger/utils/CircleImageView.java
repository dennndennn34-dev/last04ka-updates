package com.last04ka.messenger.utils;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Bitmap;
import android.graphics.BitmapShader;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Shader;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.widget.ImageView;

import com.last04ka.messenger.R;

public class CircleImageView extends ImageView {
    private Paint paint;
    private Paint borderPaint;
    private int borderColor = Color.TRANSPARENT;
    private int borderWidth = 4;
    private int viewWidth;
    private int viewHeight;

    public CircleImageView(Context context) {
        super(context);
        init();
    }

    public CircleImageView(Context context, AttributeSet attrs) {
        super(context, attrs);
        init();
        if (attrs != null) {
            TypedArray a = context.obtainStyledAttributes(attrs, R.styleable.CircleImageView);
            borderColor = a.getColor(R.styleable.CircleImageView_borderColor, Color.TRANSPARENT);
            borderWidth = a.getDimensionPixelSize(R.styleable.CircleImageView_borderWidth, 4);
            a.recycle();
        }
    }

    private void init() {
        paint = new Paint();
        paint.setAntiAlias(true);
        borderPaint = new Paint();
        borderPaint.setAntiAlias(true);
        borderPaint.setStyle(Paint.Style.STROKE);
        borderPaint.setStrokeWidth(borderWidth);
    }

    public void setBorderColor(int color) {
        this.borderColor = color;
        invalidate();
    }

    public void setBorderWidth(int width) {
        this.borderWidth = width;
        borderPaint.setStrokeWidth(width);
        invalidate();
    }

    @Override
    protected void onSizeChanged(int w, int h, int oldw, int oldh) {
        super.onSizeChanged(w, h, oldw, oldh);
        viewWidth = w;
        viewHeight = h;
    }

    @Override
    protected void onDraw(Canvas canvas) {
        Drawable drawable = getDrawable();
        if (drawable == null) {
            super.onDraw(canvas);
            return;
        }

        Bitmap bitmap = ((BitmapDrawable) drawable).getBitmap();
        if (bitmap == null) {
            super.onDraw(canvas);
            return;
        }

        Bitmap roundedBitmap = getRoundedBitmap(bitmap);
        canvas.drawBitmap(roundedBitmap, 0, 0, paint);

        if (borderColor != Color.TRANSPARENT) {
            borderPaint.setColor(borderColor);
            float radius = Math.min(viewWidth, viewHeight) / 2f;
            canvas.drawCircle(viewWidth / 2f, viewHeight / 2f, radius - borderWidth / 2f, borderPaint);
        }
    }

    private Bitmap getRoundedBitmap(Bitmap bitmap) {
        int width = Math.min(bitmap.getWidth(), bitmap.getHeight());
        Bitmap output = Bitmap.createBitmap(width, width, Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(output);

        Paint paint = new Paint();
        paint.setAntiAlias(true);
        paint.setShader(new BitmapShader(bitmap, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP));

        float radius = width / 2f;
        canvas.drawCircle(radius, radius, radius, paint);

        return output;
    }
}