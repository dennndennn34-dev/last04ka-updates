package com.last04ka.messenger.ui;

import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import com.last04ka.messenger.utils.AppLogger;
import java.util.Random;

public class PredictorActivity extends Activity {

    private TextView predText;
    private String current = "";
    private Random r = new Random();

    private String[] predictions = {
        "Сегодня вас ждёт неожиданная удача в делах, связанных с цифрами.",
        "Завтра вы встретите человека, который изменит вашу жизнь. Или просто курьера.",
        "В ближайшие дни вам стоит быть осторожнее с острыми предметами и острыми шутками.",
        "Звёзды говорят: вам пора в отпуск. Даже если вы только что из отпуска.",
        "Ваш телефон скоро разрядится. Не паникуйте, это просто предсказание.",
        "В этом месяце вас ждёт финансовый успех. Или хотя бы кешбэк.",
        "Будьте внимательны: рядом с вами кто-то очень умный. Посмотрите в зеркало.",
        "Сегодня отличный день чтобы начать новое дело. Или закончить старое. Или просто поесть.",
        "Вам предстоит важный разговор. Не забудьте зарядить наушники.",
        "Судьба готовит вам сюрприз. Скорее всего, приятный. Но это не точно.",
        "Ваша интуиция сегодня на высоте. Доверьтесь ей, но проверяйте факты.",
        "В ближайшее время вы получите сообщение, которое вас обрадует.",
        "Звёзды советуют вам больше спать и меньше переживать о мелочах.",
        "Сегодня вы будете неотразимы. Как, впрочем, и всегда.",
        "Грядут перемены. Хорошие. Наверное. Будем надеяться.",
        "Ваше упорство будет вознаграждено. Главное — не пропустить награду.",
        "Деньги идут к вам. Медленно, но верно. Как черепаха с кошельком.",
        "Вас ждёт романтическое приключение. Или просто хороший кофе.",
        "Будьте готовы к неожиданностям: они уже в пути.",
        "Сегодня вы примете важное решение. Не спешите, подумайте ещё раз."
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        try {
            AppLogger.log(this, "Predictor", "onCreate started");
            LinearLayout layout = new LinearLayout(this);
            layout.setOrientation(LinearLayout.VERTICAL);
            layout.setPadding(24, 24, 24, 24);
            layout.setBackgroundColor(0xFF1A1A2E);

            TextView title = new TextView(this);
            title.setText("🔮 Предсказатель");
            title.setTextSize(20); title.setTextColor(0xFFFFFFFF);
            title.setGravity(android.view.Gravity.CENTER);
            title.setPadding(0, 0, 0, 16);
            layout.addView(title);

            predText = new TextView(this);
            predText.setText("Нажмите 'Узнать судьбу'");
            predText.setTextSize(20); predText.setTextColor(0xFFFFD740);
            predText.setGravity(android.view.Gravity.CENTER);
            predText.setPadding(16, 32, 16, 32);
            predText.setBackgroundColor(0xFF333333);
            predText.setMinHeight(150);
            layout.addView(predText);

            LinearLayout btns = new LinearLayout(this);
            btns.setOrientation(LinearLayout.HORIZONTAL);

            Button btnPred = new Button(this); btnPred.setText("Узнать судьбу");
            btnPred.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    current = predictions[r.nextInt(predictions.length)];
                    predText.setText(current);
                    AppLogger.log(PredictorActivity.this, "Predictor", "New prediction: " + current);
                }
            });
            btns.addView(btnPred);

            Button btnCopy = new Button(this); btnCopy.setText("Копировать");
            btnCopy.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (!current.isEmpty()) {
                        ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
                        cm.setPrimaryClip(ClipData.newPlainText("prediction", current));
                        Toast.makeText(PredictorActivity.this, "Скопировано!", Toast.LENGTH_SHORT).show();
                    }
                }
            });
            btns.addView(btnCopy);
            layout.addView(btns);

            setContentView(layout);
            setTitle("🔮 Предсказатель");
            AppLogger.log(this, "Predictor", "onCreate completed");
        } catch (Exception e) { AppLogger.logException(this, "Predictor", e); finish(); }
    }
}