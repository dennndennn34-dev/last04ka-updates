package com.last04ka.messenger.ui;

import android.app.Activity;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.GridLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import com.last04ka.messenger.utils.AppLogger;
import com.last04ka.messenger.utils.GameScores;
import java.util.Random;

public class ColorTestActivity extends Activity {

    private GridLayout grid;
    private TextView levelText, scoreText;
    private Button btnNext;
    private int level = 1;
    private int score = 0;
    private int gridSize = 4; // 4x4 = 16 клеток
    private int baseColor;
    private int oddCellIndex;
    private Random r = new Random();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        try {
            LinearLayout layout = new LinearLayout(this);
            layout.setOrientation(LinearLayout.VERTICAL);
            layout.setPadding(16, 16, 16, 16);
            layout.setBackgroundColor(0xFF1A1A2E);

            levelText = new TextView(this);
            levelText.setText("Уровень: 1 | Рекорд: " + GameScores.getScore(this, "colortest"));
            levelText.setTextSize(18);
            levelText.setTextColor(0xFFFFFFFF);
            levelText.setGravity(android.view.Gravity.CENTER);
            levelText.setPadding(0, 8, 0, 16);
            layout.addView(levelText);

            scoreText = new TextView(this);
            scoreText.setText("Счёт: 0");
            scoreText.setTextSize(16);
            scoreText.setTextColor(0xFFBDBDBD);
            scoreText.setGravity(android.view.Gravity.CENTER);
            scoreText.setPadding(0, 0, 0, 16);
            layout.addView(scoreText);

            grid = new GridLayout(this);
            grid.setColumnCount(4);
            grid.setRowCount(4);
            grid.setPadding(8, 8, 8, 8);
            LinearLayout.LayoutParams gp = new LinearLayout.LayoutParams(500, 500);
            gp.gravity = android.view.Gravity.CENTER;
            grid.setLayoutParams(gp);
            layout.addView(grid);

            btnNext = new Button(this);
            btnNext.setText("Пропустить (следующий)");
            btnNext.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    level++;
                    generateLevel();
                }
            });
            layout.addView(btnNext);

            setContentView(layout);
            setTitle("🎨 Цветовой тест");
            generateLevel();
        } catch (Exception e) {
            AppLogger.logException(this, "ColorTest", e);
            finish();
        }
    }

    private void generateLevel() {
        grid.removeAllViews();
        int cols, rows;

        // Размер сетки зависит от уровня
        if (level <= 3) { cols = rows = 3; }
        else if (level <= 6) { cols = rows = 4; }
        else if (level <= 10) { cols = rows = 5; }
        else { cols = rows = 6; }

        grid.setColumnCount(cols);
        grid.setRowCount(rows);

        // Базовый цвет
        baseColor = Color.rgb(r.nextInt(256), r.nextInt(256), r.nextInt(256));

        // Разница оттенка (уменьшается с уровнем)
        int delta = Math.max(5, 50 - level * 3);

        // Отличающаяся клетка
        oddCellIndex = r.nextInt(cols * rows);
        int oddColor;
        if (r.nextBoolean()) {
            oddColor = Color.rgb(
                Math.min(255, Math.max(0, Color.red(baseColor) + delta)),
                Math.min(255, Math.max(0, Color.green(baseColor) + delta)),
                Math.min(255, Math.max(0, Color.blue(baseColor) + delta))
            );
        } else {
            oddColor = Color.rgb(
                Math.min(255, Math.max(0, Color.red(baseColor) - delta)),
                Math.min(255, Math.max(0, Color.green(baseColor) - delta)),
                Math.min(255, Math.max(0, Color.blue(baseColor) - delta))
            );
        }

        for (int i = 0; i < cols * rows; i++) {
            View cell = new View(this);
            GridLayout.LayoutParams params = new GridLayout.LayoutParams();
            params.width = 0;
            params.height = 0;
            params.columnSpec = GridLayout.spec(i % cols, 1f);
            params.rowSpec = GridLayout.spec(i / cols, 1f);
            params.setMargins(2, 2, 2, 2);
            cell.setLayoutParams(params);

            final boolean isOdd = (i == oddCellIndex);
            cell.setBackgroundColor(isOdd ? oddColor : baseColor);
            cell.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (isOdd) {
                        score += level;
                        GameScores.saveScore(ColorTestActivity.this, "colortest", score);
                        Toast.makeText(ColorTestActivity.this, "✅ +" + level, Toast.LENGTH_SHORT).show();
                        level++;
                        levelText.setText("Уровень: " + level + " | Рекорд: " + GameScores.getScore(ColorTestActivity.this, "colortest"));
                        scoreText.setText("Счёт: " + score);
                        generateLevel();
                    } else {
                        Toast.makeText(ColorTestActivity.this, "❌ Не та клетка! Попробуйте ещё", Toast.LENGTH_SHORT).show();
                    }
                }
            });
            grid.addView(cell);
        }

        levelText.setText("Уровень: " + level + " | Рекорд: " + GameScores.getScore(this, "colortest"));
        scoreText.setText("Счёт: " + score);
    }
}