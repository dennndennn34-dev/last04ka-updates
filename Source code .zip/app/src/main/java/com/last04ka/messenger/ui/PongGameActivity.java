package com.last04ka.messenger.ui;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.media.AudioFormat;
import android.media.AudioManager;
import android.media.AudioTrack;
import android.os.Bundle;
import android.os.Handler;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import com.last04ka.messenger.utils.AppLogger;
import com.last04ka.messenger.utils.GameScores;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class PongGameActivity extends Activity {

    private GameView gameView;
    private TextView scoreText, highScoreText, levelText;
    private Button btnPause, btnLevel;
    private int playerScore = 0, botScore = 0, highScore = 0;
    private boolean paused = false;
    private int difficulty = 1;
    private String[] diffNames = {"Лёгкий", "Средний", "Сложный", "Эксперт"};
    private float[] botSpeeds = {4f, 6f, 9f, 14f};
    private float[] ballSpeeds = {7f, 9f, 11f, 15f};
    private Handler handler = new Handler();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        try {
            AppLogger.log(this, "PongGame", "onCreate v2.0 stable");
            AppLogger.logUI(this, "PongGame", "Field with trails", true);
            AppLogger.logTexture(this, "PongGame", "Ball glow", true);

            highScore = GameScores.getScore(this, "pong");
            LinearLayout mainLayout = new LinearLayout(this);
            mainLayout.setOrientation(LinearLayout.VERTICAL);
            mainLayout.setBackgroundColor(0xFF0D1B2A);

            LinearLayout statsRow = new LinearLayout(this);
            statsRow.setOrientation(LinearLayout.HORIZONTAL);
            statsRow.setGravity(Gravity.CENTER);
            statsRow.setPadding(8, 4, 8, 4);
            scoreText = new TextView(this); scoreText.setText("Вы: 0  |  Бот: 0"); scoreText.setTextSize(14);
            scoreText.setTextColor(0xFF90CAF9); statsRow.addView(scoreText);
            highScoreText = new TextView(this); highScoreText.setText("  Рекорд: " + highScore); highScoreText.setTextSize(12);
            highScoreText.setTextColor(0xFFFFD740); statsRow.addView(highScoreText);
            levelText = new TextView(this); levelText.setText("  " + diffNames[difficulty]); levelText.setTextSize(12);
            levelText.setTextColor(0xFFFF5252); statsRow.addView(levelText);
            mainLayout.addView(statsRow);

            gameView = new GameView(this);
            LinearLayout.LayoutParams gvp = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1);
            gameView.setLayoutParams(gvp); mainLayout.addView(gameView);

            LinearLayout btnRow = new LinearLayout(this);
            btnRow.setOrientation(LinearLayout.HORIZONTAL); btnRow.setGravity(Gravity.CENTER); btnRow.setPadding(4, 4, 4, 4);
            btnPause = new Button(this); btnPause.setText("⏯ Пауза"); btnPause.setTextSize(12);
            btnPause.setOnClickListener(v -> togglePause()); btnRow.addView(btnPause);
            btnLevel = new Button(this); btnLevel.setText("🎮 Уровень"); btnLevel.setTextSize(12);
            btnLevel.setOnClickListener(v -> showLevelDialog()); btnRow.addView(btnLevel);
            Button btnNewGame = new Button(this); btnNewGame.setText("🔄 Новая"); btnNewGame.setTextSize(12);
            btnNewGame.setOnClickListener(v -> resetGame()); btnRow.addView(btnNewGame);
            mainLayout.addView(btnRow);
            setContentView(mainLayout); setTitle("🏓 Пинг-понг");
            AppLogger.log(this, "PongGame", "onCreate completed");
        } catch (Exception e) { AppLogger.logException(this, "PongGame", e); finish(); }
    }

    private void togglePause() { paused=!paused;btnPause.setText(paused?"▶ Играть":"⏯ Пауза");if(!paused)gameView.startLoop(); }
    private void showLevelDialog() { new AlertDialog.Builder(this).setTitle("Уровень сложности").setItems(diffNames,(d,w)->{difficulty=w;levelText.setText("  "+diffNames[difficulty]);gameView.updateSpeed();Toast.makeText(this,"Уровень: "+diffNames[difficulty],Toast.LENGTH_SHORT).show();}).show(); }
    private void resetGame() { playerScore=0;botScore=0;updateScore();gameView.reset();paused=false;btnPause.setText("⏯ Пауза"); }
    private void updateScore() { scoreText.setText("Вы: "+playerScore+"  |  Бот: "+botScore); if(playerScore>highScore){highScore=playerScore;GameScores.saveScore(this,"pong",highScore);highScoreText.setText("  Рекорд: "+highScore);} }
    private void checkWin() { int ws=difficulty>=3?15:11; if(playerScore>=ws){paused=true;btnPause.setText("▶ Играть");new AlertDialog.Builder(this).setTitle("🏆 Победа!").setMessage("Вы выиграли "+playerScore+":"+botScore+"\nРекорд: "+highScore).setPositiveButton("Новая игра",(d,w)->resetGame()).setNegativeButton("OK",null).show();} else if(botScore>=ws){paused=true;btnPause.setText("▶ Играть");new AlertDialog.Builder(this).setTitle("😞 Поражение").setMessage("Бот выиграл "+playerScore+":"+botScore+"\nРекорд: "+highScore).setPositiveButton("Новая игра",(d,w)->resetGame()).setNegativeButton("OK",null).show();} }
    private void playHitSound() { try{int dur=50,s=8000*dur/1000;byte[]t=new byte[s];for(int i=0;i<s;i++)t[i]=(byte)(Math.sin(2*Math.PI*600*i/8000)*80);AudioTrack tr=new AudioTrack(AudioManager.STREAM_MUSIC,8000,AudioFormat.CHANNEL_OUT_MONO,AudioFormat.ENCODING_PCM_8BIT,s,AudioTrack.MODE_STATIC);tr.write(t,0,s);tr.play();handler.postDelayed(()->{try{tr.release();}catch(Exception e){}},dur+10);}catch(Exception e){} }

    class GameView extends View {
        private Paint paint = new Paint();
        private Random random = new Random();
        private float paddleWidth, paddleHeight, ballRadius, playerX, playerY, botX, botY, paddleSpeed=12f;
        private float ballX, ballY, ballSpeedX, ballSpeedY, baseBallSpeed;
        private RectF field;
        private boolean running=false, initialized=false;
        private List<Trail> trails = new ArrayList<>();

        public GameView(Context context) { super(context); setFocusable(true); setFocusableInTouchMode(true); setBackgroundColor(0xFF0D1B2A); }
        private void init() { int w=getWidth(),h=getHeight();if(w==0||h==0)return;paddleWidth=w*0.02f;paddleHeight=h*0.15f;ballRadius=w*0.015f;baseBallSpeed=ballSpeeds[difficulty];field=new RectF(0,0,w,h);initialized=true;reset(); }
        private void reset() { int w=getWidth(),h=getHeight();playerX=paddleWidth*2;playerY=h/2f-paddleHeight/2f;botX=w-paddleWidth*3;botY=h/2f-paddleHeight/2f;ballX=w/2f;ballY=h/2f;float angle=(random.nextFloat()-0.5f)*(float)Math.PI/3;ballSpeedX=baseBallSpeed*(float)Math.cos(angle)*(random.nextBoolean()?1:-1);ballSpeedY=baseBallSpeed*(float)Math.sin(angle);if(Math.abs(ballSpeedX)<3)ballSpeedX=ballSpeedX>0?3:-3;trails.clear(); }
        public void updateSpeed() { baseBallSpeed=ballSpeeds[difficulty];float speed=(float)Math.sqrt(ballSpeedX*ballSpeedX+ballSpeedY*ballSpeedY);if(speed>0){ballSpeedX=ballSpeedX/speed*baseBallSpeed;ballSpeedY=ballSpeedY/speed*baseBallSpeed;} }

        @Override
        protected void onDraw(Canvas c) {
            try {
                super.onDraw(c);
                int w=getWidth(),h=getHeight();
                if (w<=0||h<=0||!initialized) return;

                paint.setColor(0xFF0D1B2A);c.drawRect(field,paint);paint.setColor(0xFF132940);c.drawRect(0,h*0.3f,w,h*0.5f,paint);
                paint.setColor(0x33FFFFFF);paint.setStrokeWidth(2);c.drawLine(w/2f,0,w/2f,h,paint);
                paint.setStyle(Paint.Style.STROKE);paint.setStrokeWidth(3);c.drawCircle(w/2f,h/2f,h*0.1f,paint);paint.setStyle(Paint.Style.FILL);
                for(Trail t:trails){paint.setColor(0x66FFEB3B);paint.setAlpha(t.alpha);c.drawCircle(t.x,t.y,ballRadius*0.7f,paint);}
                paint.setAlpha(255);
                paint.setColor(0x334FC3F7);c.drawRoundRect(playerX-3,playerY-3,playerX+paddleWidth+3,playerY+paddleHeight+3,10,10,paint);
                paint.setColor(0xFF4FC3F7);c.drawRoundRect(playerX,playerY,playerX+paddleWidth,playerY+paddleHeight,8,8,paint);
                paint.setColor(0x33FF5252);c.drawRoundRect(botX-3,botY-3,botX+paddleWidth+3,botY+paddleHeight+3,10,10,paint);
                paint.setColor(0xFFFF5252);c.drawRoundRect(botX,botY,botX+paddleWidth,botY+paddleHeight,8,8,paint);
                paint.setColor(0x44FFEB3B);c.drawCircle(ballX,ballY,ballRadius*2.5f,paint);
                paint.setColor(0x66FFEB3B);c.drawCircle(ballX,ballY,ballRadius*1.5f,paint);
                paint.setColor(0xFFFFEB3B);c.drawCircle(ballX,ballY,ballRadius,paint);
                paint.setColor(0x10FFFFFF);paint.setTextSize(h*0.15f);paint.setTextAlign(Paint.Align.CENTER);
                c.drawText(playerScore+"",w*0.25f,h*0.3f,paint);c.drawText(botScore+"",w*0.75f,h*0.3f,paint);paint.setTextAlign(Paint.Align.LEFT);
                if(paused){paint.setColor(0xAA000000);c.drawRect(0,0,w,h,paint);paint.setColor(Color.WHITE);paint.setTextSize(36);paint.setTextAlign(Paint.Align.CENTER);c.drawText("ПАУЗА",w/2f,h/2f,paint);paint.setTextAlign(Paint.Align.LEFT);}
            } catch (Exception e) {
                AppLogger.logException(PongGameActivity.this, "Pong", e);
            }
        }

        public void update() {
            if(paused||!initialized)return;int w=getWidth(),h=getHeight();
            ballX+=ballSpeedX;ballY+=ballSpeedY;
            trails.add(0,new Trail(ballX,ballY));if(trails.size()>15)trails.remove(trails.size()-1);
            for(int i=trails.size()-1;i>=0;i--){Trail t=trails.get(i);t.life-=18;t.alpha=Math.max(0,t.life);if(t.life<=0)trails.remove(i);}
            if(ballY-ballRadius<=0){ballY=ballRadius;ballSpeedY=-ballSpeedY;playHitSound();}
            if(ballY+ballRadius>=h){ballY=h-ballRadius;ballSpeedY=-ballSpeedY;playHitSound();}
            if(ballX-ballRadius<=playerX+paddleWidth&&ballX+ballRadius>=playerX&&ballY+ballRadius>=playerY&&ballY-ballRadius<=playerY+paddleHeight){ballX=playerX+paddleWidth+ballRadius;float hp=(ballY-playerY)/paddleHeight;float a=(hp-0.5f)*(float)Math.PI/3;ballSpeedX=Math.abs(ballSpeedX)*(float)Math.cos(a);ballSpeedY=baseBallSpeed*(float)Math.sin(a);ballSpeedX*=1.05f;ballSpeedY*=1.05f;playHitSound();}
            if(ballX+ballRadius>=botX&&ballX-ballRadius<=botX+paddleWidth&&ballY+ballRadius>=botY&&ballY-ballRadius<=botY+paddleHeight){ballX=botX-ballRadius;float hp=(ballY-botY)/paddleHeight;float a=(hp-0.5f)*(float)Math.PI/3;ballSpeedX=-Math.abs(ballSpeedX)*(float)Math.cos(a);ballSpeedY=baseBallSpeed*(float)Math.sin(a);ballSpeedX*=1.05f;ballSpeedY*=1.05f;playHitSound();}
            if(ballX-ballRadius>w){playerScore++;updateScore();checkWin();reset();return;}
            if(ballX+ballRadius<0){botScore++;updateScore();checkWin();reset();return;}
            float ty=ballY-paddleHeight/2f,err=(4-difficulty)*25f;ty+=(random.nextFloat()-0.5f)*err;ty=Math.max(0,Math.min(h-paddleHeight,ty));float bs=botSpeeds[difficulty];if(Math.abs(botY-ty)<bs)botY=ty;else if(botY<ty)botY+=bs;else botY-=bs;
            playerY=Math.max(0,Math.min(h-paddleHeight,playerY));
        }

        @Override public boolean onTouchEvent(MotionEvent e){if(paused)return true;playerY=Math.max(0,Math.min(getHeight()-paddleHeight,e.getY()-paddleHeight/2f));return true;}
        public void startLoop(){if(running)return;running=true;new Thread(()->{while(running){try{Thread.sleep(16);if(!paused){update();postInvalidate();}}catch(Exception e){AppLogger.logException(PongGameActivity.this,"Pong",e);}}}).start();}
        @Override protected void onAttachedToWindow(){super.onAttachedToWindow();if(!initialized){handler.postDelayed(()->{init();startLoop();},200);}else startLoop();}
        @Override protected void onDetachedFromWindow(){super.onDetachedFromWindow();running=false;}
    }

    static class Trail { float x,y; int life=200,alpha=200; Trail(float x,float y){this.x=x;this.y=y;} }

    @Override protected void onDestroy() { super.onDestroy(); gameView.running=false; handler.removeCallbacksAndMessages(null); }
}