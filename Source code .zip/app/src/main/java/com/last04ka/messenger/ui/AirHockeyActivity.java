package com.last04ka.messenger.ui;

import android.app.Activity;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.media.AudioFormat;
import android.media.AudioManager;
import android.media.AudioTrack;
import android.os.Bundle;
import android.os.Handler;
import android.os.Vibrator;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.last04ka.messenger.utils.AppLogger;
import com.last04ka.messenger.utils.GameScores;

import java.util.Random;

public class AirHockeyActivity extends Activity {

    private GameView gameView;
    private TextView scoreText, modeText, timerText;
    private Button btnPause, btnMode, btnReset;
    private Handler handler = new Handler();
    private Random random = new Random();

    private int scorePlayer = 0;
    private int scoreBot = 0;
    private boolean paused = false;
    private int gameMode = 0; // 0=бот, 1=PvP
    private Vibrator vibrator;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        try {
            AppLogger.log(this, "AirHockey", "onCreate started (v4 - sub-stepping)");

            vibrator = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);

            LinearLayout mainLayout = new LinearLayout(this);
            mainLayout.setOrientation(LinearLayout.VERTICAL);
            mainLayout.setBackgroundColor(0xFF1A1A2E);

            LinearLayout stats = new LinearLayout(this);
            stats.setOrientation(LinearLayout.HORIZONTAL);
            stats.setGravity(Gravity.CENTER);
            stats.setPadding(8, 4, 8, 4);

            scoreText = new TextView(this);
            scoreText.setText("Вы: 0  |  Бот: 0");
            scoreText.setTextSize(14);
            scoreText.setTextColor(0xFFFFFFFF);
            stats.addView(scoreText);

            modeText = new TextView(this);
            modeText.setText("  🤖 Бот");
            modeText.setTextSize(13);
            modeText.setTextColor(0xFFFFD740);
            stats.addView(modeText);

            timerText = new TextView(this);
            timerText.setText("  ⏱ 0:00");
            timerText.setTextSize(13);
            timerText.setTextColor(0xFF4FC3F7);
            stats.addView(timerText);

            mainLayout.addView(stats);

            gameView = new GameView(this);
            LinearLayout.LayoutParams gp = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT, 0, 1);
            gameView.setLayoutParams(gp);
            mainLayout.addView(gameView);

            LinearLayout btnRow = new LinearLayout(this);
            btnRow.setOrientation(LinearLayout.HORIZONTAL);
            btnRow.setGravity(Gravity.CENTER);
            btnRow.setPadding(4, 8, 4, 8);

            btnPause = new Button(this);
            btnPause.setText("⏯ Пауза");
            btnPause.setTextSize(12);
            btnPause.setOnClickListener(v -> {
                paused = !paused;
                btnPause.setText(paused ? "▶ Играть" : "⏯ Пауза");
                if (!paused) gameView.startLoop();
            });
            btnRow.addView(btnPause);

            btnMode = new Button(this);
            btnMode.setText("🤖/👥");
            btnMode.setTextSize(12);
            btnMode.setOnClickListener(v -> {
                gameMode = 1 - gameMode;
                modeText.setText(gameMode == 0 ? "  🤖 Бот" : "  👥 PvP");
                resetGame();
                Toast.makeText(this, gameMode == 0 ? "Режим: Бот" : "Режим: PvP (два игрока)", Toast.LENGTH_SHORT).show();
            });
            btnRow.addView(btnMode);

            btnReset = new Button(this);
            btnReset.setText("🔄 Новая");
            btnReset.setTextSize(12);
            btnReset.setOnClickListener(v -> resetGame());
            btnRow.addView(btnReset);

            mainLayout.addView(btnRow);

            setContentView(mainLayout);
            setTitle("🪩 Аэрохоккей v4");
            AppLogger.log(this, "AirHockey", "onCreate completed");
        } catch (Exception e) {
            AppLogger.logException(this, "AirHockey", e);
            finish();
        }
    }

    private void resetGame() {
        scorePlayer = 0;
        scoreBot = 0;
        updateScore();
        gameView.reset();
        paused = false;
        btnPause.setText("⏯ Пауза");
        timerText.setText("  ⏱ 0:00");
        gameView.startLoop();
    }

    private void updateScore() {
        scoreText.setText("Вы: " + scorePlayer + "  |  Бот: " + scoreBot);
    }

    private void playGoalSound() {
        try {
            int dur = 400;
            int samples = 8000 * dur / 1000;
            byte[] tone = new byte[samples];
            for (int i = 0; i < samples; i++) {
                double t = (double) i / 8000;
                tone[i] = (byte) (Math.sin(2 * Math.PI * 600 * t) * 60);
                if (i > samples / 2) tone[i] *= 0.5;
            }
            AudioTrack track = new AudioTrack(AudioManager.STREAM_MUSIC, 8000,
                    AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_8BIT,
                    samples, AudioTrack.MODE_STATIC);
            track.write(tone, 0, samples);
            track.play();
            handler.postDelayed(() -> {
                try { track.release(); } catch (Exception e) {}
            }, dur + 50);
        } catch (Exception e) {}
    }

    private void vibrate(int ms) {
        if (vibrator != null && vibrator.hasVibrator()) {
            vibrator.vibrate(ms);
        }
    }

    // ==================== GAME VIEW ====================

    class GameView extends View {
        private Paint paint = new Paint();

        // Параметры поля
        private float tableLeft, tableRight, tableTop, tableBottom;
        private float centerX, centerY;
        private float malletRadius, puckRadius;
        private float goalWidth, goalHeight;

        // Игроки и шайба
        private float p1X, p1Y, p2X, p2Y;
        private float puckX, puckY, puckVX, puckVY;
        private float friction = 0.99f;
        private float maxSpeed = 14f;
        private float malletSpeed = 12f;

        // Состояние
        private boolean goalScored = false;
        private boolean gameRunning = false;
        private long gameStartTime = 0;

        // Сенсор
        private int activePointer = -1;
        private boolean isDragging = false;
        private float targetP1X, targetP1Y;

        // ИИ
        private float botSpeed = 6.5f;
        private float botError = 25f;

        // Подшаги
        private static final int SUB_STEPS = 8;

        public GameView(Context context) {
            super(context);
            setFocusable(true);
            setFocusableInTouchMode(true);
            setClickable(true);
            init();
            reset();
            startLoop();
        }

        private void init() {
            int w = getWidth(), h = getHeight();
            if (w == 0 || h == 0) return;
            float margin = w * 0.04f;
            tableLeft = margin;
            tableRight = w - margin;
            tableTop = margin;
            tableBottom = h - margin;
            centerX = w / 2f;
            centerY = h / 2f;

            malletRadius = Math.min(w, h) * 0.04f;
            puckRadius = Math.min(w, h) * 0.025f;
            goalWidth = w * 0.22f;
            goalHeight = h * 0.02f;
        }

        public void reset() {
            int w = getWidth(), h = getHeight();
            if (w == 0 || h == 0) return;
            p1X = w * 0.25f;
            p1Y = h / 2f;
            p2X = w * 0.75f;
            p2Y = h / 2f;
            targetP1X = p1X;
            targetP1Y = p1Y;
            puckX = w / 2f;
            puckY = h / 2f;
            puckVX = 0;
            puckVY = 0;
            goalScored = false;
            gameStartTime = System.currentTimeMillis();
            botError = 15 + random.nextFloat() * 30;
        }

        private void startLoop() {
            if (gameRunning) return;
            gameRunning = true;
            new Thread(() -> {
                while (gameRunning) {
                    try {
                        Thread.sleep(16);
                        update();
                        postInvalidate();
                    } catch (InterruptedException e) {
                        break;
                    }
                }
            }).start();
        }

        @Override
        protected void onSizeChanged(int w, int h, int oldw, int oldh) {
            super.onSizeChanged(w, h, oldw, oldh);
            init();
            reset();
        }

        // ==================== ОБНОВЛЕНИЕ С ПОДШАГАМИ ====================

        public void update() {
            if (paused || goalScored || !gameRunning) return;
            int w = getWidth(), h = getHeight();

            // ---- Движение игрока 1 (слежение за пальцем) ----
            if (isDragging && activePointer != -1) {
                float dx = targetP1X - p1X;
                float dy = targetP1Y - p1Y;
                float dist = (float) Math.sqrt(dx * dx + dy * dy);
                if (dist > 1) {
                    float speed = Math.min(malletSpeed, dist);
                    p1X += dx / dist * speed;
                    p1Y += dy / dist * speed;
                } else {
                    p1X = targetP1X;
                    p1Y = targetP1Y;
                }
                // Ограничения
                p1X = Math.max(tableLeft + malletRadius, Math.min(tableRight - malletRadius, p1X));
                p1Y = Math.max(tableTop + malletRadius, Math.min(centerY - malletRadius - 10, p1Y));
            }

            // ---- Движение игрока 2 (бот) ----
            if (gameMode == 0) {
                // Бот преследует шайбу с задержкой и ошибкой
                float targetX = puckX + (random.nextFloat() - 0.5f) * botError;
                float targetY = puckY + (random.nextFloat() - 0.5f) * botError;
                // Ограничиваем зону бота (нижняя половина)
                targetX = Math.max(tableLeft + malletRadius, Math.min(tableRight - malletRadius, targetX));
                targetY = Math.max(centerY + malletRadius + 10, Math.min(tableBottom - malletRadius, targetY));

                float dx = targetX - p2X;
                float dy = targetY - p2Y;
                float dist = (float) Math.sqrt(dx * dx + dy * dy);
                if (dist > 1) {
                    float speed = Math.min(botSpeed, dist);
                    p2X += dx / dist * speed;
                    p2Y += dy / dist * speed;
                } else {
                    p2X = targetX;
                    p2Y = targetY;
                }
                // Жёсткие границы
                p2X = Math.max(tableLeft + malletRadius, Math.min(tableRight - malletRadius, p2X));
                p2Y = Math.max(centerY + malletRadius + 10, Math.min(tableBottom - malletRadius, p2Y));
            } else {
                // PvP: управление вторым игроком через второй палец (в onTouchEvent)
            }

            // ---- Физика шайбы с подшагами ----
            float stepX = puckVX / SUB_STEPS;
            float stepY = puckVY / SUB_STEPS;

            for (int i = 0; i < SUB_STEPS; i++) {
                // Движение на подшаг
                puckX += stepX;
                puckY += stepY;

                // Столкновение со стенками (с учётом ворот)
                float goalLeft = centerX - goalWidth / 2;
                float goalRight = centerX + goalWidth / 2;

                // Верхняя стенка
                if (puckY - puckRadius < tableTop) {
                    if (puckX > goalLeft && puckX < goalRight) {
                        // Гол!
                        goalScored = true;
                        scoreBot++;
                        updateScore();
                        playGoalSound();
                        vibrate(200);
                        handler.postDelayed(() -> {
                            reset();
                            goalScored = false;
                        }, 1500);
                        return;
                    } else {
                        puckY = tableTop + puckRadius;
                        puckVY = -puckVY * 0.85f;
                        // Пересчитываем скорость для подшагов
                        stepY = puckVY / SUB_STEPS;
                    }
                }
                // Нижняя стенка
                if (puckY + puckRadius > tableBottom) {
                    if (puckX > goalLeft && puckX < goalRight) {
                        goalScored = true;
                        scorePlayer++;
                        updateScore();
                        playGoalSound();
                        vibrate(200);
                        handler.postDelayed(() -> {
                            reset();
                            goalScored = false;
                        }, 1500);
                        return;
                    } else {
                        puckY = tableBottom - puckRadius;
                        puckVY = -puckVY * 0.85f;
                        stepY = puckVY / SUB_STEPS;
                    }
                }
                // Левая стенка
                if (puckX - puckRadius < tableLeft) {
                    puckX = tableLeft + puckRadius;
                    puckVX = -puckVX * 0.85f;
                    stepX = puckVX / SUB_STEPS;
                }
                // Правая стенка
                if (puckX + puckRadius > tableRight) {
                    puckX = tableRight - puckRadius;
                    puckVX = -puckVX * 0.85f;
                    stepX = puckVX / SUB_STEPS;
                }

                // ---- Столкновение с клюшками (с подшагами) ----
                // Клюшка 1
                float dx1 = puckX - p1X;
                float dy1 = puckY - p1Y;
                float dist1 = (float) Math.sqrt(dx1 * dx1 + dy1 * dy1);
                if (dist1 < malletRadius + puckRadius && dist1 > 0.001f) {
                    // Отодвигаем шайбу
                    float overlap = (malletRadius + puckRadius - dist1) * 0.5f;
                    float nx1 = dx1 / dist1;
                    float ny1 = dy1 / dist1;
                    puckX += nx1 * (overlap + 0.5f);
                    puckY += ny1 * (overlap + 0.5f);
                    // Отскок с добавлением скорости от клюшки
                    float vel = (float) Math.sqrt(puckVX * puckVX + puckVY * puckVY);
                    float targetSpeed = Math.max(vel, 2f) * 1.3f;
                    puckVX = nx1 * targetSpeed;
                    puckVY = ny1 * targetSpeed;
                    // Пересчитываем подшаги
                    stepX = puckVX / SUB_STEPS;
                    stepY = puckVY / SUB_STEPS;
                }

                // Клюшка 2
                float dx2 = puckX - p2X;
                float dy2 = puckY - p2Y;
                float dist2 = (float) Math.sqrt(dx2 * dx2 + dy2 * dy2);
                if (dist2 < malletRadius + puckRadius && dist2 > 0.001f) {
                    float overlap = (malletRadius + puckRadius - dist2) * 0.5f;
                    float nx2 = dx2 / dist2;
                    float ny2 = dy2 / dist2;
                    puckX += nx2 * (overlap + 0.5f);
                    puckY += ny2 * (overlap + 0.5f);
                    float vel = (float) Math.sqrt(puckVX * puckVX + puckVY * puckVY);
                    float targetSpeed = Math.max(vel, 2f) * 1.3f;
                    puckVX = nx2 * targetSpeed;
                    puckVY = ny2 * targetSpeed;
                    stepX = puckVX / SUB_STEPS;
                    stepY = puckVY / SUB_STEPS;
                }
            }

            // ---- Применение трения (после подшагов) ----
            puckVX *= friction;
            puckVY *= friction;

            // Ограничение скорости
            float speed = (float) Math.sqrt(puckVX * puckVX + puckVY * puckVY);
            if (speed > maxSpeed) {
                puckVX = puckVX / speed * maxSpeed;
                puckVY = puckVY / speed * maxSpeed;
            }

            // ---- Таймер ----
            if (gameStartTime > 0) {
                long elapsed = System.currentTimeMillis() - gameStartTime;
                long seconds = elapsed / 1000;
                long minutes = seconds / 60;
                seconds %= 60;
                String timeStr = String.format("  ⏱ %d:%02d", minutes, seconds);
                handler.post(() -> timerText.setText(timeStr));
            }
        }

        @Override
        protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            int w = getWidth(), h = getHeight();
            if (w == 0 || h == 0) return;

            // Фон поля
            paint.setColor(0xFF1B2A3A);
            canvas.drawRect(tableLeft, tableTop, tableRight, tableBottom, paint);

            // Центральная линия и круг
            paint.setColor(0x33FFFFFF);
            paint.setStrokeWidth(3);
            canvas.drawLine(centerX, tableTop, centerX, tableBottom, paint);
            paint.setStyle(Paint.Style.STROKE);
            canvas.drawCircle(centerX, centerY, Math.min(w, h) * 0.13f, paint);
            paint.setStyle(Paint.Style.FILL);

            // Ворота
            float goalLeft = centerX - goalWidth / 2;
            float goalRight = centerX + goalWidth / 2;
            paint.setColor(0x44FFFFFF);
            canvas.drawRect(goalLeft, tableTop, goalRight, tableTop + goalHeight, paint);
            canvas.drawRect(goalLeft, tableBottom - goalHeight, goalRight, tableBottom, paint);

            // Игрок 1 (синий)
            paint.setColor(0xFF2196F3);
            canvas.drawCircle(p1X, p1Y, malletRadius, paint);
            paint.setColor(0x332196F3);
            canvas.drawCircle(p1X, p1Y, malletRadius * 1.5f, paint);

            // Игрок 2 (красный)
            paint.setColor(0xFFFF5252);
            canvas.drawCircle(p2X, p2Y, malletRadius, paint);
            paint.setColor(0x33FF5252);
            canvas.drawCircle(p2X, p2Y, malletRadius * 1.5f, paint);

            // Шайба
            paint.setColor(0xFFFFEB3B);
            canvas.drawCircle(puckX, puckY, puckRadius, paint);
            paint.setColor(0x88FFEB3B);
            canvas.drawCircle(puckX, puckY, puckRadius * 1.5f, paint);

            // Гол
            if (goalScored) {
                paint.setColor(0xAA000000);
                canvas.drawRect(tableLeft, tableTop, tableRight, tableBottom, paint);
                paint.setColor(Color.WHITE);
                paint.setTextSize(Math.min(w, h) * 0.08f);
                paint.setTextAlign(Paint.Align.CENTER);
                canvas.drawText("⚡ ГОЛ!", centerX, centerY - 20, paint);
                paint.setTextAlign(Paint.Align.LEFT);
            }

            if (paused) {
                paint.setColor(0xAA000000);
                canvas.drawRect(tableLeft, tableTop, tableRight, tableBottom, paint);
                paint.setColor(Color.WHITE);
                paint.setTextSize(Math.min(w, h) * 0.07f);
                paint.setTextAlign(Paint.Align.CENTER);
                canvas.drawText("⏸ ПАУЗА", centerX, centerY, paint);
                paint.setTextAlign(Paint.Align.LEFT);
            }
        }

        @Override
        public boolean onTouchEvent(MotionEvent event) {
            if (paused || goalScored) return true;

            int action = event.getActionMasked();
            int pointerId = event.getPointerId(event.getActionIndex());

            if (action == MotionEvent.ACTION_DOWN || action == MotionEvent.ACTION_POINTER_DOWN) {
                if (activePointer == -1) {
                    activePointer = pointerId;
                    isDragging = true;
                }
            } else if (action == MotionEvent.ACTION_UP || action == MotionEvent.ACTION_POINTER_UP) {
                if (pointerId == activePointer) {
                    activePointer = -1;
                    isDragging = false;
                }
            }

            if (isDragging && activePointer != -1) {
                int index = event.findPointerIndex(activePointer);
                if (index >= 0) {
                    float x = event.getX(index);
                    float y = event.getY(index);
                    // Ограничиваем зону игрока 1 (верхняя половина)
                    float maxY = centerY - malletRadius - 10;
                    targetP1X = Math.max(tableLeft + malletRadius, Math.min(tableRight - malletRadius, x));
                    targetP1Y = Math.max(tableTop + malletRadius, Math.min(maxY, y));
                }
            }

            // PvP: второй игрок
            if (gameMode == 1) {
                for (int i = 0; i < event.getPointerCount(); i++) {
                    int pid = event.getPointerId(i);
                    if (pid != activePointer) {
                        float x = event.getX(i);
                        float y = event.getY(i);
                        p2X = Math.max(tableLeft + malletRadius, Math.min(tableRight - malletRadius, x));
                        p2Y = Math.max(centerY + malletRadius + 10, Math.min(tableBottom - malletRadius, y));
                    }
                }
            }
            return true;
        }

        @Override
        protected void onAttachedToWindow() {
            super.onAttachedToWindow();
            if (!gameRunning) startLoop();
        }

        @Override
        protected void onDetachedFromWindow() {
            super.onDetachedFromWindow();
            gameRunning = false;
        }
    }
}