package com.last04ka.messenger.adapters;

import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.last04ka.messenger.R;
import com.last04ka.messenger.utils.LanguageData;

import java.util.List;

public class LanguageAdapter extends RecyclerView.Adapter<LanguageAdapter.ViewHolder> {

    private List<LanguageData.Language> languages;
    private OnLanguageClickListener listener;

    public interface OnLanguageClickListener {
        void onLanguageClick(int position);
    }

    public LanguageAdapter(List<LanguageData.Language> languages, OnLanguageClickListener listener) {
        this.languages = languages;
        this.listener = listener;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_language, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {
        LanguageData.Language lang = languages.get(position);
        holder.tvFlag.setText(lang.getFlag());
        holder.tvName.setText(lang.getName());
        holder.tvNativeName.setText(lang.getNativeName());

        holder.itemView.setOnClickListener(v -> {
            if (listener != null) {
                listener.onLanguageClick(position);
            }
        });
    }

    @Override
    public int getItemCount() {
        return languages.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        TextView tvFlag, tvName, tvNativeName;

        public ViewHolder(View itemView) {
            super(itemView);
            tvFlag = itemView.findViewById(R.id.tv_lang_flag);
            tvName = itemView.findViewById(R.id.tv_lang_name);
            tvNativeName = itemView.findViewById(R.id.tv_lang_native);
        }
    }
}