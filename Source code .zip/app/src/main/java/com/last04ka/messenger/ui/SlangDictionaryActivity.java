package com.last04ka.messenger.ui;

import android.app.Activity;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import com.last04ka.messenger.utils.AppLogger;
import java.util.HashMap;
import java.util.Map;

public class SlangDictionaryActivity extends Activity {

    private EditText searchInput;
    private TextView resultText;
    private Map<String, String> dictionary = new HashMap<>();
    private Button btnRandom;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        try {
            AppLogger.log(this, "SlangDict", "onCreate started");
            initDictionary();

            LinearLayout layout = new LinearLayout(this);
            layout.setOrientation(LinearLayout.VERTICAL);
            layout.setPadding(24, 24, 24, 24);
            layout.setBackgroundColor(0xFF1A1A2E);

            searchInput = new EditText(this);
            searchInput.setHint("Введите слово...");
            searchInput.setTextColor(0xFFFFFFFF); searchInput.setHintTextColor(0xFF757575);
            searchInput.setTextSize(18); searchInput.setPadding(12, 12, 12, 12);
            searchInput.addTextChangedListener(new TextWatcher() {
                @Override public void beforeTextChanged(CharSequence s, int st, int c, int a) {}
                @Override public void onTextChanged(CharSequence s, int st, int b, int c) { searchWord(s.toString()); }
                @Override public void afterTextChanged(Editable s) {}
            });
            layout.addView(searchInput);

            btnRandom = new Button(this); btnRandom.setText("Случайное слово");
            btnRandom.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Object[] keys = dictionary.keySet().toArray();
                    String key = (String) keys[new java.util.Random().nextInt(keys.length)];
                    searchInput.setText(key);
                }
            });
            layout.addView(btnRandom);

            ScrollView sv = new ScrollView(this);
            resultText = new TextView(this);
            resultText.setText("Введите слово для поиска");
            resultText.setTextSize(16); resultText.setTextColor(0xFFFFFFFF);
            resultText.setPadding(16, 16, 16, 16);
            resultText.setBackgroundColor(0xFF333333);
            resultText.setMinHeight(300);
            sv.addView(resultText);
            layout.addView(sv);

            setContentView(layout);
            setTitle("📖 Словарь сленга");
            AppLogger.log(this, "SlangDict", "onCreate completed");
        } catch (Exception e) { AppLogger.logException(this, "SlangDict", e); finish(); }
    }

    private void initDictionary() {
        dictionary.put("краш", "Человек, в которого ты тайно влюблён или который тебе очень нравится.");
        dictionary.put("кринж", "Чувство стыда или неловкости за чужие действия; испанский стыд.");
        dictionary.put("чилить", "Расслабляться, отдыхать, ничего не делать.");
        dictionary.put("флексить", "Хвастаться, выпендриваться, показывать своё превосходство.");
        dictionary.put("агриться", "Злиться, раздражаться, выходить из себя.");
        dictionary.put("буллинг", "Травля, запугивание, преследование коллективом.");
        dictionary.put("хайп", "Шумиха, ажиотаж вокруг чего-либо; то, что сейчас модно.");
        dictionary.put("рофл", "Шутка, прикол; от англ. Rolling On Floor Laughing.");
        dictionary.put("панч", "Ударная фраза, остроумный ответ, смысловой удар.");
        dictionary.put("треш", "Что-то ужасное, отвратительное, выходящее за рамки.");
        dictionary.put("зашквар", "Позор, стыд; то, что считается неприемлемым.");
        dictionary.put("форсить", "Навязывать, продвигать, усиленно рекламировать.");
        dictionary.put("лойс", "Лайк, одобрение; означает 'круто' или 'нравится'.");
        dictionary.put("байтить", "Провоцировать, подстрекать, копировать чужой стиль.");
        dictionary.put("скуф", "Неопрятный, неухоженный мужчина среднего возраста.");
        dictionary.put("альтушка", "Девушка с альтернативным стилем и взглядами.");
        dictionary.put("вайб", "Атмосфера, настроение, энергия места или человека.");
        dictionary.put("сасный", "Привлекательный, сексуальный (от англ. sassy).");
        dictionary.put("токсик", "Человек, отравляющий жизнь другим; вредный.");
        dictionary.put("фиксить", "Исправлять, чинить, решать проблему (от англ. fix).");
        dictionary.put("донат", "Пожертвование, денежная поддержка стримера или проекта.");
        dictionary.put("имба", "Несбалансированно сильный персонаж или предмет в игре.");
        dictionary.put("нуб", "Новичок, неопытный игрок (от англ. newbie).");
        dictionary.put("лайтовый", "Лёгкий, простой, не напрягающий.");
        dictionary.put("хейт", "Ненависть, негативные комментарии (от англ. hate).");
        dictionary.put("чекать", "Проверять, смотреть (от англ. check).");
        dictionary.put("шеймить", "Стыдить, осуждать публично (от англ. shame).");
        dictionary.put("юзать", "Использовать (от англ. use).");
        dictionary.put("гуглить", "Искать информацию в интернете (обычно через Google).");
        dictionary.put("шипперить", "Представлять романтические отношения между людьми/персонажами.");
    }

    private void searchWord(String query) {
        if (query.isEmpty()) { resultText.setText("Введите слово для поиска"); return; }
        String lower = query.toLowerCase().trim();
        StringBuilder sb = new StringBuilder();
        boolean found = false;
        for (Map.Entry<String, String> e : dictionary.entrySet()) {
            if (e.getKey().contains(lower) || lower.contains(e.getKey())) {
                sb.append("📌 ").append(e.getKey()).append("\n").append(e.getValue()).append("\n\n");
                found = true;
            }
        }
        if (!found) {
            for (Map.Entry<String, String> e : dictionary.entrySet()) {
                if (e.getValue().toLowerCase().contains(lower)) {
                    sb.append("📌 ").append(e.getKey()).append("\n").append(e.getValue()).append("\n\n");
                    found = true;
                }
            }
        }
        if (!found) sb.append("Слово не найдено. Попробуйте другое.");
        resultText.setText(sb.toString());
        AppLogger.log(this, "SlangDict", "Search: " + query + " found: " + found);
    }
}