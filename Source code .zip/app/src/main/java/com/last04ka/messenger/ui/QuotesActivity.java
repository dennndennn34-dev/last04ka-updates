package com.last04ka.messenger.ui;

import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import com.last04ka.messenger.utils.AppLogger;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class QuotesActivity extends Activity {

    private TextView quoteText, authorText;
    private EditText searchInput;
    private Button btnRandom, btnCopy, btnShare, btnFav;
    private String currentQuote = "", currentAuthor = "";
    private List<String[]> favorites = new ArrayList<>();
    private Random r = new Random();

    private String[][] quotes = {
        {"Будьте сами собой, все остальные роли уже заняты.", "Оскар Уайльд"},
        {"Жизнь — это то, что случается с вами, пока вы строите другие планы.", "Джон Леннон"},
        {"Лучшее время посадить дерево было 20 лет назад. Следующее лучшее время — сегодня.", "Китайская пословица"},
        {"Успех — это способность двигаться от неудачи к неудаче, не теряя энтузиазма.", "Уинстон Черчилль"},
        {"Всё, что вы можете вообразить, реально.", "Пабло Пикассо"},
        {"Сложнее всего начать действовать.", "Амелия Эрхарт"},
        {"Стремитесь не к успеху, а к ценностям.", "Альберт Эйнштейн"},
        {"Тот, кто хочет — ищет способ.", "Сократ"},
        {"Лучшая месть — огромный успех.", "Фрэнк Синатра"},
        {"Вдохновение существует, но оно должно застать вас за работой.", "Пабло Пикассо"},
        {"Не считайте дни, пусть дни считают.", "Мохаммед Али"},
        {"Делай что можешь, с тем что имеешь.", "Теодор Рузвельт"},
        {"Образование — самое мощное оружие.", "Нельсон Мандела"},
        {"В середине трудности лежит возможность.", "Альберт Эйнштейн"},
        {"Ты никогда не пересечёшь океан, если не наберёшься смелости потерять берег из виду.", "Христофор Колумб"},
        {"Лучше зажечь свечу, чем проклинать темноту.", "Конфуций"},
        {"Если вы думаете, что можете — вы правы.", "Генри Форд"},
        {"Неудача — это возможность начать заново, но более мудро.", "Генри Форд"},
        {"Великие дела совершаются не силой, а упорством.", "Сэмюэл Джонсон"},
        {"Будьте переменой, которую хотите видеть в мире.", "Махатма Ганди"},
        {"Слабые никогда не прощают. Прощение — свойство сильных.", "Махатма Ганди"},
        {"Знание — сила.", "Фрэнсис Бэкон"},
        {"Свобода — это право говорить людям то, что они не хотят слышать.", "Джордж Оруэлл"},
        {"Опыт — это имя, которое каждый даёт своим ошибкам.", "Оскар Уайльд"},
        {"Только те, кто предпринимают абсурдные попытки, могут достичь невозможного.", "Альберт Эйнштейн"},
        {"Счастье — это не цель, а побочный продукт.", "Элеонора Рузвельт"},
        {"Всё приходит вовремя для того, кто умеет ждать.", "Франсуа Рабле"},
        {"Я мыслю — следовательно, существую.", "Рене Декарт"},
        {"Чем больше вы скажете, тем меньше люди запомнят.", "Франсуа Фенелон"},
        {"Жизнь на 10% состоит из того, что с нами происходит, и на 90% из того, как мы на это реагируем.", "Чарльз Свиндолл"},
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        try {
            AppLogger.log(this, "Quotes", "onCreate started");
            LinearLayout layout = new LinearLayout(this);
            layout.setOrientation(LinearLayout.VERTICAL);
            layout.setPadding(24, 24, 24, 24);
            layout.setBackgroundColor(0xFF1A1A2E);

            searchInput = new EditText(this);
            searchInput.setHint("Поиск по автору или тексту...");
            searchInput.setTextColor(0xFFFFFFFF); searchInput.setHintTextColor(0xFF757575);
            searchInput.addTextChangedListener(new TextWatcher() {
                @Override public void beforeTextChanged(CharSequence s, int st, int c, int a) {}
                @Override public void onTextChanged(CharSequence s, int st, int b, int c) { searchQuotes(s.toString()); }
                @Override public void afterTextChanged(Editable s) {}
            });
            layout.addView(searchInput);

            ScrollView sv = new ScrollView(this);
            LinearLayout ql = new LinearLayout(this); ql.setOrientation(LinearLayout.VERTICAL);
            ql.setPadding(16, 24, 16, 24); ql.setBackgroundColor(0xFF333333);
            quoteText = new TextView(this); quoteText.setText("Нажмите 'Случайная'");
            quoteText.setTextSize(20); quoteText.setTextColor(0xFFFFFFFF); quoteText.setPadding(0, 0, 0, 12);
            ql.addView(quoteText);
            authorText = new TextView(this); authorText.setText(""); authorText.setTextSize(16); authorText.setTextColor(0xFFFFD740);
            ql.addView(authorText);
            sv.addView(ql);
            layout.addView(sv);

            LinearLayout btns = new LinearLayout(this); btns.setOrientation(LinearLayout.HORIZONTAL);
            btnRandom = new Button(this); btnRandom.setText("Случайная");
            btnRandom.setOnClickListener(new View.OnClickListener() { @Override public void onClick(View v) { showRandomQuote(); } });
            btns.addView(btnRandom);
            btnCopy = new Button(this); btnCopy.setText("Копировать");
            btnCopy.setOnClickListener(new View.OnClickListener() { @Override public void onClick(View v) { copyQuote(); } });
            btns.addView(btnCopy);
            btnShare = new Button(this); btnShare.setText("📤");
            btnShare.setOnClickListener(new View.OnClickListener() { @Override public void onClick(View v) { shareQuote(); } });
            btns.addView(btnShare);
            btnFav = new Button(this); btnFav.setText("⭐");
            btnFav.setOnClickListener(new View.OnClickListener() { @Override public void onClick(View v) { addFavorite(); } });
            btns.addView(btnFav);
            layout.addView(btns);

            setContentView(layout); setTitle("📖 Цитаты великих");
            AppLogger.log(this, "Quotes", "onCreate completed");
        } catch (Exception e) { AppLogger.logException(this, "Quotes", e); finish(); }
    }

    private void showRandomQuote() {
        int idx = r.nextInt(quotes.length);
        currentQuote = quotes[idx][0]; currentAuthor = "— " + quotes[idx][1];
        quoteText.setText("\"" + currentQuote + "\""); authorText.setText(currentAuthor);
    }

    private void searchQuotes(String query) {
        if (query.isEmpty()) return;
        String q = query.toLowerCase();
        StringBuilder sb = new StringBuilder();
        for (String[] qt : quotes) if (qt[0].toLowerCase().contains(q) || qt[1].toLowerCase().contains(q))
            sb.append("• \"").append(qt[0]).append("\"\n  — ").append(qt[1]).append("\n\n");
        if (sb.length() == 0) sb.append("Ничего не найдено");
        quoteText.setText(sb.toString()); authorText.setText("");
    }

    private void copyQuote() {
        if (currentQuote.isEmpty()) { Toast.makeText(this, "Сначала выберите цитату", Toast.LENGTH_SHORT).show(); return; }
        ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
        cm.setPrimaryClip(ClipData.newPlainText("quote", "\"" + currentQuote + "\" " + currentAuthor));
        Toast.makeText(this, "Скопировано!", Toast.LENGTH_SHORT).show();
    }

    private void shareQuote() {
        if (currentQuote.isEmpty()) return;
        Intent share = new Intent(Intent.ACTION_SEND);
        share.setType("text/plain");
        share.putExtra(Intent.EXTRA_TEXT, "\"" + currentQuote + "\" " + currentAuthor);
        startActivity(Intent.createChooser(share, "Поделиться цитатой"));
    }

    private void addFavorite() {
        if (currentQuote.isEmpty()) return;
        for (String[] f : favorites) if (f[0].equals(currentQuote)) { Toast.makeText(this, "Уже в избранном", Toast.LENGTH_SHORT).show(); return; }
        favorites.add(new String[]{currentQuote, currentAuthor.replace("— ", "")});
        Toast.makeText(this, "⭐ Добавлено в избранное!", Toast.LENGTH_SHORT).show();
    }
}