package com.last04ka.messenger.ui;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;
import com.last04ka.messenger.utils.AppLogger;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;

public class BackgroundRemoverActivity extends Activity {

    private ImageView imageView;
    private Bitmap original, processed;
    private SeekBar toleranceBar;
    private TextView toleranceText;
    private Button btnPick, btnRemove, btnSave;
    private int tolerance = 30;
    private static final int PICK_IMAGE = 1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        try {
            AppLogger.log(this, "BgRemover", "onCreate started");
            LinearLayout layout = new LinearLayout(this);
            layout.setOrientation(LinearLayout.VERTICAL);
            layout.setPadding(16, 16, 16, 16);
            layout.setBackgroundColor(0xFF1A1A2E);

            imageView = new ImageView(this);
            LinearLayout.LayoutParams ip = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 1);
            imageView.setLayoutParams(ip);
            imageView.setScaleType(ImageView.ScaleType.FIT_CENTER);
            imageView.setBackgroundColor(0xFF424242); // Серый фон для видимости прозрачности
            layout.addView(imageView);

            toleranceText = new TextView(this);
            toleranceText.setText("Чувствительность: " + tolerance);
            toleranceText.setTextColor(0xFFFFFFFF); toleranceText.setTextSize(14);
            toleranceText.setGravity(android.view.Gravity.CENTER);
            layout.addView(toleranceText);

            toleranceBar = new SeekBar(this);
            toleranceBar.setMax(100); toleranceBar.setProgress(30);
            toleranceBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
                @Override public void onProgressChanged(SeekBar s, int p, boolean u) { tolerance = p; toleranceText.setText("Чувствительность: " + p); }
                @Override public void onStartTrackingTouch(SeekBar s) {}
                @Override public void onStopTrackingTouch(SeekBar s) {}
            });
            layout.addView(toleranceBar);

            LinearLayout btns = new LinearLayout(this);
            btns.setOrientation(LinearLayout.HORIZONTAL);

            btnPick = new Button(this); btnPick.setText("Выбрать фото");
            btnPick.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) { pickImage(); }
            });
            btns.addView(btnPick);

            btnRemove = new Button(this); btnRemove.setText("Удалить фон");
            btnRemove.setEnabled(false);
            btnRemove.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) { removeBackground(); }
            });
            btns.addView(btnRemove);

            btnSave = new Button(this); btnSave.setText("Сохранить");
            btnSave.setEnabled(false);
            btnSave.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) { saveImage(); }
            });
            btns.addView(btnSave);

            layout.addView(btns);
            setContentView(layout);
            setTitle("🖼️ Удаление фона");
            AppLogger.log(this, "BgRemover", "onCreate completed");
        } catch (Exception e) { AppLogger.logException(this, "BgRemover", e); finish(); }
    }

    private void pickImage() {
        Intent intent = new Intent(Intent.ACTION_PICK, android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        startActivityForResult(intent, PICK_IMAGE);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PICK_IMAGE && resultCode == RESULT_OK && data != null) {
            try {
                Uri uri = data.getData();
                InputStream is = getContentResolver().openInputStream(uri);
                original = BitmapFactory.decodeStream(is);
                // Уменьшаем для скорости
                original = Bitmap.createScaledBitmap(original, Math.min(400, original.getWidth()), Math.min(400, original.getHeight()), true);
                is.close();
                imageView.setImageBitmap(original);
                btnRemove.setEnabled(true);
                btnSave.setEnabled(false);
            } catch (Exception e) { Toast.makeText(this, "Ошибка", Toast.LENGTH_SHORT).show(); }
        }
    }

    private void removeBackground() {
        if (original == null) return;
        int w = original.getWidth(), h = original.getHeight();
        int[] pixels = new int[w * h];
        original.getPixels(pixels, 0, w, 0, 0, w, h);

        // Берём цвет левого верхнего угла как цвет фона
        int bgColor = pixels[0];

        for (int i = 0; i < pixels.length; i++) {
            int pixel = pixels[i];
            int dr = Math.abs(Color.red(pixel) - Color.red(bgColor));
            int dg = Math.abs(Color.green(pixel) - Color.green(bgColor));
            int db = Math.abs(Color.blue(pixel) - Color.blue(bgColor));
            if (dr < tolerance && dg < tolerance && db < tolerance) {
                pixels[i] = Color.TRANSPARENT;
            }
        }

        processed = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
        processed.setPixels(pixels, 0, w, 0, 0, w, h);
        imageView.setImageBitmap(processed);
        btnSave.setEnabled(true);
        Toast.makeText(this, "Фон удалён!", Toast.LENGTH_SHORT).show();
        AppLogger.log(this, "BgRemover", "Background removed with tolerance=" + tolerance);
    }

    private void saveImage() {
        if (processed == null) return;
        try {
            File dir = new File(android.os.Environment.getExternalStoragePublicDirectory(
                android.os.Environment.DIRECTORY_DOWNLOADS), "Last04ka");
            if (!dir.exists()) dir.mkdirs();
            File file = new File(dir, "nobg_" + System.currentTimeMillis() + ".png");
            FileOutputStream fos = new FileOutputStream(file);
            processed.compress(Bitmap.CompressFormat.PNG, 100, fos);
            fos.close();
            Toast.makeText(this, "Сохранено: " + file.getAbsolutePath(), Toast.LENGTH_LONG).show();
        } catch (Exception e) { Toast.makeText(this, "Ошибка сохранения", Toast.LENGTH_SHORT).show(); }
    }
}