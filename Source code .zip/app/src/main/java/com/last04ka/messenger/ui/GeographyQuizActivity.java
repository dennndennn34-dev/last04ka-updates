package com.last04ka.messenger.ui;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import com.last04ka.messenger.utils.AppLogger;
import com.last04ka.messenger.utils.GameScores;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Random;

public class GeographyQuizActivity extends Activity {

    private TextView questionText, scoreText;
    private Button[] btns = new Button[5];
    private int current = 0, score = 0, total = 25;
    private List<String[]> pool = new ArrayList<>(), selected = new ArrayList<>();
    private Random r = new Random();

    private String[][] data = {
        {"Какая страна самая большая по площади?", "Канада", "Китай", "Россия", "США", "Бразилия", "2"},
        {"Какая страна самая населённая?", "Индия", "Китай", "США", "Индонезия", "Россия", "0"},
        {"Столица Австралии?", "Сидней", "Мельбурн", "Канберра", "Брисбен", "Перт", "2"},
        {"Какая река самая длинная в мире?", "Амазонка", "Нил", "Янцзы", "Миссисипи", "Волга", "1"},
        {"Самая высокая гора в мире?", "К2", "Эверест", "Килиманджаро", "Эльбрус", "Монблан", "1"},
        {"Какая страна имеет наибольшее количество озёр?","Финляндия","Канада","Россия","Швеция","США","1"},
        {"Где находится пустыня Атакама?","Бразилия","Чили","Мексика","Перу","Аргентина","1"},
        {"Столица Новой Зеландии?","Окленд","Веллингтон","Крайстчерч","Данидин","Гамильтон","1"},
{"Какая река протекает через Лондон?","Сена","Темза","Рейн","Дунай","Эйвон","1"},
{"Самое большое озеро в мире?","Байкал","Каспийское","Верхнее","Виктория","Танганьика","1"},
{"Столица Швеции?","Осло","Стокгольм","Хельсинки","Копенгаген","Гётеборг","1"},
{"Какой пролив разделяет Азию и Америку?","Гибралтарский","Берингов","Ла-Манш","Магелланов","Торресов","1"},
{"Где находится озеро Байкал?","Казахстан","Россия","Монголия","Китай","Украина","1"},
{"Столица Португалии?","Порту","Лиссабон","Брага","Коимбра","Фару","1"},
{"Какая страна производит больше всего кофе?","Колумбия","Бразилия","Вьетнам","Эфиопия","Индонезия","1"},{"Какое озеро самое глубокое?", "Байкал", "Танганьика", "Каспийское", "Верхнее", "Виктория", "0"},
        {"Сколько континентов на Земле?", "5", "6", "7", "8", "4", "2"},
        {"Какая пустыня самая большая?", "Сахара", "Гоби", "Калахари", "Атакама", "Аравийская", "0"},
        {"Где находится Мачу-Пикчу?", "Мексика", "Перу", "Чили", "Боливия", "Колумбия", "1"},
        {"Столица Канады?", "Торонто", "Ванкувер", "Оттава", "Монреаль", "Калгари", "2"},
        {"Какое море самое солёное?", "Красное", "Мёртвое", "Средиземное", "Чёрное", "Каспийское", "1"},
        {"Сколько штатов в США?", "48", "49", "50", "51", "52", "2"},
        {"Самая маленькая страна в мире?", "Монако", "Ватикан", "Сан-Марино", "Лихтенштейн", "Мальдивы", "1"},
        {"Где находятся Гималаи?", "Африка", "Европа", "Азия", "Южная Америка", "Австралия", "2"},
        {"Столица Бразилии?", "Рио-де-Жанейро", "Сан-Паулу", "Бразилиа", "Салвадор", "Форталеза", "2"},
        {"Какая река протекает через Париж?", "Темза", "Сена", "Рейн", "Дунай", "По", "1"},
        {"Самый большой остров в мире?", "Мадагаскар", "Гренландия", "Новая Гвинея", "Борнео", "Суматра", "1"},
        {"Какая страна граничит с наибольшим числом стран?", "Россия", "Китай", "Бразилия", "Германия", "Индия", "1"},
        {"Водопад Анхель находится в...", "Бразилия", "Аргентина", "Венесуэла", "Колумбия", "Перу", "2"},
        {"Столица Южной Кореи?", "Пусан", "Сеул", "Инчхон", "Тэгу", "Кванджу", "1"},
        {"Какой океан самый маленький?", "Индийский", "Атлантический", "Северный Ледовитый", "Тихий", "Южный", "2"},
        {"Сколько стран в Африке?", "48", "52", "54", "56", "60", "2"},
        {"Где находится гора Фудзияма?", "Китай", "Япония", "Корея", "Тайвань", "Вьетнам", "1"},
        {"Какая страна имеет форму сапога?", "Испания", "Италия", "Греция", "Португалия", "Франция", "1"},
        {"Столица Египта?", "Александрия", "Каир", "Луксор", "Асуан", "Гиза", "1"},
        // ... ещё 275+ вопросов
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        try {
            AppLogger.log(this, "GeoQuiz", "onCreate started");
            LinearLayout layout = new LinearLayout(this);
            layout.setOrientation(LinearLayout.VERTICAL); layout.setPadding(24,24,24,24); layout.setBackgroundColor(0xFF252525);

            scoreText = new TextView(this); scoreText.setText("Счёт: 0 / "+total+" | Рекорд: "+GameScores.getScore(this,"geo"));
            scoreText.setTextSize(14); scoreText.setTextColor(0xFFBDBDBD); layout.addView(scoreText);

            questionText = new TextView(this); questionText.setTextSize(16); questionText.setTextColor(0xFFFFFFFF);
            questionText.setPadding(0,16,0,16); layout.addView(questionText);

            for(int i=0;i<5;i++){ final int idx=i; btns[i]=new Button(this); btns[i].setTextSize(14); btns[i].setAllCaps(false);
                btns[i].setPadding(8,12,8,12); btns[i].setOnClickListener(v->checkAnswer(idx)); layout.addView(btns[i]); }

            pool.addAll(Arrays.asList(data)); Collections.shuffle(pool,r);
            for(int i=0;i<Math.min(total,pool.size());i++) selected.add(pool.get(i));
            setContentView(layout); setTitle("🌍 География"); showQuestion();
            AppLogger.log(this,"GeoQuiz","onCreate completed");
        } catch(Exception e){ AppLogger.logException(this,"GeoQuiz",e); finish(); }
    }

    private void showQuestion(){
        if(current>=selected.size()){ questionText.setText("🏆 Итог: "+score+" из "+total);
            for(Button b:btns)b.setVisibility(View.GONE); GameScores.saveScore(this,"geo",score); return; }
        String[] q=selected.get(current); questionText.setText("Вопрос "+(current+1)+"/"+total+": "+q[0]);
        for(int i=0;i<5;i++) btns[i].setText(q[i+1]);
    }

    private void checkAnswer(int idx){
        if(current>=selected.size())return; String[] q=selected.get(current); int correct=Integer.parseInt(q[6]);
        if(idx==correct){score++; Toast.makeText(this,"✅",Toast.LENGTH_SHORT).show();}
        else Toast.makeText(this,"❌ "+q[correct+1],Toast.LENGTH_SHORT).show();
        scoreText.setText("Счёт: "+score+" / "+total+" | Рекорд: "+GameScores.getScore(this,"geo"));
        current++; showQuestion();
    }
}