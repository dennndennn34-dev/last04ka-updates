package com.last04ka.messenger.ui;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import com.last04ka.messenger.utils.AppLogger;
import com.last04ka.messenger.utils.GameScores;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Random;

public class ChemistryQuizActivity extends Activity {

    private TextView questionText, scoreText;
    private Button[] btns = new Button[5];
    private int current = 0, score = 0, total = 25;
    private List<String[]> pool = new ArrayList<>(), selected = new ArrayList<>();
    private Random r = new Random();

    private String[][] data = {
        {"Химический символ золота?", "Ag", "Au", "Fe", "Cu", "Pb", "1"},
        {"Самый лёгкий элемент?", "Гелий", "Водород", "Литий", "Бериллий", "Бор", "1"},
        {"Формула воды?", "CO2", "H2O", "NaCl", "O2", "H2SO4", "1"},
        {"Какой элемент обозначается 'O'?", "Золото", "Кислород", "Олово", "Осмий", "Оганесон", "1"},
        {"Сколько атомов в молекуле кислорода O2?", "1", "2", "3", "4", "8", "1"},
        {"Химический символ серебра?", "Si", "Ag", "Au", "Sr", "Sl", "1"},
        {"Какой газ преобладает в атмосфере Земли?", "Кислород", "Азот", "Углекислый газ", "Аргон", "Водород", "1"},
        {"Формула поваренной соли?", "KCl", "NaCl", "CaCl2", "MgCl2", "Na2CO3", "1"},
        {"Самый твёрдый природный материал?", "Графит", "Алмаз", "Кварц", "Топаз", "Корунд", "1"},
        {"Какой металл жидкий при комнатной температуре?", "Галлий", "Ртуть", "Цезий", "Рубидий", "Франций", "1"},
        {"Химический символ железа?", "Fe", "Ir", "I", "In", "Fr", "0"},
        {"Формула углекислого газа?", "CO", "CO2", "CH4", "C2H5OH", "CaCO3", "1"},
        {"Какой элемент самый распространённый во Вселенной?", "Кислород", "Водород", "Гелий", "Углерод", "Азот", "1"},
        {"Сколько электронов у атома углерода?", "4", "6", "8", "12", "14", "1"},
        {"Какой элемент добавляют в зубную пасту?", "Кальций", "Фтор", "Хлор", "Йод", "Бром", "1"},
        {"Формула серной кислоты?", "HCl", "HNO3", "H2SO4", "H2CO3", "H3PO4", "2"},
        {"Химический символ калия?", "Ca", "K", "C", "Ka", "Kl", "1"},
        {"Какая кислота содержится в желудке?", "Серная", "Соляная", "Азотная", "Уксусная", "Лимонная", "1"},
        {"Какой элемент нужен для дыхания?", "Азот", "Кислород", "Водород", "Гелий", "Углерод", "1"},
        {"Формула метана?", "CH4", "C2H6", "C3H8", "CH3OH", "CO2", "0"},
        {"Химический символ натрия?", "Na", "N", "Ni", "No", "S", "0"},
        {"Какой элемент светится в темноте?", "Кальций", "Фосфор", "Сера", "Магний", "Цинк", "1"},
        {"Сколько протонов у атома водорода?", "0", "1", "2", "3", "4", "1"},
        {"Формула аммиака?", "NH3", "NO2", "N2O", "HNO3", "NH4", "0"},
        {"Какой элемент используют в термометрах?", "Галлий", "Ртуть", "Цезий", "Спирт", "Вода", "1"},
        {"Химический символ меди?", "Cu", "Co", "Cr", "Cm", "C", "0"},
        {"Какой газ используют в воздушных шарах?", "Кислород", "Гелий", "Азот", "Водород", "Аргон", "1"},
        {"Формула уксусной кислоты?", "CH3OH", "C2H5OH", "CH3COOH", "HCOOH", "C3H7OH", "2"},
        {"Самый тяжёлый природный элемент?", "Уран", "Плутоний", "Свинец", "Золото", "Осмий", "0"},
        {"Какой элемент входит в состав костей?", "Железо", "Кальций", "Натрий", "Калий", "Магний", "1"},
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        try {
            AppLogger.log(this, "ChemQuiz", "onCreate started");
            LinearLayout layout = new LinearLayout(this);
            layout.setOrientation(LinearLayout.VERTICAL); layout.setPadding(24,24,24,24); layout.setBackgroundColor(0xFF252525);

            scoreText = new TextView(this); scoreText.setText("Счёт: 0 / "+total+" | Рекорд: "+GameScores.getScore(this,"chem"));
            scoreText.setTextSize(14); scoreText.setTextColor(0xFFBDBDBD); layout.addView(scoreText);

            questionText = new TextView(this); questionText.setTextSize(16); questionText.setTextColor(0xFFFFFFFF);
            questionText.setPadding(0,16,0,16); layout.addView(questionText);

            for(int i=0;i<5;i++){ final int idx=i; btns[i]=new Button(this); btns[i].setTextSize(14); btns[i].setAllCaps(false);
                btns[i].setPadding(8,12,8,12); btns[i].setOnClickListener(new View.OnClickListener() {
                    @Override public void onClick(View v) { checkAnswer(idx); }
                }); layout.addView(btns[i]); }

            pool.addAll(Arrays.asList(data)); Collections.shuffle(pool,r);
            for(int i=0;i<Math.min(total,pool.size());i++) selected.add(pool.get(i));
            setContentView(layout); setTitle("🧪 Химия"); showQuestion();
            AppLogger.log(this,"ChemQuiz","onCreate completed, questions: "+selected.size());
        } catch(Exception e){ AppLogger.logException(this,"ChemQuiz",e); finish(); }
    }

    private void showQuestion(){
        if(current>=selected.size()){ questionText.setText("🏆 Итог: "+score+" из "+total);
            for(Button b:btns)b.setVisibility(View.GONE); GameScores.saveScore(this,"chem",score); return; }
        String[] q=selected.get(current); questionText.setText("Вопрос "+(current+1)+"/"+total+": "+q[0]);
        for(int i=0;i<5;i++) btns[i].setText(q[i+1]);
    }

    private void checkAnswer(int idx){
        if(current>=selected.size())return; String[] q=selected.get(current); int correct=Integer.parseInt(q[6]);
        if(idx==correct){score++; Toast.makeText(this,"✅",Toast.LENGTH_SHORT).show();}
        else Toast.makeText(this,"❌ "+q[correct+1],Toast.LENGTH_SHORT).show();
        scoreText.setText("Счёт: "+score+" / "+total+" | Рекорд: "+GameScores.getScore(this,"chem"));
        current++; showQuestion();
    }
}