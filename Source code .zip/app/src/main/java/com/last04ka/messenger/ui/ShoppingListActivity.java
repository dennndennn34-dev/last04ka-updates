package com.last04ka.messenger.ui;

import android.app.Activity;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import com.last04ka.messenger.utils.AppLogger;

public class ShoppingListActivity extends Activity {

    private LinearLayout listLayout;
    private EditText inputItem;
    private SQLiteDatabase db;
    private Button btnAdd;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        try {
            AppLogger.log(this, "ShoppingList", "onCreate started");
            db = openOrCreateDatabase("shopping.db", MODE_PRIVATE, null);
            db.execSQL("CREATE TABLE IF NOT EXISTS items (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT, checked INTEGER DEFAULT 0)");

            LinearLayout layout = new LinearLayout(this);
            layout.setOrientation(LinearLayout.VERTICAL);
            layout.setPadding(16, 16, 16, 16);
            layout.setBackgroundColor(0xFF1A1A2E);

            TextView title = new TextView(this);
            title.setText("🛒 Список покупок"); title.setTextSize(20);
            title.setTextColor(0xFFFFFFFF); title.setGravity(Gravity.CENTER);
            layout.addView(title);

            LinearLayout inputRow = new LinearLayout(this);
            inputRow.setOrientation(LinearLayout.HORIZONTAL);
            inputItem = new EditText(this);
            inputItem.setHint("Что купить?"); inputItem.setTextColor(0xFFFFFFFF);
            inputItem.setHintTextColor(0xFF888888); inputItem.setBackgroundColor(0xFF333333);
            inputItem.setPadding(12, 10, 12, 10);
            LinearLayout.LayoutParams ip = new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1);
            inputItem.setLayoutParams(ip); inputRow.addView(inputItem);

            btnAdd = new Button(this); btnAdd.setText("+"); btnAdd.setOnClickListener(v -> addItem());
            inputRow.addView(btnAdd);
            layout.addView(inputRow);

            Button btnClear = new Button(this); btnClear.setText("Очистить купленные");
            btnClear.setOnClickListener(v -> { db.execSQL("DELETE FROM items WHERE checked=1"); loadItems(); });
            layout.addView(btnClear);

            listLayout = new LinearLayout(this);
            listLayout.setOrientation(LinearLayout.VERTICAL);
            ScrollView sv = new ScrollView(this); sv.addView(listLayout);
            layout.addView(sv);

            setContentView(layout); setTitle("🛒 Список покупок");
            loadItems();
            AppLogger.log(this, "ShoppingList", "onCreate completed");
        } catch (Exception e) { AppLogger.logException(this, "ShoppingList", e); finish(); }
    }

    private void addItem() {
        String text = inputItem.getText().toString().trim();
        if (text.isEmpty()) { Toast.makeText(this, "Введите название", Toast.LENGTH_SHORT).show(); return; }
        db.execSQL("INSERT INTO items (name, checked) VALUES (?, 0)", new Object[]{text});
        inputItem.setText("");
        loadItems();
        AppLogger.log(this, "ShoppingList", "Item added: " + text);
    }

    private void loadItems() {
        listLayout.removeAllViews();
        Cursor c = db.rawQuery("SELECT * FROM items ORDER BY checked ASC, id DESC", null);
        while (c.moveToNext()) {
            int id = c.getInt(0);
            String name = c.getString(1);
            boolean checked = c.getInt(2) == 1;

            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setPadding(8, 6, 8, 6);
            row.setBackgroundColor(checked ? 0xFF1B5E20 : 0xFF333333);

            CheckBox cb = new CheckBox(this);
            cb.setText(name); cb.setTextColor(0xFFFFFFFF); cb.setChecked(checked);
            cb.setOnCheckedChangeListener((v, isChecked) -> {
                db.execSQL("UPDATE items SET checked=? WHERE id=?", new Object[]{isChecked ? 1 : 0, id});
                loadItems();
            });
            row.addView(cb);

            Button del = new Button(this); del.setText("✕"); del.setTextSize(10);
            int itemId = id;
            del.setOnClickListener(v -> { db.execSQL("DELETE FROM items WHERE id=?", new Object[]{itemId}); loadItems(); });
            row.addView(del);

            listLayout.addView(row);
        }
        c.close();
    }

    @Override
    protected void onDestroy() { super.onDestroy(); if (db != null && db.isOpen()) db.close(); }
}