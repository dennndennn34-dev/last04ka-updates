package com.last04ka.messenger.ui;

import android.app.Activity;
import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;
import com.last04ka.messenger.utils.AppLogger;
import java.util.Calendar;

public class AlarmClockActivity extends Activity {

    private TimePicker timePicker;
    private EditText alarmLabel;
    private TextView statusText;
    private Button btnSet, btnCancel, btnTest;
    private PendingIntent pendingIntent;
    private AlarmManager alarmManager;
    private MediaPlayer mediaPlayer;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        try {
            AppLogger.log(this, "AlarmClock", "onCreate started");
            LinearLayout layout = new LinearLayout(this);
            layout.setOrientation(LinearLayout.VERTICAL);
            layout.setPadding(16, 16, 16, 16);
            layout.setBackgroundColor(0xFF1A1A2E);

            TextView title = new TextView(this);
            title.setText("⏰ Будильник"); title.setTextSize(20);
            title.setTextColor(0xFFFFFFFF); title.setGravity(Gravity.CENTER);
            layout.addView(title);

            timePicker = new TimePicker(this);
            timePicker.setIs24HourView(true);
            layout.addView(timePicker);

            alarmLabel = new EditText(this);
            alarmLabel.setHint("Название будильника");
            alarmLabel.setTextColor(0xFFFFFFFF); alarmLabel.setHintTextColor(0xFF888888);
            alarmLabel.setBackgroundColor(0xFF333333); alarmLabel.setPadding(12, 10, 12, 10);
            layout.addView(alarmLabel);

            statusText = new TextView(this);
            statusText.setText("Будильник не установлен"); statusText.setTextSize(13);
            statusText.setTextColor(0xFF888888); statusText.setGravity(Gravity.CENTER);
            statusText.setPadding(0, 8, 0, 8);
            layout.addView(statusText);

            LinearLayout btnRow = new LinearLayout(this);
            btnRow.setGravity(Gravity.CENTER);
            btnSet = new Button(this); btnSet.setText("Установить");
            btnSet.setOnClickListener(v -> setAlarm()); btnRow.addView(btnSet);
            btnCancel = new Button(this); btnCancel.setText("Отменить");
            btnCancel.setOnClickListener(v -> cancelAlarm()); btnRow.addView(btnCancel);
            btnTest = new Button(this); btnTest.setText("Тест");
            btnTest.setOnClickListener(v -> testAlarm()); btnRow.addView(btnTest);
            layout.addView(btnRow);

            alarmManager = (AlarmManager) getSystemService(ALARM_SERVICE);
            setContentView(layout);
            setTitle("⏰ Будильник");
            AppLogger.log(this, "AlarmClock", "onCreate completed");
        } catch (Exception e) { AppLogger.logException(this, "AlarmClock", e); finish(); }
    }

    private void setAlarm() {
        Calendar cal = Calendar.getInstance();
        cal.set(Calendar.HOUR_OF_DAY, timePicker.getCurrentHour());
        cal.set(Calendar.MINUTE, timePicker.getCurrentMinute());
        cal.set(Calendar.SECOND, 0);
        if (cal.before(Calendar.getInstance())) cal.add(Calendar.DAY_OF_MONTH, 1);

        Intent intent = new Intent(this, AlarmReceiver.class);
        intent.putExtra("label", alarmLabel.getText().toString());
        pendingIntent = PendingIntent.getBroadcast(this, 0, intent, PendingIntent.FLAG_UPDATE_CURRENT);

        if (alarmManager != null) {
            alarmManager.setExact(AlarmManager.RTC_WAKEUP, cal.getTimeInMillis(), pendingIntent);
            String time = String.format("%02d:%02d", timePicker.getCurrentHour(), timePicker.getCurrentMinute());
            statusText.setText("Установлен на " + time);
            Toast.makeText(this, "Будильник на " + time, Toast.LENGTH_SHORT).show();
            AppLogger.log(this, "AlarmClock", "Alarm set for " + time);
        }
    }

    private void cancelAlarm() {
        if (pendingIntent != null && alarmManager != null) {
            alarmManager.cancel(pendingIntent);
            statusText.setText("Будильник отменён");
            Toast.makeText(this, "Отменён", Toast.LENGTH_SHORT).show();
            AppLogger.log(this, "AlarmClock", "Alarm cancelled");
        }
    }

    private void testAlarm() {
        try {
            mediaPlayer = MediaPlayer.create(this, Settings.System.DEFAULT_ALARM_ALERT_URI);
            if (mediaPlayer != null) { mediaPlayer.start(); Toast.makeText(this, "Тест!", Toast.LENGTH_SHORT).show(); }
        } catch (Exception e) { Toast.makeText(this, "Нет звука", Toast.LENGTH_SHORT).show(); }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (mediaPlayer != null) { try { mediaPlayer.release(); } catch (Exception e) {} }
    }
}