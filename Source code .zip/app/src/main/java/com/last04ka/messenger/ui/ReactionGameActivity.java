package com.last04ka.messenger.ui;

import android.app.Activity;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import com.last04ka.messenger.utils.AppLogger;
import com.last04ka.messenger.utils.GameScores;
import java.util.Random;

public class ReactionGameActivity extends Activity {

    private TextView statusText, timeText, bestText;
    private Button btnStart;
    private LinearLayout mainLayout;
    private long startTime;
    private boolean waiting = false;
    private Random random = new Random();
    private long bestTime = Long.MAX_VALUE;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        try {
            bestTime = GameScores.getScore(this, "reaction");
            if (bestTime == 0) bestTime = Long.MAX_VALUE;

            mainLayout = new LinearLayout(this);
            mainLayout.setOrientation(LinearLayout.VERTICAL);
            mainLayout.setGravity(android.view.Gravity.CENTER);
            mainLayout.setBackgroundColor(0xFFFF0000); // Красный — жди
            mainLayout.setClickable(true);

            statusText = new TextView(this);
            statusText.setText("⚡ Тест реакции");
            statusText.setTextSize(28);
            statusText.setTextColor(0xFFFFFFFF);
            statusText.setGravity(android.view.Gravity.CENTER);
            statusText.setPadding(0, 40, 0, 20);
            mainLayout.addView(statusText);

            timeText = new TextView(this);
            timeText.setText("Нажмите 'Начать'");
            timeText.setTextSize(20);
            timeText.setTextColor(0xFFFFFFFF);
            timeText.setGravity(android.view.Gravity.CENTER);
            timeText.setPadding(0, 0, 0, 20);
            mainLayout.addView(timeText);

            bestText = new TextView(this);
            bestText.setText("Рекорд: " + (bestTime == Long.MAX_VALUE ? "--" : bestTime + " мс"));
            bestText.setTextSize(16);
            bestText.setTextColor(0xFFFFCDD2);
            bestText.setGravity(android.view.Gravity.CENTER);
            bestText.setPadding(0, 0, 0, 20);
            mainLayout.addView(bestText);

            btnStart = new Button(this);
            btnStart.setText("Начать");
            btnStart.setTextSize(22);
            btnStart.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    startGame();
                }
            });
            mainLayout.addView(btnStart);

            // Нажатие на весь экран
            mainLayout.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (waiting) {
                        screenClicked();
                    }
                }
            });

            setContentView(mainLayout);
            setTitle("⚡ Реакция");
        } catch (Exception e) {
            AppLogger.logException(this, "ReactionGame", e);
            finish();
        }
    }

    private void startGame() {
        btnStart.setVisibility(View.GONE);
        mainLayout.setBackgroundColor(0xFFFF0000);
        statusText.setText("Ждите зелёный...");
        timeText.setText("Приготовьтесь!");
        waiting = true;

        // Случайная задержка 1-5 секунд
        int delay = 1000 + random.nextInt(4000);
        mainLayout.postDelayed(new Runnable() {
            @Override
            public void run() {
                if (waiting) {
                    mainLayout.setBackgroundColor(0xFF00C853);
                    statusText.setText("НАЖМИТЕ!");
                    startTime = System.currentTimeMillis();
                }
            }
        }, delay);
    }

    private void screenClicked() {
        if (!waiting) return;

        long reactionTime = System.currentTimeMillis() - startTime;

        if (reactionTime < 10) {
            // Слишком быстро — жульничество
            statusText.setText("Слишком рано! 😅");
            timeText.setText("Дождитесь зелёного цвета!");
            mainLayout.setBackgroundColor(0xFFFF0000);
            waiting = false;
            btnStart.setVisibility(View.VISIBLE);
            return;
        }

        waiting = false;
        mainLayout.setBackgroundColor(0xFF1565C0);
        statusText.setText("Ваша реакция:");
        timeText.setText(reactionTime + " мс");

        if (reactionTime < bestTime) {
            bestTime = reactionTime;
            GameScores.saveScore(this, "reaction", (int) bestTime);
            bestText.setText("🏆 Новый рекорд: " + bestTime + " мс!");
            Toast.makeText(this, "🏆 Новый рекорд!", Toast.LENGTH_SHORT).show();
        } else {
            bestText.setText("Рекорд: " + (bestTime == Long.MAX_VALUE ? "--" : bestTime + " мс"));
        }

        btnStart.setText("Повторить");
        btnStart.setVisibility(View.VISIBLE);
        AppLogger.log(this, "ReactionGame", "Reaction: " + reactionTime + "ms");
    }
}