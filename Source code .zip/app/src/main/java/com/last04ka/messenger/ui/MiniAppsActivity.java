package com.last04ka.messenger.ui;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.AlphaAnimation;
import android.view.animation.AnimationSet;
import android.view.animation.TranslateAnimation;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.last04ka.messenger.R;
import com.last04ka.messenger.utils.AppLogger;
import com.last04ka.messenger.utils.ThemeManager;

import java.util.ArrayList;
import java.util.List;

public class MiniAppsActivity extends AppCompatActivity {

    private String[] allApps = {
        // ============ НОВАЯ ИГРА ============
        "🎱 Шарики и дырка",
        // ============ НОВАЯ ИГРА В НАЧАЛЕ СПИСКА ============
        "🎮 Шарик-приключение",
        // ============ НОВОЕ ПРИЛОЖЕНИЕ ============
        "🌍 Изучение языков v2.0",
        // ============ НОВАЯ ПОЧТА ============
        "📧 Почта (IMAP)",
        // ============ ОСТАЛЬНЫЕ ПРИЛОЖЕНИЯ ============
        "🖼️ AI Фото-редактор",
        "📊 Метаданные фото",
        "💀 Виселица",
        "🔢 Судоку",
        "⏰ Будильник",
        "🛒 Список покупок",
        "✊✋✌ Камень-Ножницы-Бумага",
        "⏲ Таймер",
        "⚖ Калькулятор ИМТ",
        "🎨 Пиксель-Арт",
        "🥠 Печенье с предсказаниями",
        "❌⭕ Крестики-нолики 2.0",
        "🏎️ Ретро-гонки",
        "🌀 Лабиринт",
        "🧱 Арканоид 2.0",
        "🚀 Космо-стрелялка",
        "🏃 Платформер",
        "📐 Конвертер единиц",
        "🌐 IP-инструменты",
        "🔐 Шифратор",
        "⚡ Быстрый доступ",
        "🗣 Изучение языков",
        "📁 Файловый менеджер",
        "🌤 Погода",
        "🐤 Флаппи Бёрд",
        "❌⭕ Крестики-нолики PvP",
        "📝 Заметки",
        "🎙️ Диктофон",
        "🧠 Мнемокарточки",
        "📻 Азбука Морзе PRO",
        "🎲 Кубик",
        "🪩 Аэрохоккей",
        "🌐 Браузер",
        "🤖 Чат-бот с ИИ",
        "📝 Офлайн-переводчик",
        "🔢 Калькулятор",
        "🔑 Генератор паролей",
        "📅 Календарь",
        "🔗 QR-генератор",
        "🗺️ Офлайн-карты",
        "📶 Спидтест",
        "🎭 Анекдоты",
        "📝 Совет дня",
        "🔮 Предсказатель",
        "📖 Словарь сленга",
        "💰 Конвертер валют",
        "📋 Генератор ников",
        "📚 Литература",
        "🧬 Биология",
        "🏳️ Флаги мира",
        "🌍 Столицы мира",
        "🧮 Таблица умножения",
        "⌨️ Скорость печати",
        "⚡ Реакция",
        "🧠 Матем. блиц",
        "🎨 Цветовой тест",
        "🎨 Рисовалка",
        "🧮 24 points",
        "👆 Тап-рекорд",
        "🌍 География",
        "🧪 Химия",
        "🧠 Эрудит",
        "⚔️ Морской бой",
        "♟️ Шахматы",
        "🧬 Генетический калькулятор",
        "🧠 IQ тест",
        "📸 Сканер документов",
        "📄 PDF читалка",
        "🖼️ Удаление фона",
        "🧪 Анализатор звука",
        "🎛️ Эквалайзер",
        "🔦 Фонарик",
        "🧭 Компас",
        "⏱️ Секундомер",
        "🎯 Колесо фортуны",
        "📡 Wi-Fi сканер PRO",
        "📖 Цитаты великих",
        "🏆 Ежедневный челлендж",
        "👤 Профиль игрока",
        "📊 График прогресса",
        "🐍 Змейка",
        "🧱 Тетрис",
        "🎯 Угадай число",
        "🧠 Викторина",
        "🔢 2048",
        "💣 Сапёр",
        "🧠 Память",
        "🎲 Кости",
        "⚡ Тайминг",
        "🏓 Пинг-понг",
        "📖 Правила всех игр"
    };

    private EditText searchInput;
    private ListView listView;
    private ArrayAdapter<String> adapter;
    private List<String> filteredApps = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        setTheme(ThemeManager.getThemeResource(this));
        super.onCreate(savedInstanceState);
        try {
            AppLogger.log(this, "MiniApps", "onCreate v13 with Email (Почта)");
            AppLogger.logUI(this, "MiniApps", "MiniAppsActivity layout with search", true);

            setContentView(R.layout.activity_mini_apps);
            setTitle("Мини-приложения (" + allApps.length + ")");

            searchInput = findViewById(R.id.search_mini_apps);
            listView = findViewById(R.id.mini_apps_list);

            filteredApps.clear();
            for (String app : allApps) {
                filteredApps.add(app);
            }

            adapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, filteredApps) {
                @Override
                public View getView(int position, View convertView, ViewGroup parent) {
                    View v = super.getView(position, convertView, parent);
                    TextView tv = (TextView) v.findViewById(android.R.id.text1);
                    if (tv != null) {
                        tv.setTextColor(ThemeManager.getTextColor(MiniAppsActivity.this));
                        tv.setPadding(24, 18, 24, 18);
                        tv.setTextSize(16);
                    }
                    AnimationSet set = new AnimationSet(true);
                    set.addAnimation(new TranslateAnimation(300, 0, 0, 0){{setDuration(400 + position * 15);}});
                    set.addAnimation(new AlphaAnimation(0f, 1f){{setDuration(400 + position * 15);}});
                    v.startAnimation(set);
                    return v;
                }
            };

            listView.setAdapter(adapter);
            listView.setBackgroundColor(ThemeManager.getBackgroundColor(this));

            listView.setOnItemClickListener((parent, view, position, id) -> {
                String appName = filteredApps.get(position);
                AppLogger.log(MiniAppsActivity.this, "MiniApps", "App selected: " + position + " - " + appName);
                int originalPos = getOriginalPosition(appName);
                Intent i = getIntent(originalPos);
                if (i != null) {
                    startActivity(i);
                } else {
                    Toast.makeText(MiniAppsActivity.this, "В разработке", Toast.LENGTH_SHORT).show();
                    AppLogger.log(MiniAppsActivity.this, "MiniApps", "App not implemented yet: " + originalPos);
                }
            });

            searchInput.addTextChangedListener(new TextWatcher() {
                @Override
                public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

                @Override
                public void onTextChanged(CharSequence s, int start, int before, int count) {
                    filterApps(s.toString());
                }

                @Override
                public void afterTextChanged(Editable s) {}
            });

            AppLogger.log(this, "MiniApps", "onCreate completed successfully with search");
        } catch(Exception e) {
            AppLogger.logException(this, "MiniApps", e);
            Toast.makeText(this, "Ошибка загрузки мини-приложений", Toast.LENGTH_LONG).show();
            finish();
        }
    }

    private void filterApps(String query) {
        filteredApps.clear();
        if (query.isEmpty()) {
            for (String app : allApps) {
                filteredApps.add(app);
            }
        } else {
            String lowerQuery = query.toLowerCase().trim();
            for (String app : allApps) {
                if (app.toLowerCase().contains(lowerQuery)) {
                    filteredApps.add(app);
                }
            }
        }
        adapter.notifyDataSetChanged();
        AppLogger.log(this, "MiniApps", "Filtered: " + filteredApps.size() + " apps, query: " + query);
    }

    private int getOriginalPosition(String appName) {
        for (int i = 0; i < allApps.length; i++) {
            if (allApps[i].equals(appName)) {
                return i;
            }
        }
        return -1;
    }

    private Intent getIntent(int position) {
        AppLogger.log(this, "MiniApps", "getIntent for position: " + position);

        // ============ НОВАЯ ИГРА "ШАРИКИ И ДЫРКА" ============
        if (position == 0) {
            AppLogger.log(this, "MiniApps", "Launching BallHoleActivity (Шарики и дырка)");
            return new Intent(this, BallHoleActivity.class);
        }

        // ============ ИГРА "ШАРИК-ПРИКЛЮЧЕНИЕ" ============
        if (position == 1) {
            AppLogger.log(this, "MiniApps", "Launching BallLevelSelectionActivity");
            return new Intent(this, BallLevelSelectionActivity.class);
        }

        // ============ НОВОЕ ПРИЛОЖЕНИЕ "ИЗУЧЕНИЕ ЯЗЫКОВ v2.0" ============
        if (position == 2) {
            AppLogger.log(this, "MiniApps", "Launching LanguageLearningActivity");
            return new Intent(this, LanguageLearningActivity.class);
        }

        // ============ НОВАЯ ПОЧТА ============
        if (position == 3) {
            AppLogger.log(this, "MiniApps", "Launching EmailActivity (Почта)");
            return new Intent(this, EmailActivity.class);
        }

        // ============ ОСТАЛЬНЫЕ ПРИЛОЖЕНИЯ ============
        switch(position) {
            case 4: return new Intent(this, PhotoEditorActivity.class);
            case 5: return new Intent(this, PhotoMetadataActivity.class);
            case 6: return new Intent(this, HangmanActivity.class);
            case 7: return new Intent(this, SudokuActivity.class);
            case 8: return new Intent(this, AlarmClockActivity.class);
            case 9: return new Intent(this, ShoppingListActivity.class);
            case 10: return new Intent(this, RockPaperScissorsActivity.class);
            case 11: return new Intent(this, CountdownActivity.class);
            case 12: return new Intent(this, BmiCalculatorActivity.class);
            case 13: return new Intent(this, PixelArtActivity.class);
            case 14: return new Intent(this, FortuneCookieActivity.class);
            case 15: return new Intent(this, TicTacToeActivity.class);
            case 16: return new Intent(this, RetroRacerActivity.class);
            case 17: return new Intent(this, MazeActivity.class);
            case 18: return new Intent(this, ArkanoidActivity.class);
            case 19: return new Intent(this, SpaceShooterActivity.class);
            case 20: return new Intent(this, DoodleJumpActivity.class);
            case 21: return new Intent(this, UnitConverterActivity.class);
            case 22: return new Intent(this, IPToolsActivity.class);
            case 23: return new Intent(this, CipherActivity.class);
            case 24: return new Intent(this, WidgetActivity.class);
            case 25: return new Intent(this, LanguageTrainerActivity.class);
            case 26: return new Intent(this, FileManagerActivity.class);
            case 27: return new Intent(this, WeatherActivity.class);
            case 28: return new Intent(this, FlappyBirdActivity.class);
            case 29: return new Intent(this, TicTacToePvPActivity.class);
            case 30: return new Intent(this, NotesActivity.class);
            case 31: return new Intent(this, VoiceMemoActivity.class);
            case 32: return new Intent(this, FlashCardsActivity.class);
            case 33: return new Intent(this, MorseCodeActivity.class);
            case 34: return new Intent(this, DiceRollerActivity.class);
            case 35: return new Intent(this, AirHockeyActivity.class);
            case 36: return new Intent(this, BrowserActivity.class);
            case 37: return new Intent(this, ChatBotActivity.class);
            case 38: return new Intent(this, TranslatorActivity.class);
            case 39: return new Intent(this, CalculatorActivity.class);
            case 40: return new Intent(this, PasswordGeneratorActivity.class);
            case 41: return new Intent(this, CalendarActivity.class);
            case 42: return new Intent(this, QRGeneratorActivity.class);
            case 43: return new Intent(this, OfflineMapsActivity.class);
            case 44: return new Intent(this, SpeedTestActivity.class);
            case 45: return new Intent(this, JokesActivity.class);
            case 46: return new Intent(this, DailyAdviceActivity.class);
            case 47: return new Intent(this, PredictorActivity.class);
            case 48: return new Intent(this, SlangDictionaryActivity.class);
            case 49: return new Intent(this, CurrencyConverterActivity.class);
            case 50: return new Intent(this, NickGeneratorActivity.class);
            case 51: return new Intent(this, LiteratureQuizActivity.class);
            case 52: return new Intent(this, BiologyQuizActivity.class);
            case 53: return new Intent(this, FlagsQuizActivity.class);
            case 54: return new Intent(this, CapitalsQuizActivity.class);
            case 55: return new Intent(this, MultiplicationActivity.class);
            case 56: return new Intent(this, TypingSpeedActivity.class);
            case 57: return new Intent(this, ReactionGameActivity.class);
            case 58: return new Intent(this, MathBlitzActivity.class);
            case 59: return new Intent(this, ColorTestActivity.class);
            case 60: return new Intent(this, DrawingActivity.class);
            case 61: return new Intent(this, Game24Activity.class);
            case 62: return new Intent(this, TapRecordActivity.class);
            case 63: return new Intent(this, GeographyQuizActivity.class);
            case 64: return new Intent(this, ChemistryQuizActivity.class);
            case 65: return new Intent(this, EruditeQuizActivity.class);
            case 66: return new Intent(this, BattleshipActivity.class);
            case 67: return new Intent(this, ChessActivity.class);
            case 68: return new Intent(this, GeneticCalculatorActivity.class);
            case 69: return new Intent(this, IQTestActivity.class);
            case 70: return new Intent(this, DocumentScannerActivity.class);
            case 71: return new Intent(this, PDFReaderActivity.class);
            case 72: return new Intent(this, BackgroundRemoverActivity.class);
            case 73: return new Intent(this, SoundAnalyzerActivity.class);
            case 74: return new Intent(this, EqualizerActivity.class);
            case 75: return new Intent(this, FlashlightActivity.class);
            case 76: return new Intent(this, CompassActivity.class);
            case 77: return new Intent(this, StopwatchActivity.class);
            case 78: return new Intent(this, WheelFortuneActivity.class);
            case 79: return new Intent(this, WifiScannerActivity.class);
            case 80: return new Intent(this, QuotesActivity.class);
            case 81: return new Intent(this, DailyChallengeActivity.class);
            case 82: return new Intent(this, PlayerProfileActivity.class);
            case 83: return new Intent(this, ProgressChartActivity.class);
            case 84: return new Intent(this, SnakeGameActivity.class);
            case 85: return new Intent(this, TetrisGameActivity.class);
            case 86: return new Intent(this, GuessNumberActivity.class);
            case 87: return new Intent(this, QuizGameActivity.class);
            case 88: return new Intent(this, Game2048Activity.class);
            case 89: return new Intent(this, MinesweeperActivity.class);
            case 90: return new Intent(this, MemoryGameActivity.class);
            case 91: return new Intent(this, DiceGameActivity.class);
            case 92: return new Intent(this, TimingGameActivity.class);
            case 93: return new Intent(this, PongGameActivity.class);
            case 94: return new Intent(this, GameRulesActivity.class);
            default:
                AppLogger.log(this, "MiniApps", "Unknown position: " + position);
                return null;
        }
    }
}