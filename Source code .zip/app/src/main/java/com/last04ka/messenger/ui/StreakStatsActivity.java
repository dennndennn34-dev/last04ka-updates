package com.last04ka.messenger.ui;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.Gravity;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.last04ka.messenger.R;
import com.last04ka.messenger.utils.AppLogger;
import com.last04ka.messenger.utils.StreakManager;
import com.last04ka.messenger.utils.ThemeManager;

public class StreakStatsActivity extends AppCompatActivity {
    private static final String TAG = "StreakStats";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        setTheme(ThemeManager.getThemeResource(this));
        super.onCreate(savedInstanceState);
        AppLogger.log(this, TAG, "========== onCreate START ==========");

        try {
            LinearLayout layout = new LinearLayout(this);
            layout.setOrientation(LinearLayout.VERTICAL);
            layout.setPadding(32, 32, 32, 32);
            layout.setBackgroundColor(ThemeManager.getBackgroundColor(this));

            TextView title = new TextView(this);
            title.setText("📊 Моя статистика");
            title.setTextSize(22);
            title.setTextColor(ThemeManager.getTextColor(this));
            title.setGravity(Gravity.CENTER);
            title.setPadding(0, 0, 0, 32);
            layout.addView(title);

            int streak = StreakManager.getStreakDays(this);
            int best = StreakManager.getBestStreak(this);
            int today = StreakManager.getTodayMinutes(this);
            int total = StreakManager.getTotalMinutes(this);
            boolean complete = StreakManager.isTodayComplete(this);
            String ringName = StreakManager.getRingName(streak);
            String ringColor = StreakManager.getRingColor(streak);

            AppLogger.log(this, TAG, "Stats: streak=" + streak + ", best=" + best + ", today=" + today + ", total=" + total);

            addStat(layout, "🔥 Текущая серия", streak + " дней");
            addStat(layout, "🏆 Лучшая серия", best + " дней");
            addStat(layout, "⏱ Сегодня в приложении", today + " мин " + (complete ? "✅" : "❌ (нужно 25 мин)"));
            addStat(layout, "📅 Всего времени", total + " мин (" + (total / 60) + " ч)");
            addStat(layout, "💍 Ободок", ringName);
            addStat(layout, "🎨 Цвет ободка", ringColor);

            View divider = new View(this);
            divider.setLayoutParams(new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 1));
            divider.setBackgroundColor(ThemeManager.getDividerColor(this));
            divider.setPadding(0, 16, 0, 16);
            layout.addView(divider);

            TextView progressTitle = new TextView(this);
            progressTitle.setText("📈 Прогресс к следующему ободку:");
            progressTitle.setTextSize(16);
            progressTitle.setTextColor(ThemeManager.getTextColor(this));
            progressTitle.setPadding(0, 8, 0, 8);
            layout.addView(progressTitle);

            addProgressRow(layout, "🥉 Бронзовый (10 дней)", streak, 10);
            addProgressRow(layout, "🥈 Серебряный (30 дней)", streak, 30);
            addProgressRow(layout, "🥇 Золотой (60 дней)", streak, 60);
            addProgressRow(layout, "💎 Алмазный (100 дней)", streak, 100);

            setContentView(layout);
            setTitle("📊 Статистика");

            AppLogger.log(this, TAG, "========== onCreate SUCCESS ==========");
        } catch (Exception e) {
            AppLogger.logException(this, TAG, "onCreate error", e);
            finish();
        }
    }

    private void addStat(LinearLayout layout, String label, String value) {
        TextView tv = new TextView(this);
        tv.setText(label + ": " + value);
        tv.setTextSize(16);
        tv.setTextColor(ThemeManager.getTextColor(this));
        tv.setPadding(0, 8, 0, 8);
        layout.addView(tv);
        AppLogger.log(this, TAG, "Added stat: " + label + " = " + value);
    }

    private void addProgressRow(LinearLayout layout, String name, int current, int target) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setPadding(0, 4, 0, 4);

        TextView label = new TextView(this);
        label.setText(name + " ");
        label.setTextSize(14);
        label.setTextColor(ThemeManager.getTextSecondaryColor(this));
        row.addView(label);

        int progress = Math.min(current, target);
        String status = progress >= target ? "✅" : (progress + "/" + target);

        TextView progressText = new TextView(this);
        progressText.setText(status);
        progressText.setTextSize(14);
        progressText.setTextColor(progress >= target ? 0xFF4CAF50 : ThemeManager.getTextSecondaryColor(this));
        row.addView(progressText);

        layout.addView(row);
        AppLogger.log(this, TAG, "Progress: " + name + " = " + status);
    }
}