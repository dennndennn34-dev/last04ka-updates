package com.last04ka.messenger.utils;

import android.content.Context;
import android.content.SharedPreferences;
import com.last04ka.messenger.R;

public class ThemeManager {

    public static final String PREFS_NAME = "theme_prefs";
    public static final String KEY_THEME = "app_theme";

    public static final int THEME_LIGHT = 0;
    public static final int THEME_DARK = 1;
    public static final int THEME_AMOLED = 2;
    public static final int THEME_OCEAN = 3;
    public static final int THEME_FOREST = 4;
    public static final int THEME_TWILIGHT = 5;

    public static int getThemeResource(Context context) {
        int theme = getSavedTheme(context);
        int res;
        switch (theme) {
            case THEME_DARK: res = R.style.AppTheme_Dark; break;
            case THEME_AMOLED: res = R.style.AppTheme_Amoled; break;
            case THEME_OCEAN: res = R.style.AppTheme_Ocean; break;
            case THEME_FOREST: res = R.style.AppTheme_Forest; break;
            case THEME_TWILIGHT: res = R.style.AppTheme_Twilight; break;
            default: res = R.style.AppTheme_Light; break;
        }
        AppLogger.log(null, "ThemeManager", "getThemeResource: theme=" + theme + ", res=" + res);
        return res;
    }

    public static void saveTheme(Context context, int theme) {
        SharedPreferences prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        prefs.edit().putInt(KEY_THEME, theme).apply();
        AppLogger.log(context, "ThemeManager", "Theme saved: " + theme);
    }

    public static int getSavedTheme(Context context) {
        SharedPreferences prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        int theme = prefs.getInt(KEY_THEME, THEME_LIGHT);
        AppLogger.log(null, "ThemeManager", "getSavedTheme: " + theme);
        return theme;
    }

    public static boolean isDarkTheme(Context context) {
        int theme = getSavedTheme(context);
        return theme == THEME_DARK || theme == THEME_AMOLED;
    }

    public static String getThemeName(Context context) {
        int theme = getSavedTheme(context);
        switch (theme) {
            case THEME_LIGHT: return "Светлая";
            case THEME_DARK: return "Тёмная";
            case THEME_AMOLED: return "AMOLED";
            case THEME_OCEAN: return "Океан";
            case THEME_FOREST: return "Лес";
            case THEME_TWILIGHT: return "Сумерки";
            default: return "Светлая";
        }
    }

    public static int getActionBarColor(Context context) {
        int theme = getSavedTheme(context);
        switch (theme) {
            case THEME_DARK: return 0xFF424242;
            case THEME_AMOLED: return 0xFF1A1A1A;
            case THEME_OCEAN: return 0xFF0D47A1;
            case THEME_FOREST: return 0xFF1B5E20;
            case THEME_TWILIGHT: return 0xFF4A148C;
            default: return 0xFF1565C0;
        }
    }

    public static int getChatNameColor(Context context) {
        int theme = getSavedTheme(context);
        int color;
        switch (theme) {
            case THEME_OCEAN: color = 0xFF0D47A1; break;
            case THEME_FOREST: color = 0xFF1B5E20; break;
            case THEME_TWILIGHT: color = 0xFF4A148C; break;
            case THEME_DARK: color = 0xFFFFFFFF; break;
            case THEME_AMOLED: color = 0xFFE0E0E0; break;
            default: color = 0xFF1A237E; break;
        }
        AppLogger.log(null, "ThemeManager", "getChatNameColor: theme=" + theme + ", color=" + color);
        return color;
    }

    public static int getLastMessageColor(Context context) {
        int theme = getSavedTheme(context);
        int color;
        switch (theme) {
            case THEME_OCEAN: color = 0xFF1565C0; break;
            case THEME_FOREST: color = 0xFF2E7D32; break;
            case THEME_TWILIGHT: color = 0xFF6A1B9A; break;
            case THEME_DARK: color = 0xFFBDBDBD; break;
            case THEME_AMOLED: color = 0xFF9E9E9E; break;
            default: color = 0xFF616161; break;
        }
        return color;
    }

    public static int getBubbleSentColor(Context context) {
        int theme = getSavedTheme(context);
        switch (theme) {
            case THEME_DARK: return 0xFF1B5E20;
            case THEME_AMOLED: return 0xFF1A237E;
            case THEME_OCEAN: return 0xFF1976D2;
            case THEME_FOREST: return 0xFF388E3C;
            case THEME_TWILIGHT: return 0xFF8E24AA;
            default: return 0xFF90CAF9;
        }
    }

    public static int getBubbleReceivedColor(Context context) {
        int theme = getSavedTheme(context);
        switch (theme) {
            case THEME_DARK: return 0xFF424242;
            case THEME_AMOLED: return 0xFF212121;
            case THEME_OCEAN: return 0xFFE3F2FD;
            case THEME_FOREST: return 0xFFE8F5E9;
            case THEME_TWILIGHT: return 0xFFF3E5F5;
            default: return 0xFFFFFFFF;
        }
    }

    public static int getBackgroundColor(Context context) {
        int theme = getSavedTheme(context);
        switch (theme) {
            case THEME_DARK: return 0xFF303030;
            case THEME_AMOLED: return 0xFF000000;
            case THEME_OCEAN: return 0xFFE3F2FD;
            case THEME_FOREST: return 0xFFE8F5E9;
            case THEME_TWILIGHT: return 0xFFF3E5F5;
            default: return 0xFFF5F5F5;
        }
    }

    public static int getCardColor(Context context) {
        int theme = getSavedTheme(context);
        switch (theme) {
            case THEME_DARK: return 0xFF424242;
            case THEME_AMOLED: return 0xFF1A1A1A;
            case THEME_OCEAN: return 0xFFBBDEFB;
            case THEME_FOREST: return 0xFFC8E6C9;
            case THEME_TWILIGHT: return 0xFFE1BEE7;
            default: return 0xFFFFFFFF;
        }
    }

    public static int getTextColor(Context context) {
        int theme = getSavedTheme(context);
        switch (theme) {
            case THEME_DARK: return 0xFFFFFFFF;
            case THEME_AMOLED: return 0xFFE0E0E0;
            case THEME_OCEAN: return 0xFF0D47A1;
            case THEME_FOREST: return 0xFF1B5E20;
            case THEME_TWILIGHT: return 0xFF4A148C;
            default: return 0xFF212121;
        }
    }

    public static int getTextSecondaryColor(Context context) {
        int theme = getSavedTheme(context);
        switch (theme) {
            case THEME_DARK: return 0xFFBDBDBD;
            case THEME_AMOLED: return 0xFF9E9E9E;
            case THEME_OCEAN: return 0xFF1565C0;
            case THEME_FOREST: return 0xFF2E7D32;
            case THEME_TWILIGHT: return 0xFF6A1B9A;
            default: return 0xFF757575;
        }
    }

    public static int getDividerColor(Context context) {
        int theme = getSavedTheme(context);
        switch (theme) {
            case THEME_DARK: return 0xFF616161;
            case THEME_AMOLED: return 0xFF333333;
            case THEME_OCEAN: return 0xFF90CAF9;
            case THEME_FOREST: return 0xFFA5D6A7;
            case THEME_TWILIGHT: return 0xFFCE93D8;
            default: return 0xFFE0E0E0;
        }
    }

    public static int getInputBgColor(Context context) {
        int theme = getSavedTheme(context);
        switch (theme) {
            case THEME_DARK: return 0xFF616161;
            case THEME_AMOLED: return 0xFF2A2A2A;
            case THEME_OCEAN: return 0xFFBBDEFB;
            case THEME_FOREST: return 0xFFC8E6C9;
            case THEME_TWILIGHT: return 0xFFE1BEE7;
            default: return 0xFFFFFFFF;
        }
    }

    public static int getHintColor(Context context) {
        int theme = getSavedTheme(context);
        switch (theme) {
            case THEME_DARK: return 0xFF9E9E9E;
            case THEME_AMOLED: return 0xFF757575;
            case THEME_OCEAN: return 0xFF64B5F6;
            case THEME_FOREST: return 0xFF81C784;
            case THEME_TWILIGHT: return 0xFFBA68C8;
            default: return 0xFFBDBDBD;
        }
    }

    public static int getFabColor(Context context) {
        int theme = getSavedTheme(context);
        switch (theme) {
            case THEME_DARK: return 0xFF1565C0;
            case THEME_AMOLED: return 0xFF0D47A1;
            case THEME_OCEAN: return 0xFF1976D2;
            case THEME_FOREST: return 0xFF388E3C;
            case THEME_TWILIGHT: return 0xFF8E24AA;
            default: return 0xFF1976D2;
        }
    }

    public static int getListItemColor(Context context) {
        return getCardColor(context);
    }
}