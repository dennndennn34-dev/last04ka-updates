package com.last04ka.messenger.ui;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.media.AudioFormat;
import android.media.AudioManager;
import android.media.AudioTrack;
import android.os.Bundle;
import android.os.Handler;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import com.last04ka.messenger.utils.AppLogger;
import com.last04ka.messenger.utils.GameScores;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class ArkanoidActivity extends Activity {

    private GameView gameView;
    private TextView scoreText, livesText, bonusText, comboText, bossText;
    private int score = 0, lives = 3, level = 1;
    private int comboCount = 0;
    private long lastBrickTime = 0;
    private Handler handler = new Handler();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        try {
            AppLogger.log(this, "Arkanoid", "onCreate started v3.1");
            AppLogger.logTexture(this, "Arkanoid", "Brick textures (8 colors)", true);
            AppLogger.logTexture(this, "Arkanoid", "Bonus glow textures", true);
            AppLogger.logTexture(this, "Arkanoid", "Boss HP bar", true);
            AppLogger.logTexture(this, "Arkanoid", "Particle system", true);
            AppLogger.logTexture(this, "Arkanoid", "Sparkle effects", true);

            LinearLayout layout = new LinearLayout(this);
            layout.setOrientation(LinearLayout.VERTICAL);
            layout.setBackgroundColor(0xFF0D1B2A);

            LinearLayout statsRow1 = new LinearLayout(this);
            statsRow1.setOrientation(LinearLayout.HORIZONTAL);
            statsRow1.setGravity(Gravity.CENTER);
            statsRow1.setPadding(8, 2, 8, 2);

            scoreText = new TextView(this);
            scoreText.setText("Счёт: 0"); scoreText.setTextSize(12);
            scoreText.setTextColor(0xFFFFD740); statsRow1.addView(scoreText);

            livesText = new TextView(this);
            livesText.setText("  ❤❤❤"); livesText.setTextSize(12);
            livesText.setTextColor(0xFFFF5252); statsRow1.addView(livesText);

            comboText = new TextView(this);
            comboText.setTextSize(11); comboText.setTextColor(0xFFFF9800);
            comboText.setVisibility(View.GONE); statsRow1.addView(comboText);

            bossText = new TextView(this);
            bossText.setTextSize(11); bossText.setTextColor(0xFFFF1744);
            bossText.setVisibility(View.GONE); statsRow1.addView(bossText);

            layout.addView(statsRow1);

            bonusText = new TextView(this);
            bonusText.setText("Ур.1 | Бонусов: 0"); bonusText.setTextSize(11);
            bonusText.setTextColor(0xFF4FC3F7); bonusText.setGravity(Gravity.CENTER);
            layout.addView(bonusText);

            gameView = new GameView(this);
            LinearLayout.LayoutParams gvp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 1);
            gameView.setLayoutParams(gvp);
            layout.addView(gameView);

            setContentView(layout);
            setTitle("🧱 Арканоид 3.1");
            AppLogger.log(this, "Arkanoid", "onCreate completed");
        } catch (Exception e) { AppLogger.logException(this, "Arkanoid", e); finish(); }
    }

    private void updateUI() {
        scoreText.setText("Счёт: " + score);
        StringBuilder sb = new StringBuilder("  ");
        for (int i = 0; i < Math.min(lives, 10); i++) sb.append("❤");
        if (lives > 10) sb.append("+").append(lives - 10);
        livesText.setText(sb.toString());
        bonusText.setText("Ур." + level + " | Бонусов: " + gameView.totalBonusesCollected);
    }

    private void showBonusMessage(String msg) {
        bonusText.setText("  " + msg);
        handler.postDelayed(() -> updateUI(), 2000);
    }

    private void showCombo() {
        if (comboCount >= 3) {
            comboText.setVisibility(View.VISIBLE);
            comboText.setText("  🔥 x" + comboCount + "!");
            comboText.setTextColor(comboCount >= 15 ? 0xFFFF1744 : comboCount >= 8 ? 0xFFFF9800 : 0xFFFFD740);
            handler.postDelayed(() -> comboText.setVisibility(View.GONE), 1500);
        }
    }

    private void nextLevel() {
        level++;
        gameView.initBricks();
        gameView.resetBall();
        updateUI();

        if (level % 10 == 0) {
            gameView.spawnBoss();
            bossText.setVisibility(View.VISIBLE);
            bossText.setText("  👾 БОСС! HP:" + gameView.bossHp);
            Toast.makeText(this, "👾 БОСС! Уровень " + level + "!", Toast.LENGTH_LONG).show();
            AppLogger.log(this, "Arkanoid", "Boss spawned at level " + level + " hp=" + gameView.bossHp);
        } else {
            bossText.setVisibility(View.GONE);
        }

        AppLogger.log(this, "Arkanoid", "Level " + level + " started, bricks=" + gameView.bricks.size());
        Toast.makeText(this, "🏆 Уровень " + level + "!", Toast.LENGTH_SHORT).show();
    }

    private void loseLife() {
        lives--;
        comboCount = 0;
        updateUI();
        AppLogger.log(this, "Arkanoid", "Life lost, remaining=" + lives + " score=" + score);

        if (lives <= 0) {
            GameScores.saveScore(this, "arkanoid", score);
            AppLogger.log(this, "Arkanoid", "Game over, score=" + score + " level=" + level);
            new AlertDialog.Builder(this)
                .setTitle("💀 Игра окончена")
                .setMessage("Счёт: " + score + "\nУровень: " + level +
                    "\nБонусов: " + gameView.totalBonusesCollected +
                    "\nМакс. комбо: " + gameView.maxCombo)
                .setPositiveButton("🔄 Заново", (d, w) -> {
                    score = 0; lives = 3; level = 1; comboCount = 0;
                    gameView.totalBonusesCollected = 0; gameView.maxCombo = 0;
                    gameView.initBricks(); updateUI();
                    bossText.setVisibility(View.GONE);
                    AppLogger.log(ArkanoidActivity.this, "Arkanoid", "New game started");
                })
                .setNegativeButton("Выход", (d, w) -> finish())
                .setCancelable(false).show();
        } else {
            gameView.resetBall();
        }
    }

    class GameView extends View {
        private Paint paint = new Paint();
        private Random random = new Random();

        private float paddleX, paddleY, paddleWidth, paddleHeight;
        private float defaultPaddleWidth;
        private float ballX, ballY, ballRadius;
        private float ballSpeedX, ballSpeedY;
        private float baseBallSpeed = 8f;

        private List<Ball> extraBalls = new ArrayList<>();
        private List<Brick> bricks = new ArrayList<>();
        private List<MovingBrick> movingBricks = new ArrayList<>();
        private int brickRows = 5, brickCols = 8;
        private float brickWidth, brickHeight, brickPadding = 3f;
        private int bricksDestroyed = 0;
        private List<Bonus> bonuses = new ArrayList<>();
        private int totalBonusesCollected = 0;
        private int maxCombo = 0;

        private boolean bossActive = false;
        private float bossX, bossY, bossWidth, bossHeight;
        private int bossHp, bossMaxHp;
        private float bossSpeed = 3f;
        private float bossGlow = 0f;

        private boolean widePaddle, slowBall, fastBall, inverted, ghostBall, stickyPaddle, shieldActive, fireBall;
        private long widePaddleEnd, slowBallEnd, fastBallEnd, invertedEnd, ghostBallEnd, stickyPaddleEnd, shieldEnd, fireBallEnd;

        private boolean running = false;
        private List<Particle> particles = new ArrayList<>();
        private List<Sparkle> sparkles = new ArrayList<>();

        public GameView(Context context) {
            super(context);
            setFocusable(true);
            setFocusableInTouchMode(true);
        }

        @Override
        protected void onSizeChanged(int w, int h, int oldw, int oldh) {
            super.onSizeChanged(w, h, oldw, oldh);
            paddleWidth = w * 0.16f; defaultPaddleWidth = paddleWidth;
            paddleHeight = h * 0.022f; ballRadius = w * 0.014f;
            paddleY = h * 0.87f; paddleX = w / 2f - paddleWidth / 2f;
            brickWidth = (w - brickPadding * (brickCols + 1)) / brickCols;
            brickHeight = h * 0.035f;
            initBricks(); resetBall();
        }

        private void initBricks() {
            bricks.clear(); movingBricks.clear(); bossActive = false; bricksDestroyed = 0;
            int[] colors = {0xFFE53935, 0xFFFF6F00, 0xFFFFEB3B, 0xFF4CAF50, 0xFF2196F3, 0xFF9C27B0, 0xFF00BCD4, 0xFF795548};
            int rows = brickRows + (level - 1) / 2;
            if (rows > 12) rows = 12;
            int w = getWidth();
            for (int row = 0; row < rows; row++) {
                for (int col = 0; col < brickCols; col++) {
                    float x = brickPadding + col * (brickWidth + brickPadding);
                    float y = getHeight() * 0.06f + row * (brickHeight + brickPadding);
                    int hp = 1;
                    if (row < 2) hp = 2;
                    if (row < 1 && level >= 5) hp = 3;
                    int color = colors[(row + level) % colors.length];
                    boolean invisible = level >= 5 && random.nextFloat() < 0.2f;
                    bricks.add(new Brick(x, y, brickWidth, brickHeight, hp, color, invisible));
                    if (level >= 3 && random.nextFloat() < 0.15f) {
                        float speed = 1f + level * 0.15f;
                        movingBricks.add(new MovingBrick(x, y, brickWidth, brickHeight, hp, color,
                            random.nextBoolean() ? speed : -speed));
                    }
                }
            }
            AppLogger.log(ArkanoidActivity.this, "Arkanoid", "Bricks: " + bricks.size() + " invisible=" + countInvisible() + " moving=" + movingBricks.size());
        }

        private int countInvisible() { int c = 0; for (Brick b : bricks) if (b.invisible) c++; return c; }

        public void spawnBoss() {
            bossActive = true; bossWidth = getWidth() * 0.5f; bossHeight = getHeight() * 0.045f;
            bossX = getWidth() / 2f - bossWidth / 2f; bossY = getHeight() * 0.2f;
            bossMaxHp = 20 + level * 5; bossHp = bossMaxHp; bossSpeed = 2f + level * 0.2f;
        }

        private void resetBall() {
            extraBalls.clear();
            int w = getWidth(), h = getHeight();
            ballX = w / 2f; ballY = h / 2f;
            float speed = baseBallSpeed + level * 0.6f;
            float angle = (random.nextFloat() - 0.5f) * 1.2f;
            ballSpeedX = speed * (float)Math.cos(angle) * (random.nextBoolean() ? 1 : -1);
            ballSpeedY = speed * (float)Math.sin(angle);
            if (Math.abs(ballSpeedY) < 4) ballSpeedY = -4;
        }

        private void spawnExtraBall(float x, float y) {
            float speed = baseBallSpeed + level * 0.6f;
            float angle = (random.nextFloat() - 0.5f) * 2.5f;
            extraBalls.add(new Ball(x, y, speed * (float)Math.cos(angle), -speed * Math.abs((float)Math.sin(angle))));
        }

        @Override
        protected void onDraw(Canvas canvas) {
            try {
                super.onDraw(canvas);
                int w = getWidth(), h = getHeight();

                paint.setColor(0xFF0D1B2A); canvas.drawRect(0, 0, w, h, paint);
                paint.setColor(0xFF132940); canvas.drawRect(0, h*0.4f, w, h*0.6f, paint);

                if (shieldActive) { paint.setColor(0x664FC3F7); canvas.drawRect(0, h - 10, w, h, paint); }

                for (Brick brick : bricks) {
                    paint.setColor(brick.invisible ? ((brick.color & 0x00FFFFFF) | 0x44000000) : brick.color);
                    canvas.drawRoundRect(brick.rect, 4, 4, paint);
                    if (brick.hp >= 2) {
                        paint.setColor(0x44FFFFFF); canvas.drawRoundRect(brick.rect, 4, 4, paint);
                        paint.setTextSize(brickHeight * 0.5f); paint.setTextAlign(Paint.Align.CENTER);
                        paint.setColor(0xFFFFFFFF);
                        canvas.drawText(String.valueOf(brick.hp), brick.rect.centerX(), brick.rect.centerY() + brickHeight*0.2f, paint);
                        paint.setTextAlign(Paint.Align.LEFT);
                    }
                }

                if (bossActive) {
                    bossGlow += 0.05f;
                    paint.setColor(0xFFFF1744);
                    canvas.drawRoundRect(bossX, bossY, bossX + bossWidth, bossY + bossHeight, 10, 10, paint);
                    paint.setColor(0x55FFFFFF);
                    canvas.drawRoundRect(bossX+3, bossY+3, bossX+bossWidth-3, bossY+bossHeight-3, 8, 8, paint);
                    paint.setColor(0xFF333333);
                    canvas.drawRect(bossX, bossY - 14, bossX + bossWidth, bossY - 6, paint);
                    paint.setColor(0xFFFF5252);
                    canvas.drawRect(bossX, bossY - 14, bossX + bossWidth * (float)bossHp/bossMaxHp, bossY - 6, paint);
                    paint.setColor(Color.WHITE); paint.setTextSize(10); paint.setTextAlign(Paint.Align.CENTER);
                    canvas.drawText("BOSS " + bossHp + "/" + bossMaxHp, bossX + bossWidth/2, bossY - 16, paint);
                    paint.setTextAlign(Paint.Align.LEFT);
                }

                for (Bonus bonus : bonuses) {
                    paint.setColor((bonus.bgColor & 0x00FFFFFF) | 0x44000000);
                    canvas.drawCircle(bonus.x, bonus.y, bonus.radius * 1.8f, paint);
                    paint.setColor((bonus.bgColor & 0x00FFFFFF) | 0x66000000);
                    canvas.drawCircle(bonus.x, bonus.y, bonus.radius * 1.3f, paint);
                    paint.setColor(bonus.bgColor);
                    canvas.drawCircle(bonus.x, bonus.y, bonus.radius, paint);
                    paint.setColor(bonus.textColor);
                    paint.setTextSize(bonus.radius); paint.setTextAlign(Paint.Align.CENTER);
                    canvas.drawText(bonus.icon, bonus.x, bonus.y + bonus.radius*0.3f, paint);
                    paint.setTextAlign(Paint.Align.LEFT);
                }

                for (Particle p : particles) {
                    paint.setColor(p.color); paint.setAlpha(p.alpha);
                    canvas.drawCircle(p.x, p.y, p.size, paint);
                }

                for (Sparkle s : sparkles) {
                    paint.setColor(s.color); paint.setAlpha(s.alpha);
                    canvas.drawCircle(s.x, s.y, s.size, paint);
                }
                paint.setAlpha(255);

                float pw = widePaddle ? defaultPaddleWidth * 1.8f : defaultPaddleWidth;
                paint.setColor(stickyPaddle ? 0xFF00E676 : (inverted ? 0xFFFF5252 : 0xFF4FC3F7));
                canvas.drawRoundRect(paddleX, paddleY, paddleX + pw, paddleY + paddleHeight, 8, 8, paint);
                paint.setColor((stickyPaddle ? 0xFF00E676 : 0xFF4FC3F7) & 0x33FFFFFF);
                canvas.drawRoundRect(paddleX-3, paddleY-3, paddleX+pw+3, paddleY+paddleHeight+3, 10, 10, paint);

                if (!stickyPaddle || ballSpeedY != 0 || ballSpeedX != 0) {
                    int bc = ghostBall ? 0x88FFEB3B : (fireBall ? 0xFFFF5722 : 0xFFFFEB3B);
                    paint.setColor(bc);
                    canvas.drawCircle(ballX, ballY, ballRadius, paint);
                    if (fireBall) {
                        paint.setColor(0x66FF5722); canvas.drawCircle(ballX, ballY, ballRadius * 2f, paint);
                        paint.setColor(0x33FF5722); canvas.drawCircle(ballX, ballY, ballRadius * 3f, paint);
                    }
                    if (ghostBall) {
                        paint.setColor(0x44FFFFFF); canvas.drawCircle(ballX, ballY, ballRadius * 1.5f, paint);
                    }
                }
                for (Ball b : extraBalls) {
                    paint.setColor(0xFFFF9800); canvas.drawCircle(b.x, b.y, ballRadius*0.7f, paint);
                }
            } catch (Exception e) {
                AppLogger.logException(ArkanoidActivity.this, "Arkanoid", e);
            }
        }

        public void update() {
            try {
                int w = getWidth(), h = getHeight();
                long now = System.currentTimeMillis();

                if (widePaddle && now > widePaddleEnd) widePaddle = false;
                if (slowBall && now > slowBallEnd) slowBall = false;
                if (fastBall && now > fastBallEnd) fastBall = false;
                if (inverted && now > invertedEnd) inverted = false;
                if (ghostBall && now > ghostBallEnd) ghostBall = false;
                if (stickyPaddle && now > stickyPaddleEnd) { stickyPaddle = false; ballSpeedY = -Math.abs(ballSpeedY); }
                if (shieldActive && now > shieldEnd) shieldActive = false;
                if (fireBall && now > fireBallEnd) fireBall = false;

                for (int i = particles.size() - 1; i >= 0; i--) {
                    Particle p = particles.get(i); p.y += p.vy; p.x += p.vx; p.life -= 16;
                    p.alpha = Math.max(0, p.life); if (p.life <= 0) particles.remove(i);
                }
                for (int i = sparkles.size() - 1; i >= 0; i--) {
                    Sparkle s = sparkles.get(i); s.life -= 20; s.alpha = Math.max(0, s.life);
                    if (s.life <= 0) sparkles.remove(i);
                }

                for (MovingBrick mb : movingBricks) {
                    mb.x += mb.speed;
                    if (mb.x < 0 || mb.x + brickWidth > w) mb.speed = -mb.speed;
                    mb.x = Math.max(0, Math.min(w - brickWidth, mb.x));
                    for (Brick b : bricks) if (b.rect.left == mb.prevX) { b.rect.offset(mb.x - mb.prevX, 0); break; }
                    mb.prevX = mb.x;
                }

                if (bossActive) { bossX += bossSpeed; if (bossX < 0 || bossX + bossWidth > w) { bossSpeed = -bossSpeed; bossX = Math.max(0, Math.min(w - bossWidth, bossX)); } }

                float speedMult = slowBall ? 0.45f : (fastBall ? 1.7f : 1f);

                if (!stickyPaddle || ballSpeedY != 0 || ballSpeedX != 0) { ballX += ballSpeedX * speedMult; ballY += ballSpeedY * speedMult; }

                if (ballX - ballRadius <= 0) { ballX = ballRadius; ballSpeedX = -ballSpeedX; }
                if (ballX + ballRadius >= w) { ballX = w - ballRadius; ballSpeedX = -ballSpeedX; }
                if (ballY - ballRadius <= 0) { ballY = ballRadius; ballSpeedY = -ballSpeedY; }

                if (ballY + ballRadius >= h) {
                    if (shieldActive) { ballY = h - ballRadius - 12; ballSpeedY = -Math.abs(ballSpeedY); shieldActive = false; handler.post(() -> showBonusMessage("🛡 Щит спас!")); }
                    else { handler.post(() -> loseLife()); return; }
                }

                float pw = widePaddle ? defaultPaddleWidth * 1.8f : defaultPaddleWidth;
                if (ballY + ballRadius >= paddleY && ballY - ballRadius <= paddleY + paddleHeight &&
                    ballX + ballRadius >= paddleX && ballX - ballRadius <= paddleX + pw) {
                    float hitPos = (ballX - paddleX) / pw;
                    float angle = (hitPos - 0.5f) * (float)Math.PI * 0.65f;
                    float speed = (float)Math.sqrt(ballSpeedX * ballSpeedX + ballSpeedY * ballSpeedY);
                    if (stickyPaddle) { ballSpeedY = 0; ballSpeedX = 0; ballY = paddleY - ballRadius; }
                    else { ballY = paddleY - ballRadius; ballSpeedX = speed * (float)Math.sin(angle); ballSpeedY = -speed * (float)Math.cos(angle); if (Math.abs(ballSpeedY) < 5) ballSpeedY = -5; }
                }

                if (bossActive && ballY + ballRadius > bossY && ballY - ballRadius < bossY + bossHeight &&
                    ballX + ballRadius > bossX && ballX - ballRadius < bossX + bossWidth) {
                    bossHp--; ballSpeedY = -Math.abs(ballSpeedY);
                    if (bossHp <= 0) { bossActive = false; score += 200 + level * 50; handler.post(() -> { updateUI(); bossText.setVisibility(View.GONE); showBonusMessage("👾 Босс повержен!"); }); AppLogger.log(ArkanoidActivity.this, "Arkanoid", "Boss defeated at level " + level); }
                    handler.post(() -> bossText.setText("  👾 БОСС! HP:" + bossHp));
                }

                for (int i = extraBalls.size() - 1; i >= 0; i--) {
                    Ball b = extraBalls.get(i); b.x += b.vx * speedMult; b.y += b.vy * speedMult;
                    float br = ballRadius * 0.7f;
                    if (b.x - br <= 0) { b.x = br; b.vx = -b.vx; } if (b.x + br >= w) { b.x = w - br; b.vx = -b.vx; }
                    if (b.y - br <= 0) { b.y = br; b.vy = -b.vy; } if (b.y > h) { extraBalls.remove(i); continue; }
                    hitBricks(b.x, b.y, br);
                    if (bossActive && b.y + br > bossY && b.y - br < bossY + bossHeight && b.x + br > bossX && b.x - br < bossX + bossWidth) {
                        bossHp--; b.vy = -Math.abs(b.vy);
                        if (bossHp <= 0) { bossActive = false; score += 200 + level * 50; handler.post(() -> { updateUI(); bossText.setVisibility(View.GONE); }); }
                    }
                }

                hitBricks(ballX, ballY, ballRadius);

                for (int i = bonuses.size() - 1; i >= 0; i--) {
                    Bonus bonus = bonuses.get(i); bonus.y += 3.8f;
                    if (bonus.y > h) { bonuses.remove(i); continue; }
                    if (bonus.y + bonus.radius >= paddleY && bonus.x >= paddleX && bonus.x <= paddleX + pw) { applyBonus(bonus.type); bonuses.remove(i); }
                }

                if (bricks.isEmpty() && !bossActive) { score += 150 + level * 30; handler.post(() -> { updateUI(); nextLevel(); }); }
            } catch (Exception e) {
                AppLogger.logException(ArkanoidActivity.this, "Arkanoid", e);
            }
        }

        private void hitBricks(float bx, float by, float br) {
            for (int i = bricks.size() - 1; i >= 0; i--) {
                Brick brick = bricks.get(i);
                if (bx + br > brick.rect.left && bx - br < brick.rect.right &&
                    by + br > brick.rect.top && by - br < brick.rect.bottom) {
                    if (ghostBall) continue;
                    brick.hp--; if (fireBall) brick.hp--;
                    score += 5; bricksDestroyed++;
                    long now = System.currentTimeMillis();
                    if (now - lastBrickTime < 1500) { comboCount++; if (comboCount > maxCombo) maxCombo = comboCount; }
                    else comboCount = 1;
                    lastBrickTime = now;

                    for (int p = 0; p < 10; p++) {
                        particles.add(new Particle(brick.rect.centerX(), brick.rect.centerY(),
                            (random.nextFloat()-0.5f)*8f, (random.nextFloat()-0.5f)*8f - 3f,
                            brick.color, random.nextFloat()*5+1));
                    }

                    if (brick.hp <= 0) {
                        for (int s = 0; s < 6; s++) {
                            sparkles.add(new Sparkle(brick.rect.centerX(), brick.rect.centerY(), brick.color));
                        }
                        if (bricksDestroyed % 2 == 0) spawnBonus(brick);
                        if (brick.initialHp >= 3 && random.nextFloat() < 0.60f) spawnBonus(brick);
                        bricks.remove(i); score += 15;
                        handler.post(() -> { updateUI(); showCombo(); });
                    }
                    if (bx == ballX && by == ballY) {
                        float ol = (bx+br)-brick.rect.left, or_=brick.rect.right-(bx-br);
                        float ot = (by+br)-brick.rect.top, ob=brick.rect.bottom-(by-br);
                        if (Math.min(ol,or_) < Math.min(ot,ob)) ballSpeedX=-ballSpeedX; else ballSpeedY=-ballSpeedY;
                    }
                    break;
                }
            }
        }

        private void spawnBonus(Brick brick) {
            int type; float r = random.nextFloat();
            if (r < 0.55f) type = random.nextInt(7);
            else if (r < 0.85f) type = 7 + random.nextInt(4);
            else if (r < 0.95f) type = 11;
            else type = 12;
            bonuses.add(new Bonus(brick.rect.centerX(), brick.rect.centerY(), getHeight() * 0.022f, type));
        }

        private void applyBonus(int type) {
            long now = System.currentTimeMillis();
            int dur = 8000 + level * 1200;
            totalBonusesCollected++;
            String[] names = {"Широкая","+Очки","+Жизнь","Медленный","Мультимяч","Прилипание","Щит","Узкая","Быстрый","Инверт","Призрак","Джекпот","Огонь"};
            AppLogger.log(ArkanoidActivity.this, "Arkanoid", "Bonus: " + names[type] + " total=" + totalBonusesCollected);
            switch (type) {
                case 0: widePaddle = true; widePaddleEnd = now + dur; handler.post(() -> showBonusMessage("↔ Широкая!")); break;
                case 1: score += 100 + level * 10; handler.post(() -> { updateUI(); showBonusMessage("+"+(100+level*10)+"!"); }); break;
                case 2: lives++; handler.post(() -> { updateUI(); showBonusMessage("+❤ Жизнь!"); }); break;
                case 3: slowBall = true; fastBall = false; slowBallEnd = now + dur; handler.post(() -> showBonusMessage("🐌 Медленно!")); break;
                case 4: for (int i = 0; i < 3; i++) { final int d = i; handler.postDelayed(() -> spawnExtraBall(ballX, ballY), d * 80); } handler.post(() -> showBonusMessage("🔄 x3!")); break;
                case 5: stickyPaddle = true; stickyPaddleEnd = now + dur; handler.post(() -> showBonusMessage("🧲 Прилипание!")); break;
                case 6: shieldActive = true; shieldEnd = now + dur; handler.post(() -> showBonusMessage("🛡 Щит!")); break;
                case 7: widePaddle = false; defaultPaddleWidth = getWidth() * 0.08f; handler.postDelayed(() -> defaultPaddleWidth = getWidth() * 0.16f, dur); handler.post(() -> showBonusMessage("⚠ Узкая!")); break;
                case 8: fastBall = true; slowBall = false; fastBallEnd = now + dur; handler.post(() -> showBonusMessage("⚡ Быстрый!")); break;
                case 9: inverted = true; invertedEnd = now + dur; handler.post(() -> showBonusMessage("🔄 Инверт!")); break;
                case 10: ghostBall = true; ghostBallEnd = now + dur; handler.post(() -> showBonusMessage("👻 Призрак!")); break;
                case 11: score += 200 + level * 50; lives++; handler.post(() -> { updateUI(); showBonusMessage("🎰 Джекпот!"); }); break;
                case 12: fireBall = true; fireBallEnd = now + dur; handler.post(() -> showBonusMessage("🔥 Огонь!")); break;
            }
        }

        @Override
        public boolean onTouchEvent(MotionEvent event) {
            float x = inverted ? (getWidth() - event.getX()) : event.getX();
            float pw = widePaddle ? defaultPaddleWidth * 1.8f : defaultPaddleWidth;
            paddleX = Math.max(0, Math.min(getWidth() - pw, x - pw / 2f));
            if (stickyPaddle && ballSpeedY == 0 && ballSpeedX == 0 && event.getAction() == MotionEvent.ACTION_UP) {
                float speed = baseBallSpeed + level * 0.6f;
                float hitPos = (ballX - paddleX) / pw;
                float angle = (hitPos - 0.5f) * (float)Math.PI * 0.7f;
                ballSpeedX = speed * (float)Math.sin(angle); ballSpeedY = -speed * (float)Math.cos(angle);
                if (Math.abs(ballSpeedY) < 5) ballSpeedY = -5;
            }
            return true;
        }

        @Override
        protected void onAttachedToWindow() { super.onAttachedToWindow(); running = true;
            new Thread(() -> { while (running) { try { Thread.sleep(16); update(); postInvalidate(); } catch (InterruptedException e) { break; } catch (Exception e) { AppLogger.logException(ArkanoidActivity.this, "Arkanoid", e); } } }).start(); }
        @Override
        protected void onDetachedFromWindow() { super.onDetachedFromWindow(); running = false; }
    }

    static class Brick { RectF rect; int hp, color, initialHp; boolean invisible;
        Brick(float x, float y, float w, float h, int hp, int color, boolean inv) { this.rect = new RectF(x, y, x+w, y+h); this.hp = hp; this.color = color; this.initialHp = hp; this.invisible = inv; } }
    static class MovingBrick { float x, prevX, speed; int hp, color;
        MovingBrick(float x, float y, float w, float h, int hp, int color, float speed) { this.x = x; this.prevX = x; this.speed = speed; this.hp = hp; this.color = color; } }
    static class Bonus { float x, y, radius; int type; String icon; int bgColor, textColor;
        Bonus(float x, float y, float r, int type) { this.x=x; this.y=y; this.radius=r; this.type=type;
            switch(type){case 0:icon="↔";bgColor=0xFF4CAF50;textColor=0xFFFFFFFF;break;case 1:icon="+";bgColor=0xFFFFD740;textColor=0xFF212121;break;case 2:icon="❤";bgColor=0xFFFF5252;textColor=0xFFFFFFFF;break;case 3:icon="🐌";bgColor=0xFF2196F3;textColor=0xFFFFFFFF;break;case 4:icon="⚫";bgColor=0xFFFF9800;textColor=0xFFFFFFFF;break;case 5:icon="🧲";bgColor=0xFF00E676;textColor=0xFF212121;break;case 6:icon="🛡";bgColor=0xFF448AFF;textColor=0xFFFFFFFF;break;case 7:icon="⚠";bgColor=0xFFFF1744;textColor=0xFFFFFFFF;break;case 8:icon="⚡";bgColor=0xFFFF6D00;textColor=0xFFFFFFFF;break;case 9:icon="🔄";bgColor=0xFFAA00FF;textColor=0xFFFFFFFF;break;case 10:icon="👻";bgColor=0xFF78909C;textColor=0xFFFFFFFF;break;case 11:icon="🎰";bgColor=0xFFFFD700;textColor=0xFF212121;break;case 12:icon="🔥";bgColor=0xFFFF5722;textColor=0xFFFFFFFF;break;default:icon="?";bgColor=0xFF888888;textColor=0xFFFFFFFF;} } }
    static class Ball { float x, y, vx, vy; Ball(float x, float y, float vx, float vy) { this.x=x; this.y=y; this.vx=vx; this.vy=vy; } }
    static class Particle { float x, y, vx, vy, size; int color, life, alpha;
        Particle(float x, float y, float vx, float vy, int color, float size) { this.x=x; this.y=y; this.vx=vx; this.vy=vy; this.color=color; this.size=size; this.life=255; this.alpha=255; } }
    static class Sparkle { float x, y, size; int color, life, alpha;
        Sparkle(float x, float y, int color) { Random r = new Random(); this.x = x + r.nextFloat()*20-10; this.y = y + r.nextFloat()*20-10; this.size = r.nextFloat()*5+2; this.color = color; this.life = 200; this.alpha = 255; } }
}