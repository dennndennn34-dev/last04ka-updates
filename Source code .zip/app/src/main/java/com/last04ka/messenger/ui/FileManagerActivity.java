package com.last04ka.messenger.ui;

import android.app.Activity;
import android.app.AlertDialog;
import android.os.Bundle;
import android.os.Environment;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import com.last04ka.messenger.utils.AppLogger;
import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Comparator;
import java.util.Date;
import java.util.Locale;

public class FileManagerActivity extends Activity {

    private TextView pathText;
    private LinearLayout fileList;
    private File currentDir;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        try {
            AppLogger.log(this, "FileManager", "onCreate started");

            LinearLayout layout = new LinearLayout(this);
            layout.setOrientation(LinearLayout.VERTICAL);
            layout.setPadding(8, 8, 8, 8);
            layout.setBackgroundColor(0xFF1A1A2E);

            pathText = new TextView(this);
            pathText.setTextSize(13); pathText.setTextColor(0xFFFFD740); pathText.setPadding(8, 8, 8, 8);
            layout.addView(pathText);

            Button btnUp = new Button(this);
            btnUp.setText("📁 Вверх");
            btnUp.setOnClickListener(v -> {
                if (currentDir.getParentFile() != null && currentDir.getParentFile().exists())
                    navigateTo(currentDir.getParentFile());
            });
            layout.addView(btnUp);

            fileList = new LinearLayout(this);
            fileList.setOrientation(LinearLayout.VERTICAL);
            ScrollView sv = new ScrollView(this);
            sv.addView(fileList);
            LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 1);
            sv.setLayoutParams(sp);
            layout.addView(sv);

            setContentView(layout);
            setTitle("📁 Файлы");
            navigateTo(Environment.getExternalStorageDirectory());
            AppLogger.log(this, "FileManager", "onCreate completed");
        } catch (Exception e) { AppLogger.logException(this, "FileManager", e); finish(); }
    }

    private void navigateTo(File dir) {
        currentDir = dir;
        pathText.setText("📂 " + dir.getAbsolutePath());
        fileList.removeAllViews();

        File[] files = dir.listFiles();
        if (files == null || files.length == 0) {
            TextView empty = new TextView(this);
            empty.setText("Папка пуста"); empty.setTextColor(0xFF888888);
            fileList.addView(empty);
            return;
        }

        Arrays.sort(files, (a, b) -> {
            if (a.isDirectory() && !b.isDirectory()) return -1;
            if (!a.isDirectory() && b.isDirectory()) return 1;
            return a.getName().compareToIgnoreCase(b.getName());
        });

        for (File f : files) {
            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setPadding(8, 8, 8, 8);
            row.setBackgroundColor(0xFF333333);
            LinearLayout.LayoutParams rp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
            rp.setMargins(0, 0, 0, 2);
            row.setLayoutParams(rp);

            TextView tv = new TextView(this);
            String icon = f.isDirectory() ? "📁 " : "📄 ";
            String sizeStr = f.isFile() ? " (" + formatSize(f.length()) + ")" : "";
            tv.setText(icon + f.getName() + sizeStr);
            tv.setTextSize(13); tv.setTextColor(0xFFFFFFFF);
            LinearLayout.LayoutParams tp = new LinearLayout.LayoutParams(
                0, LinearLayout.LayoutParams.WRAP_CONTENT, 1);
            tv.setLayoutParams(tp);
            row.addView(tv);

            final File file = f;
            row.setOnClickListener(v -> {
                if (file.isDirectory()) navigateTo(file);
                else Toast.makeText(FileManagerActivity.this, file.getName(), Toast.LENGTH_SHORT).show();
            });

            row.setOnLongClickListener(v -> {
                String[] opts = file.isDirectory() ? new String[]{"Переименовать", "Удалить"} : new String[]{"Переименовать", "Удалить"};
                new AlertDialog.Builder(FileManagerActivity.this)
                    .setTitle(file.getName())
                    .setItems(opts, (d, w) -> {
                        if (w == 0) renameFile(file);
                        else deleteFile(file);
                    }).show();
                return true;
            });

            fileList.addView(row);
        }
    }

    private void renameFile(File file) {
        EditText input = new EditText(this);
        input.setText(file.getName());
        new AlertDialog.Builder(this)
            .setTitle("Переименовать")
            .setView(input)
            .setPositiveButton("OK", (d, w) -> {
                File newFile = new File(file.getParent(), input.getText().toString());
                if (file.renameTo(newFile)) { navigateTo(currentDir); Toast.makeText(this, "Готово", Toast.LENGTH_SHORT).show(); }
                else Toast.makeText(this, "Ошибка", Toast.LENGTH_SHORT).show();
            })
            .setNegativeButton("Отмена", null).show();
    }

    private void deleteFile(File file) {
        new AlertDialog.Builder(this)
            .setTitle("Удалить " + file.getName() + "?")
            .setPositiveButton("Да", (d, w) -> {
                if (file.delete()) { navigateTo(currentDir); Toast.makeText(this, "Удалено", Toast.LENGTH_SHORT).show(); }
                else Toast.makeText(this, "Ошибка удаления", Toast.LENGTH_SHORT).show();
            })
            .setNegativeButton("Нет", null).show();
    }

    private String formatSize(long bytes) {
        if (bytes < 1024) return bytes + " B";
        if (bytes < 1024 * 1024) return String.format("%.1f KB", bytes / 1024.0);
        return String.format("%.1f MB", bytes / (1024.0 * 1024));
    }
}