package com.last04ka.messenger.ui;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Shader;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import com.last04ka.messenger.utils.AppLogger;
import java.io.File;
import java.io.FileOutputStream;

public class PixelArtActivity extends Activity {

    private PixelGridView pixelGrid;
    private int currentColor = Color.BLACK;
    private int gridSize = 16;
    private TextView colorPreview;
    private ColorPaletteView colorPalette;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        try {
            AppLogger.log(this, "PixelArt", "onCreate v3");
            LinearLayout layout = new LinearLayout(this);
            layout.setOrientation(LinearLayout.VERTICAL);
            layout.setPadding(4, 4, 4, 4);
            layout.setBackgroundColor(0xFF1A1A2E);

            TextView title = new TextView(this);
            title.setText("🎨 Пиксель-Арт"); title.setTextSize(16);
            title.setTextColor(0xFFFFFFFF); title.setGravity(Gravity.CENTER);
            layout.addView(title);

            // Текущий цвет
            LinearLayout colorRow = new LinearLayout(this);
            colorRow.setGravity(Gravity.CENTER_VERTICAL);
            colorRow.setPadding(8, 4, 8, 4);

            colorPreview = new TextView(this);
            colorPreview.setText("█ Текущий: #000000");
            colorPreview.setTextSize(13);
            colorPreview.setTextColor(0xFFFFFFFF);
            colorRow.addView(colorPreview);
            layout.addView(colorRow);

            // Поле рисования
            pixelGrid = new PixelGridView(this);
            LinearLayout.LayoutParams gp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 1);
            gp.weight = 1;
            pixelGrid.setLayoutParams(gp);
            layout.addView(pixelGrid);

            // RGB-палитра
            colorPalette = new ColorPaletteView(this);
            LinearLayout.LayoutParams pp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 120);
            colorPalette.setLayoutParams(pp);
            layout.addView(colorPalette);

            // Пресетные цвета
            LinearLayout presetsRow1 = new LinearLayout(this);
            presetsRow1.setGravity(Gravity.CENTER);
            int[] presetColors = {
                Color.BLACK, Color.WHITE, Color.RED, 0xFFFF5722, 0xFFFF9800,
                Color.YELLOW, 0xFF8BC34A, Color.GREEN, 0xFF00BCD4, Color.BLUE,
                0xFF9C27B0, Color.MAGENTA, 0xFF795548, Color.GRAY, 0xFF607D8B, 0xFFFFEB3B
            };
            for (int c : presetColors) {
                ImageView iv = new ImageView(this);
                iv.setBackgroundColor(c);
                LinearLayout.LayoutParams ip = new LinearLayout.LayoutParams(38, 38);
                ip.setMargins(2, 2, 2, 2);
                iv.setLayoutParams(ip);
                final int color = c;
                iv.setOnClickListener(v -> selectColor(color));
                presetsRow1.addView(iv);
            }
            layout.addView(presetsRow1);

            // Кнопки
            LinearLayout btnRow = new LinearLayout(this);
            btnRow.setGravity(Gravity.CENTER);
            btnRow.setPadding(0, 4, 0, 8);

            Button btnClear = new Button(this);
            btnClear.setText("Очистить"); btnClear.setTextSize(12);
            btnClear.setOnClickListener(v -> pixelGrid.clear());
            btnRow.addView(btnClear);

            Button btnSize16 = new Button(this);
            btnSize16.setText("16×16"); btnSize16.setTextSize(12);
            btnSize16.setOnClickListener(v -> { gridSize = 16; pixelGrid.initGrid(); });
            btnRow.addView(btnSize16);

            Button btnSize32 = new Button(this);
            btnSize32.setText("32×32"); btnSize32.setTextSize(12);
            btnSize32.setOnClickListener(v -> { gridSize = 32; pixelGrid.initGrid(); });
            btnRow.addView(btnSize32);

            Button btnSave = new Button(this);
            btnSave.setText("💾"); btnSave.setTextSize(12);
            btnSave.setOnClickListener(v -> saveToGallery());
            btnRow.addView(btnSave);

            layout.addView(btnRow);

            setContentView(layout);
            setTitle("🎨 Пиксель-Арт");
            AppLogger.log(this, "PixelArt", "onCreate completed");
        } catch (Exception e) { AppLogger.logException(this, "PixelArt", e); finish(); }
    }

    private void selectColor(int color) {
        currentColor = color;
        String hex = String.format("#%06X", 0xFFFFFF & color);
        colorPreview.setText("█ Текущий: " + hex);
        colorPreview.setTextColor(color);
        AppLogger.log(this, "PixelArt", "Color selected: " + hex);
    }

    private void saveToGallery() {
        try {
            int[][] pixels = pixelGrid.pixels;
            int size = gridSize;
            Bitmap bitmap = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888);
            for (int r = 0; r < size; r++)
                for (int c = 0; c < size; c++)
                    bitmap.setPixel(c, r, pixels[r][c] != 0 ? pixels[r][c] : Color.WHITE);

            Bitmap scaled = Bitmap.createScaledBitmap(bitmap, 512, 512, false);
            File dir = new File(Environment.getExternalStoragePublicDirectory(
                Environment.DIRECTORY_PICTURES), "PixelArt");
            if (!dir.exists()) dir.mkdirs();
            String fileName = "pixelart_" + System.currentTimeMillis() + ".png";
            File file = new File(dir, fileName);
            FileOutputStream fos = new FileOutputStream(file);
            scaled.compress(Bitmap.CompressFormat.PNG, 100, fos);
            fos.close();

            Intent mediaScan = new Intent(Intent.ACTION_MEDIA_SCANNER_SCAN_FILE);
            mediaScan.setData(Uri.fromFile(file));
            sendBroadcast(mediaScan);
            Toast.makeText(this, "Сохранено: " + fileName, Toast.LENGTH_LONG).show();
            AppLogger.log(this, "PixelArt", "Saved: " + file.getAbsolutePath());
        } catch (Exception e) {
            Toast.makeText(this, "Ошибка сохранения", Toast.LENGTH_SHORT).show();
            AppLogger.logException(this, "PixelArt", e);
        }
    }

    // RGB-палитра с градиентом и ползунком
    class ColorPaletteView extends View {
        private Paint paint = new Paint();
        private int hue = 0;           // 0-360
        private float satX = 0.8f;     // позиция на палитре насыщенности (0-1)
        private float satY = 0.2f;     // позиция на палитре яркости (0-1)
        private RectF hueRect, satRect;
        private boolean draggingHue = false, draggingSat = false;

        public ColorPaletteView(Context ctx) {
            super(ctx);
            setFocusable(true);
            setFocusableInTouchMode(true);
            setClickable(true);
        }

        @Override
        protected void onSizeChanged(int w, int h, int oldw, int oldh) {
            super.onSizeChanged(w, h, oldw, oldh);
            hueRect = new RectF(8, 8, w * 0.85f, h * 0.25f);
            satRect = new RectF(8, h * 0.4f, w * 0.85f, h * 0.9f);
        }

        @Override
        protected void onDraw(Canvas c) {
            super.onDraw(c);
            int w = getWidth(), h = getHeight();
            if (hueRect == null) {
                hueRect = new RectF(8, 8, w * 0.85f, h * 0.25f);
                satRect = new RectF(8, h * 0.4f, w * 0.85f, h * 0.9f);
            }

            // Hue-полоса (радуга)
            int[] hueColors = {Color.RED, Color.YELLOW, Color.GREEN, Color.CYAN, Color.BLUE, Color.MAGENTA, Color.RED};
            float[] huePos = {0f, 1f/6f, 2f/6f, 3f/6f, 4f/6f, 5f/6f, 1f};
            LinearGradient hueGrad = new LinearGradient(hueRect.left, 0, hueRect.right, 0,
                hueColors, huePos, Shader.TileMode.CLAMP);
            paint.setShader(hueGrad);
            paint.setStyle(Paint.Style.FILL);
            c.drawRoundRect(hueRect, 6, 6, paint);
            paint.setShader(null);

            // Указатель на hue
            float hueX = hueRect.left + (hue / 360f) * hueRect.width();
            paint.setColor(Color.WHITE);
            paint.setStyle(Paint.Style.STROKE);
            paint.setStrokeWidth(3);
            c.drawCircle(hueX, hueRect.centerY(), hueRect.height() * 0.5f, paint);
            paint.setColor(Color.BLACK);
            paint.setStrokeWidth(1);
            c.drawCircle(hueX, hueRect.centerY(), hueRect.height() * 0.5f - 1, paint);
            paint.setStyle(Paint.Style.FILL);

            // Палитра насыщенности/яркости
            int hueColor = Color.HSVToColor(new float[]{hue, 1f, 1f});
            LinearGradient satGradH = new LinearGradient(satRect.left, 0, satRect.right, 0,
                Color.WHITE, hueColor, Shader.TileMode.CLAMP);
            paint.setShader(satGradH);
            c.drawRoundRect(satRect, 6, 6, paint);

            LinearGradient satGradV = new LinearGradient(0, satRect.top, 0, satRect.bottom,
                0x00000000, 0xFF000000, Shader.TileMode.CLAMP);
            paint.setShader(satGradV);
            c.drawRoundRect(satRect, 6, 6, paint);
            paint.setShader(null);

            // Указатель на sat
            float sx = satRect.left + satX * satRect.width();
            float sy = satRect.top + satY * satRect.height();
            paint.setColor(Color.WHITE);
            paint.setStyle(Paint.Style.STROKE);
            paint.setStrokeWidth(3);
            c.drawCircle(sx, sy, 10, paint);
            paint.setStyle(Paint.Style.FILL);

            // Текущий цвет справа
            float[] hsv = {hue, satX, 1f - satY};
            int current = Color.HSVToColor(hsv);
            paint.setColor(current);
            float cx = w * 0.92f;
            float cy = h * 0.5f;
            c.drawRoundRect(cx - 5, cy - 5, cx + w * 0.06f, cy + h * 0.3f, 4, 4, paint);
            paint.setColor(0xFFCCCCCC);
            paint.setStyle(Paint.Style.STROKE);
            paint.setStrokeWidth(1);
            c.drawRoundRect(cx - 5, cy - 5, cx + w * 0.06f, cy + h * 0.3f, 4, 4, paint);
            paint.setStyle(Paint.Style.FILL);

            // Подписи
            paint.setColor(0xFF888888);
            paint.setTextSize(18);
            paint.setTextAlign(Paint.Align.CENTER);
            c.drawText("Оттенок", hueRect.centerX(), hueRect.top - 4, paint);
            c.drawText("Яркость / Насыщенность", satRect.centerX(), satRect.top - 4, paint);
            paint.setTextAlign(Paint.Align.LEFT);
        }

        @Override
        public boolean onTouchEvent(MotionEvent e) {
            float x = e.getX(), y = e.getY();

            switch (e.getAction()) {
                case MotionEvent.ACTION_DOWN:
                    if (hueRect.contains(x, y)) draggingHue = true;
                    else if (satRect.contains(x, y)) draggingSat = true;
                    break;
                case MotionEvent.ACTION_MOVE:
                    if (draggingHue) {
                        hue = (int)((x - hueRect.left) / hueRect.width() * 360);
                        hue = Math.max(0, Math.min(360, hue));
                    }
                    if (draggingSat) {
                        satX = (x - satRect.left) / satRect.width();
                        satY = (y - satRect.top) / satRect.height();
                        satX = Math.max(0, Math.min(1, satX));
                        satY = Math.max(0, Math.min(1, satY));
                    }
                    if (draggingHue || draggingSat) {
                        float[] hsv = {hue, satX, 1f - satY};
                        selectColor(Color.HSVToColor(hsv));
                    }
                    break;
                case MotionEvent.ACTION_UP:
                    draggingHue = false;
                    draggingSat = false;
                    break;
            }
            invalidate();
            return true;
        }
    }

    class PixelGridView extends View {
        private Paint paint = new Paint();
        private int[][] pixels;

        public PixelGridView(Context ctx) {
            super(ctx);
            setFocusable(true);
            setFocusableInTouchMode(true);
            initGrid();
        }

        public void initGrid() {
            pixels = new int[gridSize][gridSize];
            invalidate();
        }

        public void clear() {
            initGrid();
            AppLogger.log(PixelArtActivity.this, "PixelArt", "Cleared");
        }

        @Override
        protected void onDraw(Canvas c) {
            super.onDraw(c);
            int w = getWidth(), h = getHeight();
            float cell = Math.min(w, h) / (float) gridSize;
            float ox = (w - cell * gridSize) / 2f;
            float oy = (h - cell * gridSize) / 2f;

            for (int r = 0; r < gridSize; r++) {
                for (int col = 0; col < gridSize; col++) {
                    paint.setColor(pixels[r][col] != 0 ? pixels[r][col] : Color.WHITE);
                    c.drawRect(ox + col * cell, oy + r * cell,
                        ox + col * cell + cell, oy + r * cell + cell, paint);
                }
            }

            if (cell > 8) {
                paint.setColor(0xFFCCCCCC);
                paint.setStrokeWidth(0.5f);
                for (int i = 0; i <= gridSize; i++) {
                    c.drawLine(ox, oy + i * cell, ox + gridSize * cell, oy + i * cell, paint);
                    c.drawLine(ox + i * cell, oy, ox + i * cell, oy + gridSize * cell, paint);
                }
            }
        }

        @Override
        public boolean onTouchEvent(MotionEvent e) {
            int w = getWidth(), h = getHeight();
            float cell = Math.min(w, h) / (float) gridSize;
            float ox = (w - cell * gridSize) / 2f;
            float oy = (h - cell * gridSize) / 2f;

            switch (e.getAction()) {
                case MotionEvent.ACTION_DOWN:
                case MotionEvent.ACTION_MOVE:
                    float x = e.getX();
                    float y = e.getY();
                    int col = (int) ((x - ox) / cell);
                    int row = (int) ((y - oy) / cell);
                    if (col >= 0 && col < gridSize && row >= 0 && row < gridSize) {
                        pixels[row][col] = currentColor;
                        invalidate();
                    }
                    break;
            }
            return true;
        }
    }
}