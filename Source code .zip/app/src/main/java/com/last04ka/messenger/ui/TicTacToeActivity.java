package com.last04ka.messenger.ui;

import android.app.Activity;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.os.Bundle;
import android.os.Handler;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import com.last04ka.messenger.utils.AppLogger;
import com.last04ka.messenger.utils.GameScores;

public class TicTacToeActivity extends Activity {

    private BoardView boardView;
    private TextView statusText;
    private Button btnNew;
    private int[][] board = new int[3][3];
    private int playerScore = 0, botScore = 0, draws = 0;
    private boolean playerTurn = true;
    private boolean gameOver = false;
    private Handler handler = new Handler();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        try {
            AppLogger.log(this, "TicTacToe", "onCreate started v2");
            LinearLayout layout = new LinearLayout(this);
            layout.setOrientation(LinearLayout.VERTICAL);
            layout.setBackgroundColor(0xFF1A1A2E);

            statusText = new TextView(this);
            statusText.setText("Ваш ход (X)"); statusText.setTextSize(16);
            statusText.setTextColor(0xFFFFFFFF); statusText.setGravity(Gravity.CENTER);
            layout.addView(statusText);

            boardView = new BoardView(this);
            LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1);
            boardView.setLayoutParams(bp);
            layout.addView(boardView);

            btnNew = new Button(this); btnNew.setText("Новая игра");
            btnNew.setOnClickListener(v -> resetBoard());
            layout.addView(btnNew);

            setContentView(layout); setTitle("❌⭕ Крестики-нолики");
            AppLogger.log(this, "TicTacToe", "onCreate completed");
        } catch (Exception e) { AppLogger.logException(this, "TicTacToe", e); finish(); }
    }

    private void resetBoard() {
        board = new int[3][3]; playerTurn = true; gameOver = false;
        statusText.setText("Ваш ход (X): " + playerScore + "-" + botScore + "-" + draws);
        boardView.invalidate();
    }

    private void botMove() {
        int[] best = findBestMove();
        board[best[0]][best[1]] = 2; playerTurn = true;
        boardView.invalidate();
        int winner = checkWinner();
        if (winner == 2) { botScore++; statusText.setText("Бот выиграл! " + playerScore + "-" + botScore + "-" + draws); gameOver = true; AppLogger.log(this, "TicTacToe", "Bot wins"); }
        else if (isFull()) { draws++; statusText.setText("Ничья! " + playerScore + "-" + botScore + "-" + draws); gameOver = true; AppLogger.log(this, "TicTacToe", "Draw"); }
        else statusText.setText("Ваш ход (X): " + playerScore + "-" + botScore + "-" + draws);
    }

    private int[] findBestMove() {
        for (int r=0;r<3;r++) for (int c=0;c<3;c++) if (board[r][c]==0) { board[r][c]=2; if (checkWinner()==2) { board[r][c]=0; return new int[]{r,c}; } board[r][c]=0; }
        for (int r=0;r<3;r++) for (int c=0;c<3;c++) if (board[r][c]==0) { board[r][c]=1; if (checkWinner()==1) { board[r][c]=0; return new int[]{r,c}; } board[r][c]=0; }
        int[] center = {1,1}; if (board[1][1]==0) return center;
        int[][] corners = {{0,0},{0,2},{2,0},{2,2}};
        for (int[] cor : corners) if (board[cor[0]][cor[1]]==0) return cor;
        for (int r=0;r<3;r++) for (int c=0;c<3;c++) if (board[r][c]==0) return new int[]{r,c};
        return new int[]{0,0};
    }

    private int checkWinner() {
        int[][] lines = {{0,0,0,1,0,2},{1,0,1,1,1,2},{2,0,2,1,2,2},{0,0,1,0,2,0},{0,1,1,1,2,1},{0,2,1,2,2,2},{0,0,1,1,2,2},{0,2,1,1,2,0}};
        for (int[] l : lines) if (board[l[0]][l[1]]!=0&&board[l[0]][l[1]]==board[l[2]][l[3]]&&board[l[0]][l[1]]==board[l[4]][l[5]]) return board[l[0]][l[1]];
        return 0;
    }

    private boolean isFull() { for (int r=0;r<3;r++) for (int c=0;c<3;c++) if (board[r][c]==0) return false; return true; }

    class BoardView extends View {
        private Paint paint = new Paint();
        public BoardView(Context ctx) { super(ctx); setFocusable(true); }
        @Override
        protected void onDraw(Canvas c) {
            super.onDraw(c);
            int w=getWidth(),h=getHeight(); float cell=Math.min(w,h)/3f, ox=(w-cell*3)/2, oy=(h-cell*3)/2;
            paint.setColor(0xFF2E2E3E); c.drawRect(ox,oy,ox+cell*3,oy+cell*3,paint);
            paint.setColor(0xFFFFFFFF); paint.setStrokeWidth(4);
            for (int i=1;i<3;i++) { c.drawLine(ox,oy+i*cell,ox+3*cell,oy+i*cell,paint); c.drawLine(ox+i*cell,oy,ox+i*cell,oy+3*cell,paint); }
            for (int r=0;r<3;r++) for (int col=0;col<3;col++) {
                float cx=ox+col*cell+cell/2, cy=oy+r*cell+cell/2;
                if (board[r][col]==1) { paint.setColor(0xFF4FC3F7); paint.setStrokeWidth(10);
                    c.drawLine(cx-cell*0.3f,cy-cell*0.3f,cx+cell*0.3f,cy+cell*0.3f,paint); c.drawLine(cx+cell*0.3f,cy-cell*0.3f,cx-cell*0.3f,cy+cell*0.3f,paint); }
                else if (board[r][col]==2) { paint.setColor(0xFFFF5252); paint.setStyle(Paint.Style.STROKE); paint.setStrokeWidth(10);
                    c.drawCircle(cx,cy,cell*0.3f,paint); paint.setStyle(Paint.Style.FILL); }
            }
        }
        @Override
        public boolean onTouchEvent(MotionEvent e) {
            if (!playerTurn||gameOver) return true;
            int w=getWidth(),h=getHeight(); float cell=Math.min(w,h)/3f,ox=(w-cell*3)/2,oy=(h-cell*3)/2;
            int col=(int)((e.getX()-ox)/cell),row=(int)((e.getY()-oy)/cell);
            if (row<0||row>=3||col<0||col>=3||board[row][col]!=0) return true;
            board[row][col]=1; playerTurn=false; boardView.invalidate();
            int winner = checkWinner();
            if (winner==1) { playerScore++; statusText.setText("Вы выиграли! "+playerScore+"-"+botScore+"-"+draws); gameOver=true; AppLogger.log(TicTacToeActivity.this,"TicTacToe","Player wins"); }
            else if (isFull()) { draws++; statusText.setText("Ничья! "+playerScore+"-"+botScore+"-"+draws); gameOver=true; AppLogger.log(TicTacToeActivity.this,"TicTacToe","Draw"); }
            else { statusText.setText("Ход бота..."); handler.postDelayed(()->botMove(),500); }
            return true;
        }
    }
}