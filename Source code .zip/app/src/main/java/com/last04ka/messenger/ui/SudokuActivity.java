package com.last04ka.messenger.ui;

import android.app.Activity;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.os.Bundle;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import com.last04ka.messenger.utils.AppLogger;
import java.util.Random;

public class SudokuActivity extends Activity {

    private GameView gameView;
    private TextView statusText;
    private int[][] board = new int[9][9];
    private int[][] solution = new int[9][9];
    private boolean[][] fixed = new boolean[9][9];
    private int selRow = -1, selCol = -1;
    private Random rand = new Random();

    private static final int[][] SEED = {
        {5,3,4,6,7,8,9,1,2},{6,7,2,1,9,5,3,4,8},{1,9,8,3,4,2,5,6,7},
        {8,5,9,7,6,1,4,2,3},{4,2,6,8,5,3,7,9,1},{7,1,3,9,2,4,8,5,6},
        {9,6,1,5,3,7,2,8,4},{2,8,7,4,1,9,6,3,5},{3,4,5,2,8,6,1,7,9}
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        try {
            AppLogger.log(this, "Sudoku", "onCreate v3");
            LinearLayout layout = new LinearLayout(this);
            layout.setOrientation(LinearLayout.VERTICAL);
            layout.setBackgroundColor(0xFF1A1A2E);

            statusText = new TextView(this);
            statusText.setText("Судоку"); statusText.setTextSize(16);
            statusText.setTextColor(0xFFFFD740); statusText.setGravity(Gravity.CENTER);
            layout.addView(statusText);

            gameView = new GameView(this);
            LinearLayout.LayoutParams gp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 1);
            gameView.setLayoutParams(gp);
            layout.addView(gameView);

            LinearLayout numRow = new LinearLayout(this);
            numRow.setGravity(Gravity.CENTER);
            for (int i = 1; i <= 9; i++) { final int n = i;
                Button btn = new Button(this); btn.setText(String.valueOf(n)); btn.setTextSize(14);
                btn.setPadding(6,4,6,4); btn.setOnClickListener(v -> placeNumber(n)); numRow.addView(btn);
            }
            layout.addView(numRow);

            LinearLayout actRow = new LinearLayout(this);
            actRow.setGravity(Gravity.CENTER);
            Button btnClear = new Button(this); btnClear.setText("Стереть");
            btnClear.setOnClickListener(v -> placeNumber(0)); actRow.addView(btnClear);
            Button btnNew = new Button(this); btnNew.setText("Новая");
            btnNew.setOnClickListener(v -> generatePuzzle()); actRow.addView(btnNew);
            Button btnCheck = new Button(this); btnCheck.setText("Проверить");
            btnCheck.setOnClickListener(v -> checkSolution()); actRow.addView(btnCheck);
            layout.addView(actRow);

            setContentView(layout); setTitle("🔢 Судоку");
            generatePuzzle();
            AppLogger.log(this, "Sudoku", "onCreate completed");
        } catch (Exception e) { AppLogger.logException(this, "Sudoku", e); finish(); }
    }

    private void generatePuzzle() {
        for (int r=0;r<9;r++) for (int c=0;c<9;c++) {
            solution[r][c]=SEED[r][c]; board[r][c]=solution[r][c];
            fixed[r][c]=rand.nextFloat()>0.45f;
            if(!fixed[r][c])board[r][c]=0;
        }
        statusText.setText("Судоку"); gameView.invalidate();
        AppLogger.log(this,"Sudoku","New puzzle");
    }

    private void placeNumber(int n) {
        if(selRow>=0&&selCol>=0&&!fixed[selRow][selCol]){board[selRow][selCol]=n;gameView.invalidate();}
    }

    private void checkSolution() {
        for(int r=0;r<9;r++)for(int c=0;c<9;c++)if(board[r][c]!=solution[r][c]){Toast.makeText(this,"Есть ошибки!",Toast.LENGTH_SHORT).show();return;}
        statusText.setText("🏆 Решено верно!");Toast.makeText(this,"Поздравляем!",Toast.LENGTH_SHORT).show();
        AppLogger.log(this,"Sudoku","Solved");
    }

    class GameView extends View {
        private Paint paint = new Paint();
        public GameView(Context ctx){super(ctx);setFocusable(true);setClickable(true);}
        @Override
        protected void onDraw(Canvas c) {
            super.onDraw(c);
            int w=getWidth(),h=getHeight();
            float cell=Math.min(w,h)/9f, ox=(w-cell*9)/2, oy=(h-cell*9)/2;

            // Фон
            paint.setColor(0xFF2A2A3E); c.drawRect(ox,oy,ox+cell*9,oy+cell*9,paint);

            // Ячейки
            for(int r=0;r<9;r++)for(int col=0;col<9;col++){
                float x=ox+col*cell,y=oy+r*cell;
                if(selRow==r&&selCol==col)paint.setColor(0xFF4FC3F7);
                else if(selRow>=0&&r/3==selRow/3&&col/3==selCol/3)paint.setColor(0xFF3A3A5E);
                else paint.setColor(0xFF2A2A3E);
                c.drawRect(x+1,y+1,x+cell-1,y+cell-1,paint);
                if(board[r][col]>0){
                    paint.setColor(fixed[r][col]?0xFFFFFFFF:0xFFFFD740);
                    paint.setTextSize(cell*0.45f);paint.setTextAlign(Paint.Align.CENTER);
                    c.drawText(String.valueOf(board[r][col]),x+cell/2,y+cell*0.68f,paint);
                    paint.setTextAlign(Paint.Align.LEFT);
                }
            }

            // Сетка
            paint.setColor(0xFF666666);paint.setStrokeWidth(1);
            for(int i=0;i<=9;i++){float pos=ox+i*cell;c.drawLine(pos,oy,pos,oy+9*cell,paint);c.drawLine(ox,pos,ox+9*cell,pos,paint);}
            paint.setColor(0xFFFFFFFF);paint.setStrokeWidth(3);
            for(int i=0;i<=9;i+=3){float pos=ox+i*cell;c.drawLine(pos,oy,pos,oy+9*cell,paint);c.drawLine(ox,pos,ox+9*cell,pos,paint);}
        }
        @Override
        public boolean onTouchEvent(MotionEvent e){
            if(e.getAction()!=MotionEvent.ACTION_DOWN)return true;
            int w=getWidth(),h=getHeight();
            float cell=Math.min(w,h)/9f,ox=(w-cell*9)/2,oy=(h-cell*9)/2;
            int col=(int)((e.getX()-ox)/cell),row=(int)((e.getY()-oy)/cell);
            selRow=(col>=0&&col<9&&row>=0&&row<9)?row:-1;selCol=(col>=0&&col<9&&row>=0&&row<9)?col:-1;
            invalidate();return true;
        }
    }
}