package com.last04ka.messenger.ui;

import android.Manifest;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.res.ColorStateList;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.speech.RecognizerIntent;
import android.support.annotation.NonNull;
import android.support.design.widget.FloatingActionButton;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.helper.ItemTouchHelper;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.view.animation.OvershootInterpolator;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Toast;

import com.last04ka.messenger.R;
import com.last04ka.messenger.adapters.ChatListAdapter;
import com.last04ka.messenger.data.Chat;
import com.last04ka.messenger.data.DatabaseHelper;
import com.last04ka.messenger.utils.AchievementManager;
import com.last04ka.messenger.utils.AppLogger;
import com.last04ka.messenger.utils.StreakManager;
import com.last04ka.messenger.utils.ThemeManager;
import com.last04ka.messenger.utils.UpdateManager;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;

public class MainActivity extends AppCompatActivity {
    private static final String TAG = "MainActivity";
    private static final int REQUEST_PERMISSIONS = 100;
    private static final int REQUEST_VOICE = 101;
    private static final int REQUEST_ALL_PERMISSIONS = 200;
    private static final int REQUEST_GPS_PERMISSION = 300;
    private static final String PREF_FIRST_LAUNCH = "first_launch";

    private RecyclerView recyclerView;
    private ChatListAdapter adapter;
    private DatabaseHelper dbHelper;
    private List<Chat> chatList = new ArrayList<>();
    private List<Chat> filteredList = new ArrayList<>();
    private EditText searchChats;
    private int sortMode = 0;
    private UpdateManager updateManager;

    // ==================== ПОДТВЕРЖДЕНИЕ ВЫХОДА ====================
    private long backPressedTime = 0;
    private Toast backToast;

    // ==================== ВИДЖЕТ ПОГОДЫ ====================
    private WeatherWidgetView weatherWidget;
    private LinearLayout weatherContainer;

    // Для отслеживания времени
    private Handler timeHandler = new Handler();
    private boolean isTrackingTime = false;
    private static final long UPDATE_INTERVAL_MS = 60000; // 1 минута

    private String[] allPermissions = {
            Manifest.permission.RECORD_AUDIO,
            Manifest.permission.READ_EXTERNAL_STORAGE,
            Manifest.permission.WRITE_EXTERNAL_STORAGE,
            Manifest.permission.CAMERA,
            Manifest.permission.ACCESS_FINE_LOCATION,
            Manifest.permission.ACCESS_COARSE_LOCATION
    };
    private String[] bluetoothPermissions = {
            "android.permission.BLUETOOTH_SCAN",
            "android.permission.BLUETOOTH_CONNECT",
            "android.permission.BLUETOOTH_ADVERTISE"
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        setTheme(ThemeManager.getThemeResource(this));
        super.onCreate(savedInstanceState);
        try {
            AppLogger.log(this, TAG, "========== onCreate START ==========");
            setContentView(R.layout.activity_main);
            dbHelper = new DatabaseHelper(this);

            // ==================== ВИДЖЕТ ПОГОДЫ ====================
            weatherContainer = findViewById(R.id.weather_container);
            if (weatherContainer != null) {
                weatherWidget = new WeatherWidgetView(this);
                weatherContainer.addView(weatherWidget);
                AppLogger.log(this, TAG, "✅ Weather widget added");
            } else {
                AppLogger.log(this, TAG, "⚠️ weather_container not found");
            }

            // ==================== ПРОВЕРКА GPS РАЗРЕШЕНИЙ ====================
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
                    != PackageManager.PERMISSION_GRANTED) {
                AppLogger.log(this, TAG, "⚠️ GPS permission not granted, requesting...");
                ActivityCompat.requestPermissions(this,
                        new String[]{Manifest.permission.ACCESS_FINE_LOCATION},
                        REQUEST_GPS_PERMISSION);
            } else {
                AppLogger.log(this, TAG, "✅ GPS permission granted");
            }

            // ==================== СОЗДАЁМ ЧАТ "ИСТОРИЯ ИЗМЕНЕНИЙ" ====================
            createChangelogChatIfNotExists();
            AppLogger.log(this, TAG, "✅ Changelog chat checked");

            initViews();
            setupRecyclerView();
            setupFABs();
            applyThemeColors();

            checkFirstLaunch();
            requestAllPermissionsIfNeeded();
            loadChats();
            checkForUpdates();

            // Запускаем отслеживание времени
            startTimeTracking();

            // ========== ПРОВЕРКА ДОСТИЖЕНИЙ ПРИ ЗАПУСКЕ ==========
            AchievementManager.checkAllAchievements(this);

            AppLogger.log(this, TAG, "========== onCreate SUCCESS ==========");
        } catch (Exception e) {
            AppLogger.logException(this, TAG, "onCreate error", e);
            finish();
        }
    }

    // ==================== ПОДТВЕРЖДЕНИЕ ВЫХОДА ====================
    @Override
    public void onBackPressed() {
        AppLogger.log(this, TAG, "🔙 Back pressed");
        if (backPressedTime + 2000 > System.currentTimeMillis()) {
            if (backToast != null) backToast.cancel();
            AppLogger.log(this, TAG, "✅ Exiting app");
            super.onBackPressed();
            return;
        } else {
            backToast = Toast.makeText(this, "Нажмите ещё раз, чтобы выйти", Toast.LENGTH_SHORT);
            backToast.show();
            backPressedTime = System.currentTimeMillis();
            AppLogger.log(this, TAG, "⏳ First back press, showing toast");
        }
    }

    // ==================== ЧАТ "ИСТОРИЯ ИЗМЕНЕНИЙ" ====================
    private void createChangelogChatIfNotExists() {
        AppLogger.log(this, TAG, "📋 createChangelogChatIfNotExists() START");

        String changelogChatId = "changelog_chat";
        Chat existing = dbHelper.getChat(changelogChatId);
        if (existing == null) {
            AppLogger.log(this, TAG, "📋 Creating changelog chat");
            Chat chat = new Chat();
            chat.setId(changelogChatId);
            chat.setName("📋 История изменений");
            chat.setType(0);
            chat.setAddress("");
            chat.setDeviceAddress("");
            chat.setLastMessage("📋 Версия 2.9 — Умная Ласточка");
            chat.setLastTime(System.currentTimeMillis());
            chat.setTimestamp(System.currentTimeMillis());
            chat.setFavorite(true);
            chat.setAvatar("");
            chat.setUnreadCount(0);
            dbHelper.addChat(chat);
            AppLogger.log(this, TAG, "✅ Changelog chat created");
        } else {
            AppLogger.log(this, TAG, "✅ Changelog chat already exists");
        }
        AppLogger.log(this, TAG, "📋 createChangelogChatIfNotExists() END");
    }

    private void initViews() {
        recyclerView = findViewById(R.id.recycler_chats);
        searchChats = findViewById(R.id.search_chats);

        searchChats.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int st, int c, int a) {}
            @Override public void onTextChanged(CharSequence s, int st, int b, int c) {
                filterChats(s.toString());
            }
            @Override public void afterTextChanged(Editable s) {}
        });
        AppLogger.log(this, TAG, "Views initialized");
    }

    private void setupRecyclerView() {
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        adapter = new ChatListAdapter(filteredList, chat -> {
            AppLogger.log(MainActivity.this, TAG, "📋 Chat clicked: " + chat.getName() + " (id=" + chat.getId() + ")");
            if ("changelog_chat".equals(chat.getId())) {
                AppLogger.log(MainActivity.this, TAG, "📋 Opening ChangelogChatActivity");
                Intent intent = new Intent(MainActivity.this, ChangelogChatActivity.class);
                startActivity(intent);
            } else {
                Intent i = new Intent(MainActivity.this, ChatActivity.class);
                i.putExtra("CHAT_ID", chat.getId());
                i.putExtra("CHAT_NAME", chat.getName());
                i.putExtra("CHAT_TYPE", chat.getType());
                startActivity(i);
            }
        });

        adapter.setOnChatLongClickListener(c -> showChatActions(c));

        new ItemTouchHelper(new ItemTouchHelper.SimpleCallback(0, ItemTouchHelper.LEFT | ItemTouchHelper.RIGHT) {
            @Override
            public boolean onMove(RecyclerView rv, RecyclerView.ViewHolder vh, RecyclerView.ViewHolder t) {
                return false;
            }

            @Override
            public void onSwiped(RecyclerView.ViewHolder vh, int dir) {
                int pos = vh.getAdapterPosition();
                if (pos < 0 || pos >= filteredList.size()) return;
                Chat c = filteredList.get(pos);

                if ("changelog_chat".equals(c.getId())) {
                    AppLogger.log(MainActivity.this, TAG, "⚠️ Cannot delete changelog chat");
                    adapter.notifyItemChanged(pos);
                    Toast.makeText(MainActivity.this, "Этот чат нельзя удалить", Toast.LENGTH_SHORT).show();
                    return;
                }

                if (dir == ItemTouchHelper.LEFT) {
                    showDeleteConfirm(c, pos);
                } else {
                    dbHelper.setFavorite(c.getId(), !c.isFavorite());
                    loadChats();
                }
            }
        }).attachToRecyclerView(recyclerView);

        recyclerView.setAdapter(adapter);
        AppLogger.log(this, TAG, "RecyclerView setup complete");
    }

    private void setupFABs() {
        FloatingActionButton fabS = findViewById(R.id.fab_settings);
        FloatingActionButton fabN = findViewById(R.id.fab_new_chat);
        FloatingActionButton fabM = findViewById(R.id.fab_mini_apps);

        animateFAB(fabS, 300);
        animateFAB(fabN, 500);
        animateFAB(fabM, 700);

        fabS.setOnClickListener(v -> {
            pulse(v);
            startActivity(new Intent(this, SettingsActivity.class));
        });
        fabN.setOnClickListener(v -> {
            pulse(v);
            startActivity(new Intent(this, NewChatActivity.class));
        });
        fabM.setOnClickListener(v -> {
            pulse(v);
            startActivity(new Intent(this, MiniAppsActivity.class));
        });

        fabS.setOnLongClickListener(v -> {
            sortMode = (sortMode + 1) % 3;
            loadChats();
            return true;
        });
        fabM.setOnLongClickListener(v -> {
            startVoiceSearch();
            return true;
        });

        AppLogger.log(this, TAG, "FABs setup complete");
    }

    // ==================== ОТСЛЕЖИВАНИЕ ВРЕМЕНИ ====================

    private void startTimeTracking() {
        if (isTrackingTime) {
            AppLogger.log(this, TAG, "⏱ Time tracking already running");
            return;
        }
        isTrackingTime = true;
        timeHandler.postDelayed(timeRunnable, UPDATE_INTERVAL_MS);
        AppLogger.log(this, TAG, "⏱ Time tracking STARTED (interval: " + UPDATE_INTERVAL_MS + "ms)");
    }

    private Runnable timeRunnable = new Runnable() {
        @Override
        public void run() {
            if (isTrackingTime) {
                AppLogger.log(MainActivity.this, TAG, "⏱ Adding 1 minute...");
                StreakManager.addTime(MainActivity.this, 1);
                AppLogger.log(MainActivity.this, TAG, "⏱ Time added, scheduling next update");
                timeHandler.postDelayed(this, UPDATE_INTERVAL_MS);
            } else {
                AppLogger.log(MainActivity.this, TAG, "⏱ Time tracking stopped, not rescheduling");
            }
        }
    };

    private void stopTimeTracking() {
        isTrackingTime = false;
        timeHandler.removeCallbacks(timeRunnable);
        AppLogger.log(this, TAG, "⏱ Time tracking STOPPED");
    }

    @Override
    protected void onResume() {
        super.onResume();
        AppLogger.log(this, TAG, "onResume");
        loadChats();
        if (!isTrackingTime) {
            startTimeTracking();
        }
        // Обновляем погоду при возвращении
        if (weatherWidget != null) {
            weatherWidget.refreshWeather();
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        AppLogger.log(this, TAG, "onPause");
        // Не останавливаем, чтобы время шло в фоне
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        stopTimeTracking();
        AppLogger.log(this, TAG, "onDestroy");
    }

    // ==================== ПЕРВЫЙ ЗАПУСК ====================

    private void checkFirstLaunch() {
        SharedPreferences prefs = getSharedPreferences("app_prefs", MODE_PRIVATE);
        boolean isFirstLaunch = prefs.getBoolean(PREF_FIRST_LAUNCH, true);
        AppLogger.log(this, TAG, "First launch: " + isFirstLaunch);

        if (isFirstLaunch) {
            showWelcomeDialog();
        }
    }

    private void showWelcomeDialog() {
        AppLogger.log(this, TAG, "showWelcomeDialog()");
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        View dialogView = getLayoutInflater().inflate(R.layout.dialog_first_launch, null);
        builder.setView(dialogView);
        builder.setCancelable(false);

        AlertDialog dialog = builder.create();
        dialog.show();

        Button btnStart = dialogView.findViewById(R.id.btn_start_using);
        btnStart.setOnClickListener(v -> {
            AppLogger.log(MainActivity.this, TAG, "User clicked start");
            dialog.dismiss();
            requestAllPermissionsForFirstLaunch();
        });
    }

    private void requestAllPermissionsForFirstLaunch() {
        requestAllPermissionsWithCallback(REQUEST_ALL_PERMISSIONS);
    }

    private void requestAllPermissionsIfNeeded() {
        List<String> missing = getMissingPermissions();
        if (!missing.isEmpty()) {
            requestAllPermissionsWithCallback(REQUEST_PERMISSIONS);
        }
    }

    private void requestAllPermissionsWithCallback(int requestCode) {
        List<String> permissionsToRequest = getMissingPermissions();
        if (permissionsToRequest.isEmpty()) {
            setFirstLaunchDone();
            return;
        }

        String[] permsArray = permissionsToRequest.toArray(new String[0]);
        ActivityCompat.requestPermissions(this, permsArray, requestCode);
    }

    private List<String> getMissingPermissions() {
        List<String> missing = new ArrayList<>();
        for (String perm : allPermissions) {
            if (ContextCompat.checkSelfPermission(this, perm) != PackageManager.PERMISSION_GRANTED) {
                missing.add(perm);
            }
        }
        if (Build.VERSION.SDK_INT >= 31) {
            for (String perm : bluetoothPermissions) {
                if (ContextCompat.checkSelfPermission(this, perm) != PackageManager.PERMISSION_GRANTED) {
                    missing.add(perm);
                }
            }
        }
        return missing;
    }

    private void setFirstLaunchDone() {
        SharedPreferences prefs = getSharedPreferences("app_prefs", MODE_PRIVATE);
        prefs.edit().putBoolean(PREF_FIRST_LAUNCH, false).apply();
        AppLogger.log(this, TAG, "First launch flag set");
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        
        if (requestCode == REQUEST_GPS_PERMISSION) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                AppLogger.log(this, TAG, "✅ GPS permission granted");
                if (weatherWidget != null) {
                    weatherWidget.refreshWeather();
                }
            } else {
                AppLogger.log(this, TAG, "❌ GPS permission denied");
                Toast.makeText(this, "Для определения погоды по GPS нужно разрешение", Toast.LENGTH_LONG).show();
            }
            return;
        }

        if (requestCode == REQUEST_ALL_PERMISSIONS || requestCode == REQUEST_PERMISSIONS) {
            List<String> denied = new ArrayList<>();
            for (int i = 0; i < permissions.length; i++) {
                if (grantResults[i] != PackageManager.PERMISSION_GRANTED) {
                    denied.add(permissions[i]);
                }
            }
            if (denied.isEmpty()) {
                if (requestCode == REQUEST_ALL_PERMISSIONS) {
                    Toast.makeText(this, R.string.all_permissions_granted, Toast.LENGTH_SHORT).show();
                }
            } else {
                if (requestCode == REQUEST_ALL_PERMISSIONS) {
                    Toast.makeText(this, R.string.permission_denied_partial, Toast.LENGTH_LONG).show();
                }
            }
            if (requestCode == REQUEST_ALL_PERMISSIONS) {
                setFirstLaunchDone();
            }
        }
    }

    // ==================== ОСТАЛЬНЫЕ МЕТОДЫ ====================

    private void checkForUpdates() {
        updateManager = new UpdateManager(this);
        updateManager.setListener(new UpdateManager.UpdateListener() {
            @Override
            public void onUpdateAvailable(String versionName, String message, String downloadUrl) {
                updateManager.showUpdateDialog(versionName, message, downloadUrl);
            }
            @Override public void onNoUpdate() {}
            @Override public void onError(String error) {}
            @Override public void onUpdateStarted() {}
        });
        updateManager.checkForUpdates(false);
    }

    private void animateFAB(View fab, long d) {
        fab.setScaleX(0f);
        fab.setScaleY(0f);
        fab.animate().scaleX(1f).scaleY(1f).setDuration(400).setStartDelay(d).setInterpolator(new OvershootInterpolator(1.5f)).start();
    }

    private void pulse(View v) {
        v.animate().scaleX(0.85f).scaleY(0.85f).setDuration(80).withEndAction(() ->
                v.animate().scaleX(1f).scaleY(1f).setDuration(80).start()
        ).start();
    }

    private void showDeleteConfirm(Chat c, int pos) {
        new AlertDialog.Builder(this)
                .setTitle("Удалить «" + c.getName() + "»?")
                .setPositiveButton("Да", (d, w) -> {
                    filteredList.remove(pos);
                    adapter.notifyItemRemoved(pos);
                    dbHelper.deleteChat(c.getId());
                    loadChats();
                })
                .setNegativeButton("Нет", (d, w) -> adapter.notifyItemChanged(pos))
                .show();
    }

    private void showChatActions(Chat c) {
        if ("changelog_chat".equals(c.getId())) {
            Toast.makeText(this, "Этот чат нельзя изменять", Toast.LENGTH_SHORT).show();
            return;
        }

        new AlertDialog.Builder(this)
                .setTitle(c.getName())
                .setItems(new String[]{"Удалить", "В избранное"}, (d, w) -> {
                    if (w == 0) {
                        dbHelper.deleteChat(c.getId());
                        loadChats();
                    } else {
                        dbHelper.setFavorite(c.getId(), true);
                        loadChats();
                    }
                })
                .show();
    }

    private void startVoiceSearch() {
        Intent i = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault());
        try {
            startActivityForResult(i, REQUEST_VOICE);
        } catch (Exception e) {
            Toast.makeText(this, "Недоступно", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    protected void onActivityResult(int rq, int rc, Intent d) {
        super.onActivityResult(rq, rc, d);
        if (rq == REQUEST_VOICE && rc == RESULT_OK && d != null) {
            ArrayList<String> r = d.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
            if (r != null && !r.isEmpty()) {
                searchChats.setText(r.get(0));
                filterChats(r.get(0));
            }
        }
    }

    private void applyThemeColors() {
        int fc = ThemeManager.getFabColor(this);
        findViewById(R.id.fab_settings).setBackgroundTintList(ColorStateList.valueOf(fc));
        findViewById(R.id.fab_new_chat).setBackgroundTintList(ColorStateList.valueOf(fc));
        findViewById(R.id.fab_mini_apps).setBackgroundTintList(ColorStateList.valueOf(fc));
        if (getSupportActionBar() != null) {
            getSupportActionBar().setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(
                    ThemeManager.isDarkTheme(this) ? 0xFF424242 : 0xFF1565C0));
        }
    }

    private void loadChats() {
        chatList.clear();
        chatList.addAll(dbHelper.getAllChatsSorted());
        if (sortMode == 1) {
            Collections.sort(chatList, (a, b) -> a.getName().compareToIgnoreCase(b.getName()));
        } else if (sortMode == 2) {
            Collections.sort(chatList, (a, b) -> Integer.compare(a.getType(), b.getType()));
        }
        setTitle("Last04ka (" + chatList.size() + ")");
        filterChats(searchChats.getText().toString());
    }

    private void filterChats(String q) {
        filteredList.clear();
        if (q.isEmpty()) {
            filteredList.addAll(chatList);
        } else {
            String lq = q.toLowerCase();
            for (Chat c : chatList) {
                if (c.getName().toLowerCase().contains(lq)) {
                    filteredList.add(c);
                }
            }
        }
        adapter.notifyDataSetChanged();
    }
}