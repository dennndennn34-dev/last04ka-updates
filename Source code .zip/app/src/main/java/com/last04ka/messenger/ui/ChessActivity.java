package com.last04ka.messenger.ui;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;
import com.last04ka.messenger.utils.AppLogger;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class ChessActivity extends Activity {

    private ChessView chessView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        try {
            AppLogger.log(this, "Chess", "onCreate started");
            chessView = new ChessView(this);
            setContentView(chessView);
            setTitle("♟️ Шахматы");
            AppLogger.log(this, "Chess", "onCreate completed");
        } catch (Exception e) { AppLogger.logException(this, "Chess", e); finish(); }
    }

    class ChessView extends View {
        private int[][] board = new int[8][8];
        private boolean whiteTurn = true;
        private int selectedRow = -1, selectedCol = -1;
        private Paint paint = new Paint();
        private Random r = new Random();
        private boolean gameOver = false;

        public ChessView(Context ctx) {
            super(ctx);
            setBackgroundColor(Color.rgb(30, 30, 30));
            setFocusable(true);
            setFocusableInTouchMode(true);
            initBoard();
        }

        private void initBoard() {
            board = new int[8][8];
            board[0] = new int[]{-2,-3,-4,-5,-6,-4,-3,-2};
            board[1] = new int[]{-1,-1,-1,-1,-1,-1,-1,-1};
            board[6] = new int[]{1,1,1,1,1,1,1,1};
            board[7] = new int[]{2,3,4,5,6,4,3,2};
            whiteTurn = true;
            gameOver = false;
            selectedRow = -1;
            selectedCol = -1;
        }

        @Override
        protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            float cellSize = Math.min(getWidth(), getHeight()) / 8f;
            float offX = (getWidth() - cellSize * 8) / 2f;
            float offY = (getHeight() - cellSize * 8) / 2f;

            for (int r = 0; r < 8; r++) {
                for (int c = 0; c < 8; c++) {
                    float x = offX + c * cellSize, y = offY + r * cellSize;
                    paint.setColor((r + c) % 2 == 0 ? Color.rgb(240, 217, 181) : Color.rgb(181, 136, 99));
                    canvas.drawRect(x, y, x + cellSize, y + cellSize, paint);

                    if (r == selectedRow && c == selectedCol) {
                        paint.setColor(Color.argb(120, 255, 255, 0));
                        canvas.drawRect(x, y, x + cellSize, y + cellSize, paint);
                    }

                    int piece = board[r][c];
                    if (piece != 0) {
                        paint.setColor(piece > 0 ? Color.WHITE : Color.BLACK);
                        paint.setShadowLayer(3, 1, 1, Color.GRAY);
                        paint.setTextSize(cellSize * 0.7f);
                        paint.setTextAlign(Paint.Align.CENTER);
                        String symbol = getPieceSymbol(piece);
                        canvas.drawText(symbol, x + cellSize / 2, y + cellSize / 2 + cellSize * 0.25f, paint);
                        paint.setShadowLayer(0, 0, 0, 0);
                    }
                }
            }
        }

        private String getPieceSymbol(int piece) {
            String[] symbols = {"", "♟","♜","♞","♝","♛","♚"};
            int idx = Math.abs(piece);
            return idx < symbols.length ? symbols[idx] : "?";
        }

        @Override
        public boolean onTouchEvent(MotionEvent event) {
            if (event.getAction() != MotionEvent.ACTION_DOWN || gameOver) {
                if (gameOver) { initBoard(); invalidate(); }
                return true;
            }
            float cellSize = Math.min(getWidth(), getHeight()) / 8f;
            float offX = (getWidth() - cellSize * 8) / 2f;
            float offY = (getHeight() - cellSize * 8) / 2f;
            int col = (int) ((event.getX() - offX) / cellSize);
            int row = (int) ((event.getY() - offY) / cellSize);
            if (col < 0 || col >= 8 || row < 0 || row >= 8) return true;

            if (selectedRow == -1) {
                if (board[row][col] != 0 && (board[row][col] > 0) == whiteTurn) {
                    selectedRow = row;
                    selectedCol = col;
                    AppLogger.log(getContext(), "Chess", "Selected: " + row + "," + col);
                }
            } else {
                if (isValidMove(selectedRow, selectedCol, row, col)) {
                    int piece = board[selectedRow][selectedCol];
                    board[row][col] = piece;
                    board[selectedRow][selectedCol] = 0;
                    
                    // Проверка на превращение пешки
                    if (Math.abs(piece) == 1 && (row == 0 || row == 7)) {
                        board[row][col] = piece > 0 ? 5 : -5;
                    }
                    
                    selectedRow = -1;
                    selectedCol = -1;
                    whiteTurn = !whiteTurn;
                    invalidate();

                    // Проверка на мат
                    if (isKingCaptured()) {
                        gameOver = true;
                        String winner = whiteTurn ? "Чёрные" : "Белые";
                        AppLogger.log(getContext(), "Chess", "Game over! Winner: " + winner);
                        showGameOverDialog(winner);
                    } else if (!whiteTurn) {
                        postDelayed(new Runnable() {
                            @Override
                            public void run() { makeAIMove(); }
                        }, 300);
                    }
                } else if (board[row][col] != 0 && (board[row][col] > 0) == whiteTurn) {
                    selectedRow = row;
                    selectedCol = col;
                } else {
                    selectedRow = -1;
                    selectedCol = -1;
                }
            }
            invalidate();
            return true;
        }

        private boolean isKingCaptured() {
            boolean whiteKing = false, blackKing = false;
            for (int r = 0; r < 8; r++) {
                for (int c = 0; c < 8; c++) {
                    if (board[r][c] == 6) whiteKing = true;
                    if (board[r][c] == -6) blackKing = true;
                }
            }
            return !whiteKing || !blackKing;
        }

        private void showGameOverDialog(String winner) {
            post(new Runnable() {
                @Override
                public void run() {
                    new AlertDialog.Builder(ChessActivity.this)
                        .setTitle("♟️ Игра окончена!")
                        .setMessage("🏆 Победили: " + winner + "!\n\nНажмите OK для новой игры.")
                        .setCancelable(false)
                        .setPositiveButton("Новая игра", new DialogInterface.OnClickListener() {
                            @Override public void onClick(DialogInterface d, int w) {
                                initBoard();
                                invalidate();
                            }
                        })
                        .show();
                }
            });
        }

        private boolean isValidMove(int fromR, int fromC, int toR, int toC) {
            int piece = board[fromR][fromC];
            if (piece == 0) return false;
            // Нельзя сьесть свою
            if (board[toR][toC] != 0 && (board[toR][toC] > 0) == (piece > 0)) return false;
            
            int absPiece = Math.abs(piece);
            int dir = piece > 0 ? -1 : 1;
            
            // Пешка
            if (absPiece == 1) {
                // Ход вперёд на 1
                if (fromC == toC && board[toR][toC] == 0 && toR - fromR == dir) return true;
                // Ход вперёд на 2 с начальной позиции
                int startRow = piece > 0 ? 6 : 1;
                if (fromC == toC && board[toR][toC] == 0 && fromR == startRow && toR - fromR == 2 * dir) {
                    int midRow = (fromR + toR) / 2;
                    if (board[midRow][fromC] == 0) return true;
                }
                // Атака по диагонали
                if (Math.abs(fromC - toC) == 1 && toR - fromR == dir && board[toR][toC] != 0) return true;
                return false;
            }
            
            // Ладья
            if (absPiece == 2) {
                if (fromR == toR) {
                    return checkStraightPath(fromR, fromC, toR, toC, true);
                }
                if (fromC == toC) {
                    return checkStraightPath(fromR, fromC, toR, toC, false);
                }
                return false;
            }
            
            // Конь
            if (absPiece == 3) {
                int dr = Math.abs(fromR - toR), dc = Math.abs(fromC - toC);
                return (dr == 2 && dc == 1) || (dr == 1 && dc == 2);
            }
            
            // Слон
            if (absPiece == 4) {
                if (Math.abs(fromR - toR) == Math.abs(fromC - toC)) {
                    return checkDiagonalPath(fromR, fromC, toR, toC);
                }
                return false;
            }
            
            // Ферзь
            if (absPiece == 5) {
                if (fromR == toR) return checkStraightPath(fromR, fromC, toR, toC, true);
                if (fromC == toC) return checkStraightPath(fromR, fromC, toR, toC, false);
                if (Math.abs(fromR - toR) == Math.abs(fromC - toC)) return checkDiagonalPath(fromR, fromC, toR, toC);
                return false;
            }
            
            // Король
            if (absPiece == 6) {
                return Math.abs(fromR - toR) <= 1 && Math.abs(fromC - toC) <= 1;
            }
            
            return false;
        }

        private boolean checkStraightPath(int fromR, int fromC, int toR, int toC, boolean horizontal) {
            if (horizontal) {
                int minC = Math.min(fromC, toC), maxC = Math.max(fromC, toC);
                for (int c = minC + 1; c < maxC; c++) {
                    if (board[fromR][c] != 0) return false;
                }
            } else {
                int minR = Math.min(fromR, toR), maxR = Math.max(fromR, toR);
                for (int r = minR + 1; r < maxR; r++) {
                    if (board[r][fromC] != 0) return false;
                }
            }
            return true;
        }

        private boolean checkDiagonalPath(int fromR, int fromC, int toR, int toC) {
            int dr = Integer.signum(toR - fromR);
            int dc = Integer.signum(toC - fromC);
            int r = fromR + dr, c = fromC + dc;
            while (r != toR && c != toC) {
                if (board[r][c] != 0) return false;
                r += dr; c += dc;
            }
            return true;
        }

        private void makeAIMove() {
            if (gameOver) return;
            List<int[]> moves = new ArrayList<>();
            for (int r = 0; r < 8; r++) {
                for (int c = 0; c < 8; c++) {
                    if (board[r][c] < 0) {
                        for (int tr = 0; tr < 8; tr++) {
                            for (int tc = 0; tc < 8; tc++) {
                                if (isValidMove(r, c, tr, tc)) {
                                    moves.add(new int[]{r, c, tr, tc});
                                }
                            }
                        }
                    }
                }
            }
            if (!moves.isEmpty()) {
                int[] move = moves.get(r.nextInt(moves.size()));
                int piece = board[move[0]][move[1]];
                board[move[2]][move[3]] = piece;
                board[move[0]][move[1]] = 0;
                
                if (Math.abs(piece) == 1 && (move[2] == 0 || move[2] == 7)) {
                    board[move[2]][move[3]] = piece > 0 ? 5 : -5;
                }
                
                whiteTurn = true;
                AppLogger.log(getContext(), "Chess", "AI moved: " + move[0]+","+move[1] + " → " + move[2]+","+move[3]);
                
                if (isKingCaptured()) {
                    gameOver = true;
                    AppLogger.log(getContext(), "Chess", "Game over! Winner: White");
                    showGameOverDialog("Белые");
                }
                invalidate();
            } else {
                String winner = whiteTurn ? "Белые" : "Чёрные";
                gameOver = true;
                AppLogger.log(getContext(), "Chess", "No moves! Winner: " + winner);
                showGameOverDialog(winner);
            }
        }
    }
}