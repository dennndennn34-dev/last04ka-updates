package com.last04ka.messenger.ui;

import android.app.Activity;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.media.AudioFormat;
import android.media.AudioManager;
import android.media.AudioTrack;
import android.os.Bundle;
import android.os.Handler;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import com.last04ka.messenger.utils.AppLogger;
import com.last04ka.messenger.utils.GameScores;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class SpaceShooterActivity extends Activity {

    private GameView gameView;
    private TextView scoreText, livesText, waveText;
    private int score = 0, lives = 3, wave = 1;
    private Handler handler = new Handler();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        try {
            AppLogger.log(this, "SpaceShooter", "onCreate started");
            LinearLayout layout = new LinearLayout(this);
            layout.setOrientation(LinearLayout.VERTICAL);
            layout.setBackgroundColor(Color.BLACK);

            LinearLayout stats = new LinearLayout(this);
            stats.setOrientation(LinearLayout.HORIZONTAL);
            stats.setGravity(Gravity.CENTER);
            stats.setPadding(8, 4, 8, 4);

            scoreText = new TextView(this);
            scoreText.setText("Счёт: 0"); scoreText.setTextSize(13);
            scoreText.setTextColor(0xFFFFD740); stats.addView(scoreText);

            livesText = new TextView(this);
            livesText.setText("  ❤❤❤"); livesText.setTextSize(13);
            livesText.setTextColor(0xFFFF5252); stats.addView(livesText);

            waveText = new TextView(this);
            waveText.setText("  Волна 1"); waveText.setTextSize(13);
            waveText.setTextColor(0xFF4FC3F7); stats.addView(waveText);

            layout.addView(stats);
            gameView = new GameView(this);
            layout.addView(gameView);

            setContentView(layout);
            setTitle("🚀 Космо-стрелялка");
            AppLogger.log(this, "SpaceShooter", "onCreate completed");
        } catch (Exception e) { AppLogger.logException(this, "SpaceShooter", e); finish(); }
    }

    class GameView extends View {
        private Paint paint = new Paint();
        private Random rand = new Random();

        private float shipX, shipY, shipW = 60, shipH = 80;
        private List<Bullet> bullets = new ArrayList<>();
        private List<Enemy> enemies = new ArrayList<>();
        private List<Explosion> explosions = new ArrayList<>();

        private long lastShot = 0;
        private int waveEnemyCount = 5;
        private boolean gameOver = false;
        private boolean running = false;
        private boolean waveSpawning = false; // флаг: волна уже в процессе спавна
        private float touchX = -1;

        public GameView(Context ctx) {
            super(ctx);
            setFocusable(true);
            setFocusableInTouchMode(true);
        }

        @Override
        protected void onSizeChanged(int w, int h, int oldw, int oldh) {
            super.onSizeChanged(w, h, oldw, oldh);
            shipX = w/2f - shipW/2;
            shipY = h - shipH - 30;
            spawnWave();
        }

        private void spawnWave() {
            enemies.clear();
            bullets.clear();
            waveSpawning = true;
            int count = waveEnemyCount + (wave-1)*2;
            if (count > 60) count = 60; // ОГРАНИЧЕНИЕ: максимум 60 врагов
            for (int i = 0; i < count; i++) {
                enemies.add(new Enemy(rand.nextFloat()*(getWidth()-60), -rand.nextFloat()*300,
                    45+rand.nextInt(20), 1.5f+wave*0.3f, wave >= 5 && rand.nextFloat() < 0.25f));
            }
            AppLogger.log(SpaceShooterActivity.this, "SpaceShooter", "Wave " + wave + " spawned, enemies=" + count);
            handler.post(() -> waveText.setText("  Волна " + wave));
            waveSpawning = false;
        }

        @Override
        protected void onDraw(Canvas c) {
            super.onDraw(c);
            int w = getWidth(), h = getHeight();
            paint.setColor(0xFF0A0A1A); c.drawRect(0,0,w,h,paint);

            // Звёзды
            paint.setColor(0x88FFFFFF);
            rand.setSeed(42);
            for (int i = 0; i < 80; i++) c.drawCircle(rand.nextFloat()*w, rand.nextFloat()*h, rand.nextFloat()*2, paint);

            // Враги
            for (Enemy e : enemies) {
                paint.setColor(e.tough ? 0xFFFF5722 : 0xFFE53935);
                c.drawRoundRect(e.x, e.y, e.x+e.size, e.y+e.size, 8, 8, paint);
                paint.setColor(0xFFFFEB3B);
                c.drawCircle(e.x+e.size/2, e.y+e.size/2, e.size*0.2f, paint);
            }

            // Пули
            paint.setColor(0xFF00E5FF);
            for (Bullet b : bullets) c.drawRoundRect(b.x, b.y, b.x+b.w, b.y+b.h, 4, 4, paint);

            // Корабль
            paint.setColor(0xFF4FC3F7);
            float cx = shipX + shipW/2;
            c.drawRect(shipX+10, shipY+shipH*0.3f, shipX+shipW-10, shipY+shipH, paint);
            paint.setColor(0xFF81D4FA);
            c.drawRect(shipX+20, shipY, shipX+shipW-20, shipY+shipH*0.4f, paint);
            paint.setColor(0xFFFFEB3B);
            c.drawCircle(cx, shipY+shipH*0.5f, 10, paint);

            // Взрывы
            for (Explosion ex : explosions) {
                paint.setColor(0xFFFF9800);
                paint.setAlpha(ex.alpha);
                c.drawCircle(ex.x, ex.y, ex.size, paint);
            }
            paint.setAlpha(255);

            if (gameOver) {
                paint.setColor(0xAA000000); c.drawRect(0,0,w,h,paint);
                paint.setColor(Color.WHITE); paint.setTextSize(40); paint.setTextAlign(Paint.Align.CENTER);
                c.drawText("Game Over", w/2, h/2, paint);
                paint.setTextSize(22); c.drawText("Счёт: "+score+" | Волна: "+wave, w/2, h/2+35, paint);
                c.drawText("Тап для рестарта", w/2, h/2+60, paint);
                paint.setTextAlign(Paint.Align.LEFT);
            }
        }

        public void update() {
            if (gameOver || !running) return;
            int w = getWidth();

            // Движение корабля
            if (touchX >= 0) shipX = Math.max(0, Math.min(w-shipW, touchX - shipW/2));

            // Пули
            long now = System.currentTimeMillis();
            if (now - lastShot > 300 && touchX >= 0) {
                bullets.add(new Bullet(shipX+shipW/2-4, shipY-20, 8, 22));
                lastShot = now;
            }
            for (int i = bullets.size()-1; i >= 0; i--) {
                Bullet b = bullets.get(i);
                b.y -= 15;
                if (b.y < -30) bullets.remove(i);
            }

            // Враги
            for (int i = enemies.size()-1; i >= 0; i--) {
                Enemy e = enemies.get(i);
                e.y += e.speed;
                if (e.y > getHeight() + 50) { enemies.remove(i); continue; }

                // Столкновение с кораблём
                if (e.y+e.size > shipY && e.y < shipY+shipH && e.x+e.size > shipX && e.x < shipX+shipW) {
                    enemies.remove(i);
                    hitPlayer();
                    continue;
                }

                // Столкновение с пулями
                for (int j = bullets.size()-1; j >= 0; j--) {
                    Bullet b = bullets.get(j);
                    if (b.x+b.w > e.x && b.x < e.x+e.size && b.y < e.y+e.size && b.y+b.h > e.y) {
                        bullets.remove(j);
                        if (e.tough) {
                            e.tough = false;
                        } else {
                            explosions.add(new Explosion(e.x+e.size/2, e.y+e.size/2, 10));
                            enemies.remove(i);
                            score += 10;
                            handler.post(() -> scoreText.setText("Счёт: " + score));
                        }
                        break;
                    }
                }
            }

            // Взрывы
            for (int i = explosions.size()-1; i >= 0; i--) {
                Explosion ex = explosions.get(i);
                ex.size += 2; ex.alpha -= 12;
                if (ex.alpha <= 0) explosions.remove(i);
            }

            // Проверка волны — ТОЛЬКО если не в процессе спавна и врагов нет
            if (!waveSpawning && enemies.isEmpty()) {
                wave++;
                waveSpawning = true;
                handler.postDelayed(() -> spawnWave(), 1000);
            }
        }

        private void hitPlayer() {
            lives--;
            explosions.add(new Explosion(shipX+shipW/2, shipY+shipH/2, 20));
            handler.post(() -> {
                StringBuilder sb = new StringBuilder("  ");
                for (int i = 0; i < lives; i++) sb.append("❤");
                livesText.setText(sb.toString());
            });
            AppLogger.log(SpaceShooterActivity.this, "SpaceShooter", "Hit! Lives=" + lives);
            if (lives <= 0) {
                gameOver = true;
                GameScores.saveScore(SpaceShooterActivity.this, "spaceshooter", score);
                AppLogger.log(SpaceShooterActivity.this, "SpaceShooter", "Game over, score=" + score + " wave=" + wave);
            }
        }

        @Override
        public boolean onTouchEvent(MotionEvent e) {
            if (gameOver) {
                score = 0; lives = 3; wave = 1; waveEnemyCount = 5;
                enemies.clear(); bullets.clear(); explosions.clear();
                gameOver = false; waveSpawning = false;
                spawnWave();
                handler.post(() -> { scoreText.setText("Счёт: 0"); livesText.setText("  ❤❤❤"); waveText.setText("  Волна 1"); });
                AppLogger.log(SpaceShooterActivity.this, "SpaceShooter", "Game restarted");
                return true;
            }
            touchX = e.getX();
            if (e.getAction() == MotionEvent.ACTION_UP) touchX = -1;
            return true;
        }

        @Override
        protected void onAttachedToWindow() { super.onAttachedToWindow(); running = true;
            new Thread(() -> { while(running) { try { Thread.sleep(16); update(); postInvalidate(); } catch(Exception ex){break;} } }).start(); }
        @Override
        protected void onDetachedFromWindow() { super.onDetachedFromWindow(); running = false; }
    }

    static class Bullet { float x, y, w, h; Bullet(float x, float y, float w, float h) { this.x=x; this.y=y; this.w=w; this.h=h; } }
    static class Enemy { float x, y, size, speed; boolean tough; Enemy(float x, float y, float s, float sp, boolean t) { this.x=x; this.y=y; this.size=s; this.speed=sp; this.tough=t; } }
    static class Explosion { float x, y, size; int alpha=200; Explosion(float x, float y, float s) { this.x=x; this.y=y; this.size=s; } }

    @Override
    protected void onDestroy() { super.onDestroy(); handler.removeCallbacksAndMessages(null); }
}