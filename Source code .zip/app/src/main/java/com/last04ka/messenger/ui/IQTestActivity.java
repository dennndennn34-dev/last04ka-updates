package com.last04ka.messenger.ui;

import android.app.Activity;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import com.last04ka.messenger.utils.AppLogger;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Random;

public class IQTestActivity extends Activity {

    private TextView questionText, timerText, progressText;
    private Button[] btns = new Button[5];
    private int current = 0, score = 0, total = 20;
    private List<String[]> pool = new ArrayList<>(), selected = new ArrayList<>();
    private CountDownTimer timer;
    private Random r = new Random();
    private boolean finished = false;

    private String[][] data = {
        {"Какое число лишнее?","2","4","6","7","8","3"},
        {"Продолжите: 1, 1, 2, 3, 5, ...","6","7","8","9","10","2"},
        {"Сколько секунд в часе?","60","600","3600","3660","7200","2"},
        {"Если 3 кошки ловят 3 мышей за 3 минуты, сколько кошек поймают 100 мышей за 100 минут?","1","3","33","100","300","1"},
        {"Какое слово лишнее?","Кошка","Собака","Корова","Стол","Лошадь","3"},
        {"Сколько будет 15% от 200?","15","20","25","30","35","3"},
        {"Если перевернуть 9, что получится?","6","8","0","9","Ничего","0"},
        {"Какая буква следующая: А, В, Д, Ё, ...?","Ж","З","И","Й","К","2"},
        {"Сколько месяцев имеют 28 дней?","1","2","6","12","Все","4"},
        {"Что тяжелее: килограмм пуха или килограмм железа?","Пух","Железо","Одинаково","Зависит","Нельзя сравнить","2"},
        {"Если 2+3=10, 3+4=21, то 4+5=?","25","32","36","40","45","2"},
        {"Сколько букв в английском алфавите?","24","26","28","30","33","1"},
        {"Какая планета третья от Солнца?","Марс","Венера","Земля","Юпитер","Сатурн","2"},
        {"Если A=1, B=2, C=3, то чему равно Z?","24","25","26","27","28","2"},
        {"Сколько будет 2¹⁰?","256","512","1024","2048","4096","2"},
        {"Какая из этих фигур не является четырёхугольником?","Квадрат","Ромб","Треугольник","Трапеция","Прямоугольник","2"},
        {"Какое число следующее: 3, 6, 12, 24, ...?","30","36","42","48","50","3"},
        {"Если все A это B, и все B это C, то все A это C. Это:","Ложно","Истинно","Не всегда","Зависит","Нельзя сказать","1"},
        {"Какая страна не граничит с Россией?","Китай","Норвегия","Франция","Монголия","КНДР","2"},
        {"Сколько будет 11×11?","111","121","131","144","100","1"},
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        try {
            AppLogger.log(this, "IQTest", "onCreate started");
            LinearLayout layout = new LinearLayout(this);
            layout.setOrientation(LinearLayout.VERTICAL);
            layout.setPadding(24, 24, 24, 24);
            layout.setBackgroundColor(0xFF1A1A2E);

            timerText = new TextView(this);
            timerText.setText("⏱ 20:00");
            timerText.setTextSize(20); timerText.setTextColor(0xFFFF5252);
            timerText.setGravity(android.view.Gravity.CENTER);
            layout.addView(timerText);

            progressText = new TextView(this);
            progressText.setText("Вопрос 0/" + total);
            progressText.setTextSize(14); progressText.setTextColor(0xFFBDBDBD);
            progressText.setGravity(android.view.Gravity.CENTER);
            progressText.setPadding(0, 8, 0, 16);
            layout.addView(progressText);

            questionText = new TextView(this);
            questionText.setTextSize(17); questionText.setTextColor(0xFFFFFFFF);
            questionText.setPadding(0, 16, 0, 16);
            layout.addView(questionText);

            for (int i = 0; i < 5; i++) {
                final int idx = i;
                btns[i] = new Button(this);
                btns[i].setTextSize(14); btns[i].setAllCaps(false);
                btns[i].setPadding(8, 12, 8, 12);
                btns[i].setOnClickListener(new View.OnClickListener() {
                    @Override public void onClick(View v) { checkAnswer(idx); }
                });
                layout.addView(btns[i]);
            }

            pool.addAll(Arrays.asList(data));
            Collections.shuffle(pool, r);
            for (int i = 0; i < Math.min(total, pool.size()); i++) selected.add(pool.get(i));

            // Таймер 20 минут
            timer = new CountDownTimer(1200000, 1000) {
                @Override public void onTick(long millis) {
                    long min = millis / 60000, sec = (millis / 1000) % 60;
                    timerText.setText(String.format("⏱ %d:%02d", min, sec));
                }
                @Override public void onFinish() {
                    if (!finished) showResult();
                }
            }.start();

            setContentView(layout);
            setTitle("🧠 IQ тест");
            showQuestion();
            AppLogger.log(this, "IQTest", "onCreate completed");
        } catch (Exception e) { AppLogger.logException(this, "IQTest", e); finish(); }
    }

    private void showQuestion() {
        if (current >= selected.size()) { showResult(); return; }
        String[] q = selected.get(current);
        questionText.setText("Вопрос " + (current + 1) + ": " + q[0]);
        for (int i = 0; i < 5; i++) btns[i].setText(q[i + 1]);
        progressText.setText("Вопрос " + (current + 1) + "/" + total);
    }

    private void checkAnswer(int idx) {
        if (finished) return;
        String[] q = selected.get(current);
        int correct = Integer.parseInt(q[6]);
        if (idx == correct) score++;
        current++;
        showQuestion();
    }

    private void showResult() {
        finished = true;
        if (timer != null) timer.cancel();
        int iq = Math.min(160, Math.max(70, 70 + score * 3));
        String level;
        if (iq < 85) level = "Ниже среднего";
        else if (iq < 100) level = "Средний";
        else if (iq < 115) level = "Выше среднего";
        else if (iq < 130) level = "Высокий";
        else level = "Очень высокий";

        questionText.setText("🧠 Ваш IQ: " + iq + "\nУровень: " + level + "\nПравильных ответов: " + score + "/" + total);
        for (Button b : btns) b.setVisibility(View.GONE);
        progressText.setText("Тест завершён");
        timerText.setText("⏱ --");
        AppLogger.log(this, "IQTest", "Result: " + iq + " (" + score + "/" + total + ")");
    }
}