package com.last04ka.messenger.ui;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import com.last04ka.messenger.utils.AppLogger;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Random;

public class FlagsQuizActivity extends Activity {

    private TextView questionText, scoreText;
    private Button[] answerButtons = new Button[4];
    private int current = 0, score = 0, total = 20;
    private List<String[]> pool = new ArrayList<>();
    private List<String[]> selected = new ArrayList<>();
    private Random r = new Random();

    private String[][] data = {
        {"🇷🇺", "Россия"}, {"🇺🇸", "США"}, {"🇩🇪", "Германия"}, {"🇫🇷", "Франция"},
        {"🇯🇵", "Япония"}, {"🇨🇳", "Китай"}, {"🇬🇧", "Великобритания"}, {"🇮🇹", "Италия"},
        {"🇪🇸", "Испания"}, {"🇧🇷", "Бразилия"}, {"🇨🇦", "Канада"}, {"🇦🇺", "Австралия"},
        {"🇮🇳", "Индия"}, {"🇲🇽", "Мексика"}, {"🇰🇷", "Южная Корея"}, {"🇹🇷", "Турция"},
        {"🇦🇷", "Аргентина"}, {"🇿🇦", "ЮАР"}, {"🇸🇦", "Саудовская Аравия"}, {"🇪🇬", "Египет"},
        {"🇳🇬", "Нигерия"}, {"🇰🇪", "Кения"}, {"🇲🇦", "Марокко"}, {"🇬🇭", "Гана"},
        {"🇸🇪", "Швеция"}, {"🇳🇴", "Норвегия"}, {"🇩🇰", "Дания"}, {"🇫🇮", "Финляндия"},
        {"🇵🇱", "Польша"}, {"🇺🇦", "Украина"}, {"🇨🇿", "Чехия"}, {"🇳🇱", "Нидерланды"},
        {"🇧🇪", "Бельгия"}, {"🇨🇭", "Швейцария"}, {"🇦🇹", "Австрия"}, {"🇬🇷", "Греция"},
        {"🇵🇹", "Португалия"}, {"🇮🇪", "Ирландия"}, {"🇹🇭", "Таиланд"}, {"🇻🇳", "Вьетнам"},
        {"🇮🇩", "Индонезия"}, {"🇵🇭", "Филиппины"}, {"🇲🇾", "Малайзия"}, {"🇸🇬", "Сингапур"},
        {"🇳🇿", "Новая Зеландия"}, {"🇨🇱", "Чили"}, {"🇨🇴", "Колумбия"}, {"🇵🇪", "Перу"},
        {"🇨🇺", "Куба"}, {"🇮🇱", "Израиль"},
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        try {
            LinearLayout layout = new LinearLayout(this);
            layout.setOrientation(LinearLayout.VERTICAL);
            layout.setPadding(24, 24, 24, 24);
            layout.setBackgroundColor(0xFF252525);

            scoreText = new TextView(this); scoreText.setText("Счёт: 0 / " + total);
            scoreText.setTextSize(16); scoreText.setTextColor(0xFFFFFFFF); layout.addView(scoreText);

            questionText = new TextView(this);
            questionText.setTextSize(60); questionText.setTextColor(0xFFFFFFFF);
            questionText.setGravity(android.view.Gravity.CENTER);
            questionText.setPadding(0, 24, 0, 24); layout.addView(questionText);

            for (int i = 0; i < 4; i++) {
                answerButtons[i] = new Button(this); answerButtons[i].setTextSize(16);
                answerButtons[i].setAllCaps(false); answerButtons[i].setPadding(12, 16, 12, 16);
                final int idx = i;
                answerButtons[i].setOnClickListener(new View.OnClickListener() {
                    @Override public void onClick(View v) { checkAnswer(idx); }
                });
                layout.addView(answerButtons[i]);
            }

            pool.addAll(Arrays.asList(data));
            Collections.shuffle(pool, r);
            for (int i = 0; i < Math.min(total, pool.size()); i++) selected.add(pool.get(i));

            setContentView(layout); setTitle("🏳️ Флаги мира"); showQuestion();
        } catch (Exception e) { AppLogger.logException(this, "FlagsQuiz", e); finish(); }
    }

    private void showQuestion() {
        if (current >= selected.size()) {
            questionText.setText("🏆 Итог: " + score + " / " + total);
            for (Button b : answerButtons) b.setVisibility(View.GONE);
            return;
        }
        String[] q = selected.get(current);
        questionText.setText(q[0]);
        List<String> options = new ArrayList<>();
        options.add(q[1]);
        while (options.size() < 4) {
            String[] rand = data[r.nextInt(data.length)];
            if (!options.contains(rand[1])) options.add(rand[1]);
        }
        Collections.shuffle(options, r);
        for (int i = 0; i < 4; i++) answerButtons[i].setText(options.get(i));
    }

    private void checkAnswer(int idx) {
        if (answerButtons[idx].getText().toString().equals(selected.get(current)[1])) {
            score++; Toast.makeText(this, "✅", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, "❌ " + selected.get(current)[1], Toast.LENGTH_SHORT).show();
        }
        scoreText.setText("Счёт: " + score + " / " + total);
        current++; showQuestion();
    }
}