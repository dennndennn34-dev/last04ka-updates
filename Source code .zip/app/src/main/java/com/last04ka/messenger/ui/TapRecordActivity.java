package com.last04ka.messenger.ui;

import android.app.Activity;
import android.graphics.Color;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import com.last04ka.messenger.utils.AppLogger;
import com.last04ka.messenger.utils.GameScores;

public class TapRecordActivity extends Activity {

    private TextView countText, timerText, bestText;
    private Button btnStart;
    private LinearLayout tapArea;
    private int tapCount = 0;
    private boolean running = false;
    private CountDownTimer timer;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        try {
            AppLogger.log(this, "TapRecord", "onCreate started");
            LinearLayout layout = new LinearLayout(this);
            layout.setOrientation(LinearLayout.VERTICAL);
            layout.setBackgroundColor(0xFF1A1A2E);

            timerText = new TextView(this); timerText.setText("⏱ 10.0"); timerText.setTextSize(40);
            timerText.setTextColor(0xFFFF5252); timerText.setGravity(android.view.Gravity.CENTER);
            timerText.setPadding(0, 24, 0, 8); layout.addView(timerText);

            countText = new TextView(this); countText.setText("0 нажатий"); countText.setTextSize(48);
            countText.setTextColor(0xFFFFFFFF); countText.setGravity(android.view.Gravity.CENTER);
            layout.addView(countText);

            bestText = new TextView(this);
            bestText.setText("Рекорд: " + GameScores.getScore(this, "taprecord"));
            bestText.setTextSize(16); bestText.setTextColor(0xFFBDBDBD);
            bestText.setGravity(android.view.Gravity.CENTER); bestText.setPadding(0, 0, 0, 16);
            layout.addView(bestText);

            tapArea = new LinearLayout(this);
            tapArea.setBackgroundColor(Color.rgb(33, 33, 33));
            LinearLayout.LayoutParams tp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 1);
            tapArea.setLayoutParams(tp);
            tapArea.setGravity(android.view.Gravity.CENTER);
            tapArea.setClickable(true);

            TextView tapLabel = new TextView(this); tapLabel.setText("ТАПАЙТЕ СЮДА!");
            tapLabel.setTextSize(28); tapLabel.setTextColor(0xFF00E676);
            tapArea.addView(tapLabel);
            tapArea.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) {
                    if (running) { tapCount++; countText.setText(tapCount + " нажатий"); }
                }
            });
            layout.addView(tapArea);

            btnStart = new Button(this); btnStart.setText("Начать (10 секунд)");
            btnStart.setTextSize(18);
            btnStart.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) { startGame(); }
            });
            layout.addView(btnStart);

            setContentView(layout); setTitle("👆 Тап-рекорд");
            AppLogger.log(this, "TapRecord", "onCreate completed");
        } catch (Exception e) { AppLogger.logException(this, "TapRecord", e); finish(); }
    }

    private void startGame() {
        tapCount = 0; countText.setText("0 нажатий"); running = true; btnStart.setEnabled(false);
        timer = new CountDownTimer(10000, 100) {
            @Override public void onTick(long millis) { timerText.setText("⏱ " + (millis / 1000.0)); }
            @Override public void onFinish() {
                timerText.setText("⏱ 0.0"); running = false; btnStart.setEnabled(true);
                GameScores.saveScore(TapRecordActivity.this, "taprecord", tapCount);
                bestText.setText("Рекорд: " + GameScores.getScore(TapRecordActivity.this, "taprecord"));
                Toast.makeText(TapRecordActivity.this, "Готово! " + tapCount + " нажатий", Toast.LENGTH_LONG).show();
                AppLogger.log(TapRecordActivity.this, "TapRecord", "Result: " + tapCount);
            }
        }.start();
    }
}