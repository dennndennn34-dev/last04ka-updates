package com.last04ka.messenger.utils;

import android.content.ContentResolver;
import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import android.os.Environment;
import android.provider.MediaStore;
import android.provider.OpenableColumns;
import android.util.Base64;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class FileTransferManager {

    private static final String TAG = "FileTransfer";
    private static final int MAX_FILE_SIZE_BYTES = 20 * 1024 * 1024; // 20 MB
    private static final long CHUNK_SIZE = 32768; // 32 KB

    public interface FileTransferCallback {
        void onProgress(int percent);
        void onSuccess(String filePath);
        void onError(String error);
    }

    // ==================== ОТПРАВКА ФАЙЛА ====================

    public static void sendFile(Context context, String chatId, Uri fileUri,
                                FileTransferCallback callback) {
        AppLogger.log(context, TAG, "═══════════════════════════════════════════════════════════");
        AppLogger.log(context, TAG, "📤 sendFile() START");
        AppLogger.log(context, TAG, "   chatId: " + chatId);
        AppLogger.log(context, TAG, "   fileUri: " + fileUri);

        try {
            String fileName = getFileName(context, fileUri);
            long fileSize = getFileSize(context, fileUri);
            String mimeType = getMimeType(context, fileUri);

            AppLogger.log(context, TAG, "   fileName: " + fileName);
            AppLogger.log(context, TAG, "   fileSize: " + fileSize + " bytes");
            AppLogger.log(context, TAG, "   mimeType: " + mimeType);

            if (fileSize > MAX_FILE_SIZE_BYTES) {
                AppLogger.log(context, TAG, "❌ File too large: " + fileSize + " > " + MAX_FILE_SIZE_BYTES);
                callback.onError("Файл слишком большой (макс. 20 МБ)");
                return;
            }

            if (fileSize == 0) {
                AppLogger.log(context, TAG, "❌ Empty file");
                callback.onError("Файл пуст");
                return;
            }

            byte[] fileData = readFileToBytes(context, fileUri);
            if (fileData == null) {
                AppLogger.log(context, TAG, "❌ Failed to read file");
                callback.onError("Не удалось прочитать файл");
                return;
            }

            AppLogger.log(context, TAG, "📥 File read: " + fileData.length + " bytes");

            String base64Data = Base64.encodeToString(fileData, Base64.NO_WRAP);
            AppLogger.log(context, TAG, "🔐 Base64 encoded, length: " + base64Data.length());

            String localPath = saveFileLocally(context, chatId, fileName, fileData);
            AppLogger.log(context, TAG, "📁 Local file saved: " + localPath);

            String fileMessage = "FILE|" + fileName + "|" + fileSize + "|" + mimeType + "|" + base64Data;
            AppLogger.log(context, TAG, "📤 File message length: " + fileMessage.length());

            callback.onSuccess(localPath);
            AppLogger.log(context, TAG, "✅ sendFile() SUCCESS");

        } catch (Exception e) {
            AppLogger.logException(context, TAG, "❌ sendFile() error", e);
            callback.onError("Ошибка отправки: " + e.getMessage());
        }

        AppLogger.log(context, TAG, "═══════════════════════════════════════════════════════════");
    }

    // ==================== ПРИЁМ ФАЙЛА ====================

    public static void receiveFile(Context context, String chatId, String fileName,
                                   String fileSizeStr, String mimeType, String base64Data,
                                   FileTransferCallback callback) {
        AppLogger.log(context, TAG, "═══════════════════════════════════════════════════════════");
        AppLogger.log(context, TAG, "📥 receiveFile() START");
        AppLogger.log(context, TAG, "   chatId: " + chatId);
        AppLogger.log(context, TAG, "   fileName: " + fileName);
        AppLogger.log(context, TAG, "   fileSize: " + fileSizeStr);
        AppLogger.log(context, TAG, "   mimeType: " + mimeType);
        AppLogger.log(context, TAG, "   base64 length: " + base64Data.length());

        try {
            byte[] fileData = Base64.decode(base64Data, Base64.DEFAULT);
            AppLogger.log(context, TAG, "📥 Decoded: " + fileData.length + " bytes");

            long expectedSize = Long.parseLong(fileSizeStr);
            if (fileData.length != expectedSize) {
                AppLogger.log(context, TAG, "⚠️ Size mismatch: " + fileData.length + " vs " + expectedSize);
            }

            String localPath = saveFileLocally(context, chatId, fileName, fileData);
            AppLogger.log(context, TAG, "📁 File saved: " + localPath);

            callback.onSuccess(localPath);
            AppLogger.log(context, TAG, "✅ receiveFile() SUCCESS");

        } catch (Exception e) {
            AppLogger.logException(context, TAG, "❌ receiveFile() error", e);
            callback.onError("Ошибка приёма: " + e.getMessage());
        }

        AppLogger.log(context, TAG, "═══════════════════════════════════════════════════════════");
    }

    // ==================== ВСПОМОГАТЕЛЬНЫЕ МЕТОДЫ ====================

    public static String getFileName(Context context, Uri uri) {
        AppLogger.log(context, TAG, "📝 getFileName() called for URI: " + uri);

        String result = null;
        if (uri.getScheme() != null && uri.getScheme().equals("content")) {
            try (Cursor cursor = context.getContentResolver().query(uri, null, null, null, null)) {
                if (cursor != null && cursor.moveToFirst()) {
                    int nameIndex = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                    if (nameIndex != -1) {
                        result = cursor.getString(nameIndex);
                        AppLogger.log(context, TAG, "   ContentResolver name: " + result);
                    }
                }
            } catch (Exception e) {
                AppLogger.logException(context, TAG, "   ContentResolver error", e);
            }
        }

        if (result == null) {
            result = uri.getLastPathSegment();
            if (result == null) result = "file_" + System.currentTimeMillis();
            AppLogger.log(context, TAG, "   Fallback name: " + result);
        }

        return result;
    }

    public static long getFileSize(Context context, Uri uri) {
        AppLogger.log(context, TAG, "📏 getFileSize() called");

        long size = 0;
        if (uri.getScheme() != null && uri.getScheme().equals("content")) {
            try (Cursor cursor = context.getContentResolver().query(uri, null, null, null, null)) {
                if (cursor != null && cursor.moveToFirst()) {
                    int sizeIndex = cursor.getColumnIndex(OpenableColumns.SIZE);
                    if (sizeIndex != -1) {
                        size = cursor.getLong(sizeIndex);
                        AppLogger.log(context, TAG, "   ContentResolver size: " + size);
                    }
                }
            } catch (Exception e) {
                AppLogger.logException(context, TAG, "   ContentResolver error", e);
            }
        }

        if (size == 0) {
            try {
                File file = new File(uri.getPath());
                size = file.length();
                AppLogger.log(context, TAG, "   File size: " + size);
            } catch (Exception e) {
                AppLogger.logException(context, TAG, "   File size error", e);
            }
        }

        return size;
    }

    public static String getMimeType(Context context, Uri uri) {
        String mime = context.getContentResolver().getType(uri);
        if (mime == null) {
            String name = getFileName(context, uri);
            if (name != null) {
                String ext = name.substring(name.lastIndexOf('.') + 1).toLowerCase();
                mime = getMimeFromExtension(ext);
            }
        }
        if (mime == null) mime = "application/octet-stream";
        AppLogger.log(context, TAG, "📋 Mime type: " + mime);
        return mime;
    }

    private static String getMimeFromExtension(String ext) {
        switch (ext) {
            case "jpg": case "jpeg": return "image/jpeg";
            case "png": return "image/png";
            case "gif": return "image/gif";
            case "bmp": return "image/bmp";
            case "webp": return "image/webp";
            case "mp4": return "video/mp4";
            case "avi": return "video/avi";
            case "mkv": return "video/x-matroska";
            case "mp3": return "audio/mpeg";
            case "wav": return "audio/wav";
            case "ogg": return "audio/ogg";
            case "pdf": return "application/pdf";
            case "doc": return "application/msword";
            case "docx": return "application/vnd.openxmlformats-officedocument.wordprocessingml.document";
            case "xls": return "application/vnd.ms-excel";
            case "xlsx": return "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
            case "txt": return "text/plain";
            case "zip": return "application/zip";
            case "rar": return "application/x-rar-compressed";
            case "apk": return "application/vnd.android.package-archive";
            default: return null;
        }
    }

    // ==================== PUBLIC STATIC МЕТОДЫ (исправлено) ====================
    public static byte[] readFileToBytes(Context context, Uri uri) throws Exception {
        AppLogger.log(context, TAG, "📖 readFileToBytes() START");

        try (InputStream is = context.getContentResolver().openInputStream(uri);
             ByteArrayOutputStream baos = new ByteArrayOutputStream()) {

            if (is == null) {
                AppLogger.log(context, TAG, "❌ InputStream is null");
                return null;
            }

            byte[] buffer = new byte[8192];
            int totalRead = 0;
            int bytesRead;
            long startTime = System.currentTimeMillis();

            while ((bytesRead = is.read(buffer)) != -1) {
                baos.write(buffer, 0, bytesRead);
                totalRead += bytesRead;
            }

            long elapsed = System.currentTimeMillis() - startTime;
            AppLogger.log(context, TAG, "   Read " + totalRead + " bytes in " + elapsed + "ms");
            AppLogger.log(context, TAG, "📖 readFileToBytes() END");

            return baos.toByteArray();
        }
    }

    public static String saveFileLocally(Context context, String chatId, String fileName, byte[] data) {
        AppLogger.log(context, TAG, "💾 saveFileLocally() START");
        AppLogger.log(context, TAG, "   chatId: " + chatId);
        AppLogger.log(context, TAG, "   fileName: " + fileName);
        AppLogger.log(context, TAG, "   data size: " + data.length);

        try {
            File baseDir = new File(context.getFilesDir(), "chat_files");
            if (!baseDir.exists()) {
                baseDir.mkdirs();
                AppLogger.log(context, TAG, "📁 Created base directory: " + baseDir.getAbsolutePath());
            }

            File chatDir = new File(baseDir, chatId);
            if (!chatDir.exists()) {
                chatDir.mkdirs();
                AppLogger.log(context, TAG, "📁 Created chat directory: " + chatDir.getAbsolutePath());
            }

            File file = new File(chatDir, fileName);
            if (file.exists()) {
                String nameWithoutExt = fileName.substring(0, fileName.lastIndexOf('.'));
                String ext = fileName.substring(fileName.lastIndexOf('.'));
                String timestamp = new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(new Date());
                String newFileName = nameWithoutExt + "_" + timestamp + ext;
                file = new File(chatDir, newFileName);
                AppLogger.log(context, TAG, "   File exists, renamed to: " + newFileName);
            }

            try (FileOutputStream fos = new FileOutputStream(file)) {
                fos.write(data);
                fos.flush();
            }

            AppLogger.log(context, TAG, "✅ File saved: " + file.getAbsolutePath());
            AppLogger.log(context, TAG, "   File size: " + file.length() + " bytes");

            return file.getAbsolutePath();

        } catch (Exception e) {
            AppLogger.logException(context, TAG, "❌ saveFileLocally error", e);
            return null;
        }
    }

    public static boolean isImageFile(String mimeType) {
        return mimeType != null && mimeType.startsWith("image/");
    }

    public static boolean isVideoFile(String mimeType) {
        return mimeType != null && mimeType.startsWith("video/");
    }

    public static boolean isAudioFile(String mimeType) {
        return mimeType != null && mimeType.startsWith("audio/");
    }

    public static String getFileIcon(String mimeType) {
        if (mimeType == null) return "📄";
        if (mimeType.startsWith("image/")) return "🖼️";
        if (mimeType.startsWith("video/")) return "🎬";
        if (mimeType.startsWith("audio/")) return "🎵";
        if (mimeType.equals("application/pdf")) return "📄";
        if (mimeType.equals("application/msword") || mimeType.contains("word")) return "📝";
        if (mimeType.contains("excel") || mimeType.contains("spreadsheet")) return "📊";
        if (mimeType.equals("application/zip") || mimeType.contains("compressed")) return "📦";
        if (mimeType.equals("application/vnd.android.package-archive")) return "📱";
        if (mimeType.startsWith("text/")) return "📄";
        return "📄";
    }
}