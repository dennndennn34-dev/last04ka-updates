package com.last04ka.messenger.adapters;

import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.media.MediaPlayer;
import android.net.Uri;
import android.support.v4.content.FileProvider;
import android.support.v7.widget.RecyclerView;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.last04ka.messenger.R;
import com.last04ka.messenger.data.DatabaseHelper;
import com.last04ka.messenger.data.Message;
import com.last04ka.messenger.utils.AppLogger;
import com.last04ka.messenger.utils.CircleImageView;
import com.last04ka.messenger.utils.FileTransferManager;
import com.last04ka.messenger.utils.StreakManager;
import com.last04ka.messenger.utils.ThemeManager;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class MessageAdapter extends RecyclerView.Adapter<MessageAdapter.ViewHolder> {
    private List<Message> messages;
    private OnMessageLongClickListener longClickListener;
    private OnMessageClickListener clickListener;
    private SimpleDateFormat timeFormat = new SimpleDateFormat("HH:mm", Locale.getDefault());
    private SimpleDateFormat fullDateFormat = new SimpleDateFormat("dd.MM.yyyy HH:mm:ss", Locale.getDefault());
    private DatabaseHelper dbHelper;
    private String chatId;
    private float fontSize = 15f;
    private MediaPlayer currentPlayer = null;

    public interface OnMessageLongClickListener {
        void onMessageLongClick(Message message);
    }

    public interface OnMessageClickListener {
        void onMessageClick(Message message);
    }

    public MessageAdapter(List<Message> messages,
                          OnMessageLongClickListener longListener,
                          OnMessageClickListener clickListener) {
        this.messages = messages;
        this.longClickListener = longListener;
        this.clickListener = clickListener;
    }

    public MessageAdapter(List<Message> messages, OnMessageLongClickListener longListener) {
        this.messages = messages;
        this.longClickListener = longListener;
        this.clickListener = null;
    }

    public void setFontSize(float size) {
        this.fontSize = size;
        notifyDataSetChanged();
    }

    public void setChatId(String chatId) {
        this.chatId = chatId;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_message, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {
        Message msg = messages.get(position);
        Context ctx = holder.itemView.getContext();

        AppLogger.log(ctx, "MessageAdapter", "onBindViewHolder: position=" + position + ", hasFile=" + msg.hasFile() + ", isVoice=" + msg.isVoice());

        if (dbHelper == null) {
            dbHelper = new DatabaseHelper(ctx);
        }

        holder.messageText.setTextSize(fontSize);

        // ========== ОТОБРАЖЕНИЕ ФАЙЛОВ ==========
        if (msg.hasFile()) {
            String fileIcon = FileTransferManager.getFileIcon(msg.getMimeType());
            String fileName = msg.getFileName() != null ? msg.getFileName() : "Файл";
            String fileSize = formatFileSize(msg.getFileSize());

            AppLogger.log(ctx, "MessageAdapter", "📎 File message: " + fileName + " (" + fileSize + ")");

            holder.messageText.setText(fileIcon + " " + fileName);

            // Показываем информацию о файле
            holder.fileInfoLayout.setVisibility(View.VISIBLE);
            holder.tvFileIcon.setText(fileIcon);
            holder.tvFileName.setText(fileName);
            holder.tvFileSize.setText("(" + fileSize + ")");

            // Кнопка открытия файла
            holder.btnOpenFile.setVisibility(View.VISIBLE);
            holder.btnOpenFile.setOnClickListener(v -> {
                AppLogger.log(ctx, "MessageAdapter", "📂 Open file button clicked: " + msg.getFilePath());
                if (msg.getFilePath() != null) {
                    File file = new File(msg.getFilePath());
                    if (file.exists()) {
                        openFile(ctx, file, msg.getMimeType());
                    } else {
                        Toast.makeText(ctx, "Файл не найден", Toast.LENGTH_SHORT).show();
                        AppLogger.log(ctx, "MessageAdapter", "❌ File not found: " + msg.getFilePath());
                    }
                } else {
                    Toast.makeText(ctx, "Путь к файлу не указан", Toast.LENGTH_SHORT).show();
                    AppLogger.log(ctx, "MessageAdapter", "❌ File path is null");
                }
            });

            // Скрываем кнопку голосового
            holder.btnPlayVoice.setVisibility(View.GONE);
            holder.btnPlayVoice.setOnClickListener(null);

        } else if (msg.isVoice()) {
            String durationText = formatDuration(msg.getDuration());
            holder.messageText.setText("🎤 " + durationText);
            holder.btnPlayVoice.setVisibility(View.VISIBLE);
            holder.btnPlayVoice.setImageResource(android.R.drawable.ic_media_play);
            holder.btnPlayVoice.setOnClickListener(v -> {
                AppLogger.log(ctx, "MessageAdapter", "▶️ Play button clicked for voice message: " + msg.getId());
                playVoiceMessage(msg, holder);
            });
            holder.fileInfoLayout.setVisibility(View.GONE);
            holder.btnOpenFile.setVisibility(View.GONE);

        } else {
            // Обычное текстовое сообщение
            holder.messageText.setText(msg.getText());
            holder.fileInfoLayout.setVisibility(View.GONE);
            holder.btnOpenFile.setVisibility(View.GONE);
            holder.btnPlayVoice.setVisibility(View.GONE);
            holder.btnPlayVoice.setOnClickListener(null);
        }

        holder.timeText.setText(timeFormat.format(new Date(msg.getTimestamp())));

        int sentColor = ThemeManager.getBubbleSentColor(ctx);
        int receivedColor = ThemeManager.getBubbleReceivedColor(ctx);
        boolean isDark = ThemeManager.isDarkTheme(ctx);

        GradientDrawable bubbleBg = new GradientDrawable();

        // ========== АВАТАРКА С ОБОДКОМ ==========
        int streakDays = StreakManager.getStreakDays(ctx);
        String ringColor = StreakManager.getRingColor(streakDays);
        int ringColorInt = Color.parseColor(ringColor);

        if (msg.isSent()) {
            holder.ivAvatar.setVisibility(View.GONE);
            holder.container.setGravity(Gravity.END);
            bubbleBg.setColor(sentColor);
            bubbleBg.setCornerRadii(new float[]{16, 16, 4, 16, 16, 16, 16, 16});
            holder.messageText.setTextColor(0xFF212121);
            holder.timeText.setTextColor(0xFF424242);
        } else {
            String avatarPath = null;
            if (dbHelper != null && chatId != null) {
                avatarPath = dbHelper.getChatAvatar(chatId);
            }
            if (avatarPath != null && !avatarPath.isEmpty()) {
                File avatarFile = new File(avatarPath);
                if (avatarFile.exists()) {
                    Bitmap bm = BitmapFactory.decodeFile(avatarPath);
                    if (bm != null) {
                        holder.ivAvatar.setImageBitmap(bm);
                        holder.ivAvatar.setVisibility(View.VISIBLE);
                        holder.ivAvatar.setBorderColor(ringColorInt);
                        holder.ivAvatar.setBorderWidth(4);
                    } else {
                        holder.ivAvatar.setVisibility(View.GONE);
                    }
                } else {
                    holder.ivAvatar.setVisibility(View.GONE);
                }
            } else {
                holder.ivAvatar.setVisibility(View.GONE);
            }

            holder.container.setGravity(Gravity.START);
            bubbleBg.setColor(receivedColor);
            bubbleBg.setCornerRadii(new float[]{16, 16, 16, 4, 16, 16, 16, 16});
            if (isDark) {
                holder.messageText.setTextColor(0xFFFFFFFF);
                holder.timeText.setTextColor(0xFFBDBDBD);
            } else {
                holder.messageText.setTextColor(0xFF212121);
                holder.timeText.setTextColor(0xFF757575);
            }
        }

        holder.messageContainer.setBackground(bubbleBg);

        // Клик для полной даты
        holder.itemView.setOnClickListener(v -> {
            if (clickListener != null) {
                clickListener.onMessageClick(msg);
            } else {
                String fullDate = fullDateFormat.format(new Date(msg.getTimestamp()));
                new AlertDialog.Builder(ctx)
                        .setTitle("Дата сообщения")
                        .setMessage(fullDate)
                        .setPositiveButton("OK", null)
                        .show();
            }
        });

        holder.itemView.setOnLongClickListener(v -> {
            if (longClickListener != null) {
                longClickListener.onMessageLongClick(msg);
            }
            return true;
        });
    }

    private String formatDuration(int seconds) {
        if (seconds <= 0) return "0:00";
        int mins = seconds / 60;
        int secs = seconds % 60;
        return mins + ":" + String.format(Locale.getDefault(), "%02d", secs);
    }

    private String formatFileSize(long size) {
        if (size < 1024) return size + " B";
        if (size < 1024 * 1024) return String.format("%.1f KB", size / 1024.0);
        if (size < 1024 * 1024 * 1024) return String.format("%.1f MB", size / (1024.0 * 1024));
        return String.format("%.1f GB", size / (1024.0 * 1024 * 1024));
    }

    private void openFile(Context context, File file, String mimeType) {
        AppLogger.log(context, "MessageAdapter", "📂 openFile() called: " + file.getAbsolutePath());
        try {
            Uri uri = FileProvider.getUriForFile(context,
                    context.getPackageName() + ".provider",
                    file);
            Intent intent = new Intent(Intent.ACTION_VIEW);
            intent.setDataAndType(uri, mimeType != null ? mimeType : "application/octet-stream");
            intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            context.startActivity(intent);
            AppLogger.log(context, "MessageAdapter", "✅ File opened: " + file.getName());
        } catch (Exception e) {
            AppLogger.logException(context, "MessageAdapter", "❌ Open file error", e);
            Toast.makeText(context, "Не удалось открыть файл: " + e.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }

    private void playVoiceMessage(Message msg, ViewHolder holder) {
        String path = msg.getVoicePath();
        AppLogger.log(null, "MessageAdapter", "▶️ playVoiceMessage: path=" + path);

        if (path == null || path.isEmpty()) {
            AppLogger.log(null, "MessageAdapter", "❌ Voice path is null or empty");
            Toast.makeText(holder.itemView.getContext(), "Путь к файлу отсутствует", Toast.LENGTH_SHORT).show();
            return;
        }

        File file = new File(path);
        if (!file.exists()) {
            AppLogger.log(null, "MessageAdapter", "❌ Voice file does not exist: " + path);
            Toast.makeText(holder.itemView.getContext(), "Файл не найден", Toast.LENGTH_SHORT).show();
            return;
        }

        AppLogger.log(null, "MessageAdapter", "✅ Voice file exists, size=" + file.length() + " bytes");

        if (currentPlayer != null) {
            try {
                currentPlayer.stop();
                currentPlayer.release();
                currentPlayer = null;
                AppLogger.log(null, "MessageAdapter", "⏹️ Previous player stopped");
            } catch (Exception e) {
                AppLogger.logException(null, "MessageAdapter", "Error stopping player", e);
            }
        }

        try {
            currentPlayer = new MediaPlayer();
            currentPlayer.setDataSource(path);
            currentPlayer.prepare();
            AppLogger.log(null, "MessageAdapter", "✅ MediaPlayer prepared, duration=" + currentPlayer.getDuration() + " ms");

            holder.btnPlayVoice.setImageResource(android.R.drawable.ic_media_pause);
            AppLogger.log(null, "MessageAdapter", "▶️ Starting playback");

            currentPlayer.start();
            currentPlayer.setOnCompletionListener(mp -> {
                AppLogger.log(null, "MessageAdapter", "⏹️ Playback completed");
                holder.btnPlayVoice.setImageResource(android.R.drawable.ic_media_play);
                currentPlayer = null;
                mp.release();
            });

            currentPlayer.setOnErrorListener((mp, what, extra) -> {
                AppLogger.log(null, "MessageAdapter", "❌ MediaPlayer error: what=" + what + ", extra=" + extra);
                holder.btnPlayVoice.setImageResource(android.R.drawable.ic_media_play);
                currentPlayer = null;
                mp.release();
                Toast.makeText(holder.itemView.getContext(), "Ошибка воспроизведения", Toast.LENGTH_SHORT).show();
                return true;
            });

        } catch (IOException e) {
            AppLogger.logException(null, "MessageAdapter", "❌ MediaPlayer prepare error", e);
            Toast.makeText(holder.itemView.getContext(), "Ошибка воспроизведения: " + e.getMessage(), Toast.LENGTH_SHORT).show();
            holder.btnPlayVoice.setImageResource(android.R.drawable.ic_media_play);
        } catch (Exception e) {
            AppLogger.logException(null, "MessageAdapter", "❌ Unexpected error", e);
            Toast.makeText(holder.itemView.getContext(), "Ошибка: " + e.getMessage(), Toast.LENGTH_SHORT).show();
            holder.btnPlayVoice.setImageResource(android.R.drawable.ic_media_play);
        }
    }

    @Override
    public int getItemCount() {
        return messages.size();
    }

    static class ViewHolder extends RecyclerView.ViewHolder {
        LinearLayout container, messageContainer;
        TextView messageText, timeText;
        CircleImageView ivAvatar;
        ImageButton btnPlayVoice;

        // ========== НОВЫЕ ПОЛЯ ДЛЯ ФАЙЛОВ ==========
        LinearLayout fileInfoLayout;
        TextView tvFileIcon, tvFileName, tvFileSize;
        Button btnOpenFile;

        ViewHolder(View itemView) {
            super(itemView);
            container = itemView.findViewById(R.id.message_container);
            messageContainer = itemView.findViewById(R.id.message_bubble);
            messageText = itemView.findViewById(R.id.message_text);
            timeText = itemView.findViewById(R.id.message_time);
            ivAvatar = itemView.findViewById(R.id.iv_avatar);
            btnPlayVoice = itemView.findViewById(R.id.btn_play_voice);

            // ========== ИНИЦИАЛИЗАЦИЯ ПОЛЕЙ ДЛЯ ФАЙЛОВ ==========
            fileInfoLayout = itemView.findViewById(R.id.file_info_layout);
            tvFileIcon = itemView.findViewById(R.id.tv_file_icon);
            tvFileName = itemView.findViewById(R.id.tv_file_name);
            tvFileSize = itemView.findViewById(R.id.tv_file_size);
            btnOpenFile = itemView.findViewById(R.id.btn_open_file);
        }
    }
}