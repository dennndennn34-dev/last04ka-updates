package com.last04ka.messenger.ui;

import android.Manifest;
import android.content.pm.PackageManager;
import android.media.AudioFormat;
import android.media.AudioManager;
import android.media.AudioRecord;
import android.media.AudioTrack;
import android.media.MediaRecorder;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Vibrator;
import android.support.annotation.NonNull;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.util.Base64;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.last04ka.messenger.R;
import com.last04ka.messenger.utils.AppLogger;
import com.last04ka.messenger.utils.ThemeManager;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class CallActivity extends android.app.Activity {
    private static final String TAG = "CallActivity";
    private static final int REQUEST_RECORD_AUDIO = 200;
    
    private static final int SAMPLE_RATE = 8000;
    private static final int CHANNEL_CONFIG = AudioFormat.CHANNEL_IN_MONO;
    private static final int AUDIO_FORMAT = AudioFormat.ENCODING_PCM_16BIT;
    private static final int AUDIO_BUFFER_SIZE = AudioRecord.getMinBufferSize(SAMPLE_RATE, CHANNEL_CONFIG, AUDIO_FORMAT);
    
    private TextView tvStatus, tvCallDuration;
    private Button btnEndCall, btnMuteMic, btnSpeaker;
    private String targetAddress;
    private String targetName;
    private boolean isInitiator;
    private boolean isCallActive = false;
    private boolean isMicMuted = false;
    private boolean isSpeakerOn = false;
    
    private ExecutorService executor;
    private Handler mainHandler;
    private boolean isRunning = false;
    
    private AudioRecord audioRecord;
    private AudioTrack audioTrack;
    private Vibrator vibrator;
    
    private long callStartTime;
    private Handler timerHandler;
    private Runnable timerRunnable;
    
    private StringBuilder audioBuffer = new StringBuilder();
    private final Object bufferLock = new Object();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        setTheme(ThemeManager.getThemeResource(this));
        super.onCreate(savedInstanceState);
        AppLogger.log(this, TAG, "📞 CallActivity onCreate START");
        
        try {
            setContentView(R.layout.activity_call);
            
            getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
            
            tvStatus = findViewById(R.id.tv_call_status);
            tvCallDuration = findViewById(R.id.tv_call_duration);
            btnEndCall = findViewById(R.id.btn_end_call);
            btnMuteMic = findViewById(R.id.btn_mute_mic);
            btnSpeaker = findViewById(R.id.btn_speaker);
            
            targetAddress = getIntent().getStringExtra("target_address");
            targetName = getIntent().getStringExtra("target_name");
            isInitiator = getIntent().getBooleanExtra("is_initiator", false);
            
            AppLogger.log(this, TAG, "targetAddress=" + targetAddress + ", targetName=" + targetName + ", isInitiator=" + isInitiator);
            
            vibrator = (Vibrator) getSystemService(VIBRATOR_SERVICE);
            mainHandler = new Handler(Looper.getMainLooper());
            executor = Executors.newFixedThreadPool(3);
            timerHandler = new Handler(Looper.getMainLooper());
            
            BluetoothChatActivity.setActiveCallActivity(this);
            
            if (targetName != null) {
                tvStatus.setText("Звонок с: " + targetName);
            }
            
            btnEndCall.setOnClickListener(v -> endCall());
            btnMuteMic.setOnClickListener(v -> toggleMute());
            btnSpeaker.setOnClickListener(v -> toggleSpeaker());
            
            if (vibrator != null && vibrator.hasVibrator()) {
                vibrator.vibrate(300);
                AppLogger.log(this, TAG, "Vibration started");
            }
            
            checkPermissions();
            
        } catch (Exception e) {
            AppLogger.logException(this, TAG, "onCreate error", e);
            finish();
        }
    }
    
    private void checkPermissions() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
                != PackageManager.PERMISSION_GRANTED) {
            AppLogger.log(this, TAG, "RECORD_AUDIO permission not granted, requesting...");
            ActivityCompat.requestPermissions(this,
                new String[]{Manifest.permission.RECORD_AUDIO},
                REQUEST_RECORD_AUDIO);
        } else {
            AppLogger.log(this, TAG, "RECORD_AUDIO permission granted");
            startCall();
        }
    }
    
    private void startCall() {
        AppLogger.log(this, TAG, "startCall() called");
        isRunning = true;
        isCallActive = true;
        
        AudioManager audioManager = (AudioManager) getSystemService(AUDIO_SERVICE);
        if (audioManager != null) {
            audioManager.setMode(AudioManager.MODE_IN_COMMUNICATION);
            AppLogger.log(this, TAG, "Audio mode set to MODE_IN_COMMUNICATION");
        }
        
        startAudioCapture();
        startAudioPlayback();
        startCallTimer();
        
        tvStatus.setText("В звонке с: " + targetName);
        AppLogger.log(this, TAG, "Call started successfully");
    }
    
    private void startAudioCapture() {
        AppLogger.log(this, TAG, "startAudioCapture() called");
        executor.execute(() -> {
            try {
                int bufferSize = Math.max(AUDIO_BUFFER_SIZE * 2, 2048);
                AppLogger.log(CallActivity.this, TAG, "Audio capture buffer size: " + bufferSize);
                
                audioRecord = new AudioRecord(MediaRecorder.AudioSource.VOICE_COMMUNICATION, SAMPLE_RATE,
                    CHANNEL_CONFIG, AUDIO_FORMAT, bufferSize);
                audioRecord.startRecording();
                
                if (audioRecord.getRecordingState() != AudioRecord.RECORDSTATE_RECORDING) {
                    AppLogger.log(CallActivity.this, TAG, "ERROR: Recording state is not RECORDING");
                    return;
                }
                AppLogger.log(CallActivity.this, TAG, "AudioRecord started successfully");
                
                byte[] buffer = new byte[bufferSize];
                
                while (isRunning && audioRecord != null) {
                    int bytesRead = audioRecord.read(buffer, 0, buffer.length);
                    if (bytesRead > 0 && !isMicMuted && isCallActive) {
                        String audioBase64 = Base64.encodeToString(buffer, 0, bytesRead, Base64.NO_WRAP);
                        BluetoothChatActivity.sendCallResponse("AUDIO_DATA|" + audioBase64);
                    }
                    Thread.sleep(20);
                }
                AppLogger.log(CallActivity.this, TAG, "Audio capture loop ended");
            } catch (Exception e) {
                AppLogger.logException(CallActivity.this, TAG, "Audio capture error", e);
            }
        });
    }
    
    private void startAudioPlayback() {
        AppLogger.log(this, TAG, "startAudioPlayback() called");
        executor.execute(() -> {
            try {
                int bufferSize = Math.max(AUDIO_BUFFER_SIZE * 2, 2048);
                AppLogger.log(CallActivity.this, TAG, "Audio playback buffer size: " + bufferSize);
                
                audioTrack = new AudioTrack(AudioManager.STREAM_VOICE_CALL, SAMPLE_RATE,
                    AudioFormat.CHANNEL_OUT_MONO, AUDIO_FORMAT, bufferSize, AudioTrack.MODE_STREAM);
                audioTrack.play();
                
                AppLogger.log(CallActivity.this, TAG, "AudioTrack created and playing");
                
                while (isRunning && audioTrack != null) {
                    synchronized (bufferLock) {
                        if (audioBuffer.length() > 0) {
                            String data = audioBuffer.toString();
                            audioBuffer.setLength(0);
                            try {
                                byte[] audioData = Base64.decode(data, Base64.DEFAULT);
                                if (audioTrack.getPlayState() == AudioTrack.PLAYSTATE_PLAYING) {
                                    audioTrack.write(audioData, 0, audioData.length);
                                }
                            } catch (Exception e) {
                                AppLogger.logException(CallActivity.this, TAG, "Audio decode error", e);
                            }
                        }
                    }
                    Thread.sleep(10);
                }
                AppLogger.log(CallActivity.this, TAG, "Audio playback loop ended");
            } catch (Exception e) {
                AppLogger.logException(CallActivity.this, TAG, "Audio playback error", e);
            }
        });
    }
    
    public void playAudioData(byte[] audioData) {
        if (!isCallActive || audioData == null || audioData.length == 0) {
            return;
        }
        
        synchronized (bufferLock) {
            audioBuffer.append(Base64.encodeToString(audioData, Base64.NO_WRAP));
        }
    }
    
    private void startCallTimer() {
        callStartTime = System.currentTimeMillis();
        timerRunnable = new Runnable() {
            @Override
            public void run() {
                if (isCallActive) {
                    long duration = (System.currentTimeMillis() - callStartTime) / 1000;
                    long minutes = duration / 60;
                    long seconds = duration % 60;
                    String timeStr = String.format("%02d:%02d", minutes, seconds);
                    tvCallDuration.setText(timeStr);
                    timerHandler.postDelayed(this, 1000);
                }
            }
        };
        timerHandler.post(timerRunnable);
        AppLogger.log(this, TAG, "Call timer started");
    }
    
    private void toggleMute() {
        isMicMuted = !isMicMuted;
        btnMuteMic.setText(isMicMuted ? "🔇" : "🎤");
        AppLogger.log(this, TAG, "Mic muted: " + isMicMuted);
        Toast.makeText(this, isMicMuted ? "Микрофон выключен" : "Микрофон включен", Toast.LENGTH_SHORT).show();
    }
    
    private void toggleSpeaker() {
        isSpeakerOn = !isSpeakerOn;
        btnSpeaker.setText(isSpeakerOn ? "🔊" : "📱");
        AudioManager audioManager = (AudioManager) getSystemService(AUDIO_SERVICE);
        if (isSpeakerOn) {
            audioManager.setMode(AudioManager.MODE_NORMAL);
            audioManager.setSpeakerphoneOn(true);
            AppLogger.log(this, TAG, "Speaker ON");
        } else {
            audioManager.setSpeakerphoneOn(false);
            audioManager.setMode(AudioManager.MODE_IN_COMMUNICATION);
            AppLogger.log(this, TAG, "Speaker OFF");
        }
    }
    
    private void endCall() {
        AppLogger.log(this, TAG, "endCall() called");
        isRunning = false;
        isCallActive = false;
        
        if (timerHandler != null && timerRunnable != null) {
            timerHandler.removeCallbacks(timerRunnable);
        }
        
        if (audioRecord != null) {
            try {
                audioRecord.stop();
                audioRecord.release();
                AppLogger.log(this, TAG, "AudioRecord stopped and released");
            } catch (Exception e) {
                AppLogger.logException(this, TAG, "AudioRecord release error", e);
            }
            audioRecord = null;
        }
        
        if (audioTrack != null) {
            try {
                audioTrack.stop();
                audioTrack.release();
                AppLogger.log(this, TAG, "AudioTrack stopped and released");
            } catch (Exception e) {
                AppLogger.logException(this, TAG, "AudioTrack release error", e);
            }
            audioTrack = null;
        }
        
        AudioManager audioManager = (AudioManager) getSystemService(AUDIO_SERVICE);
        if (audioManager != null) {
            audioManager.setSpeakerphoneOn(false);
            audioManager.setMode(AudioManager.MODE_NORMAL);
            AppLogger.log(this, TAG, "Audio settings restored");
        }
        
        if (executor != null) {
            executor.shutdownNow();
            AppLogger.log(this, TAG, "Executor shut down");
        }
        
        if (targetAddress != null) {
            BluetoothChatActivity.sendCallResponse("CALL_END|" + targetAddress);
            AppLogger.log(this, TAG, "CALL_END signal sent");
        }
        
        BluetoothChatActivity.setActiveCallActivity(null);
        
        if (vibrator != null && vibrator.hasVibrator()) {
            vibrator.vibrate(200);
        }
        
        AppLogger.log(this, TAG, "Call ended");
        finish();
    }
    
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions,
                                           @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        AppLogger.log(this, TAG, "onRequestPermissionsResult: requestCode=" + requestCode);
        if (requestCode == REQUEST_RECORD_AUDIO) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                AppLogger.log(this, TAG, "Permission granted");
                startCall();
            } else {
                AppLogger.log(this, TAG, "Permission denied");
                Toast.makeText(this, "Необходимо разрешение на микрофон", Toast.LENGTH_LONG).show();
                finish();
            }
        }
    }
    
    @Override
    protected void onDestroy() {
        super.onDestroy();
        AppLogger.log(this, TAG, "onDestroy called");
        if (isCallActive) {
            endCall();
        }
    }
}