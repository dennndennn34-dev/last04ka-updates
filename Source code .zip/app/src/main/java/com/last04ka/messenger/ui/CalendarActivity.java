package com.last04ka.messenger.ui;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import com.last04ka.messenger.utils.AppLogger;
import java.util.Calendar;

public class CalendarActivity extends Activity {

    private TextView monthYearText;
    private LinearLayout daysGrid;
    private Calendar cal = Calendar.getInstance();
    private TextView noteText;
    private String[] dayNotes = new String[32];

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        try {
            LinearLayout layout = new LinearLayout(this);
            layout.setOrientation(LinearLayout.VERTICAL);
            layout.setPadding(16, 16, 16, 16);
            layout.setBackgroundColor(0xFF1A1A2E);

            // Заголовок с месяцем
            LinearLayout header = new LinearLayout(this);
            header.setOrientation(LinearLayout.HORIZONTAL);
            header.setGravity(android.view.Gravity.CENTER);

            Button prev = new Button(this); prev.setText("◀");
            prev.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) { cal.add(Calendar.MONTH, -1); updateCalendar(); }
            });
            header.addView(prev);

            monthYearText = new TextView(this);
            monthYearText.setTextSize(20); monthYearText.setTextColor(0xFFFFFFFF);
            monthYearText.setGravity(android.view.Gravity.CENTER);
            monthYearText.setPadding(32, 0, 32, 0);
            header.addView(monthYearText);

            Button next = new Button(this); next.setText("▶");
            next.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) { cal.add(Calendar.MONTH, 1); updateCalendar(); }
            });
            header.addView(next);
            layout.addView(header);

            // Дни недели
            LinearLayout weekDays = new LinearLayout(this);
            String[] wd = {"Вс","Пн","Вт","Ср","Чт","Пт","Сб"};
            for (String d : wd) {
                TextView tv = new TextView(this);
                tv.setText(d); tv.setTextColor(0xFFBDBDBD); tv.setTextSize(12);
                tv.setGravity(android.view.Gravity.CENTER);
                tv.setLayoutParams(new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1));
                weekDays.addView(tv);
            }
            layout.addView(weekDays);

            // Сетка дней
            daysGrid = new LinearLayout(this);
            daysGrid.setOrientation(LinearLayout.VERTICAL);
            layout.addView(daysGrid);

            // Заметка на выбранный день
            noteText = new TextView(this);
            noteText.setText("Выберите день");
            noteText.setTextColor(0xFFBDBDBD);
            noteText.setPadding(0, 16, 0, 8);
            layout.addView(noteText);

            final EditText noteInput = new EditText(this);
            noteInput.setHint("Заметка на день...");
            noteInput.setTextColor(0xFFFFFFFF); noteInput.setHintTextColor(0xFF757575);
            layout.addView(noteInput);

            Button saveNote = new Button(this); saveNote.setText("Сохранить заметку");
            saveNote.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) {
                    int day = cal.get(Calendar.DAY_OF_MONTH);
                    dayNotes[day] = noteInput.getText().toString();
                    Toast.makeText(CalendarActivity.this, "Заметка сохранена на " + day + " число", Toast.LENGTH_SHORT).show();
                    updateCalendar();
                }
            });
            layout.addView(saveNote);

            setContentView(layout);
            setTitle("📅 Календарь");
            updateCalendar();
        } catch (Exception e) { AppLogger.logException(this, "Calendar", e); finish(); }
    }

    private void updateCalendar() {
        monthYearText.setText(String.format("%tB %tY", cal, cal));
        daysGrid.removeAllViews();

        Calendar c = (Calendar) cal.clone();
        c.set(Calendar.DAY_OF_MONTH, 1);
        int firstDay = c.get(Calendar.DAY_OF_WEEK) - 1;
        int daysInMonth = c.getActualMaximum(Calendar.DAY_OF_MONTH);

        int day = 1;
        for (int row = 0; row < 6 && day <= daysInMonth; row++) {
            LinearLayout weekRow = new LinearLayout(this);
            for (int col = 0; col < 7; col++) {
                TextView tv = new TextView(this);
                tv.setGravity(android.view.Gravity.CENTER);
                tv.setPadding(4, 8, 4, 8);
                tv.setTextSize(14);
                tv.setLayoutParams(new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1));

                if ((row == 0 && col < firstDay) || day > daysInMonth) {
                    tv.setText("");
                } else {
                    tv.setText(String.valueOf(day));
                    tv.setTextColor(0xFFFFFFFF);

                    // Подсветка сегодня
                    Calendar today = Calendar.getInstance();
                    if (day == today.get(Calendar.DAY_OF_MONTH) &&
                        cal.get(Calendar.MONTH) == today.get(Calendar.MONTH) &&
                        cal.get(Calendar.YEAR) == today.get(Calendar.YEAR)) {
                        tv.setBackgroundColor(0xFF1565C0);
                    }

                    // Заметка
                    if (dayNotes[day] != null && !dayNotes[day].isEmpty()) {
                        tv.setBackgroundColor(0xFF2E7D32);
                    }

                    final int d = day;
                    tv.setOnClickListener(new View.OnClickListener() {
                        @Override public void onClick(View v) {
                            cal.set(Calendar.DAY_OF_MONTH, d);
                            noteText.setText("День " + d + ": " + (dayNotes[d] != null ? dayNotes[d] : "нет заметки"));
                        }
                    });
                    day++;
                }
                weekRow.addView(tv);
            }
            daysGrid.addView(weekRow);
        }
    }
}