package com.last04ka.messenger.game;

import android.content.Context;
import android.content.SharedPreferences;

import com.last04ka.messenger.utils.AppLogger;

public class LevelManager {
    private static final String PREFS = "ball_game_progress";
    private static final String KEY_UNLOCKED_LEVEL = "unlocked_level";
    private static final String KEY_STARS = "stars_";

    public static int getUnlockedLevel(Context context) {
        SharedPreferences prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        return prefs.getInt(KEY_UNLOCKED_LEVEL, 1);
    }

    public static void setUnlockedLevel(Context context, int level) {
        SharedPreferences prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        prefs.edit().putInt(KEY_UNLOCKED_LEVEL, level).apply();
        AppLogger.log(context, "LevelManager", "Unlocked level set to " + level);
    }

    public static int getStarsForLevel(Context context, int level) {
        SharedPreferences prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        return prefs.getInt(KEY_STARS + level, 0);
    }

    public static void setStarsForLevel(Context context, int level, int stars) {
        SharedPreferences prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        prefs.edit().putInt(KEY_STARS + level, stars).apply();
        AppLogger.log(context, "LevelManager", "Stars for level " + level + " set to " + stars);
    }
}