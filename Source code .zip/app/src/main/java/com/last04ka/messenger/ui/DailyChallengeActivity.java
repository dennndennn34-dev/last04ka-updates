package com.last04ka.messenger.ui;

import android.app.Activity;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.last04ka.messenger.utils.AchievementManager;
import com.last04ka.messenger.utils.AppLogger;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.Random;

public class DailyChallengeActivity extends Activity {

    private TextView challengeText, statusText;
    private Button btnComplete;
    private String currentChallenge = "";
    private int challengeIndex = 0;
    private boolean completed = false;

    private String[] challenges = {
        "Сыграйте в Змейку и наберите 5+ очков",
        "Сыграйте в Тетрис и наберите 100+ очков",
        "Выиграйте 1 раз в Сапёра",
        "Наберите 200+ очков в 2048",
        "Сыграйте в Кости 5 раз",
        "Наберите 100+ очков в Тайминге",
        "Сыграйте в Пинг-понг и наберите 50+ очков",
        "Выиграйте в Крестики-нолики",
        "Ответьте на 10+ вопросов в Викторине",
        "Сгенерируйте 3 пароля",
        "Создайте 2 QR-кода",
        "Прочитайте 5 анекдотов",
        "Получите 3 предсказания",
        "Найдите 5 слов в словаре сленга",
        "Выполните 3 конвертации валют",
        "Сгенерируйте 5 ников",
        "Сохраните 2 заметки в календаре",
        "Пройдите тест скорости печати",
        "Решите 15+ примеров в Таблице умножения",
        "Сыграйте в Цветовой тест и дойдите до 5 уровня",
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        try {
            AppLogger.log(this, "DailyChallenge", "onCreate started");
            LinearLayout layout = new LinearLayout(this);
            layout.setOrientation(LinearLayout.VERTICAL);
            layout.setPadding(24, 24, 24, 24);
            layout.setBackgroundColor(0xFF1A1A2E);

            TextView title = new TextView(this);
            title.setText("🏆 Ежедневный челлендж");
            title.setTextSize(20);
            title.setTextColor(0xFFFFFFFF);
            title.setGravity(android.view.Gravity.CENTER);
            title.setPadding(0, 0, 0, 16);
            layout.addView(title);

            statusText = new TextView(this);
            statusText.setTextSize(14);
            statusText.setTextColor(0xFFBDBDBD);
            statusText.setGravity(android.view.Gravity.CENTER);
            layout.addView(statusText);

            challengeText = new TextView(this);
            challengeText.setTextSize(18);
            challengeText.setTextColor(0xFFFFD740);
            challengeText.setGravity(android.view.Gravity.CENTER);
            challengeText.setPadding(16, 24, 16, 24);
            challengeText.setBackgroundColor(0xFF333333);
            challengeText.setMinHeight(120);
            layout.addView(challengeText);

            btnComplete = new Button(this);
            btnComplete.setText("Отметить как выполненное");
            btnComplete.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (!completed) {
                        completed = true;
                        SharedPreferences prefs = getSharedPreferences("daily_challenge", MODE_PRIVATE);
                        String today = new SimpleDateFormat("yyyyMMdd", Locale.getDefault()).format(new Date());
                        prefs.edit().putBoolean("done_" + today, true).putInt("index_" + today, challengeIndex).apply();
                        // ========== УБРАЛИ ВЫЗОВ trackAction, ТАК КАК ОН УДАЛЁН ИЗ AchievementManager ==========
                        // AchievementManager.trackAction(DailyChallengeActivity.this, "daily_done");
                        btnComplete.setText("✅ Выполнено!");
                        btnComplete.setEnabled(false);
                        Toast.makeText(DailyChallengeActivity.this, "🎉 Челлендж выполнен!", Toast.LENGTH_SHORT).show();
                        AppLogger.log(DailyChallengeActivity.this, "DailyChallenge", "Completed: " + currentChallenge);
                    }
                }
            });
            layout.addView(btnComplete);

            loadChallenge();

            setContentView(layout);
            setTitle("🏆 Ежедневный челлендж");
            AppLogger.log(this, "DailyChallenge", "onCreate completed");
        } catch (Exception e) {
            AppLogger.logException(this, "DailyChallenge", e);
            finish();
        }
    }

    private void loadChallenge() {
        SharedPreferences prefs = getSharedPreferences("daily_challenge", MODE_PRIVATE);
        String today = new SimpleDateFormat("yyyyMMdd", Locale.getDefault()).format(new Date());

        if (prefs.getBoolean("done_" + today, false)) {
            int idx = prefs.getInt("index_" + today, 0);
            currentChallenge = challenges[idx];
            challengeText.setText("Сегодняшний челлендж:\n\n" + currentChallenge);
            statusText.setText("Статус: Уже выполнено ✅");
            btnComplete.setText("✅ Выполнено!");
            btnComplete.setEnabled(false);
            completed = true;
        } else {
            int idx = new Random().nextInt(challenges.length);
            currentChallenge = challenges[idx];
            challengeIndex = idx;
            challengeText.setText("Сегодняшний челлендж:\n\n" + currentChallenge);
            statusText.setText("Статус: Не выполнено");
            btnComplete.setText("Отметить как выполненное");
            btnComplete.setEnabled(true);
            completed = false;
        }
    }
}