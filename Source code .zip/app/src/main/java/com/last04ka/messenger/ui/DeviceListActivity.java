package com.last04ka.messenger.ui;

import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Color;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import com.last04ka.messenger.R;
import com.last04ka.messenger.data.Chat;
import com.last04ka.messenger.data.DatabaseHelper;
import com.last04ka.messenger.utils.AppLogger;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.UUID;

public class DeviceListActivity extends Activity {

    public static final String EXTRA_CHAT_TYPE = "chat_type";
    public static final String EXTRA_IS_CREATE = "is_create";

    private ListView deviceList;
    private TextView emptyText;
    private Button btnScan;
    private DeviceAdapter adapter;
    private List<BluetoothDevice> devices = new ArrayList<>();
    private BluetoothAdapter bluetoothAdapter;
    private DatabaseHelper dbHelper;
    private int chatType;
    private boolean isCreate;
    private BroadcastReceiver discoveryReceiver;
    private boolean receiverRegistered = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        try {
            AppLogger.log(this, "DeviceList", "========== onCreate START ==========");
            AppLogger.logUI(this, "DeviceList", "Device list layout", true);

            setContentView(R.layout.activity_device_list);

            chatType = getIntent().getIntExtra(EXTRA_CHAT_TYPE, 1);
            isCreate = getIntent().getBooleanExtra(EXTRA_IS_CREATE, false);
            AppLogger.log(this, "DeviceList", "chatType=" + chatType + ", isCreate=" + isCreate);

            dbHelper = new DatabaseHelper(this);
            AppLogger.log(this, "DeviceList", "DatabaseHelper created");

            bluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
            AppLogger.log(this, "DeviceList", "BluetoothAdapter: " + (bluetoothAdapter != null ? "OK" : "NULL"));

            deviceList = findViewById(R.id.device_list);
            emptyText = findViewById(R.id.empty_text);
            btnScan = findViewById(R.id.btn_scan);

            // Кастомный адаптер с белым текстом и тёмным фоном
            adapter = new DeviceAdapter(this, devices);
            deviceList.setAdapter(adapter);
            deviceList.setOnItemClickListener((parent, view, position, id) -> {
                AppLogger.log(DeviceListActivity.this, "DeviceList", "Device selected: position=" + position);
                onDeviceSelected(position);
            });

            btnScan.setOnClickListener(v -> {
                AppLogger.log(DeviceListActivity.this, "DeviceList", "Scan button clicked");
                startDiscovery();
            });

            if (bluetoothAdapter == null) {
                AppLogger.log(this, "DeviceList", "ERROR: Bluetooth not supported");
                emptyText.setText("Bluetooth не поддерживается");
                emptyText.setTextColor(0xFFFF5252);
                btnScan.setEnabled(false);
                return;
            }

            if (!bluetoothAdapter.isEnabled()) {
                AppLogger.log(this, "DeviceList", "Bluetooth is disabled");
                emptyText.setText("Включите Bluetooth\nи нажмите Сканировать");
                emptyText.setTextColor(0xFFFFD740);
            }

            AppLogger.log(this, "DeviceList", "Loading paired devices...");
            try {
                Set<BluetoothDevice> paired = bluetoothAdapter.getBondedDevices();
                AppLogger.log(this, "DeviceList", "Paired devices count: " + (paired != null ? paired.size() : 0));
                if (paired != null) {
                    for (BluetoothDevice d : paired) {
                        devices.add(d);
                        AppLogger.log(this, "DeviceList", "Paired: " + (d.getName() != null ? d.getName() : "Неизвестно"));
                    }
                }
                adapter.notifyDataSetChanged();
                emptyText.setVisibility(devices.isEmpty() ? View.VISIBLE : View.GONE);
            } catch (SecurityException e) {
                AppLogger.logException(this, "DeviceList", e);
            }

            discoveryReceiver = new BroadcastReceiver() {
                @Override
                public void onReceive(Context context, Intent intent) {
                    String action = intent.getAction();
                    try {
                        if (BluetoothDevice.ACTION_FOUND.equals(action)) {
                            BluetoothDevice device = intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE);
                            if (device != null && !devices.contains(device)) {
                                devices.add(device);
                                adapter.notifyDataSetChanged();
                                emptyText.setVisibility(View.GONE);
                                AppLogger.log(DeviceListActivity.this, "DeviceList", "Found: " + (device.getName() != null ? device.getName() : "Неизвестно"));
                            }
                        } else if (BluetoothAdapter.ACTION_DISCOVERY_FINISHED.equals(action)) {
                            btnScan.setText("Сканировать");
                            btnScan.setEnabled(true);
                            AppLogger.log(DeviceListActivity.this, "DeviceList", "Discovery finished, total: " + devices.size());
                        }
                    } catch (Exception e) {
                        AppLogger.logException(DeviceListActivity.this, "DeviceList", e);
                    }
                }
            };

            AppLogger.log(this, "DeviceList", "========== onCreate END ==========");
        } catch (Exception e) {
            AppLogger.logException(this, "DeviceList", e);
            Toast.makeText(this, "Ошибка: " + e.getMessage(), Toast.LENGTH_LONG).show();
            finish();
        }
    }

    @Override
    protected void onStart() {
        super.onStart();
        AppLogger.log(this, "DeviceList", "onStart()");
        try {
            if (discoveryReceiver != null && !receiverRegistered) {
                IntentFilter filter = new IntentFilter(BluetoothDevice.ACTION_FOUND);
                filter.addAction(BluetoothAdapter.ACTION_DISCOVERY_FINISHED);
                registerReceiver(discoveryReceiver, filter);
                receiverRegistered = true;
                AppLogger.log(this, "DeviceList", "Receiver registered");
            }
        } catch (Exception e) {
            AppLogger.logException(this, "DeviceList", e);
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        AppLogger.log(this, "DeviceList", "onResume()");
        startDiscovery();
    }

    @Override
    protected void onStop() {
        super.onStop();
        AppLogger.log(this, "DeviceList", "onStop()");
        try {
            if (discoveryReceiver != null && receiverRegistered) {
                unregisterReceiver(discoveryReceiver);
                receiverRegistered = false;
            }
        } catch (Exception e) {
            AppLogger.logException(this, "DeviceList", e);
        }
    }

    private void startDiscovery() {
        AppLogger.log(this, "DeviceList", "startDiscovery()");
        if (bluetoothAdapter == null) return;
        try {
            if (bluetoothAdapter.isDiscovering()) bluetoothAdapter.cancelDiscovery();
            boolean started = bluetoothAdapter.startDiscovery();
            if (started) { btnScan.setText("Сканирование..."); btnScan.setEnabled(false); }
        } catch (SecurityException e) {
            AppLogger.logException(this, "DeviceList", e);
            Toast.makeText(this, "Нет разрешения", Toast.LENGTH_SHORT).show();
        }
    }

    private void onDeviceSelected(int position) {
        if (position < 0 || position >= devices.size()) return;
        try {
            BluetoothDevice device = devices.get(position);
            String address = device.getAddress();
            String name = device.getName() != null ? device.getName() : "Устройство";
            AppLogger.log(this, "DeviceList", "Selected: " + name);

            Chat chat = new Chat();
            chat.setId(UUID.randomUUID().toString());
            chat.setName(name);
            chat.setType(chatType);
            chat.setAddress(address);
            chat.setDeviceAddress(address);
            chat.setTimestamp(System.currentTimeMillis());
            chat.setLastTime(System.currentTimeMillis());
            dbHelper.addChat(chat);

            Intent intent = new Intent(this, BluetoothChatActivity.class);
            intent.putExtra("CHAT_ID", chat.getId());
            intent.putExtra("CHAT_NAME", name);
            intent.putExtra("DEVICE_ADDRESS", address);
            intent.putExtra("IS_SERVER", isCreate);
            startActivity(intent);
            finish();
        } catch (Exception e) {
            AppLogger.logException(this, "DeviceList", e);
            Toast.makeText(this, "Ошибка", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        try { if (discoveryReceiver != null && receiverRegistered) unregisterReceiver(discoveryReceiver); }
        catch (Exception e) {}
        if (bluetoothAdapter != null) {
            try { if (bluetoothAdapter.isDiscovering()) bluetoothAdapter.cancelDiscovery(); }
            catch (SecurityException e) {}
        }
    }

    // Кастомный адаптер с крупным белым текстом на тёмном фоне
    class DeviceAdapter extends ArrayAdapter<BluetoothDevice> {
        DeviceAdapter(Context ctx, List<BluetoothDevice> list) {
            super(ctx, android.R.layout.simple_list_item_1, list);
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            TextView tv;
            if (convertView instanceof TextView) {
                tv = (TextView) convertView;
            } else {
                tv = new TextView(DeviceListActivity.this);
                tv.setPadding(24, 18, 24, 18);
                tv.setTextSize(16);
                tv.setTextColor(0xFFFFFFFF);
                tv.setGravity(Gravity.CENTER_VERTICAL);
            }

            BluetoothDevice device = getItem(position);
            if (device != null) {
                String name = device.getName();
                String address = device.getAddress();
                if (name != null && !name.isEmpty()) {
                    tv.setText(name + "\n" + address);
                } else {
                    tv.setText("Неизвестное устройство\n" + address);
                }
            }
            return tv;
        }
    }
}