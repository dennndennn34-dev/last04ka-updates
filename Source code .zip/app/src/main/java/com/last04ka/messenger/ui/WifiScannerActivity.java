package com.last04ka.messenger.ui;

import android.Manifest;
import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.net.ConnectivityManager;
import android.net.wifi.ScanResult;
import android.net.wifi.WifiInfo;
import android.net.wifi.WifiManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.text.format.Formatter;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import com.last04ka.messenger.utils.AppLogger;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

public class WifiScannerActivity extends Activity {

    private static final int REQUEST_PERMISSION = 300;
    private static final int SCAN_TIMEOUT_MS = 15000;
    private static final int RSSI_MAX = -30;
    private static final int RSSI_MIN = -100;
    private static final int CHANNEL_2G_MIN = 2412;
    private static final int CHANNEL_2G_MAX = 2484;
    private static final int CHANNEL_5G_MIN = 5170;
    private static final int CHANNEL_5G_MAX = 5825;
    private static final int CHANNEL_6G_MIN = 5945;
    private static final int CHANNEL_6G_MAX = 7125;

    private WifiManager wifiManager;
    private TextView resultText, statusText, signalStatsText, channelInfoText, ipInfoText;
    private Button btnScan, btnRefresh, btnExport, btnFilter, btnSort;
    private ProgressBar progressBar;
    private Handler handler = new Handler(Looper.getMainLooper());
    private BroadcastReceiver wifiReceiver;
    private BroadcastReceiver wifiStateReceiver;
    private boolean isScanning = false;
    private boolean receiverRegistered = false;
    private boolean stateReceiverRegistered = false;
    private List<ScanResult> lastResults = new ArrayList<>();
    private List<ScanResult> filteredResults = new ArrayList<>();
    private String currentFilter = "all";
    private String currentSort = "signal";
    private Map<Integer, Integer> channelMap = new HashMap<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        try {
            AppLogger.log(this, "WifiScanner", "========== onCreate START ==========");
            initChannelMap();
            
            LinearLayout layout = new LinearLayout(this);
            layout.setOrientation(LinearLayout.VERTICAL);
            layout.setPadding(16, 16, 16, 16);
            layout.setBackgroundColor(0xFF1A1A2E);

            TextView title = new TextView(this);
            title.setText("📡 Wi-Fi сканер PRO");
            title.setTextSize(22);
            title.setTextColor(0xFFFFFFFF);
            title.setGravity(Gravity.CENTER);
            title.setPadding(0, 0, 0, 12);
            layout.addView(title);

            statusText = new TextView(this);
            statusText.setText("Готов к сканированию");
            statusText.setTextSize(13);
            statusText.setTextColor(0xFF4FC3F7);
            statusText.setGravity(Gravity.CENTER);
            statusText.setPadding(0, 0, 0, 8);
            layout.addView(statusText);

            signalStatsText = new TextView(this);
            signalStatsText.setTextSize(11);
            signalStatsText.setTextColor(0xFFAAAAAA);
            signalStatsText.setGravity(Gravity.CENTER);
            signalStatsText.setPadding(0, 0, 0, 4);
            layout.addView(signalStatsText);

            progressBar = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
            progressBar.setMax(100);
            progressBar.setProgress(0);
            progressBar.setVisibility(View.GONE);
            layout.addView(progressBar);

            LinearLayout btnRow1 = new LinearLayout(this);
            btnRow1.setGravity(Gravity.CENTER);
            btnRow1.setPadding(0, 0, 0, 8);
            btnRow1.setWeightSum(2);

            btnScan = new Button(this);
            btnScan.setText("🔍 Сканировать");
            btnScan.setTextSize(14);
            btnScan.setLayoutParams(new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1));
            btnScan.setOnClickListener(v -> {
                AppLogger.log(this, "WifiScanner", "Button: Scan clicked");
                startScan();
            });
            btnRow1.addView(btnScan);

            btnRefresh = new Button(this);
            btnRefresh.setText("🔄 Обновить");
            btnRefresh.setTextSize(14);
            btnRefresh.setLayoutParams(new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1));
            btnRefresh.setOnClickListener(v -> {
                AppLogger.log(this, "WifiScanner", "Button: Refresh clicked");
                refreshResults();
            });
            btnRow1.addView(btnRefresh);
            layout.addView(btnRow1);

            LinearLayout btnRow2 = new LinearLayout(this);
            btnRow2.setGravity(Gravity.CENTER);
            btnRow2.setPadding(0, 0, 0, 8);
            btnRow2.setWeightSum(3);

            btnExport = new Button(this);
            btnExport.setText("📄 Экспорт");
            btnExport.setTextSize(12);
            btnExport.setLayoutParams(new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1));
            btnExport.setOnClickListener(v -> exportResults());
            btnRow2.addView(btnExport);

            btnFilter = new Button(this);
            btnFilter.setText("🔘 Фильтр");
            btnFilter.setTextSize(12);
            btnFilter.setLayoutParams(new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1));
            btnFilter.setOnClickListener(v -> showFilterDialog());
            btnRow2.addView(btnFilter);

            btnSort = new Button(this);
            btnSort.setText("📊 Сортировка");
            btnSort.setTextSize(12);
            btnSort.setLayoutParams(new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1));
            btnSort.setOnClickListener(v -> showSortDialog());
            btnRow2.addView(btnSort);
            layout.addView(btnRow2);

            channelInfoText = new TextView(this);
            channelInfoText.setTextSize(10);
            channelInfoText.setTextColor(0xFF888888);
            channelInfoText.setPadding(8, 4, 8, 4);
            layout.addView(channelInfoText);

            ipInfoText = new TextView(this);
            ipInfoText.setTextSize(10);
            ipInfoText.setTextColor(0xFF888888);
            ipInfoText.setPadding(8, 4, 8, 4);
            layout.addView(ipInfoText);

            resultText = new TextView(this);
            resultText.setTextSize(11);
            resultText.setTextColor(0xFFFFFFFF);
            resultText.setPadding(8, 8, 8, 8);
            resultText.setBackgroundColor(0xFF0D0D1A);
            resultText.setText("Нажмите «Сканировать»\n\nДля работы Wi-Fi сканера нужно:\n1. Включить Wi-Fi\n2. Разрешить доступ к местоположению\n3. Включить геолокацию в настройках");

            ScrollView scrollView = new ScrollView(this);
            scrollView.addView(resultText);
            LinearLayout.LayoutParams svp = new LinearLayout.LayoutParams(-1, 0, 1);
            scrollView.setLayoutParams(svp);
            layout.addView(scrollView);

            setContentView(layout);
            setTitle("📡 Wi-Fi сканер PRO");

            wifiManager = (WifiManager) getApplicationContext().getSystemService(Context.WIFI_SERVICE);
            
            if (wifiManager == null) {
                AppLogger.log(this, "WifiScanner", "ERROR: WifiManager is NULL!");
                statusText.setText("Wi-Fi недоступен");
                statusText.setTextColor(0xFFFF5252);
                btnScan.setEnabled(false);
            } else {
                AppLogger.log(this, "WifiScanner", "WifiManager OK, enabled=" + wifiManager.isWifiEnabled());
                updateIPInfo();
            }

            wifiReceiver = new BroadcastReceiver() {
                @Override
                public void onReceive(Context context, Intent intent) {
                    AppLogger.log(WifiScannerActivity.this, "WifiScanner", "onReceive() called");
                    try {
                        if (intent != null) {
                            // Проверяем, обновлены ли результаты
                            if (intent.getAction().equals(WifiManager.SCAN_RESULTS_AVAILABLE_ACTION)) {
                                scanSuccess();
                            }
                        }
                    } catch (Exception e) {
                        AppLogger.logException(WifiScannerActivity.this, "WifiScanner", e);
                        scanFailure();
                    }
                }
            };

            wifiStateReceiver = new BroadcastReceiver() {
                @Override
                public void onReceive(Context context, Intent intent) {
                    int wifiState = intent.getIntExtra(WifiManager.EXTRA_WIFI_STATE, WifiManager.WIFI_STATE_UNKNOWN);
                    switch (wifiState) {
                        case WifiManager.WIFI_STATE_ENABLED:
                            AppLogger.log(WifiScannerActivity.this, "WifiScanner", "Wi-Fi enabled");
                            statusText.setText("Wi-Fi включен");
                            statusText.setTextColor(0xFF4CAF50);
                            updateIPInfo();
                            break;
                        case WifiManager.WIFI_STATE_DISABLED:
                            AppLogger.log(WifiScannerActivity.this, "WifiScanner", "Wi-Fi disabled");
                            statusText.setText("Wi-Fi выключен");
                            statusText.setTextColor(0xFFFF5252);
                            break;
                    }
                }
            };

            AppLogger.log(this, "WifiScanner", "========== onCreate END ==========");
        } catch (Exception e) {
            AppLogger.logException(this, "WifiScanner", e);
            Toast.makeText(this, "Ошибка: " + e.getMessage(), Toast.LENGTH_LONG).show();
            finish();
        }
    }

    private void initChannelMap() {
        channelMap.put(2412, 1); channelMap.put(2417, 2); channelMap.put(2422, 3);
        channelMap.put(2427, 4); channelMap.put(2432, 5); channelMap.put(2437, 6);
        channelMap.put(2442, 7); channelMap.put(2447, 8); channelMap.put(2452, 9);
        channelMap.put(2457, 10); channelMap.put(2462, 11); channelMap.put(2467, 12);
        channelMap.put(2472, 13); channelMap.put(2484, 14);
        channelMap.put(5180, 36); channelMap.put(5200, 40); channelMap.put(5220, 44);
        channelMap.put(5240, 48); channelMap.put(5260, 52); channelMap.put(5280, 56);
        channelMap.put(5300, 60); channelMap.put(5320, 64); channelMap.put(5500, 100);
        channelMap.put(5520, 104); channelMap.put(5540, 108); channelMap.put(5560, 112);
        channelMap.put(5580, 116); channelMap.put(5600, 120); channelMap.put(5620, 124);
        channelMap.put(5640, 128); channelMap.put(5660, 132); channelMap.put(5680, 136);
        channelMap.put(5700, 140); channelMap.put(5745, 149); channelMap.put(5765, 153);
        channelMap.put(5785, 157); channelMap.put(5805, 161); channelMap.put(5825, 165);
    }

    private void updateIPInfo() {
        if (wifiManager != null && wifiManager.isWifiEnabled()) {
            WifiInfo wifiInfo = wifiManager.getConnectionInfo();
            if (wifiInfo != null && wifiInfo.getIpAddress() != 0) {
                String ip = Formatter.formatIpAddress(wifiInfo.getIpAddress());
                String mac = wifiInfo.getMacAddress();
                int rssi = wifiInfo.getRssi();
                int linkSpeed = wifiInfo.getLinkSpeed();
                ipInfoText.setText(String.format("🌐 IP: %s | MAC: %s | RSSI: %d dBm | Скорость: %d Mbps",
                        ip, mac != null ? mac : "N/A", rssi, linkSpeed));
            } else {
                ipInfoText.setText("🌐 Не подключен к Wi-Fi сети");
            }
        } else {
            ipInfoText.setText("🌐 Wi-Fi выключен");
        }
    }

    @Override
    protected void onStart() {
        super.onStart();
        AppLogger.log(this, "WifiScanner", "onStart()");
        try {
            if (wifiReceiver != null && !receiverRegistered) {
                IntentFilter filter = new IntentFilter(WifiManager.SCAN_RESULTS_AVAILABLE_ACTION);
                registerReceiver(wifiReceiver, filter);
                receiverRegistered = true;
            }
            if (wifiStateReceiver != null && !stateReceiverRegistered) {
                IntentFilter stateFilter = new IntentFilter(WifiManager.WIFI_STATE_CHANGED_ACTION);
                registerReceiver(wifiStateReceiver, stateFilter);
                stateReceiverRegistered = true;
            }
            AppLogger.log(this, "WifiScanner", "Receivers registered OK");
        } catch (Exception e) {
            AppLogger.logException(this, "WifiScanner", e);
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        AppLogger.log(this, "WifiScanner", "onResume()");
        checkPermissions();
        updateIPInfo();
    }

    @Override
    protected void onStop() {
        super.onStop();
        AppLogger.log(this, "WifiScanner", "onStop()");
        try {
            if (wifiReceiver != null && receiverRegistered) {
                unregisterReceiver(wifiReceiver);
                receiverRegistered = false;
            }
            if (wifiStateReceiver != null && stateReceiverRegistered) {
                unregisterReceiver(wifiStateReceiver);
                stateReceiverRegistered = false;
            }
        } catch (Exception e) {
            AppLogger.logException(this, "WifiScanner", e);
        }
    }

    private void checkPermissions() {
        AppLogger.log(this, "WifiScanner", "Checking permissions");
        
        List<String> neededPermissions = new ArrayList<>();
        neededPermissions.add(Manifest.permission.ACCESS_FINE_LOCATION);
        
        List<String> missingPermissions = new ArrayList<>();
        for (String perm : neededPermissions) {
            if (ContextCompat.checkSelfPermission(this, perm) != PackageManager.PERMISSION_GRANTED) {
                missingPermissions.add(perm);
            }
        }
        
        if (!missingPermissions.isEmpty()) {
            ActivityCompat.requestPermissions(this, missingPermissions.toArray(new String[0]), REQUEST_PERMISSION);
        } else {
            checkLocationEnabled();
        }
    }
    
    private void checkLocationEnabled() {
        if (Build.VERSION.SDK_INT >= 28) {
            android.location.LocationManager lm = (android.location.LocationManager) getSystemService(Context.LOCATION_SERVICE);
            boolean isLocationEnabled = lm != null && lm.isLocationEnabled();
            if (!isLocationEnabled) {
                statusText.setText("Включите геолокацию для сканирования Wi-Fi");
                statusText.setTextColor(0xFFFF9800);
                Toast.makeText(this, "Для сканирования Wi-Fi необходимо включить геолокацию", Toast.LENGTH_LONG).show();
                startActivity(new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS));
            }
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQUEST_PERMISSION) {
            boolean allGranted = true;
            for (int result : grantResults) {
                if (result != PackageManager.PERMISSION_GRANTED) {
                    allGranted = false;
                    break;
                }
            }
            if (allGranted) {
                checkLocationEnabled();
            } else {
                Toast.makeText(this, "Нужны разрешения для сканирования Wi-Fi", Toast.LENGTH_LONG).show();
                statusText.setText("Нет разрешения на местоположение");
            }
        }
    }

    private void startScan() {
        AppLogger.log(this, "WifiScanner", "startScan()");
        if (wifiManager == null) {
            statusText.setText("Wi-Fi недоступен");
            return;
        }
        if (isScanning) {
            statusText.setText("Сканирование уже выполняется");
            return;
        }
        
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            Toast.makeText(this, "Нет разрешения на местоположение", Toast.LENGTH_SHORT).show();
            checkPermissions();
            return;
        }

        if (!wifiManager.isWifiEnabled()) {
            statusText.setText("Включение Wi-Fi...");
            wifiManager.setWifiEnabled(true);
            handler.postDelayed(this::doScan, 2000);
        } else {
            doScan();
        }
    }

    private void doScan() {
        AppLogger.log(this, "WifiScanner", "doScan()");
        
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            statusText.setText("Нет разрешения на местоположение");
            return;
        }

        isScanning = true;
        btnScan.setEnabled(false);
        statusText.setText("Сканирование...");
        progressBar.setVisibility(View.VISIBLE);
        progressBar.setProgress(50);

        try {
            boolean started = wifiManager.startScan();
            AppLogger.log(this, "WifiScanner", "startScan() returned: " + started);
            
            if (!started) {
                AppLogger.log(this, "WifiScanner", "startScan returned false, trying to get results directly");
                handler.postDelayed(() -> {
                    tryGetResults();
                    if (isScanning) {
                        isScanning = false;
                        btnScan.setEnabled(true);
                        progressBar.setVisibility(View.GONE);
                        statusText.setText("Сканирование не удалось");
                    }
                }, 2000);
            }
        } catch (SecurityException e) {
            AppLogger.logException(this, "WifiScanner", e);
            statusText.setText("Нет разрешения на сканирование");
            isScanning = false;
            btnScan.setEnabled(true);
            progressBar.setVisibility(View.GONE);
        } catch (Exception e) {
            AppLogger.logException(this, "WifiScanner", e);
            statusText.setText("Ошибка: " + e.getMessage());
            isScanning = false;
            btnScan.setEnabled(true);
            progressBar.setVisibility(View.GONE);
        }

        handler.postDelayed(() -> {
            if (isScanning) {
                AppLogger.log(this, "WifiScanner", "Scan TIMEOUT");
                isScanning = false;
                btnScan.setEnabled(true);
                progressBar.setVisibility(View.GONE);
                statusText.setText("Таймаут сканирования");
                tryGetResults();
            }
        }, SCAN_TIMEOUT_MS);
    }
    
    private void tryGetResults() {
        AppLogger.log(this, "WifiScanner", "tryGetResults() called");
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            return;
        }
        try {
            List<ScanResult> results = wifiManager.getScanResults();
            if (results != null && !results.isEmpty()) {
                AppLogger.log(this, "WifiScanner", "tryGetResults found " + results.size() + " networks");
                lastResults = results;
                applyFilterAndSort();
                updateNetworkDisplay();
                updateSignalStats();
                updateChannelInfo();
                isScanning = false;
                btnScan.setEnabled(true);
                progressBar.setVisibility(View.GONE);
                statusText.setText("Найдено " + results.size() + " сетей");
                statusText.setTextColor(0xFF4CAF50);
            } else {
                AppLogger.log(this, "WifiScanner", "tryGetResults found no networks");
            }
        } catch (SecurityException e) {
            AppLogger.logException(this, "WifiScanner", e);
        }
    }

    private void scanSuccess() {
        AppLogger.log(this, "WifiScanner", "scanSuccess() called");
        isScanning = false;
        btnScan.setEnabled(true);
        progressBar.setProgress(100);
        handler.postDelayed(() -> progressBar.setVisibility(View.GONE), 500);

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            statusText.setText("Нет разрешения");
            return;
        }

        try {
            lastResults = wifiManager.getScanResults();
            AppLogger.log(this, "WifiScanner", "Got " + (lastResults != null ? lastResults.size() : 0) + " results");
            
            if (lastResults == null || lastResults.isEmpty()) {
                statusText.setText("Сетей не найдено");
                resultText.setText("Нет доступных Wi-Fi сетей.\n\nВозможные причины:\n• Wi-Fi выключен\n• Нет доступа к геолокации\n• Включите сканирование Wi-Fi в настройках");
                signalStatsText.setText("");
                return;
            }

            applyFilterAndSort();
            updateNetworkDisplay();
            updateSignalStats();
            updateChannelInfo();
            updateIPInfo();

        } catch (SecurityException e) {
            AppLogger.logException(this, "WifiScanner", e);
            statusText.setText("Ошибка доступа");
        }
    }
    
    private void scanFailure() {
        AppLogger.log(this, "WifiScanner", "scanFailure()");
        isScanning = false;
        btnScan.setEnabled(true);
        progressBar.setVisibility(View.GONE);
        statusText.setText("Ошибка сканирования");
        statusText.setTextColor(0xFFFF5252);
        
        handler.postDelayed(this::tryGetResults, 500);
    }

    private void applyFilterAndSort() {
        filteredResults.clear();
        for (ScanResult sr : lastResults) {
            if (currentFilter.equals("all")) {
                filteredResults.add(sr);
            } else if (currentFilter.equals("open") && getSecurity(sr).equals("Открытая")) {
                filteredResults.add(sr);
            } else if (currentFilter.equals("secure") && !getSecurity(sr).equals("Открытая")) {
                filteredResults.add(sr);
            } else if (currentFilter.equals("wpa3") && sr.capabilities.contains("WPA3")) {
                filteredResults.add(sr);
            } else if (currentFilter.equals("5ghz") && is5GHz(sr.frequency)) {
                filteredResults.add(sr);
            } else if (currentFilter.equals("2ghz") && is2_4GHz(sr.frequency)) {
                filteredResults.add(sr);
            } else if (currentFilter.equals("strong") && calculateSignalPercent(sr.level) >= 60) {
                filteredResults.add(sr);
            }
        }

        if (currentSort.equals("signal")) {
            Collections.sort(filteredResults, (a, b) -> Integer.compare(b.level, a.level));
        } else if (currentSort.equals("name")) {
            Collections.sort(filteredResults, (a, b) -> a.SSID.compareToIgnoreCase(b.SSID));
        } else if (currentSort.equals("security")) {
            Collections.sort(filteredResults, (a, b) -> getSecurity(a).compareTo(getSecurity(b)));
        } else if (currentSort.equals("channel")) {
            Collections.sort(filteredResults, (a, b) -> Integer.compare(getChannel(a.frequency), getChannel(b.frequency)));
        }
    }

    private void updateNetworkDisplay() {
        StringBuilder sb = new StringBuilder();
        int displayCount = 0;
        
        for (ScanResult sr : filteredResults) {
            if (displayCount++ > 200) break;
            
            String ssid = sr.SSID != null && !sr.SSID.isEmpty() && !sr.SSID.equals("<unknown ssid>") 
                ? escapeSSID(sr.SSID) : "<скрытая>";
            int signalPercent = calculateSignalPercent(sr.level);
            String bars = getSignalBars(signalPercent);
            String security = getSecurity(sr);
            int channel = getChannel(sr.frequency);
            String band = getBand(sr.frequency);
            
            sb.append(bars).append(" ").append(ssid).append("\n");
            sb.append("   📶 ").append(signalPercent).append("% (").append(sr.level).append(" dBm)");
            sb.append(" | 🔒 ").append(security);
            sb.append(" | 📡 ").append(band).append(" канал ").append(channel).append("\n");
            sb.append("   📍 ").append(sr.BSSID);
            sb.append("\n   ⚡ ").append(getMaxRate(sr));
            
            long age = System.currentTimeMillis() - sr.timestamp / 1000;
            if (age < 10000) {
                sb.append(" | 🟢 только что");
            } else if (age < 60000) {
                sb.append(" | 🟡 ").append(age / 1000).append(" сек назад");
            }
            sb.append("\n\n");
        }

        if (filteredResults.isEmpty()) {
            sb.append("Нет сетей, соответствующих фильтру\n");
            if (lastResults.isEmpty()) {
                sb.append("\n💡 Совет: Убедитесь, что:\n");
                sb.append("• Wi-Fi включен\n");
                sb.append("• Разрешение на геолокацию дано\n");
                sb.append("• Геолокация включена в настройках\n");
            }
        }
        
        resultText.setText(sb.toString());
        statusText.setText(String.format("Найдено: %d | Отображено: %d", lastResults.size(), filteredResults.size()));
        statusText.setTextColor(0xFF4CAF50);
    }

    private String getMaxRate(ScanResult sr) {
        if (sr.capabilities.contains("802.11ax")) return "AX/WiFi 6 (до 2400 Mbps)";
        if (sr.capabilities.contains("802.11ac")) return "AC (до 1300 Mbps)";
        if (sr.capabilities.contains("802.11n")) return "N (до 600 Mbps)";
        if (sr.capabilities.contains("802.11g")) return "G (до 54 Mbps)";
        return "b/g/n";
    }

    private void updateSignalStats() {
        if (lastResults.isEmpty()) {
            signalStatsText.setText("");
            return;
        }
        
        int total = lastResults.size();
        int excellent = 0, good = 0, fair = 0, poor = 0;
        int rssiSum = 0;
        
        for (ScanResult sr : lastResults) {
            int pct = calculateSignalPercent(sr.level);
            if (pct >= 80) excellent++;
            else if (pct >= 60) good++;
            else if (pct >= 40) fair++;
            else poor++;
            
            rssiSum += sr.level;
        }
        
        int rssiAvg = total > 0 ? rssiSum / total : 0;
        signalStatsText.setText(String.format("📊 Сигнал: отличный %d | хороший %d | средний %d | слабый %d | ⚡ средний RSSI: %d dBm",
                excellent, good, fair, poor, rssiAvg));
    }

    private void updateChannelInfo() {
        if (lastResults.isEmpty()) {
            channelInfoText.setText("");
            return;
        }
        
        int channels2g = 0, channels5g = 0, channels6g = 0;
        Map<Integer, Integer> channelUsage = new HashMap<>();
        
        for (ScanResult sr : lastResults) {
            int channel = getChannel(sr.frequency);
            channelUsage.put(channel, channelUsage.getOrDefault(channel, 0) + 1);
            
            if (is2_4GHz(sr.frequency)) channels2g++;
            else if (is5GHz(sr.frequency)) channels5g++;
            else if (is6GHz(sr.frequency)) channels6g++;
        }
        
        int mostOverlapChannel = 0;
        int maxOverlap = 0;
        for (Map.Entry<Integer, Integer> entry : channelUsage.entrySet()) {
            if (entry.getValue() > maxOverlap) {
                maxOverlap = entry.getValue();
                mostOverlapChannel = entry.getKey();
            }
        }
        
        channelInfoText.setText(String.format("📡 2.4ГГц: %d | 5ГГц: %d | 6ГГц: %d | ⚠️ перегружен канал %d (%d сетей)",
                channels2g, channels5g, channels6g, mostOverlapChannel, maxOverlap));
    }

    private void refreshResults() {
        if (lastResults != null && !lastResults.isEmpty()) {
            applyFilterAndSort();
            updateNetworkDisplay();
            updateSignalStats();
            statusText.setText("Обновлено (" + lastResults.size() + " сетей)");
        } else {
            startScan();
        }
    }

    private void exportResults() {
        if (lastResults.isEmpty()) {
            Toast.makeText(this, "Нет данных для экспорта", Toast.LENGTH_SHORT).show();
            return;
        }
        
        StringBuilder export = new StringBuilder();
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault());
        export.append("Wi-Fi Scanner Export - ").append(sdf.format(new Date())).append("\n");
        export.append("========================================\n\n");
        
        for (ScanResult sr : lastResults) {
            export.append("SSID: ").append(escapeSSID(sr.SSID)).append("\n");
            export.append("BSSID: ").append(sr.BSSID).append("\n");
            export.append("RSSI: ").append(sr.level).append(" dBm (").append(calculateSignalPercent(sr.level)).append("%)\n");
            export.append("Security: ").append(getSecurity(sr)).append("\n");
            export.append("Frequency: ").append(sr.frequency).append(" MHz (Channel ").append(getChannel(sr.frequency)).append(")\n");
            export.append("Capabilities: ").append(sr.capabilities).append("\n");
            export.append("Timestamp: ").append(sr.timestamp).append("\n");
            export.append("---\n");
        }
        
        String exportText = export.toString();
        android.content.ClipboardManager clipboard = (android.content.ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
        android.content.ClipData clip = android.content.ClipData.newPlainText("WiFi Scan Results", exportText);
        clipboard.setPrimaryClip(clip);
        Toast.makeText(this, "Результаты скопированы в буфер обмена", Toast.LENGTH_LONG).show();
        AppLogger.log(this, "WifiScanner", "Exported " + lastResults.size() + " networks to clipboard");
    }

    private void showFilterDialog() {
        final String[] filters = {"Все сети", "Открытые", "Защищенные", "WPA3", "5 ГГц", "2.4 ГГц", "Сильный сигнал (>60%)"};
        final String[] filterKeys = {"all", "open", "secure", "wpa3", "5ghz", "2ghz", "strong"};
        
        int currentIndex = 0;
        for (int i = 0; i < filterKeys.length; i++) {
            if (filterKeys[i].equals(currentFilter)) {
                currentIndex = i;
                break;
            }
        }
        
        new android.app.AlertDialog.Builder(this)
            .setTitle("Фильтр Wi-Fi сетей")
            .setSingleChoiceItems(filters, currentIndex, (dialog, which) -> {
                currentFilter = filterKeys[which];
                applyFilterAndSort();
                updateNetworkDisplay();
                dialog.dismiss();
                Toast.makeText(this, "Фильтр: " + filters[which], Toast.LENGTH_SHORT).show();
            })
            .setNegativeButton("Отмена", null)
            .show();
    }

    private void showSortDialog() {
        final String[] sorts = {"По силе сигнала", "По имени", "По типу защиты", "По каналу"};
        final String[] sortKeys = {"signal", "name", "security", "channel"};
        
        int currentIndex = 0;
        for (int i = 0; i < sortKeys.length; i++) {
            if (sortKeys[i].equals(currentSort)) {
                currentIndex = i;
                break;
            }
        }
        
        new android.app.AlertDialog.Builder(this)
            .setTitle("Сортировка")
            .setSingleChoiceItems(sorts, currentIndex, (dialog, which) -> {
                currentSort = sortKeys[which];
                applyFilterAndSort();
                updateNetworkDisplay();
                dialog.dismiss();
                Toast.makeText(this, "Сортировка: " + sorts[which], Toast.LENGTH_SHORT).show();
            })
            .setNegativeButton("Отмена", null)
            .show();
    }

    private String getSignalBars(int percent) {
        if (percent >= 86) return "████";
        if (percent >= 70) return "███▒";
        if (percent >= 55) return "██▒░";
        if (percent >= 35) return "█▒░░";
        if (percent >= 15) return "█░░░";
        return "▒░░░";
    }

    private String getSecurity(ScanResult sr) {
        String caps = sr.capabilities;
        if (caps.contains("WPA3-ENT") || caps.contains("WPA3-192")) return "WPA3-Enterprise";
        if (caps.contains("WPA3-Personal") || caps.contains("WPA3-SAE") || caps.contains("WPA3")) return "WPA3";
        if (caps.contains("WPA2-Enterprise")) return "WPA2-Enterprise";
        if (caps.contains("WPA2-PSK") || caps.contains("WPA2")) return "WPA2";
        if (caps.contains("WPA-PSK") || caps.contains("WPA")) return "WPA";
        if (caps.contains("WEP")) return "WEP";
        if (caps.contains("OWE")) return "OWE (Enhanced Open)";
        return "Открытая";
    }

    private int calculateSignalPercent(int rssi) {
        int percent = (rssi - RSSI_MIN) * 100 / (RSSI_MAX - RSSI_MIN);
        return Math.min(100, Math.max(0, percent));
    }

    private int getChannel(int frequency) {
        Integer channel = channelMap.get(frequency);
        if (channel != null) return channel;
        
        if (frequency >= CHANNEL_2G_MIN && frequency <= CHANNEL_2G_MAX) {
            return (frequency - CHANNEL_2G_MIN) / 5 + 1;
        } else if (frequency >= CHANNEL_5G_MIN && frequency <= CHANNEL_5G_MAX) {
            return (frequency - 5000) / 5;
        } else if (frequency >= CHANNEL_6G_MIN && frequency <= CHANNEL_6G_MAX) {
            return (frequency - 5950) / 5 + 1;
        }
        return 0;
    }

    private String getBand(int frequency) {
        if (is2_4GHz(frequency)) return "2.4 ГГц";
        if (is5GHz(frequency)) return "5 ГГц";
        if (is6GHz(frequency)) return "6 ГГц";
        return "Другой";
    }

    private boolean is2_4GHz(int frequency) {
        return frequency >= CHANNEL_2G_MIN && frequency <= CHANNEL_2G_MAX;
    }

    private boolean is5GHz(int frequency) {
        return frequency >= CHANNEL_5G_MIN && frequency <= CHANNEL_5G_MAX;
    }

    private boolean is6GHz(int frequency) {
        return frequency >= CHANNEL_6G_MIN && frequency <= CHANNEL_6G_MAX;
    }

    private String escapeSSID(String ssid) {
        if (ssid == null) return "<unknown>";
        return ssid.replace("\n", " ").replace("\r", " ").trim();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        AppLogger.log(this, "WifiScanner", "onDestroy()");
        handler.removeCallbacksAndMessages(null);
        try {
            if (wifiReceiver != null && receiverRegistered) {
                unregisterReceiver(wifiReceiver);
            }
            if (wifiStateReceiver != null && stateReceiverRegistered) {
                unregisterReceiver(wifiStateReceiver);
            }
        } catch (Exception e) {
            AppLogger.logException(this, "WifiScanner", e);
        }
    }
}