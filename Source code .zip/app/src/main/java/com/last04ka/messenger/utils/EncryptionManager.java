package com.last04ka.messenger.utils;

import android.util.Base64;

import java.security.InvalidAlgorithmParameterException;
import java.security.KeyFactory;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.SecureRandom;
import java.security.spec.ECGenParameterSpec;
import java.security.spec.PKCS8EncodedKeySpec;
import java.security.spec.X509EncodedKeySpec;

import javax.crypto.Cipher;
import javax.crypto.KeyAgreement;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;
import javax.crypto.spec.SecretKeySpec;

public class EncryptionManager {
    private static final String TAG = "EncryptionManager";
    private static final String EC_ALGORITHM = "EC";
    private static final String EC_CURVE = "secp256r1";
    private static final String AES_ALGORITHM = "AES";
    private static final String AES_GCM_NO_PADDING = "AES/GCM/NoPadding";
    private static final int AES_KEY_SIZE = 256;
    private static final int GCM_IV_LENGTH = 12;
    private static final int GCM_TAG_LENGTH = 128;
    private static final String KDF_ALGORITHM = "SHA-256";

    /**
     * Генерирует пару ключей ECDH (кривая secp256r1 / NIST P-256).
     */
    public static KeyPair generateKeyPair() throws NoSuchAlgorithmException, InvalidAlgorithmParameterException {
        AppLogger.log(null, TAG, "⏳ Generating ECDH key pair...");
        KeyPairGenerator keyGen = KeyPairGenerator.getInstance(EC_ALGORITHM);
        ECGenParameterSpec ecSpec = new ECGenParameterSpec(EC_CURVE);
        keyGen.initialize(ecSpec, new SecureRandom());
        KeyPair keyPair = keyGen.generateKeyPair();
        AppLogger.log(null, TAG, "✅ Key pair generated");
        return keyPair;
    }

    /**
     * Кодирует публичный ключ в Base64 (без переносов строк).
     */
    public static String encodePublicKey(PublicKey publicKey) {
        byte[] encoded = publicKey.getEncoded();
        String base64 = Base64.encodeToString(encoded, Base64.NO_WRAP);
        AppLogger.log(null, TAG, "🔑 Public key encoded, length=" + base64.length());
        return base64;
    }

    /**
     * Декодирует публичный ключ из Base64.
     */
    public static PublicKey decodePublicKey(String base64Key) throws Exception {
        byte[] encoded = Base64.decode(base64Key, Base64.DEFAULT);
        KeyFactory keyFactory = KeyFactory.getInstance(EC_ALGORITHM);
        X509EncodedKeySpec keySpec = new X509EncodedKeySpec(encoded);
        PublicKey publicKey = keyFactory.generatePublic(keySpec);
        AppLogger.log(null, TAG, "🔑 Public key decoded");
        return publicKey;
    }

    /**
     * Кодирует приватный ключ в Base64.
     */
    public static String encodePrivateKey(PrivateKey privateKey) {
        byte[] encoded = privateKey.getEncoded();
        String base64 = Base64.encodeToString(encoded, Base64.NO_WRAP);
        AppLogger.log(null, TAG, "🔑 Private key encoded");
        return base64;
    }

    /**
     * Декодирует приватный ключ из Base64.
     */
    public static PrivateKey decodePrivateKey(String base64Key) throws Exception {
        byte[] encoded = Base64.decode(base64Key, Base64.DEFAULT);
        KeyFactory keyFactory = KeyFactory.getInstance(EC_ALGORITHM);
        PKCS8EncodedKeySpec keySpec = new PKCS8EncodedKeySpec(encoded);
        PrivateKey privateKey = keyFactory.generatePrivate(keySpec);
        AppLogger.log(null, TAG, "🔑 Private key decoded");
        return privateKey;
    }

    /**
     * Вычисляет общий секрет по протоколу ECDH.
     */
    public static byte[] computeSharedSecret(PrivateKey myPrivateKey, PublicKey otherPublicKey) throws Exception {
        AppLogger.log(null, TAG, "⏳ Computing shared secret via ECDH...");
        KeyAgreement keyAgreement = KeyAgreement.getInstance("ECDH");
        keyAgreement.init(myPrivateKey);
        keyAgreement.doPhase(otherPublicKey, true);
        byte[] sharedSecret = keyAgreement.generateSecret();
        AppLogger.log(null, TAG, "✅ Shared secret computed, length=" + sharedSecret.length + " bytes");
        return sharedSecret;
    }

    /**
     * Из общего секрета выводит AES-256 ключ с помощью SHA-256.
     */
    public static SecretKey deriveAESKey(byte[] sharedSecret) throws Exception {
        AppLogger.log(null, TAG, "⏳ Deriving AES-256 key via SHA-256...");
        MessageDigest digest = MessageDigest.getInstance(KDF_ALGORITHM);
        byte[] hash = digest.digest(sharedSecret);
        byte[] keyBytes = new byte[32];
        System.arraycopy(hash, 0, keyBytes, 0, 32);
        SecretKey aesKey = new SecretKeySpec(keyBytes, AES_ALGORITHM);
        AppLogger.log(null, TAG, "✅ AES-256 key derived");
        return aesKey;
    }

    /**
     * Шифрует текст с использованием AES-256-GCM. Возвращает Base64 строку (IV + шифртекст).
     */
    public static String encrypt(String plainText, SecretKey aesKey) throws Exception {
        AppLogger.log(null, TAG, "⏳ Encrypting text, length=" + plainText.length());
        byte[] iv = new byte[GCM_IV_LENGTH];
        new SecureRandom().nextBytes(iv);

        Cipher cipher = Cipher.getInstance(AES_GCM_NO_PADDING);
        GCMParameterSpec spec = new GCMParameterSpec(GCM_TAG_LENGTH, iv);
        cipher.init(Cipher.ENCRYPT_MODE, aesKey, spec);

        byte[] cipherText = cipher.doFinal(plainText.getBytes("UTF-8"));

        byte[] combined = new byte[iv.length + cipherText.length];
        System.arraycopy(iv, 0, combined, 0, iv.length);
        System.arraycopy(cipherText, 0, combined, iv.length, cipherText.length);

        String result = Base64.encodeToString(combined, Base64.NO_WRAP);
        AppLogger.log(null, TAG, "✅ Encryption successful, output length=" + result.length());
        return result;
    }

    /**
     * Расшифровывает строку, закодированную в Base64 (IV + шифртекст).
     */
    public static String decrypt(String cipherTextBase64, SecretKey aesKey) throws Exception {
        AppLogger.log(null, TAG, "⏳ Decrypting ciphertext, length=" + cipherTextBase64.length());
        byte[] combined = Base64.decode(cipherTextBase64, Base64.DEFAULT);

        byte[] iv = new byte[GCM_IV_LENGTH];
        System.arraycopy(combined, 0, iv, 0, GCM_IV_LENGTH);

        byte[] cipherText = new byte[combined.length - GCM_IV_LENGTH];
        System.arraycopy(combined, GCM_IV_LENGTH, cipherText, 0, cipherText.length);

        Cipher cipher = Cipher.getInstance(AES_GCM_NO_PADDING);
        GCMParameterSpec spec = new GCMParameterSpec(GCM_TAG_LENGTH, iv);
        cipher.init(Cipher.DECRYPT_MODE, aesKey, spec);

        byte[] plainBytes = cipher.doFinal(cipherText);
        String plainText = new String(plainBytes, "UTF-8");
        AppLogger.log(null, TAG, "✅ Decryption successful, plaintext length=" + plainText.length());
        return plainText;
    }

    /**
     * Генерирует случайный AES-256 ключ (для тестов или fallback).
     */
    public static SecretKey generateRandomAESKey() throws NoSuchAlgorithmException {
        AppLogger.log(null, TAG, "⏳ Generating random AES-256 key...");
        KeyGenerator keyGen = KeyGenerator.getInstance(AES_ALGORITHM);
        keyGen.init(AES_KEY_SIZE, new SecureRandom());
        SecretKey key = keyGen.generateKey();
        AppLogger.log(null, TAG, "✅ Random AES-256 key generated");
        return key;
    }

    /**
     * Преобразует SecretKey в Base64.
     */
    public static String secretKeyToBase64(SecretKey key) {
        return Base64.encodeToString(key.getEncoded(), Base64.NO_WRAP);
    }

    /**
     * Восстанавливает SecretKey из Base64.
     */
    public static SecretKey secretKeyFromBase64(String base64Key) {
        byte[] encoded = Base64.decode(base64Key, Base64.DEFAULT);
        return new SecretKeySpec(encoded, AES_ALGORITHM);
    }
}