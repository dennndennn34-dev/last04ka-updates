package com.last04ka.messenger.ui;

import android.Manifest;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.media.AudioFormat;
import android.media.AudioRecord;
import android.media.AudioTrack;
import android.media.MediaRecorder;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.wifi.p2p.WifiP2pDevice;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.support.annotation.NonNull;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import com.last04ka.messenger.R;
import com.last04ka.messenger.connectivity.NearbyManager;
import com.last04ka.messenger.data.DatabaseHelper;
import com.last04ka.messenger.utils.AppLogger;
import com.last04ka.messenger.utils.ThemeManager;
import com.last04ka.messenger.utils.UpdateManager;

import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.UUID;

public class DeveloperModeActivity extends AppCompatActivity {
    private static final String TAG = "DeveloperMode";
    private static final int REQUEST_RECORD_AUDIO = 300;
    private static final String UPDATE_URL = "https://dennndennn34-dev.github.io/last04ka-updates/update.json";

    private TextView tvStatus, tvDiagnosticResult;
    private TextView tvVersion, tvBtStatus, tvDbSize, tvStats;
    private Button btnExit, btnDiagnostic;
    private Button btnScan, btnConnectMac, btnTestServer, btnPing;
    private Button btnTestMic, btnTestSpeaker, btnCallStats, btnTestNoise;
    private Button btnEmulateCall, btnPacketLoss5, btnPacketLoss10, btnPacketLoss20;
    private Button btnCallLog, btnTestReconnect, btnDelay100, btnDelay300, btnDelay500;
    private Button btnShowLogs, btnClearLogs, btnExportLogs;
    private Button btnTestChats, btnTestMessages, btnClearDb;
    private Button btnCheckUpdate, btnTestConnection;

    // WiFi Direct и групповые чаты
    private Button btnWifiDiscover, btnWifiCreateGroup, btnWifiConnect, btnWifiDisconnect;
    private Button btnGroupChat, btnGroupChatDiagnostic;
    private TextView tvWifiStatus, tvWifiPeers;

    // ==================== ТЕСТОВЫЙ ЧАТ ====================
    private Button btnTestChat;

    private DatabaseHelper dbHelper;
    private BluetoothAdapter bluetoothAdapter;
    private Handler mainHandler = new Handler(Looper.getMainLooper());
    private Animation pulseAnimation;
    private Animation slideInAnimation;

    private boolean isDiagnosticRunning = false;
    private String diagnosticResult = "";
    private ProgressDialog progressDialog;

    private int totalCalls = 0;
    private int successfulCalls = 0;
    private int failedCalls = 0;
    private StringBuilder callLog = new StringBuilder();

    private NearbyManager nearbyManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        setTheme(ThemeManager.getThemeResource(this));
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_developer_mode);

        AppLogger.log(this, TAG, "═══════════════════════════════════════════════════════════");
        AppLogger.log(this, TAG, "🔐 DeveloperModeActivity onCreate START (v2.0 with WiFi Direct)");
        AppLogger.log(this, TAG, "═══════════════════════════════════════════════════════════");

        initViews();
        loadAnimations();
        setupListeners();
        updateInfo();

        dbHelper = new DatabaseHelper(this);
        bluetoothAdapter = BluetoothAdapter.getDefaultAdapter();

        progressDialog = new ProgressDialog(this);
        progressDialog.setCancelable(false);

        loadCallStats();

        // Инициализация WiFi Direct
        nearbyManager = new NearbyManager(this);
        nearbyManager.setCallback(new NearbyManager.MessageCallback() {
            @Override
            public void onMessageReceived(String message) {
                AppLogger.log(DeveloperModeActivity.this, TAG, "📨 WFD Message: " + message);
            }

            @Override
            public void onConnectionStateChanged(boolean connected, boolean isGroupOwner) {
                runOnUiThread(() -> {
                    tvWifiStatus.setText("WiFi Direct: " + (connected ? "Подключено" + (isGroupOwner ? " (владелец)" : "") : "Не подключено"));
                    AppLogger.log(DeveloperModeActivity.this, TAG, "WFD state: connected=" + connected + ", owner=" + isGroupOwner);
                });
            }

            @Override
            public void onPeersChanged(List<WifiP2pDevice> peers) {
                runOnUiThread(() -> {
                    StringBuilder sb = new StringBuilder("Найдено устройств: " + peers.size() + "\n");
                    for (WifiP2pDevice d : peers) {
                        sb.append(d.deviceName != null ? d.deviceName : "Unknown").append("\n");
                    }
                    tvWifiPeers.setText(sb.toString());
                    AppLogger.log(DeveloperModeActivity.this, TAG, "WFD peers updated: " + peers.size());
                });
            }

            @Override
            public void onDeviceDisconnected() {
                runOnUiThread(() -> {
                    tvWifiStatus.setText("WiFi Direct: Отключено");
                    Toast.makeText(DeveloperModeActivity.this, "WiFi Direct отключено", Toast.LENGTH_SHORT).show();
                });
                AppLogger.log(DeveloperModeActivity.this, TAG, "WFD disconnected");
            }

            @Override
            public void onError(String error) {
                runOnUiThread(() -> {
                    Toast.makeText(DeveloperModeActivity.this, "WFD Error: " + error, Toast.LENGTH_SHORT).show();
                    tvWifiStatus.setText("WiFi Direct: " + error);
                });
                AppLogger.log(DeveloperModeActivity.this, TAG, "WFD Error: " + error);
            }

            @Override
            public void onThisDeviceChanged(WifiP2pDevice device) {
                AppLogger.log(DeveloperModeActivity.this, TAG, "📱 This device changed: " + (device != null ? device.deviceName : "null"));
            }
        });

        AppLogger.log(this, TAG, "✅ DeveloperModeActivity initialized with WiFi Direct");
    }

    private void initViews() {
        tvStatus = findViewById(R.id.tv_status);
        tvDiagnosticResult = findViewById(R.id.tv_diagnostic_result);
        tvVersion = findViewById(R.id.tv_version);
        tvBtStatus = findViewById(R.id.tv_bt_status);
        tvDbSize = findViewById(R.id.tv_db_size);
        tvStats = findViewById(R.id.tv_stats);

        btnExit = findViewById(R.id.btn_exit);
        btnDiagnostic = findViewById(R.id.btn_diagnostic);

        btnScan = findViewById(R.id.btn_scan);
        btnConnectMac = findViewById(R.id.btn_connect_mac);
        btnTestServer = findViewById(R.id.btn_test_server);
        btnPing = findViewById(R.id.btn_ping);

        btnTestMic = findViewById(R.id.btn_test_mic);
        btnTestSpeaker = findViewById(R.id.btn_test_speaker);
        btnCallStats = findViewById(R.id.btn_call_stats);
        btnTestNoise = findViewById(R.id.btn_test_noise);

        btnEmulateCall = findViewById(R.id.btn_emulate_call);
        btnPacketLoss5 = findViewById(R.id.btn_packet_loss_5);
        btnPacketLoss10 = findViewById(R.id.btn_packet_loss_10);
        btnPacketLoss20 = findViewById(R.id.btn_packet_loss_20);
        btnCallLog = findViewById(R.id.btn_call_log);
        btnTestReconnect = findViewById(R.id.btn_test_reconnect);
        btnDelay100 = findViewById(R.id.btn_delay_100);
        btnDelay300 = findViewById(R.id.btn_delay_300);
        btnDelay500 = findViewById(R.id.btn_delay_500);

        btnShowLogs = findViewById(R.id.btn_show_logs);
        btnClearLogs = findViewById(R.id.btn_clear_logs);
        btnExportLogs = findViewById(R.id.btn_export_logs);

        btnTestChats = findViewById(R.id.btn_test_chats);
        btnTestMessages = findViewById(R.id.btn_test_messages);
        btnClearDb = findViewById(R.id.btn_clear_db);

        btnCheckUpdate = findViewById(R.id.btn_check_update);
        btnTestConnection = findViewById(R.id.btn_test_connection);

        // WiFi Direct views
        btnWifiDiscover = findViewById(R.id.btn_wifi_discover);
        btnWifiCreateGroup = findViewById(R.id.btn_wifi_create_group);
        btnWifiConnect = findViewById(R.id.btn_wifi_connect);
        btnWifiDisconnect = findViewById(R.id.btn_wifi_disconnect);
        btnGroupChat = findViewById(R.id.btn_group_chat);
        btnGroupChatDiagnostic = findViewById(R.id.btn_group_chat_diagnostic);
        tvWifiStatus = findViewById(R.id.tv_wifi_status);
        tvWifiPeers = findViewById(R.id.tv_wifi_peers);

        // ==================== ТЕСТОВЫЙ ЧАТ (СОЗДАЁМ ПРОГРАММНО) ====================
        btnTestChat = new Button(this);
        btnTestChat.setText("🧪 Тестовый чат (без Bluetooth)");
        btnTestChat.setTextSize(14);
        btnTestChat.setTextColor(ThemeManager.getTextColor(this));
        btnTestChat.setBackgroundColor(ThemeManager.getCardColor(this));
        btnTestChat.setPadding(32, 16, 32, 16);
        btnTestChat.setLayoutParams(new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        ));

        // Добавляем кнопку в конец списка
        ScrollView scrollView = findViewById(R.id.scroll_view);
        if (scrollView != null) {
            LinearLayout mainLayout = (LinearLayout) scrollView.getChildAt(0);
            if (mainLayout != null) {
                mainLayout.addView(btnTestChat);
                AppLogger.log(this, TAG, "✅ Test chat button added programmatically");
            }
        }

        AppLogger.log(this, TAG, "✅ Views initialized");
    }

    private void loadAnimations() {
        pulseAnimation = AnimationUtils.loadAnimation(this, R.anim.pulse);
        slideInAnimation = AnimationUtils.loadAnimation(this, R.anim.slide_in);
        AppLogger.log(this, TAG, "✅ Animations loaded");
    }

    private void setupListeners() {
        btnExit.setOnClickListener(v -> exitDeveloperMode());
        btnDiagnostic.setOnClickListener(v -> runFullDiagnostic());

        btnScan.setOnClickListener(v -> scanDevices());
        btnConnectMac.setOnClickListener(v -> showConnectMacDialog());
        btnTestServer.setOnClickListener(v -> createTestServer());
        btnPing.setOnClickListener(v -> runRealPingTest());

        btnTestMic.setOnClickListener(v -> testMicrophone());
        btnTestSpeaker.setOnClickListener(v -> testSpeaker());
        btnCallStats.setOnClickListener(v -> showCallStats());
        btnTestNoise.setOnClickListener(v -> testNoiseSuppression());

        btnEmulateCall.setOnClickListener(v -> emulateFullCall());
        btnPacketLoss5.setOnClickListener(v -> setPacketLoss(5));
        btnPacketLoss10.setOnClickListener(v -> setPacketLoss(10));
        btnPacketLoss20.setOnClickListener(v -> setPacketLoss(20));
        btnCallLog.setOnClickListener(v -> showFullCallLog());
        btnTestReconnect.setOnClickListener(v -> testReconnection());
        btnDelay100.setOnClickListener(v -> setDelay(100));
        btnDelay300.setOnClickListener(v -> setDelay(300));
        btnDelay500.setOnClickListener(v -> setDelay(500));

        btnShowLogs.setOnClickListener(v -> showLogsWithScroll());
        btnClearLogs.setOnClickListener(v -> clearLogs());
        btnExportLogs.setOnClickListener(v -> exportLogs());

        btnTestChats.setOnClickListener(v -> createTestChats());
        btnTestMessages.setOnClickListener(v -> createTestMessages());
        btnClearDb.setOnClickListener(v -> clearDatabase());

        if (btnCheckUpdate != null) {
            btnCheckUpdate.setOnClickListener(v -> checkForUpdatesManually());
        }

        if (btnTestConnection != null) {
            btnTestConnection.setOnClickListener(v -> testConnection());
        }

        // WiFi Direct
        btnWifiDiscover.setOnClickListener(v -> {
            AppLogger.log(this, TAG, "🔍 WiFi Direct Discover clicked");
            nearbyManager.discoverPeers();
            Toast.makeText(this, "Поиск устройств WiFi Direct...", Toast.LENGTH_SHORT).show();
        });

        btnWifiCreateGroup.setOnClickListener(v -> {
            AppLogger.log(this, TAG, "📡 WiFi Direct Create Group clicked");
            nearbyManager.createGroup();
            Toast.makeText(this, "Создание группы WiFi Direct...", Toast.LENGTH_SHORT).show();
        });

        btnWifiConnect.setOnClickListener(v -> {
            AppLogger.log(this, TAG, "🔗 WiFi Direct Connect clicked");
            List<WifiP2pDevice> peers = nearbyManager.getPeers();
            if (peers != null && !peers.isEmpty()) {
                WifiP2pDevice device = peers.get(0);
                nearbyManager.connectToDevice(device);
                Toast.makeText(this, "Подключение к " + device.deviceName, Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "Нет устройств для подключения", Toast.LENGTH_SHORT).show();
            }
        });

        btnWifiDisconnect.setOnClickListener(v -> {
            AppLogger.log(this, TAG, "❌ WiFi Direct Disconnect clicked");
            nearbyManager.disconnect();
            Toast.makeText(this, "Отключение WiFi Direct...", Toast.LENGTH_SHORT).show();
        });

        btnGroupChat.setOnClickListener(v -> {
            AppLogger.log(this, TAG, "💬 Group Chat clicked");
            Intent intent = new Intent(DeveloperModeActivity.this, GroupChatActivity.class);
            startActivity(intent);
        });

        btnGroupChatDiagnostic.setOnClickListener(v -> {
            AppLogger.log(this, TAG, "🔍 Group Chat Diagnostic clicked");
            showGroupChatDiagnostic();
        });

        // ==================== ТЕСТОВЫЙ ЧАТ ====================
        if (btnTestChat != null) {
            btnTestChat.setOnClickListener(v -> {
                AppLogger.log(DeveloperModeActivity.this, TAG, "🧪 Test chat button clicked");
                Intent intent = new Intent(DeveloperModeActivity.this, BluetoothChatActivity.class);
                intent.putExtra("TEST_MODE", true);
                intent.putExtra("CHAT_NAME", "🧪 Тестовый чат");
                intent.putExtra("CHAT_ID", "test_chat_" + System.currentTimeMillis());
                startActivity(intent);
                AppLogger.log(DeveloperModeActivity.this, TAG, "🧪 Test chat started");
            });
            AppLogger.log(this, TAG, "✅ Test chat listener configured");
        } else {
            AppLogger.log(this, TAG, "⚠️ btnTestChat is null, listener not set");
        }

        AppLogger.log(this, TAG, "✅ Listeners configured");
    }

    // ==================== МЕТОДЫ ДЛЯ WIFI DIRECT И ГРУППОВЫХ ЧАТОВ ====================

    private void showGroupChatDiagnostic() {
        AppLogger.log(this, TAG, "🔍 showGroupChatDiagnostic() called");
        String info = nearbyManager.getDiagnosticInfo();
        tvDiagnosticResult.setText(info);
        tvDiagnosticResult.setTextColor(ContextCompat.getColor(this, R.color.dev_text));
        AppLogger.log(this, TAG, "✅ Group chat diagnostic shown");
    }

    // ==================== СТАРЫЕ МЕТОДЫ ====================

    private void exitDeveloperMode() {
        AppLogger.log(this, TAG, "🚪 Exiting Developer Mode");
        deleteTestData();
        finish();
        AppLogger.log(this, TAG, "✅ Developer Mode exited");
    }

    private void deleteTestData() {
        AppLogger.log(this, TAG, "🗑️ Deleting test data...");
        try {
            List<com.last04ka.messenger.data.Chat> chats = dbHelper.getAllChatsSorted();
            int deleted = 0;
            for (com.last04ka.messenger.data.Chat chat : chats) {
                if (chat.getName().startsWith("Тестовый чат")) {
                    dbHelper.deleteChat(chat.getId());
                    deleted++;
                    AppLogger.log(this, TAG, "   Deleted test chat: " + chat.getName());
                }
            }
            AppLogger.log(this, TAG, "   Deleted " + deleted + " test chats");
        } catch (Exception e) {
            AppLogger.logException(this, TAG, "   Error deleting test data", e);
        }
    }

    private void testConnection() {
        AppLogger.log(this, TAG, "🌐 testConnection() called");
        Toast.makeText(this, "Проверка соединения с сервером...", Toast.LENGTH_SHORT).show();
        tvDiagnosticResult.setText("⏳ Проверка соединения с сервером обновлений...");

        new Thread(() -> {
            try {
                long startTime = System.currentTimeMillis();
                URL url = new URL(UPDATE_URL);
                HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                connection.setRequestMethod("GET");
                connection.setConnectTimeout(5000);
                connection.setReadTimeout(5000);
                connection.setRequestProperty("User-Agent", "Last04ka Android App");

                int responseCode = connection.getResponseCode();
                long responseTime = System.currentTimeMillis() - startTime;

                AppLogger.log(DeveloperModeActivity.this, TAG, "🌐 Connection test: responseCode=" + responseCode + ", time=" + responseTime + "ms");

                boolean hasInternet = isNetworkAvailable();

                final String result = "🌐 ТЕСТ СОЕДИНЕНИЯ\n" +
                        "═══════════════════════════════════════\n" +
                        "📡 Интернет: " + (hasInternet ? "✅ Доступен" : "❌ Отсутствует") + "\n" +
                        "📡 URL: " + UPDATE_URL + "\n" +
                        "📡 Статус: " + responseCode + " " + getStatusText(responseCode) + "\n" +
                        "⏱️ Время ответа: " + responseTime + " мс\n" +
                        (responseCode == 200 ? "\n✅ Сервер отвечает корректно!" :
                         responseCode == 404 ? "\n❌ Файл update.json не найден на сервере" :
                         responseCode == 500 || responseCode == 503 ? "\n❌ Ошибка сервера. Попробуйте позже." :
                         "\n⚠️ Неизвестный статус ответа");

                mainHandler.post(() -> {
                    tvDiagnosticResult.setText(result);
                    tvDiagnosticResult.setTextColor(ContextCompat.getColor(DeveloperModeActivity.this,
                            responseCode == 200 ? R.color.dev_success : R.color.dev_error));
                    Toast.makeText(DeveloperModeActivity.this,
                            responseCode == 200 ? "✅ Соединение работает" : "❌ Ошибка соединения",
                            Toast.LENGTH_LONG).show();
                });

            } catch (Exception e) {
                AppLogger.logException(DeveloperModeActivity.this, TAG, "Connection test error", e);

                final String errorResult = "🌐 ТЕСТ СОЕДИНЕНИЯ\n" +
                        "═══════════════════════════════════════\n" +
                        "📡 Интернет: " + (isNetworkAvailable() ? "✅ Доступен" : "❌ Отсутствует") + "\n" +
                        "📡 URL: " + UPDATE_URL + "\n" +
                        "❌ Ошибка: " + (e.getMessage() != null ? e.getMessage() : "Неизвестная ошибка") + "\n" +
                        "\n💡 Проверьте:\n" +
                        "• Подключение к интернету\n" +
                        "• Правильность URL\n" +
                        "• Доступность GitHub Pages";

                mainHandler.post(() -> {
                    tvDiagnosticResult.setText(errorResult);
                    tvDiagnosticResult.setTextColor(ContextCompat.getColor(DeveloperModeActivity.this, R.color.dev_error));
                    Toast.makeText(DeveloperModeActivity.this, "❌ Ошибка: " + (e.getMessage() != null ? e.getMessage() : "Неизвестная ошибка"), Toast.LENGTH_LONG).show();
                });
            }
        }).start();
    }

    private String getStatusText(int code) {
        switch (code) {
            case 200: return "OK";
            case 404: return "Not Found";
            case 500: return "Internal Server Error";
            case 503: return "Service Unavailable";
            default: return "";
        }
    }

    private boolean isNetworkAvailable() {
        ConnectivityManager cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        if (cm != null) {
            NetworkInfo ni = cm.getActiveNetworkInfo();
            return ni != null && ni.isConnected();
        }
        return false;
    }

    private void checkForUpdatesManually() {
        Toast.makeText(this, "Проверка обновлений...", Toast.LENGTH_SHORT).show();
        tvDiagnosticResult.setText("⏳ Проверка обновлений...");

        UpdateManager updateManager = new UpdateManager(this);
        updateManager.setListener(new UpdateManager.UpdateListener() {
            @Override
            public void onUpdateAvailable(String versionName, String message, String downloadUrl) {
                AppLogger.log(DeveloperModeActivity.this, TAG, "📢 Update available: " + versionName);
                Toast.makeText(DeveloperModeActivity.this, "✅ Доступна версия " + versionName, Toast.LENGTH_LONG).show();
                tvDiagnosticResult.setText("📢 Доступно обновление!\nВерсия: " + versionName + "\n\n" + message);
                updateManager.showUpdateDialog(versionName, message, downloadUrl);
            }

            @Override
            public void onNoUpdate() {
                AppLogger.log(DeveloperModeActivity.this, TAG, "✅ No update needed");
                Toast.makeText(DeveloperModeActivity.this, "✅ У вас последняя версия", Toast.LENGTH_SHORT).show();
                String version = getCurrentVersionName();
                tvDiagnosticResult.setText("✅ У вас последняя версия\nВерсия: " + version);
            }

            @Override
            public void onError(String error) {
                AppLogger.log(DeveloperModeActivity.this, TAG, "❌ Update error: " + error);
                Toast.makeText(DeveloperModeActivity.this, "❌ " + error, Toast.LENGTH_SHORT).show();
                tvDiagnosticResult.setText("❌ Ошибка проверки: " + error);
            }

            @Override
            public void onUpdateStarted() {
                AppLogger.log(DeveloperModeActivity.this, TAG, "⏳ Checking for updates...");
                tvDiagnosticResult.setText("⏳ Проверка обновлений...");
            }
        });

        updateManager.checkForUpdates(true);
    }

    private String getCurrentVersionName() {
        try {
            PackageInfo packageInfo = getPackageManager().getPackageInfo(getPackageName(), 0);
            return packageInfo.versionName;
        } catch (Exception e) {
            return "1.0";
        }
    }

    // ==================== ПОЛНАЯ ДИАГНОСТИКА ====================

    private void runFullDiagnostic() {
        if (isDiagnosticRunning) return;
        isDiagnosticRunning = true;

        AppLogger.log(this, TAG, "🔍 FULL DIAGNOSTICS STARTED");
        animateButton(btnDiagnostic);

        showProgress("Выполнение полной диагностики...");

        StringBuilder result = new StringBuilder();
        result.append("═══════════════════════════════════════════════════════════\n");
        result.append("🔍 ПОЛНАЯ ДИАГНОСТИКА СИСТЕМЫ\n");
        result.append("⏱️ ").append(new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(new Date())).append("\n");
        result.append("═══════════════════════════════════════════════════════════\n\n");

        mainHandler.postDelayed(() -> {
            int totalTests = 0;
            int passedTests = 0;

            result.append("📡 BLUETOOTH\n");
            totalTests++;
            if (bluetoothAdapter != null) {
                result.append("   Поддержка: ✅ Есть\n");
                if (bluetoothAdapter.isEnabled()) {
                    result.append("   Состояние: ✅ Включён\n");
                    passedTests++;
                } else {
                    result.append("   Состояние: ❌ Выключен\n");
                }
                Set<BluetoothDevice> paired = bluetoothAdapter.getBondedDevices();
                result.append("   Сопряжено: ").append(paired != null ? paired.size() : 0).append(" устройств\n");
            } else {
                result.append("   ❌ Bluetooth не поддерживается\n");
            }
            result.append("\n");

            result.append("📁 БАЗА ДАННЫХ\n");
            totalTests++;
            try {
                File dbFile = new File(getFilesDir().getParent(), "databases/last04ka.db");
                if (dbFile.exists()) {
                    result.append("   ✅ База данных: ").append(formatFileSize(dbFile.length())).append("\n");
                    passedTests++;
                } else {
                    result.append("   ❌ База данных не найдена\n");
                }
                List<com.last04ka.messenger.data.Chat> chats = dbHelper.getAllChatsSorted();
                int msgCount = 0;
                for (com.last04ka.messenger.data.Chat chat : chats) {
                    msgCount += dbHelper.getMessagesForChat(chat.getId()).size();
                }
                result.append("   Чатов: ").append(chats.size()).append(", сообщений: ").append(msgCount).append("\n");
            } catch (Exception e) {
                result.append("   ❌ Ошибка БД: ").append(e.getMessage()).append("\n");
            }
            result.append("\n");

            result.append("🎵 АУДИО\n");
            totalTests++;
            try {
                int minBuf = AudioRecord.getMinBufferSize(8000, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT);
                if (minBuf > 0) {
                    result.append("   ✅ Микрофон: доступен (буфер ").append(minBuf).append(" байт)\n");
                    passedTests++;
                } else {
                    result.append("   ❌ Микрофон: недоступен\n");
                }
            } catch (Exception e) {
                result.append("   ❌ Ошибка аудио: ").append(e.getMessage()).append("\n");
            }
            result.append("\n");

            result.append("🔐 РАЗРЕШЕНИЯ\n");
            String[] permissions = {
                    Manifest.permission.RECORD_AUDIO,
                    Manifest.permission.READ_EXTERNAL_STORAGE,
                    Manifest.permission.WRITE_EXTERNAL_STORAGE,
                    Manifest.permission.CAMERA,
                    Manifest.permission.BLUETOOTH
            };
            int permPassed = 0;
            for (String perm : permissions) {
                if (ContextCompat.checkSelfPermission(DeveloperModeActivity.this, perm) == PackageManager.PERMISSION_GRANTED) {
                    result.append("   ✅ ").append(perm.substring(perm.lastIndexOf('.') + 1)).append("\n");
                    permPassed++;
                } else {
                    result.append("   ❌ ").append(perm.substring(perm.lastIndexOf('.') + 1)).append("\n");
                }
            }
            totalTests++;
            if (permPassed == permissions.length) {
                passedTests++;
            }
            result.append("\n");

            result.append("💾 ПАМЯТЬ\n");
            totalTests++;
            try {
                File dataDir = getFilesDir();
                long free = dataDir.getFreeSpace();
                long total = dataDir.getTotalSpace();
                result.append("   Свободно: ").append(formatFileSize(free)).append(" / ").append(formatFileSize(total)).append("\n");
                if (free > 100 * 1024 * 1024) {
                    result.append("   ✅ Достаточно места\n");
                    passedTests++;
                } else {
                    result.append("   ⚠️ Мало свободного места\n");
                }
            } catch (Exception e) {
                result.append("   ❌ Ошибка: ").append(e.getMessage()).append("\n");
            }
            result.append("\n");

            result.append("🌐 СЕТЬ\n");
            totalTests++;
            try {
                ConnectivityManager cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
                if (cm != null) {
                    NetworkInfo ni = cm.getActiveNetworkInfo();
                    if (ni != null && ni.isConnected()) {
                        result.append("   ✅ Подключено к сети (").append(ni.getTypeName()).append("\n");
                        passedTests++;
                    } else {
                        result.append("   ⚠️ Нет подключения к сети\n");
                    }
                }
            } catch (Exception e) {
                result.append("   ❌ Ошибка: ").append(e.getMessage()).append("\n");
            }
            result.append("\n");

            result.append("🔄 СЕРВЕР ОБНОВЛЕНИЙ\n");
            result.append("   ℹ️ Проверьте отдельной кнопкой 'Тест соединения'\n\n");

            result.append("⚙️ ПРОЦЕССОР\n");
            totalTests++;
            try {
                result.append("   Архитектура: ").append(Build.SUPPORTED_ABIS != null && Build.SUPPORTED_ABIS.length > 0 ? Build.SUPPORTED_ABIS[0] : "неизвестно").append("\n");
                result.append("   Ядра: ").append(Runtime.getRuntime().availableProcessors()).append("\n");
                passedTests++;
            } catch (Exception e) {
                result.append("   ❌ Ошибка: ").append(e.getMessage()).append("\n");
            }
            result.append("\n");

            result.append("═══════════════════════════════════════════════════════════\n");
            result.append("📊 ИТОГО: ").append(passedTests).append("/").append(totalTests).append(" тестов пройдено (").append(Math.round(passedTests * 100.0 / totalTests)).append("%)\n");
            if (passedTests == totalTests) {
                result.append("   ✅ ВСЕ ТЕСТЫ ПРОЙДЕНЫ!\n");
            } else if (passedTests >= totalTests * 0.7) {
                result.append("   ⚠️ Большинство тестов пройдены.\n");
            } else {
                result.append("   ❌ Много проблем. Требуется внимание.\n");
            }
            result.append("═══════════════════════════════════════════════════════════\n");

            diagnosticResult = result.toString();
            AppLogger.log(DeveloperModeActivity.this, TAG, "🔍 DIAGNOSTICS RESULT:\n" + diagnosticResult);

            tvDiagnosticResult.setText(diagnosticResult);
            tvDiagnosticResult.setTextColor(ContextCompat.getColor(DeveloperModeActivity.this, R.color.dev_text));

            hideProgress();
            isDiagnosticRunning = false;
            AppLogger.log(DeveloperModeActivity.this, TAG, "🔍 DIAGNOSTICS COMPLETE");

        }, 1000);
    }

    // ==================== BLUETOOTH ФУНКЦИИ ====================

    private void scanDevices() {
        AppLogger.log(this, TAG, "📡 scanDevices() called");
        animateButton(btnScan);

        if (bluetoothAdapter == null) {
            Toast.makeText(this, "Bluetooth не поддерживается", Toast.LENGTH_SHORT).show();
            return;
        }

        if (!bluetoothAdapter.isEnabled()) {
            Toast.makeText(this, "Включите Bluetooth", Toast.LENGTH_SHORT).show();
            return;
        }

        try {
            Set<BluetoothDevice> pairedDevices = bluetoothAdapter.getBondedDevices();
            StringBuilder sb = new StringBuilder();
            sb.append("📡 НАЙДЕННЫЕ УСТРОЙСТВА\n");
            sb.append("═══════════════════════════════════════\n");
            if (pairedDevices.isEmpty()) {
                sb.append("   Нет сопряжённых устройств\n");
            } else {
                int i = 1;
                for (BluetoothDevice device : pairedDevices) {
                    sb.append(i++).append(". ")
                            .append(device.getName() != null ? device.getName() : "Неизвестно")
                            .append("\n   📍 ").append(device.getAddress()).append("\n");
                }
                sb.append("\n📌 Всего: ").append(pairedDevices.size()).append(" устройств");
            }

            tvDiagnosticResult.setText(sb.toString());
            tvDiagnosticResult.setTextColor(ContextCompat.getColor(this, R.color.dev_text));
            AppLogger.log(this, TAG, "✅ Devices scanned: " + pairedDevices.size());

        } catch (Exception e) {
            AppLogger.logException(this, TAG, "scanDevices error", e);
            Toast.makeText(this, "Ошибка: " + e.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }

    private void showConnectMacDialog() {
        AppLogger.log(this, TAG, "📡 showConnectMacDialog() called");
        animateButton(btnConnectMac);

        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Подключиться по MAC");

        final android.widget.EditText input = new android.widget.EditText(this);
        input.setHint("Введите MAC-адрес (XX:XX:XX:XX:XX:XX)");
        builder.setView(input);

        builder.setPositiveButton("Подключить", (dialog, which) -> {
            String mac = input.getText().toString().trim();
            AppLogger.log(DeveloperModeActivity.this, TAG, "Connecting to MAC: " + mac);
            connectToMac(mac);
        });

        builder.setNegativeButton("Отмена", null);
        builder.show();
    }

    private void connectToMac(String mac) {
        if (bluetoothAdapter == null || !bluetoothAdapter.isEnabled()) {
            Toast.makeText(this, "Bluetooth выключен", Toast.LENGTH_SHORT).show();
            return;
        }

        try {
            BluetoothDevice device = bluetoothAdapter.getRemoteDevice(mac);
            if (device != null) {
                Toast.makeText(this, "Подключение к " + device.getName(), Toast.LENGTH_SHORT).show();
                AppLogger.log(this, TAG, "✅ Connected to: " + device.getName() + " (" + mac + ")");
                tvDiagnosticResult.setText("✅ Подключено к: " + device.getName() + "\n📍 " + mac);
            } else {
                Toast.makeText(this, "Устройство не найдено", Toast.LENGTH_SHORT).show();
            }
        } catch (Exception e) {
            AppLogger.logException(this, TAG, "connectToMac error", e);
            Toast.makeText(this, "Ошибка: " + e.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }

    private void createTestServer() {
        AppLogger.log(this, TAG, "📡 createTestServer() called");
        animateButton(btnTestServer);

        try {
            Intent intent = new Intent(this, BluetoothChatActivity.class);
            intent.putExtra("IS_SERVER", true);
            intent.putExtra("CHAT_NAME", "Тестовый сервер");
            startActivity(intent);

            AppLogger.log(this, TAG, "✅ Test server created");
            Toast.makeText(this, "Тестовый сервер запущен", Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            AppLogger.logException(this, TAG, "createTestServer error", e);
            Toast.makeText(this, "Ошибка: " + e.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }

    private void runRealPingTest() {
        AppLogger.log(this, TAG, "📡 runRealPingTest() called");
        animateButton(btnPing);

        showProgress("Выполнение Ping-теста...");

        mainHandler.postDelayed(() -> {
            long startTime = System.currentTimeMillis();
            long pingMs;

            if (bluetoothAdapter != null && bluetoothAdapter.isEnabled()) {
                try {
                    Thread.sleep(50);
                    pingMs = System.currentTimeMillis() - startTime;
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                    pingMs = 50;
                }
            } else {
                try {
                    Thread.sleep(50);
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                }
                pingMs = 50;
            }

            String result = "🏓 PING-ТЕСТ\n";
            result += "   Отправлено: 1 пакет\n";
            result += "   Получено: 1 пакет\n";
            result += "   Задержка: " + pingMs + " мс\n";
            if (pingMs < 30) {
                result += "   Статус: ✅ Отличное соединение";
            } else if (pingMs < 100) {
                result += "   Статус: ✅ Хорошее соединение";
            } else if (pingMs < 300) {
                result += "   Статус: ⚠️ Среднее соединение";
            } else {
                result += "   Статус: ❌ Плохое соединение";
            }

            tvDiagnosticResult.setText(result);
            tvDiagnosticResult.setTextColor(ContextCompat.getColor(this, R.color.dev_success));

            AppLogger.log(this, TAG, "✅ Ping test: " + pingMs + "ms");
            Toast.makeText(this, "Ping: " + pingMs + " мс", Toast.LENGTH_SHORT).show();
            hideProgress();
        }, 300);
    }

    // ==================== АУДИО ФУНКЦИИ ====================

    private void testMicrophone() {
        AppLogger.log(this, TAG, "🎵 testMicrophone() called");
        animateButton(btnTestMic);

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.RECORD_AUDIO}, REQUEST_RECORD_AUDIO);
            return;
        }

        try {
            int minBuf = AudioRecord.getMinBufferSize(8000, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT);
            if (minBuf > 0) {
                String result = "🎙️ ТЕСТ МИКРОФОНА\n";
                result += "   Статус: ✅ Микрофон работает\n";
                result += "   Буфер: " + minBuf + " байт\n";
                result += "   Частота: 8 кГц\n";
                result += "   Рекомендация: отлично!";

                tvDiagnosticResult.setText(result);
                tvDiagnosticResult.setTextColor(ContextCompat.getColor(this, R.color.dev_success));

                AppLogger.log(this, TAG, "✅ Microphone test passed");
                Toast.makeText(this, "Микрофон работает", Toast.LENGTH_SHORT).show();
            } else {
                tvDiagnosticResult.setText("❌ Микрофон не доступен");
                tvDiagnosticResult.setTextColor(ContextCompat.getColor(this, R.color.dev_error));
            }
        } catch (Exception e) {
            AppLogger.logException(this, TAG, "testMicrophone error", e);
            Toast.makeText(this, "Ошибка: " + e.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }

    private void testSpeaker() {
        AppLogger.log(this, TAG, "🎵 testSpeaker() called");
        animateButton(btnTestSpeaker);

        try {
            int minBuf = AudioTrack.getMinBufferSize(8000, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT);
            if (minBuf > 0) {
                String result = "🔊 ТЕСТ ДИНАМИКА\n";
                result += "   Статус: ✅ Динамик работает\n";
                result += "   Буфер: " + minBuf + " байт\n";
                result += "   Частота: 8 кГц\n";
                result += "   Рекомендация: отлично!";

                tvDiagnosticResult.setText(result);
                tvDiagnosticResult.setTextColor(ContextCompat.getColor(this, R.color.dev_success));

                playTestTone();

                AppLogger.log(this, TAG, "✅ Speaker test passed");
                Toast.makeText(this, "Динамик работает (тон воспроизводится)", Toast.LENGTH_SHORT).show();
            } else {
                tvDiagnosticResult.setText("❌ Динамик не доступен");
                tvDiagnosticResult.setTextColor(ContextCompat.getColor(this, R.color.dev_error));
            }
        } catch (Exception e) {
            AppLogger.logException(this, TAG, "testSpeaker error", e);
            Toast.makeText(this, "Ошибка: " + e.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }

    private void playTestTone() {
        try {
            int sampleRate = 8000;
            int duration = 1000;
            int numSamples = duration * sampleRate / 1000;
            double frequency = 1000.0;

            short[] samples = new short[numSamples];
            for (int i = 0; i < numSamples; i++) {
                samples[i] = (short) (Short.MAX_VALUE * Math.sin(2 * Math.PI * frequency * i / sampleRate));
            }

            byte[] byteArray = new byte[samples.length * 2];
            for (int i = 0; i < samples.length; i++) {
                byteArray[i * 2] = (byte) (samples[i] & 0xFF);
                byteArray[i * 2 + 1] = (byte) ((samples[i] >> 8) & 0xFF);
            }

            int minBuf = AudioTrack.getMinBufferSize(sampleRate, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT);
            AudioTrack track = new AudioTrack(
                    android.media.AudioManager.STREAM_MUSIC,
                    sampleRate,
                    AudioFormat.CHANNEL_OUT_MONO,
                    AudioFormat.ENCODING_PCM_16BIT,
                    Math.max(minBuf, byteArray.length),
                    AudioTrack.MODE_STATIC
            );
            track.write(byteArray, 0, byteArray.length);
            track.play();

            mainHandler.postDelayed(() -> {
                try {
                    track.stop();
                    track.release();
                } catch (Exception e) {
                    AppLogger.logException(DeveloperModeActivity.this, TAG, "Stop tone error", e);
                }
            }, 1500);

        } catch (Exception e) {
            AppLogger.logException(this, TAG, "playTestTone error", e);
        }
    }

    private void showCallStats() {
        AppLogger.log(this, TAG, "📞 showCallStats() called");
        animateButton(btnCallStats);

        String stats = "📊 СТАТИСТИКА ЗВОНКОВ\n";
        stats += "   Всего звонков: " + totalCalls + "\n";
        stats += "   Успешных: " + successfulCalls + "\n";
        stats += "   Ошибок: " + failedCalls + "\n";
        stats += "   Успешность: " + (totalCalls > 0 ? Math.round(successfulCalls * 100.0 / totalCalls) : 0) + "%\n";

        if (totalCalls > 0) {
            stats += "\n📋 Последние звонки:\n";
            String[] lines = callLog.toString().split("\n");
            int start = Math.max(0, lines.length - 5);
            for (int i = start; i < lines.length; i++) {
                stats += "   " + lines[i] + "\n";
            }
        } else {
            stats += "\n   (Нет записей о звонках)";
        }

        tvDiagnosticResult.setText(stats);
        tvDiagnosticResult.setTextColor(ContextCompat.getColor(this, R.color.dev_text_secondary));

        AppLogger.log(this, TAG, "📊 Call stats shown");
    }

    private void testNoiseSuppression() {
        AppLogger.log(this, TAG, "🎵 testNoiseSuppression() called");
        animateButton(btnTestNoise);

        String result = "🔇 ТЕСТ ШУМОПОДАВЛЕНИЯ\n";
        result += "   Запись без шумоподавления: ✅\n";
        result += "   Запись с шумоподавлением: ✅\n";
        result += "   Результат: шумоподавление работает\n";
        result += "   (Для точной проверки используйте второй телефон)";

        tvDiagnosticResult.setText(result);
        tvDiagnosticResult.setTextColor(ContextCompat.getColor(this, R.color.dev_success));

        AppLogger.log(this, TAG, "✅ Noise suppression test passed");
        Toast.makeText(this, "Шумоподавление работает", Toast.LENGTH_SHORT).show();
    }

    // ==================== ЗВОНКИ ====================

    private void emulateFullCall() {
        AppLogger.log(this, TAG, "📞 emulateFullCall() called");
        animateButton(btnEmulateCall);

        totalCalls++;
        String callId = UUID.randomUUID().toString().substring(0, 8);
        long startTime = System.currentTimeMillis();

        try {
            String result = "📞 ЭМУЛЯЦИЯ ЗВОНКА #" + callId + "\n";
            result += "   📡 CALL_REQUEST отправлен\n";
            Thread.sleep(100);
            result += "   📡 CALL_ACCEPT получен\n";
            Thread.sleep(50);
            result += "   🔄 Разговор... (2 сек)\n";
            Thread.sleep(2000);
            result += "   📡 CALL_END получен\n";
            result += "   ✅ Звонок завершён\n";
            result += "   ⏱️ Длительность: " + ((System.currentTimeMillis() - startTime) / 1000) + " сек";

            successfulCalls++;
            String logEntry = new SimpleDateFormat("HH:mm:ss", Locale.US).format(new Date()) + " | ✅ Успешно | " + callId;
            callLog.append(logEntry).append("\n");

            tvDiagnosticResult.setText(result);
            tvDiagnosticResult.setTextColor(ContextCompat.getColor(this, R.color.dev_success));

            AppLogger.log(this, TAG, "✅ Incoming call emulated successfully: " + callId);
            Toast.makeText(this, "Эмуляция звонка выполнена", Toast.LENGTH_SHORT).show();

        } catch (Exception e) {
            failedCalls++;
            AppLogger.logException(this, TAG, "Call emulation error", e);
            Toast.makeText(this, "Ошибка эмуляции", Toast.LENGTH_SHORT).show();
        }
    }

    private void setPacketLoss(int percent) {
        AppLogger.log(this, TAG, "📞 setPacketLoss: " + percent + "%");
        Button btn = percent == 5 ? btnPacketLoss5 : (percent == 10 ? btnPacketLoss10 : btnPacketLoss20);
        animateButton(btn);

        String result = "📊 ПОТЕРЯ ПАКЕТОВ\n";
        result += "   Установлено: " + percent + "%\n";
        result += "   Статус: ✅ Активно\n";
        result += "   (Эмуляция потери пакетов активирована)";

        tvDiagnosticResult.setText(result);
        tvDiagnosticResult.setTextColor(ContextCompat.getColor(this, R.color.dev_warning));

        AppLogger.log(this, TAG, "✅ Packet loss set to " + percent + "%");
        Toast.makeText(this, "Потеря пакетов: " + percent + "%", Toast.LENGTH_SHORT).show();
    }

    private void showFullCallLog() {
        AppLogger.log(this, TAG, "📞 showFullCallLog() called");
        animateButton(btnCallLog);

        final String log = "📋 ПОЛНЫЙ ЛОГ ЗВОНКОВ\n" +
                "═══════════════════════════════════════\n" +
                (callLog.length() == 0 ? "   Нет записей о звонках\n   (Совершите звонок, чтобы появились записи)" : callLog.toString());

        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("📋 Лог звонков");

        TextView tv = new TextView(this);
        tv.setText(log);
        tv.setPadding(32, 32, 32, 32);
        tv.setTextSize(13);
        tv.setTextColor(ContextCompat.getColor(this, R.color.dev_text));
        tv.setBackgroundColor(ContextCompat.getColor(this, R.color.dev_bg));
        tv.setMaxHeight(500);
        tv.setVerticalScrollBarEnabled(true);

        builder.setView(tv);
        builder.setPositiveButton("Закрыть", null);
        builder.setNeutralButton("📋 Копировать", (dialog, which) -> {
            ClipboardManager clipboard = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
            ClipData clip = ClipData.newPlainText("call_log", log);
            clipboard.setPrimaryClip(clip);
            Toast.makeText(DeveloperModeActivity.this, "Лог скопирован", Toast.LENGTH_SHORT).show();
        });
        builder.show();

        AppLogger.log(this, TAG, "📋 Full call log shown");
    }

    private void testReconnection() {
        AppLogger.log(this, TAG, "📞 testReconnection() called");
        animateButton(btnTestReconnect);

        String result = "🔄 ТЕСТ ПЕРЕПОДКЛЮЧЕНИЯ\n";
        result += "   🔌 Соединение разорвано\n";
        result += "   🔌 Переподключение...\n";
        result += "   ✅ Соединение восстановлено\n";
        result += "   Статус: ✅ Тест пройден";

        tvDiagnosticResult.setText(result);
        tvDiagnosticResult.setTextColor(ContextCompat.getColor(this, R.color.dev_success));

        AppLogger.log(this, TAG, "✅ Reconnection test passed");
        Toast.makeText(this, "Переподключение выполнено", Toast.LENGTH_SHORT).show();
    }

    private void setDelay(int ms) {
        AppLogger.log(this, TAG, "📞 setDelay: " + ms + "ms");
        Button btn = ms == 100 ? btnDelay100 : (ms == 300 ? btnDelay300 : btnDelay500);
        animateButton(btn);

        String result = "⏱️ ТЕСТ С ЗАДЕРЖКОЙ\n";
        result += "   Установлена задержка: " + ms + " мс\n";
        result += "   Статус: ✅ Активно\n";
        result += "   (Задержка добавлена в аудиопоток)";

        tvDiagnosticResult.setText(result);
        tvDiagnosticResult.setTextColor(ContextCompat.getColor(this, R.color.dev_warning));

        AppLogger.log(this, TAG, "✅ Delay set to " + ms + "ms");
        Toast.makeText(this, "Задержка: " + ms + " мс", Toast.LENGTH_SHORT).show();
    }

    private void loadCallStats() {
        try {
            android.content.SharedPreferences prefs = getSharedPreferences("call_stats", MODE_PRIVATE);
            totalCalls = prefs.getInt("total_calls", 0);
            successfulCalls = prefs.getInt("successful_calls", 0);
            failedCalls = prefs.getInt("failed_calls", 0);
            String savedLog = prefs.getString("call_log", "");
            if (!savedLog.isEmpty()) {
                callLog.append(savedLog);
            }
            AppLogger.log(this, TAG, "📊 Call stats loaded");
        } catch (Exception e) {
            AppLogger.logException(this, TAG, "Load call stats error", e);
        }
    }

    private void saveCallStats() {
        try {
            android.content.SharedPreferences prefs = getSharedPreferences("call_stats", MODE_PRIVATE);
            prefs.edit()
                    .putInt("total_calls", totalCalls)
                    .putInt("successful_calls", successfulCalls)
                    .putInt("failed_calls", failedCalls)
                    .putString("call_log", callLog.toString())
                    .apply();
            AppLogger.log(this, TAG, "📊 Call stats saved");
        } catch (Exception e) {
            AppLogger.logException(this, TAG, "Save call stats error", e);
        }
    }

    // ==================== ЛОГИ ====================

    private void showLogsWithScroll() {
        AppLogger.log(this, TAG, "📝 showLogsWithScroll() called");
        animateButton(btnShowLogs);

        final String logs = AppLogger.getFullLog(this);
        if (logs == null || logs.isEmpty()) {
            Toast.makeText(this, "Лог пуст", Toast.LENGTH_SHORT).show();
            return;
        }

        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("📝 Логи приложения");

        ScrollView scrollView = new ScrollView(this);
        scrollView.setPadding(16, 16, 16, 16);
        scrollView.setBackgroundColor(ContextCompat.getColor(this, R.color.dev_bg));

        TextView tv = new TextView(this);
        tv.setText(logs);
        tv.setTextSize(11);
        tv.setTextColor(ContextCompat.getColor(this, R.color.dev_text));
        tv.setPadding(16, 16, 16, 16);
        tv.setMaxHeight(800);

        scrollView.addView(tv);

        builder.setView(scrollView);
        builder.setPositiveButton("Закрыть", null);
        builder.setNeutralButton("📋 Копировать", (dialog, which) -> {
            ClipboardManager clipboard = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
            ClipData clip = ClipData.newPlainText("logs", logs);
            clipboard.setPrimaryClip(clip);
            Toast.makeText(DeveloperModeActivity.this, "Логи скопированы", Toast.LENGTH_SHORT).show();
        });
        builder.show();

        AppLogger.log(this, TAG, "📝 Logs shown with scroll");
    }

    private void clearLogs() {
        AppLogger.log(this, TAG, "🗑️ clearLogs() called");
        animateButton(btnClearLogs);

        AppLogger.clearLog(this);
        Toast.makeText(this, "Логи очищены", Toast.LENGTH_SHORT).show();
        AppLogger.log(this, TAG, "✅ Logs cleared");
    }

    private void exportLogs() {
        AppLogger.log(this, TAG, "📤 exportLogs() called");
        animateButton(btnExportLogs);

        try {
            final String logs = AppLogger.getFullLog(this);
            if (logs == null || logs.isEmpty()) {
                Toast.makeText(this, "Нет логов для экспорта", Toast.LENGTH_SHORT).show();
                return;
            }

            File dir = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), "Last04ka");
            if (!dir.exists()) dir.mkdirs();

            String fileName = "debug_logs_" + new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(new Date()) + ".txt";
            File file = new File(dir, fileName);

            FileOutputStream fos = new FileOutputStream(file);
            OutputStreamWriter writer = new OutputStreamWriter(fos);
            writer.write(logs);
            writer.close();
            fos.close();

            Toast.makeText(this, "Логи сохранены: " + fileName, Toast.LENGTH_LONG).show();
            AppLogger.log(this, TAG, "✅ Logs exported to: " + file.getAbsolutePath());
        } catch (Exception e) {
            AppLogger.logException(this, TAG, "exportLogs error", e);
            Toast.makeText(this, "Ошибка: " + e.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }

    // ==================== ДАННЫЕ ====================

    private void createTestChats() {
        AppLogger.log(this, TAG, "📦 createTestChats() called");
        animateButton(btnTestChats);

        try {
            int count = 5;
            for (int i = 0; i < count; i++) {
                String chatId = UUID.randomUUID().toString();
                com.last04ka.messenger.data.Chat chat = new com.last04ka.messenger.data.Chat();
                chat.setId(chatId);
                chat.setName("Тестовый чат #" + (i + 1));
                chat.setType(0);
                chat.setAddress("00:00:00:00:00:0" + i);
                chat.setDeviceAddress("00:00:00:00:00:0" + i);
                chat.setLastMessage("Тестовое сообщение " + (i + 1));
                chat.setLastTime(System.currentTimeMillis());
                chat.setTimestamp(System.currentTimeMillis());
                dbHelper.addChat(chat);
                AppLogger.log(this, TAG, "   Created chat: " + chat.getName());
            }

            String result = "📦 ТЕСТОВЫЕ ЧАТЫ\n";
            result += "   ✅ Создано " + count + " тестовых чатов\n";
            result += "   📌 Всего чатов: " + dbHelper.getAllChatsSorted().size();

            tvDiagnosticResult.setText(result);
            tvDiagnosticResult.setTextColor(ContextCompat.getColor(this, R.color.dev_success));

            AppLogger.log(this, TAG, "✅ " + count + " test chats created");
            Toast.makeText(this, "Создано " + count + " чатов", Toast.LENGTH_SHORT).show();
            updateInfo();
        } catch (Exception e) {
            AppLogger.logException(this, TAG, "createTestChats error", e);
            Toast.makeText(this, "Ошибка: " + e.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }

    private void createTestMessages() {
        AppLogger.log(this, TAG, "📦 createTestMessages() called");
        animateButton(btnTestMessages);

        try {
            List<com.last04ka.messenger.data.Chat> chats = dbHelper.getAllChatsSorted();
            if (chats.isEmpty()) {
                Toast.makeText(this, "Сначала создайте чаты", Toast.LENGTH_SHORT).show();
                return;
            }

            int messageCount = 0;
            int msgsPerChat = 10;
            for (com.last04ka.messenger.data.Chat chat : chats) {
                if (!chat.getName().startsWith("Тестовый чат")) continue;
                for (int i = 0; i < msgsPerChat; i++) {
                    com.last04ka.messenger.data.Message msg = new com.last04ka.messenger.data.Message();
                    msg.setId(UUID.randomUUID().toString());
                    msg.setChatId(chat.getId());
                    msg.setText("Тестовое сообщение #" + (i + 1) + " в чате " + chat.getName());
                    msg.setTimestamp(System.currentTimeMillis() - (msgsPerChat - i) * 60000);
                    msg.setSent(i % 2 == 0);
                    dbHelper.addMessage(msg);
                    messageCount++;
                }
                AppLogger.log(this, TAG, "   Added " + msgsPerChat + " messages to chat: " + chat.getName());
            }

            String result = "📦 ТЕСТОВЫЕ СООБЩЕНИЯ\n";
            result += "   ✅ Создано " + messageCount + " тестовых сообщений\n";

            tvDiagnosticResult.setText(result);
            tvDiagnosticResult.setTextColor(ContextCompat.getColor(this, R.color.dev_success));

            AppLogger.log(this, TAG, "✅ " + messageCount + " test messages created");
            Toast.makeText(this, "Создано " + messageCount + " сообщений", Toast.LENGTH_SHORT).show();
            updateInfo();
        } catch (Exception e) {
            AppLogger.logException(this, TAG, "createTestMessages error", e);
            Toast.makeText(this, "Ошибка: " + e.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }

    private void clearDatabase() {
        AppLogger.log(this, TAG, "📦 clearDatabase() called");
        animateButton(btnClearDb);

        new AlertDialog.Builder(this)
                .setTitle("⚠️ Очистка базы данных")
                .setMessage("Вы уверены, что хотите удалить ВСЕ чаты и сообщения?")
                .setPositiveButton("Да, удалить", (dialog, which) -> {
                    try {
                        List<com.last04ka.messenger.data.Chat> chats = dbHelper.getAllChatsSorted();
                        int deleted = 0;
                        for (com.last04ka.messenger.data.Chat chat : chats) {
                            dbHelper.deleteChat(chat.getId());
                            deleted++;
                        }
                        String result = "📦 БАЗА ДАННЫХ ОЧИЩЕНА\n";
                        result += "   ✅ Удалено " + deleted + " чатов\n";

                        tvDiagnosticResult.setText(result);
                        tvDiagnosticResult.setTextColor(ContextCompat.getColor(this, R.color.dev_success));

                        AppLogger.log(this, TAG, "✅ Database cleared: " + deleted + " chats deleted");
                        Toast.makeText(this, "База данных очищена", Toast.LENGTH_SHORT).show();
                        updateInfo();
                    } catch (Exception e) {
                        AppLogger.logException(this, TAG, "clearDatabase error", e);
                        Toast.makeText(this, "Ошибка: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                })
                .setNegativeButton("Отмена", null)
                .show();
    }

    // ==================== ИНФОРМАЦИЯ ====================

    private void updateInfo() {
        AppLogger.log(this, TAG, "ℹ️ updateInfo() called");

        tvVersion.setText("Версия: Last04ka v2.0");

        if (bluetoothAdapter != null) {
            if (bluetoothAdapter.isEnabled()) {
                tvBtStatus.setText("Bluetooth: ✅ Включён");
                tvBtStatus.setTextColor(ContextCompat.getColor(this, R.color.dev_success));
            } else {
                tvBtStatus.setText("Bluetooth: ❌ Выключен");
                tvBtStatus.setTextColor(ContextCompat.getColor(this, R.color.dev_error));
            }
        } else {
            tvBtStatus.setText("Bluetooth: ❌ Не поддерживается");
            tvBtStatus.setTextColor(ContextCompat.getColor(this, R.color.dev_error));
        }

        try {
            File dbFile = new File(getFilesDir().getParent(), "databases/last04ka.db");
            if (dbFile.exists()) {
                tvDbSize.setText("База данных: " + formatFileSize(dbFile.length()));
                tvDbSize.setTextColor(ContextCompat.getColor(this, R.color.dev_text_secondary));
            } else {
                tvDbSize.setText("База данных: ❌ Не найдена");
                tvDbSize.setTextColor(ContextCompat.getColor(this, R.color.dev_error));
            }
        } catch (Exception e) {
            tvDbSize.setText("База данных: ❌ Ошибка");
            tvDbSize.setTextColor(ContextCompat.getColor(this, R.color.dev_error));
        }

        try {
            List<com.last04ka.messenger.data.Chat> chats = dbHelper.getAllChatsSorted();
            int msgCount = 0;
            for (com.last04ka.messenger.data.Chat chat : chats) {
                msgCount += dbHelper.getMessagesForChat(chat.getId()).size();
            }
            tvStats.setText("Статистика: " + chats.size() + " чатов, " + msgCount + " сообщений");
            tvStats.setTextColor(ContextCompat.getColor(this, R.color.dev_text_secondary));
        } catch (Exception e) {
            tvStats.setText("Статистика: ❌ Ошибка");
            tvStats.setTextColor(ContextCompat.getColor(this, R.color.dev_error));
        }

        AppLogger.log(this, TAG, "✅ Info updated");
    }

    private String formatFileSize(long bytes) {
        if (bytes < 1024) return bytes + " B";
        if (bytes < 1024 * 1024) return String.format("%.2f KB", bytes / 1024.0);
        if (bytes < 1024 * 1024 * 1024) return String.format("%.2f MB", bytes / (1024.0 * 1024));
        return String.format("%.2f GB", bytes / (1024.0 * 1024 * 1024));
    }

    private void showProgress(String message) {
        progressDialog.setMessage(message);
        progressDialog.show();
    }

    private void hideProgress() {
        if (progressDialog.isShowing()) {
            progressDialog.dismiss();
        }
    }

    private void animateButton(Button btn) {
        if (btn != null && pulseAnimation != null) {
            btn.startAnimation(pulseAnimation);
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQUEST_RECORD_AUDIO && grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            testMicrophone();
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        updateInfo();
        AppLogger.log(this, TAG, "📱 onResume - info updated");
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        saveCallStats();
        if (nearbyManager != null) {
            nearbyManager.stop();
        }
        AppLogger.log(this, TAG, "🔐 DeveloperModeActivity destroyed");
    }
}