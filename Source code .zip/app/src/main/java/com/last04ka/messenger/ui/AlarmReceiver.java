package com.last04ka.messenger.ui;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.media.Ringtone;
import android.media.RingtoneManager;
import android.net.Uri;
import android.widget.Toast;

public class AlarmReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        String label = intent.getStringExtra("label");
        String message = "⏰ " + (label != null && !label.isEmpty() ? label : "Будильник!");
        Toast.makeText(context, message, Toast.LENGTH_LONG).show();

        try {
            Uri uri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM);
            Ringtone ringtone = RingtoneManager.getRingtone(context, uri);
            if (ringtone != null) {
                ringtone.play();
            }
        } catch (Exception e) {
            // Без звука, если не получилось
        }
    }
}