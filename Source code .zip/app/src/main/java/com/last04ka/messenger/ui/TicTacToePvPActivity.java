package com.last04ka.messenger.ui;

import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.last04ka.messenger.R;
import com.last04ka.messenger.connectivity.BluetoothManager;
import com.last04ka.messenger.utils.AppLogger;
import com.last04ka.messenger.utils.ThemeManager;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.UUID;

public class TicTacToePvPActivity extends AppCompatActivity {

    private static final String TAG = "TicTacToePvP";
    private static final int REQUEST_ENABLE_BT = 1;

    // ==================== UI ====================
    private TextView statusText, scoreText, opponentNameText;
    private BoardView boardView;
    private Button btnScan, btnConnect, btnDisconnect, btnNewGame, btnBack;

    // ==================== ИГРА ====================
    private int[][] board = new int[3][3];
    private int mySymbol = 1; // 1 = X, 2 = O
    private int currentPlayer = 1; // 1 = X, 2 = O
    private boolean gameActive = false;
    private boolean isMyTurn = false;
    private int myScore = 0;
    private int opponentScore = 0;
    private int draws = 0;
    private String opponentName = "Противник";

    // ==================== BLUETOOTH ====================
    private BluetoothManager bluetoothManager;
    private BluetoothAdapter bluetoothAdapter;
    private Handler handler = new Handler(Looper.getMainLooper());
    private boolean isConnected = false;
    private boolean isServer = false;
    private boolean isHost = false;
    private String connectedDeviceName = "";
    private String connectedDeviceAddress = "";

    // ==================== ОБНАРУЖЕНИЕ УСТРОЙСТВ ====================
    private BroadcastReceiver discoveryReceiver;
    private boolean receiverRegistered = false;
    private List<BluetoothDevice> discoveredDevices = new ArrayList<>();
    private AlertDialog devicesDialog;

    // ==================== ЛОГИРОВАНИЕ ====================
    private int moveCount = 0;
    private long gameStartTime = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        setTheme(ThemeManager.getThemeResource(this));
        super.onCreate(savedInstanceState);
        AppLogger.log(this, TAG, "═══════════════════════════════════════════════════════════");
        AppLogger.log(this, TAG, "❌⭕ TicTacToePvPActivity onCreate START");
        AppLogger.log(this, TAG, "═══════════════════════════════════════════════════════════");

        try {
            setContentView(R.layout.activity_tictactoe_pvp);
            AppLogger.log(this, TAG, "✅ Content view set");

            initViews();
            AppLogger.log(this, TAG, "✅ Views initialized");

            initBluetooth();
            AppLogger.log(this, TAG, "✅ Bluetooth initialized");

            setupListeners();
            AppLogger.log(this, TAG, "✅ Listeners setup");

            initGame();
            AppLogger.log(this, TAG, "✅ Game initialized");

            // Регистрируем в BluetoothChatActivity для обратной совместимости
            BluetoothChatActivity.setActiveTicTacToeActivity(this);
            AppLogger.log(this, TAG, "✅ Registered in BluetoothChatActivity");

            AppLogger.log(this, TAG, "═══════════════════════════════════════════════════════════");
            AppLogger.log(this, TAG, "❌⭕ TicTacToePvPActivity onCreate SUCCESS");
            AppLogger.log(this, TAG, "═══════════════════════════════════════════════════════════");

        } catch (Exception e) {
            AppLogger.logException(this, TAG, "❌ FATAL: onCreate error", e);
            Toast.makeText(this, "Ошибка: " + e.getMessage(), Toast.LENGTH_LONG).show();
            finish();
        }
    }

    private void initViews() {
        statusText = findViewById(R.id.tv_status);
        scoreText = findViewById(R.id.tv_score);
        opponentNameText = findViewById(R.id.tv_opponent_name);
        boardView = findViewById(R.id.board_view);
        btnScan = findViewById(R.id.btn_scan);
        btnConnect = findViewById(R.id.btn_connect);
        btnDisconnect = findViewById(R.id.btn_disconnect);
        btnNewGame = findViewById(R.id.btn_new_game);
        btnBack = findViewById(R.id.btn_back);

        boardView.setGameCallback(new BoardView.GameCallback() {
            @Override
            public void onCellClick(int row, int col) {
                AppLogger.log(TicTacToePvPActivity.this, TAG, "🎮 Cell clicked: row=" + row + ", col=" + col);
                handleCellClick(row, col);
            }
        });

        AppLogger.log(this, TAG, "Views: statusText=" + (statusText != null) +
                ", boardView=" + (boardView != null));
    }

    private void initBluetooth() {
        AppLogger.log(this, TAG, "📡 initBluetooth() START");

        bluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
        if (bluetoothAdapter == null) {
            AppLogger.log(this, TAG, "❌ Bluetooth not supported");
            Toast.makeText(this, "Bluetooth не поддерживается", Toast.LENGTH_LONG).show();
            finish();
            return;
        }

        if (!bluetoothAdapter.isEnabled()) {
            AppLogger.log(this, TAG, "⚠️ Bluetooth is disabled, requesting enable");
            Intent enableBtIntent = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
            startActivityForResult(enableBtIntent, REQUEST_ENABLE_BT);
        } else {
            AppLogger.log(this, TAG, "✅ Bluetooth is enabled");
        }

        bluetoothManager = new BluetoothManager(this, handler);
        bluetoothManager.setCallback(new BluetoothManager.MessageCallback() {
            @Override
            public void onMessageReceived(String message) {
                AppLogger.log(TicTacToePvPActivity.this, TAG, "📨📨📨 onMessageReceived: " + message);
                handleBluetoothMessage(message);
            }

            @Override
            public void onConnectionStateChanged(int state) {
                AppLogger.log(TicTacToePvPActivity.this, TAG, "🔌 Connection state changed: " + state);
                runOnUiThread(() -> {
                    isConnected = (state == BluetoothManager.STATE_CONNECTED);
                    AppLogger.log(TicTacToePvPActivity.this, TAG, "   isConnected=" + isConnected);
                    updateConnectionUI();
                    if (isConnected) {
                        Toast.makeText(TicTacToePvPActivity.this,
                                "✅ Подключено к " + connectedDeviceName, Toast.LENGTH_SHORT).show();
                        if (isServer) {
                            sendMessage("GAME_INIT|" + mySymbol);
                            AppLogger.log(TicTacToePvPActivity.this, TAG, "📤 GAME_INIT sent as server");
                        }
                    } else {
                        Toast.makeText(TicTacToePvPActivity.this,
                                "❌ Соединение потеряно", Toast.LENGTH_SHORT).show();
                    }
                });
            }

            @Override
            public void onDeviceDisconnected() {
                AppLogger.log(TicTacToePvPActivity.this, TAG, "🔌 Device disconnected");
                runOnUiThread(() -> {
                    isConnected = false;
                    updateConnectionUI();
                    statusText.setText("❌ Отключено");
                    Toast.makeText(TicTacToePvPActivity.this,
                            "Устройство отключено", Toast.LENGTH_LONG).show();
                });
            }
        });

        AppLogger.log(this, TAG, "📡 initBluetooth() END");
    }

    private void setupListeners() {
        AppLogger.log(this, TAG, "🔘 setupListeners() START");

        btnScan.setOnClickListener(v -> {
            AppLogger.log(TicTacToePvPActivity.this, TAG, "🔘 Scan button clicked");
            scanForDevices();
        });

        btnConnect.setOnClickListener(v -> {
            AppLogger.log(TicTacToePvPActivity.this, TAG, "🔘 Connect button clicked");
            showConnectDialog();
        });

        btnDisconnect.setOnClickListener(v -> {
            AppLogger.log(TicTacToePvPActivity.this, TAG, "🔘 Disconnect button clicked");
            disconnect();
        });

        btnNewGame.setOnClickListener(v -> {
            AppLogger.log(TicTacToePvPActivity.this, TAG, "🔘 New Game button clicked");
            if (isConnected) {
                sendMessage("GAME_RESET");
                AppLogger.log(TicTacToePvPActivity.this, TAG, "📤 GAME_RESET sent");
                resetGame();
            } else {
                Toast.makeText(TicTacToePvPActivity.this, "Нет подключения", Toast.LENGTH_SHORT).show();
            }
        });

        btnBack.setOnClickListener(v -> {
            AppLogger.log(TicTacToePvPActivity.this, TAG, "🔘 Back button clicked");
            disconnect();
            finish();
        });

        AppLogger.log(this, TAG, "🔘 setupListeners() END");
    }

    // ==================== ОБНАРУЖЕНИЕ УСТРОЙСТВ ====================

    private void scanForDevices() {
        AppLogger.log(this, TAG, "🔍 scanForDevices() START");

        if (bluetoothAdapter == null) {
            AppLogger.log(this, TAG, "❌ BluetoothAdapter is null");
            Toast.makeText(this, "Bluetooth недоступен", Toast.LENGTH_SHORT).show();
            return;
        }

        if (!bluetoothAdapter.isEnabled()) {
            AppLogger.log(this, TAG, "⚠️ Bluetooth is disabled");
            Toast.makeText(this, "Включите Bluetooth", Toast.LENGTH_SHORT).show();
            return;
        }

        discoveredDevices.clear();

        // Добавляем уже сопряжённые устройства
        Set<BluetoothDevice> pairedDevices = bluetoothAdapter.getBondedDevices();
        if (pairedDevices != null && !pairedDevices.isEmpty()) {
            AppLogger.log(this, TAG, "📋 Paired devices: " + pairedDevices.size());
            for (BluetoothDevice device : pairedDevices) {
                discoveredDevices.add(device);
                AppLogger.log(this, TAG, "   Paired: " + device.getName() + " (" + device.getAddress() + ")");
            }
        }

        // Регистрируем BroadcastReceiver для обнаружения новых устройств
        if (discoveryReceiver == null) {
            discoveryReceiver = new BroadcastReceiver() {
                @Override
                public void onReceive(Context context, Intent intent) {
                    String action = intent.getAction();
                    AppLogger.log(TicTacToePvPActivity.this, TAG, "📡 BroadcastReceiver: " + action);
                    if (BluetoothDevice.ACTION_FOUND.equals(action)) {
                        BluetoothDevice device = intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE);
                        if (device != null && !discoveredDevices.contains(device)) {
                            discoveredDevices.add(device);
                            AppLogger.log(TicTacToePvPActivity.this, TAG,
                                    "   Found device: " + device.getName() + " (" + device.getAddress() + ")");
                            updateDevicesDialog();
                        }
                    } else if (BluetoothAdapter.ACTION_DISCOVERY_FINISHED.equals(action)) {
                        AppLogger.log(TicTacToePvPActivity.this, TAG, "📡 Discovery finished");
                        Toast.makeText(TicTacToePvPActivity.this,
                                "Поиск завершён, найдено: " + discoveredDevices.size(),
                                Toast.LENGTH_SHORT).show();
                    }
                }
            };
        }

        try {
            if (!receiverRegistered) {
                IntentFilter filter = new IntentFilter();
                filter.addAction(BluetoothDevice.ACTION_FOUND);
                filter.addAction(BluetoothAdapter.ACTION_DISCOVERY_FINISHED);
                registerReceiver(discoveryReceiver, filter);
                receiverRegistered = true;
                AppLogger.log(this, TAG, "✅ Receiver registered");
            }

            if (bluetoothAdapter.isDiscovering()) {
                bluetoothAdapter.cancelDiscovery();
                AppLogger.log(this, TAG, "⚠️ Cancelled previous discovery");
            }

            boolean started = bluetoothAdapter.startDiscovery();
            AppLogger.log(this, TAG, "🔍 Discovery started: " + started);
            Toast.makeText(this, "Поиск устройств...", Toast.LENGTH_SHORT).show();

            // Показываем диалог со списком устройств
            showDevicesDialog();

        } catch (Exception e) {
            AppLogger.logException(this, TAG, "❌ Scan error", e);
            Toast.makeText(this, "Ошибка сканирования: " + e.getMessage(), Toast.LENGTH_SHORT).show();
        }

        AppLogger.log(this, TAG, "🔍 scanForDevices() END");
    }

    private void showDevicesDialog() {
        AppLogger.log(this, TAG, "📋 showDevicesDialog() START");

        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("📡 Выберите устройство");

        if (discoveredDevices.isEmpty()) {
            builder.setMessage("Устройства не найдены.\nНажмите 'Обновить' для повторного поиска.");
            builder.setPositiveButton("Обновить", (dialog, which) -> {
                AppLogger.log(TicTacToePvPActivity.this, TAG, "🔄 Refresh devices");
                dialog.dismiss();
                scanForDevices();
            });
            builder.setNegativeButton("Отмена", null);
        } else {
            String[] items = new String[discoveredDevices.size()];
            for (int i = 0; i < discoveredDevices.size(); i++) {
                BluetoothDevice device = discoveredDevices.get(i);
                String name = device.getName();
                if (name == null || name.isEmpty()) {
                    name = "Неизвестное устройство";
                }
                items[i] = name + "\n" + device.getAddress();
            }
            builder.setItems(items, (dialog, which) -> {
                BluetoothDevice device = discoveredDevices.get(which);
                AppLogger.log(TicTacToePvPActivity.this, TAG,
                        "📌 Device selected: " + device.getName() + " (" + device.getAddress() + ")");
                dialog.dismiss();
                connectToDevice(device);
            });
            builder.setNegativeButton("Отмена", null);
            builder.setNeutralButton("🔄 Обновить", (dialog, which) -> {
                AppLogger.log(TicTacToePvPActivity.this, TAG, "🔄 Refresh devices from dialog");
                dialog.dismiss();
                scanForDevices();
            });
        }

        builder.setCancelable(false);
        devicesDialog = builder.create();
        devicesDialog.show();
        AppLogger.log(this, TAG, "📋 showDevicesDialog() END");
    }

    private void updateDevicesDialog() {
        AppLogger.log(this, TAG, "📋 updateDevicesDialog() START, devices=" + discoveredDevices.size());
        if (devicesDialog != null && devicesDialog.isShowing()) {
            devicesDialog.dismiss();
            showDevicesDialog();
        }
        AppLogger.log(this, TAG, "📋 updateDevicesDialog() END");
    }

    // ==================== ПОДКЛЮЧЕНИЕ ====================

    private void showConnectDialog() {
        AppLogger.log(this, TAG, "📋 showConnectDialog() START");

        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("🔗 Подключение к противнику");

        String[] options = {
                "🔍 Найти устройство (клиент)",
                "📡 Создать комнату (сервер)"
        };

        builder.setItems(options, (dialog, which) -> {
            if (which == 0) {
                AppLogger.log(TicTacToePvPActivity.this, TAG, "📌 Client mode selected");
                scanForDevices();
            } else {
                AppLogger.log(TicTacToePvPActivity.this, TAG, "📌 Server mode selected");
                startServer();
            }
        });

        builder.setNegativeButton("Отмена", null);
        builder.show();

        AppLogger.log(this, TAG, "📋 showConnectDialog() END");
    }

    private void startServer() {
        AppLogger.log(this, TAG, "🖥️ startServer() START");

        isServer = true;
        isHost = true;
        mySymbol = 1; // Сервер всегда X

        bluetoothManager.start();
        AppLogger.log(this, TAG, "✅ Server started, waiting for connection...");
        statusText.setText("📡 Ожидание подключения...");
        Toast.makeText(this, "Ожидание подключения...", Toast.LENGTH_LONG).show();

        AppLogger.log(this, TAG, "🖥️ startServer() END");
    }

    private void connectToDevice(BluetoothDevice device) {
        AppLogger.log(this, TAG, "🔗 connectToDevice() START");
        AppLogger.log(this, TAG, "   Device: " + device.getName() + " (" + device.getAddress() + ")");

        isServer = false;
        isHost = false;
        mySymbol = 2; // Клиент всегда O
        connectedDeviceName = device.getName() != null ? device.getName() : "Противник";
        connectedDeviceAddress = device.getAddress();
        opponentNameText.setText("👤 Противник: " + connectedDeviceName);

        bluetoothManager.connect(device);
        AppLogger.log(this, TAG, "📤 Connection request sent");
        statusText.setText("⏳ Подключение к " + connectedDeviceName + "...");
        Toast.makeText(this, "Подключение к " + connectedDeviceName + "...", Toast.LENGTH_LONG).show();

        AppLogger.log(this, TAG, "🔗 connectToDevice() END");
    }

    private void disconnect() {
        AppLogger.log(this, TAG, "🔌 disconnect() START");

        if (bluetoothManager != null) {
            bluetoothManager.stop();
        }
        isConnected = false;
        isServer = false;
        isHost = false;
        updateConnectionUI();
        statusText.setText("❌ Отключено");

        if (discoveryReceiver != null && receiverRegistered) {
            try {
                unregisterReceiver(discoveryReceiver);
                receiverRegistered = false;
                AppLogger.log(this, TAG, "✅ Receiver unregistered");
            } catch (Exception e) {
                AppLogger.logException(this, TAG, "❌ Unregister error", e);
            }
        }

        Toast.makeText(this, "Отключено", Toast.LENGTH_SHORT).show();
        AppLogger.log(this, TAG, "🔌 disconnect() END");
    }

    private void updateConnectionUI() {
        AppLogger.log(this, TAG, "🎨 updateConnectionUI() START: isConnected=" + isConnected);

        btnScan.setEnabled(!isConnected);
        btnConnect.setEnabled(!isConnected);
        btnDisconnect.setEnabled(isConnected);
        btnNewGame.setEnabled(isConnected);

        if (isConnected) {
            if (isServer) {
                statusText.setText("✅ Сервер: подключено к " + connectedDeviceName);
            } else {
                statusText.setText("✅ Клиент: подключено к " + connectedDeviceName);
            }
            opponentNameText.setText("👤 Противник: " + connectedDeviceName);
        } else {
            statusText.setText("❌ Не подключено");
            opponentNameText.setText("👤 Противник: не подключён");
        }

        AppLogger.log(this, TAG, "🎨 updateConnectionUI() END");
    }

    // ==================== ИГРА ====================

    private void initGame() {
        AppLogger.log(this, TAG, "🎮 initGame() START");

        board = new int[3][3];
        currentPlayer = 1;
        isMyTurn = false;
        gameActive = false;
        moveCount = 0;
        gameStartTime = 0;

        boardView.setBoard(board);
        boardView.setMySymbol(mySymbol);
        boardView.setCurrentPlayer(currentPlayer);
        boardView.invalidate();

        statusText.setText("❌⭕ Ожидание подключения...");
        updateScore();

        AppLogger.log(this, TAG, "🎮 initGame() END");
    }

    private void resetGame() {
        AppLogger.log(this, TAG, "🔄 resetGame() START");
        AppLogger.log(this, TAG, "   mySymbol=" + mySymbol + ", isHost=" + isHost);

        board = new int[3][3];
        currentPlayer = 1;
        moveCount = 0;
        gameStartTime = System.currentTimeMillis();
        gameActive = true;

        // Ход определяется символом
        isMyTurn = (mySymbol == 1);
        if (isHost) {
            isMyTurn = true;
        }

        AppLogger.log(this, TAG, "   isMyTurn=" + isMyTurn);
        boardView.setBoard(board);
        boardView.setCurrentPlayer(currentPlayer);
        boardView.invalidate();

        String turnText = isMyTurn ? "Ваш ход (X)" : "Ход противника (O)";
        statusText.setText("🎮 " + turnText);

        AppLogger.log(this, TAG, "🔄 resetGame() END");
    }

    private void handleCellClick(int row, int col) {
        AppLogger.log(this, TAG, "🎮 handleCellClick() START: row=" + row + ", col=" + col);
        AppLogger.log(this, TAG, "   isMyTurn=" + isMyTurn + ", gameActive=" + gameActive + ", isConnected=" + isConnected);

        if (!gameActive) {
            AppLogger.log(this, TAG, "⚠️ Game not active");
            Toast.makeText(this, "Игра не активна", Toast.LENGTH_SHORT).show();
            return;
        }

        if (!isMyTurn) {
            AppLogger.log(this, TAG, "⚠️ Not my turn");
            Toast.makeText(this, "Ожидайте ход противника", Toast.LENGTH_SHORT).show();
            return;
        }

        if (!isConnected) {
            AppLogger.log(this, TAG, "⚠️ Not connected");
            Toast.makeText(this, "Нет подключения", Toast.LENGTH_SHORT).show();
            return;
        }

        if (board[row][col] != 0) {
            AppLogger.log(this, TAG, "⚠️ Cell already occupied");
            Toast.makeText(this, "Клетка занята", Toast.LENGTH_SHORT).show();
            return;
        }

        // Делаем ход
        board[row][col] = mySymbol;
        moveCount++;
        boardView.invalidate();

        AppLogger.log(this, TAG, "✅ Move made: row=" + row + ", col=" + col + ", symbol=" + mySymbol);

        // Проверяем победу
        int winner = checkWinner();
        if (winner != 0) {
            AppLogger.log(this, TAG, "🏆 Winner: " + winner);
            gameActive = false;
            if (winner == mySymbol) {
                myScore++;
                statusText.setText("🏆 Вы выиграли!");
                Toast.makeText(this, "🏆 Вы выиграли!", Toast.LENGTH_SHORT).show();
            } else {
                opponentScore++;
                statusText.setText("😞 Противник выиграл!");
                Toast.makeText(this, "😞 Противник выиграл", Toast.LENGTH_SHORT).show();
            }
            updateScore();
            sendMessage("GAME_MOVE|" + row + "|" + col + "|" + mySymbol + "|WIN|" + winner);
            AppLogger.log(this, TAG, "📤 GAME_MOVE with WIN sent");
            return;
        }

        // Проверяем ничью
        if (isBoardFull()) {
            AppLogger.log(this, TAG, "🤝 Draw");
            gameActive = false;
            draws++;
            statusText.setText("🤝 Ничья!");
            Toast.makeText(this, "🤝 Ничья!", Toast.LENGTH_SHORT).show();
            updateScore();
            sendMessage("GAME_MOVE|" + row + "|" + col + "|" + mySymbol + "|DRAW");
            AppLogger.log(this, TAG, "📤 GAME_MOVE with DRAW sent");
            return;
        }

        // Отправляем ход противнику
        isMyTurn = false;
        currentPlayer = (currentPlayer == 1) ? 2 : 1;
        boardView.setCurrentPlayer(currentPlayer);

        statusText.setText("⏳ Ход противника...");
        sendMessage("GAME_MOVE|" + row + "|" + col + "|" + mySymbol);
        AppLogger.log(this, TAG, "📤 GAME_MOVE sent");

        AppLogger.log(this, TAG, "🎮 handleCellClick() END");
    }

    // ==================== BLUETOOTH СООБЩЕНИЯ ====================

    private void sendMessage(String message) {
        AppLogger.log(this, TAG, "📤 sendMessage() START");
        AppLogger.log(this, TAG, "   message: " + message);

        if (bluetoothManager == null) {
            AppLogger.log(this, TAG, "❌ bluetoothManager is null");
            return;
        }

        bluetoothManager.write(message + "\n");
        AppLogger.log(this, TAG, "✅ Message sent");
    }

    private void handleBluetoothMessage(String rawMessage) {
        AppLogger.log(this, TAG, "📨 handleBluetoothMessage() START");
        AppLogger.log(this, TAG, "   rawMessage: " + rawMessage);

        if (rawMessage == null || rawMessage.isEmpty()) {
            AppLogger.log(this, TAG, "⚠️ Empty message");
            return;
        }

        String[] parts = rawMessage.split("\\|");
        String command = parts[0];

        AppLogger.log(this, TAG, "   command: " + command);

        switch (command) {
            case "GAME_INIT":
                handleGameInit(parts);
                break;
            case "GAME_MOVE":
                handleGameMove(parts);
                break;
            case "GAME_RESET":
                handleGameReset();
                break;
            default:
                AppLogger.log(this, TAG, "⚠️ Unknown command: " + command);
                break;
        }

        AppLogger.log(this, TAG, "📨 handleBluetoothMessage() END");
    }

    private void handleGameInit(String[] parts) {
        AppLogger.log(this, TAG, "🎮 handleGameInit() START");

        if (parts.length < 2) {
            AppLogger.log(this, TAG, "❌ Invalid GAME_INIT data");
            return;
        }

        int opponentSymbol = Integer.parseInt(parts[1]);
        AppLogger.log(this, TAG, "   opponentSymbol: " + opponentSymbol);

        if (!isServer && !isHost) {
            // Мы клиент, получаем символ от сервера
            mySymbol = (opponentSymbol == 1) ? 2 : 1;
            AppLogger.log(this, TAG, "   mySymbol set to: " + mySymbol);
        }

        // Сохраняем имя противника
        if (parts.length >= 3) {
            connectedDeviceName = parts[2];
            opponentNameText.setText("👤 Противник: " + connectedDeviceName);
            AppLogger.log(this, TAG, "   opponentName: " + connectedDeviceName);
        }

        // Устанавливаем подключение
        isConnected = true;
        updateConnectionUI();

        // Запускаем игру
        gameActive = true;
        gameStartTime = System.currentTimeMillis();

        // Ход определяется символом
        isMyTurn = (mySymbol == 1);
        if (isServer) {
            isMyTurn = true;
        }

        AppLogger.log(this, TAG, "   isMyTurn=" + isMyTurn + ", mySymbol=" + mySymbol);

        String turnText = isMyTurn ? "Ваш ход (X)" : "Ход противника (O)";
        statusText.setText("🎮 " + turnText);

        boardView.setMySymbol(mySymbol);
        boardView.invalidate();

        Toast.makeText(this, "✅ Игра началась!", Toast.LENGTH_SHORT).show();
        AppLogger.log(this, TAG, "🎮 handleGameInit() END");
    }

    private void handleGameMove(String[] parts) {
        AppLogger.log(this, TAG, "🎮 handleGameMove() START");

        if (parts.length < 4) {
            AppLogger.log(this, TAG, "❌ Invalid GAME_MOVE data");
            return;
        }

        int row = Integer.parseInt(parts[1]);
        int col = Integer.parseInt(parts[2]);
        int symbol = Integer.parseInt(parts[3]);

        AppLogger.log(this, TAG, "   row=" + row + ", col=" + col + ", symbol=" + symbol);

        if (board[row][col] != 0) {
            AppLogger.log(this, TAG, "⚠️ Cell already occupied, ignoring move");
            return;
        }

        // Применяем ход противника
        board[row][col] = symbol;
        moveCount++;
        boardView.invalidate();

        // Проверяем результат
        if (parts.length >= 5) {
            String result = parts[4];
            AppLogger.log(this, TAG, "   result: " + result);

            if ("WIN".equals(result) && parts.length >= 6) {
                int winner = Integer.parseInt(parts[5]);
                AppLogger.log(this, TAG, "🏆 Winner: " + winner);
                gameActive = false;
                if (winner == mySymbol) {
                    myScore++;
                    statusText.setText("🏆 Вы выиграли!");
                    Toast.makeText(this, "🏆 Вы выиграли!", Toast.LENGTH_SHORT).show();
                } else {
                    opponentScore++;
                    statusText.setText("😞 Противник выиграл!");
                    Toast.makeText(this, "😞 Противник выиграл", Toast.LENGTH_SHORT).show();
                }
                updateScore();
                return;
            } else if ("DRAW".equals(result)) {
                AppLogger.log(this, TAG, "🤝 Draw");
                gameActive = false;
                draws++;
                statusText.setText("🤝 Ничья!");
                Toast.makeText(this, "🤝 Ничья!", Toast.LENGTH_SHORT).show();
                updateScore();
                return;
            }
        }

        // Передаём ход игроку
        isMyTurn = true;
        currentPlayer = (currentPlayer == 1) ? 2 : 1;
        boardView.setCurrentPlayer(currentPlayer);

        String turnText = isMyTurn ? "Ваш ход (X)" : "Ход противника (O)";
        statusText.setText("🎮 " + turnText);

        AppLogger.log(this, TAG, "🎮 handleGameMove() END");
    }

    private void handleGameReset() {
        AppLogger.log(this, TAG, "🔄 handleGameReset() START");
        resetGame();
        AppLogger.log(this, TAG, "🔄 handleGameReset() END");
    }

    // ==================== ПРОВЕРКА ПОБЕДЫ ====================

    private int checkWinner() {
        AppLogger.log(this, TAG, "🏆 checkWinner() START");

        int[][] lines = {
                {0,0,0,1,0,2}, {1,0,1,1,1,2}, {2,0,2,1,2,2},
                {0,0,1,0,2,0}, {0,1,1,1,2,1}, {0,2,1,2,2,2},
                {0,0,1,1,2,2}, {0,2,1,1,2,0}
        };

        for (int[] l : lines) {
            if (board[l[0]][l[1]] != 0 &&
                board[l[0]][l[1]] == board[l[2]][l[3]] &&
                board[l[0]][l[1]] == board[l[4]][l[5]]) {
                int winner = board[l[0]][l[1]];
                AppLogger.log(this, TAG, "🏆 Winner: " + winner + " (line: " +
                        l[0]+","+l[1]+" -> "+l[2]+","+l[3]+" -> "+l[4]+","+l[5]+")");
                return winner;
            }
        }

        AppLogger.log(this, TAG, "🏆 checkWinner() END: no winner");
        return 0;
    }

    private boolean isBoardFull() {
        for (int r = 0; r < 3; r++) {
            for (int c = 0; c < 3; c++) {
                if (board[r][c] == 0) {
                    return false;
                }
            }
        }
        AppLogger.log(this, TAG, "📋 Board is full");
        return true;
    }

    private void updateScore() {
        runOnUiThread(() -> {
            scoreText.setText("🏆 Вы: " + myScore + " | Противник: " + opponentScore + " | 🤝 " + draws);
            AppLogger.log(TicTacToePvPActivity.this, TAG,
                    "📊 Score updated: " + myScore + "-" + opponentScore + "-" + draws);
        });
    }

    // ==================== ON ACTIVITY RESULT ====================

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        AppLogger.log(this, TAG, "📱 onActivityResult: requestCode=" + requestCode + ", resultCode=" + resultCode);

        if (requestCode == REQUEST_ENABLE_BT) {
            if (resultCode == RESULT_OK) {
                AppLogger.log(this, TAG, "✅ Bluetooth enabled by user");
                Toast.makeText(this, "Bluetooth включён", Toast.LENGTH_SHORT).show();
            } else {
                AppLogger.log(this, TAG, "❌ Bluetooth enable denied");
                Toast.makeText(this, "Bluetooth не включён. Некоторые функции недоступны.", Toast.LENGTH_LONG).show();
                finish();
            }
        }
    }

    // ==================== ON DESTROY ====================

    @Override
    protected void onDestroy() {
        super.onDestroy();
        AppLogger.log(this, TAG, "🔴 onDestroy() START");

        disconnect();

        if (discoveryReceiver != null && receiverRegistered) {
            try {
                unregisterReceiver(discoveryReceiver);
                receiverRegistered = false;
                AppLogger.log(this, TAG, "✅ Receiver unregistered");
            } catch (Exception e) {
                AppLogger.logException(this, TAG, "❌ Unregister error", e);
            }
        }

        if (devicesDialog != null && devicesDialog.isShowing()) {
            devicesDialog.dismiss();
            devicesDialog = null;
            AppLogger.log(this, TAG, "✅ Devices dialog dismissed");
        }

        BluetoothChatActivity.setActiveTicTacToeActivity(null);
        AppLogger.log(this, TAG, "🔴 onDestroy() END");
    }

    // ==================== ОТВЕТ НА СООБЩЕНИЯ ИЗ BluetoothChatActivity ====================

    public void receiveOpponentMove(String move) {
        AppLogger.log(this, TAG, "📨 receiveOpponentMove() called: " + move);
        if ("NEW".equals(move)) {
            handleGameReset();
        } else {
            handleBluetoothMessage(move);
        }
    }
}