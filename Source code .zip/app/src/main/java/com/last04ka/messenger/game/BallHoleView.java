package com.last04ka.messenger.game;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RadialGradient;
import android.graphics.Shader;
import android.os.Handler;
import android.os.Looper;
import android.util.AttributeSet;
import android.view.View;

import com.last04ka.messenger.utils.AppLogger;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class BallHoleView extends View {
    private static final String TAG = "BallHoleView";

    // ==================== ПАРАМЕТРЫ ФИЗИКИ ====================
    private static final float SENSITIVITY = 0.6f;          // Чувствительность к наклону
    private static final float FRICTION = 0.97f;            // Трение (затухание скорости)
    private static final float MAX_SPEED = 500f;            // Максимальная скорость
    private static final float DEADZONE = 0.8f;             // Мёртвая зона в градусах

    private static final float HOLE_RADIUS_RATIO = 0.05f;
    private static final float BALL_RADIUS_RATIO = 0.025f;
    private static final float RED_BALL_SPEED_MULTIPLIER = 1.2f;
    private static final float SUCTION_STRENGTH = 120f;

    // ==================== ОБЪЕКТЫ ====================
    private List<Ball> balls = new ArrayList<>();
    private Ball redBall;
    private Hole hole;

    private Paint ballPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private Paint holePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private Paint glowPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private Paint shadowPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private Paint bgPaint = new Paint(Paint.ANTI_ALIAS_FLAG);

    // ==================== СОСТОЯНИЕ ====================
    private int level = 1;
    private float tiltPitch = 0f;    // Наклон вперед/назад
    private float tiltRoll = 0f;     // Наклон влево/вправо
    private boolean isRunning = false;
    private boolean isPaused = false;
    private boolean levelComplete = false;
    private boolean levelFailed = false;

    private int totalBalls = 0;
    private int ballsInHole = 0;
    private boolean redBallInHole = false;
    private int attempts = 0;

    private float width, height;
    private float ballRadius;
    private float holeRadius;
    private float holeX, holeY;

    private Random random = new Random();
    private Handler handler = new Handler(Looper.getMainLooper());
    private long lastUpdateTime = 0;

    // ==================== CALLBACK ====================
    private GameCallback callback;

    public interface GameCallback {
        void onLevelComplete(int level, int ballsRemaining);
        void onLevelFailed(int level);
        void onBallCountChanged(int total, int remaining);
        void onRedBallWarning();
        void onBallEnteredHole(boolean isRed, int remaining);
    }

    // ==================== КОНСТРУКТОРЫ ====================

    public BallHoleView(Context context) {
        super(context);
        init();
    }

    public BallHoleView(Context context, AttributeSet attrs) {
        super(context, attrs);
        init();
    }

    private void init() {
        AppLogger.log(getContext(), TAG, "🔵 BallHoleView init() START");
        setFocusable(true);
        setFocusableInTouchMode(true);
        setBackgroundColor(0xFF1A1A2E);

        ballPaint.setStyle(Paint.Style.FILL);
        ballPaint.setAntiAlias(true);

        holePaint.setColor(0xFF000000);
        holePaint.setStyle(Paint.Style.FILL);
        holePaint.setAntiAlias(true);

        glowPaint.setStyle(Paint.Style.FILL);
        glowPaint.setAntiAlias(true);

        shadowPaint.setColor(0x22000000);
        shadowPaint.setStyle(Paint.Style.FILL);
        shadowPaint.setAntiAlias(true);

        bgPaint.setColor(0xFF1A1A2E);
        bgPaint.setStyle(Paint.Style.FILL);

        AppLogger.log(getContext(), TAG, "🔵 BallHoleView init() END");
    }

    // ==================== УПРАВЛЕНИЕ ====================

    public void updateTilt(float pitch, float roll) {
        // Мёртвая зона для стабильности
        float finalPitch = (Math.abs(pitch) > DEADZONE) ? pitch : 0f;
        float finalRoll = (Math.abs(roll) > DEADZONE) ? roll : 0f;

        this.tiltPitch = finalPitch;
        this.tiltRoll = finalRoll;
    }

    // ==================== НАСТРОЙКА УРОВНЯ ====================

    public void setLevel(int level) {
        AppLogger.log(getContext(), TAG, "📊 setLevel() called: " + level);
        this.level = level;
        this.attempts = 0;
        resetLevel();
    }

    public void resetLevel() {
        AppLogger.log(getContext(), TAG, "🔄 resetLevel() called, level=" + level + ", attempts=" + attempts);
        levelComplete = false;
        levelFailed = false;
        ballsInHole = 0;
        redBallInHole = false;
        redBall = null;

        if (width == 0 || height == 0) {
            AppLogger.log(getContext(), TAG, "⚠️ View size is 0, deferring creation");
            return;
        }

        generateLevel();
        startLoop();
        AppLogger.log(getContext(), TAG, "✅ Level reset complete, balls=" + (balls != null ? balls.size() : 0));
    }

    private void generateLevel() {
        AppLogger.log(getContext(), TAG, "🎲 generateLevel() START, level=" + level);

        balls.clear();

        int ballCount = Math.min(3 + level, 25);
        totalBalls = ballCount;
        AppLogger.log(getContext(), TAG, "   📊 Ball count: " + ballCount);

        float minDim = Math.min(width, height);
        ballRadius = minDim * BALL_RADIUS_RATIO;
        holeRadius = minDim * HOLE_RADIUS_RATIO;
        AppLogger.log(getContext(), TAG, "   📐 ballRadius=" + ballRadius + ", holeRadius=" + holeRadius);

        float margin = holeRadius + 60f;
        holeX = margin + random.nextFloat() * (width - margin * 2);
        holeY = margin + random.nextFloat() * (height - margin * 2);
        hole = new Hole(holeX, holeY, holeRadius);
        AppLogger.log(getContext(), TAG, "   🕳️ Hole position: (" + (int)holeX + ", " + (int)holeY + ")");

        float minDistance = ballRadius * 4 + holeRadius;

        int whiteCreated = 0;
        for (int i = 0; i < ballCount - 1; i++) {
            Ball ball = createBall(false, minDistance);
            if (ball != null) {
                balls.add(ball);
                whiteCreated++;
                AppLogger.log(getContext(), TAG, "   ⚪ White ball #" + whiteCreated + " at (" + (int)ball.x + ", " + (int)ball.y + ")");
            }
        }

        redBall = createBall(true, minDistance);
        if (redBall != null) {
            redBall.radius = ballRadius * 1.1f;
            redBall.speedMultiplier = RED_BALL_SPEED_MULTIPLIER;
            AppLogger.log(getContext(), TAG, "   🔴 Red ball at (" + (int)redBall.x + ", " + (int)redBall.y + ")");
        }

        AppLogger.log(getContext(), TAG, "   ✅ White balls: " + balls.size() + ", Red ball: " + (redBall != null ? "created" : "FAILED"));

        if (callback != null) {
            callback.onBallCountChanged(totalBalls, totalBalls);
        }
    }

    private Ball createBall(boolean isRed, float minDistance) {
        int maxAttempts = 200;
        float margin = ballRadius + 20f;

        for (int attempt = 0; attempt < maxAttempts; attempt++) {
            float x = margin + random.nextFloat() * (width - margin * 2);
            float y = margin + random.nextFloat() * (height - margin * 2);

            float dx = x - holeX;
            float dy = y - holeY;
            float distToHole = (float) Math.sqrt(dx * dx + dy * dy);
            if (distToHole < minDistance) continue;

            boolean tooClose = false;
            for (Ball existing : balls) {
                float ex = x - existing.x;
                float ey = y - existing.y;
                float dist = (float) Math.sqrt(ex * ex + ey * ey);
                if (dist < ballRadius * 3.5f) {
                    tooClose = true;
                    break;
                }
            }
            if (tooClose) continue;
            if (redBall != null) {
                float ex = x - redBall.x;
                float ey = y - redBall.y;
                float dist = (float) Math.sqrt(ex * ex + ey * ey);
                if (dist < ballRadius * 3.5f) {
                    tooClose = true;
                    continue;
                }
            }

            Ball ball = new Ball();
            ball.x = x;
            ball.y = y;
            ball.radius = ballRadius;
            ball.isRed = isRed;
            ball.vx = (random.nextFloat() - 0.5f) * 30f;
            ball.vy = (random.nextFloat() - 0.5f) * 30f;
            ball.speedMultiplier = 1f;
            ball.inHole = false;
            return ball;
        }

        AppLogger.log(getContext(), TAG, "⚠️ Fallback placement for " + (isRed ? "red" : "white") + " ball");
        Ball fallback = new Ball();
        fallback.x = width / 2 + (random.nextFloat() - 0.5f) * width * 0.25f;
        fallback.y = height / 2 + (random.nextFloat() - 0.5f) * height * 0.25f;
        fallback.radius = ballRadius;
        fallback.isRed = isRed;
        fallback.vx = 0;
        fallback.vy = 0;
        fallback.speedMultiplier = 1f;
        fallback.inHole = false;
        return fallback;
    }

    // ==================== ФИЗИКА (С ИНЕРЦИЕЙ) ====================

    private void updatePhysics(float deltaTime) {
        if (isPaused || levelComplete || levelFailed) return;
        if (deltaTime <= 0 || deltaTime > 0.05f) deltaTime = 0.016f;

        // Проверяем, все ли шарики закатились
        if (redBallInHole) {
            int whiteRemaining = getWhiteBallsRemaining();
            if (whiteRemaining > 0) {
                AppLogger.log(getContext(), TAG, "❌❌❌ RED BALL FELL FIRST! White balls remain: " + whiteRemaining);
                levelFailed = true;
                attempts++;
                if (callback != null) {
                    callback.onLevelFailed(level);
                }
                return;
            } else {
                AppLogger.log(getContext(), TAG, "🏆🏆🏆 LEVEL COMPLETE! All balls in hole, red was last!");
                levelComplete = true;
                if (callback != null) {
                    callback.onLevelComplete(level, getWhiteBallsRemaining());
                }
                return;
            }
        }

        // Обновляем белые шарики
        for (Ball ball : balls) {
            if (!ball.inHole) {
                updateBall(ball, deltaTime);
            }
        }

        if (redBall != null && !redBall.inHole) {
            updateBall(redBall, deltaTime);
        }

        // Проверяем белые шарики в дырке
        for (Ball ball : balls) {
            if (!ball.inHole && isInHole(ball)) {
                ball.inHole = true;
                ball.x = holeX;
                ball.y = holeY;
                ball.vx = 0;
                ball.vy = 0;
                ballsInHole++;
                AppLogger.log(getContext(), TAG, "⚪⚪⚪ White ball #" + ballsInHole + " fell into hole! Remaining: " + getWhiteBallsRemaining());

                if (callback != null) {
                    callback.onBallCountChanged(totalBalls, getRemainingBalls());
                    callback.onBallEnteredHole(false, getWhiteBallsRemaining());
                }
            }
        }

        // Проверяем красный шарик
        if (redBall != null && !redBall.inHole && isInHole(redBall)) {
            redBall.inHole = true;
            redBall.x = holeX;
            redBall.y = holeY;
            redBall.vx = 0;
            redBall.vy = 0;
            redBallInHole = true;
            AppLogger.log(getContext(), TAG, "🔴🔴🔴 RED BALL fell into hole! White remaining: " + getWhiteBallsRemaining());

            if (callback != null) {
                callback.onBallEnteredHole(true, getWhiteBallsRemaining());
            }

            int whiteRemaining = getWhiteBallsRemaining();
            if (whiteRemaining > 0) {
                AppLogger.log(getContext(), TAG, "⚠️⚠️⚠️ Red ball fell but " + whiteRemaining + " white balls remain!");
                if (callback != null) {
                    callback.onRedBallWarning();
                }
            }
        }

        if (getWhiteBallsRemaining() == 0 && redBall != null && !redBall.inHole && !redBallInHole) {
            AppLogger.log(getContext(), TAG, "⏳⏳⏳ All white balls in hole (" + ballsInHole + "), waiting for red...");
        }
    }

    // ==================== ОСНОВНОЙ МЕТОД ОБНОВЛЕНИЯ ШАРИКА (С ИСПРАВЛЕННОЙ ВЕРТИКАЛЬЮ) ====================

    private void updateBall(Ball ball, float deltaTime) {
        // Применяем наклон к скорости (с инерцией)
        // Roll (влево/вправо) → движение по X
        // Pitch (вперед/назад) → движение по Y (ИНВЕРТИРОВАНО)
        ball.vx += tiltRoll * SENSITIVITY;
        ball.vy -= tiltPitch * SENSITIVITY;  // ← ИСПРАВЛЕНО: минус перед tiltPitch

        // Множитель скорости для красного
        ball.vx *= ball.speedMultiplier;
        ball.vy *= ball.speedMultiplier;

        // Ограничение скорости
        float speed = (float) Math.sqrt(ball.vx * ball.vx + ball.vy * ball.vy);
        if (speed > MAX_SPEED) {
            ball.vx = ball.vx / speed * MAX_SPEED;
            ball.vy = ball.vy / speed * MAX_SPEED;
        }

        // Трение (затухание скорости)
        ball.vx *= FRICTION;
        ball.vy *= FRICTION;

        // Остановка при малой скорости
        if (Math.abs(ball.vx) < 0.3f) ball.vx = 0;
        if (Math.abs(ball.vy) < 0.3f) ball.vy = 0;

        // Перемещение
        ball.x += ball.vx * deltaTime;
        ball.y += ball.vy * deltaTime;

        // Столкновение со стенами
        if (ball.x - ball.radius < 0) {
            ball.x = ball.radius;
            ball.vx = -ball.vx * 0.3f;
        }
        if (ball.x + ball.radius > width) {
            ball.x = width - ball.radius;
            ball.vx = -ball.vx * 0.3f;
        }
        if (ball.y - ball.radius < 0) {
            ball.y = ball.radius;
            ball.vy = -ball.vy * 0.3f;
        }
        if (ball.y + ball.radius > height) {
            ball.y = height - ball.radius;
            ball.vy = -ball.vy * 0.3f;
        }

        // Притяжение к дырке (мягкое)
        if (!ball.inHole) {
            float dx = ball.x - holeX;
            float dy = ball.y - holeY;
            float dist = (float) Math.sqrt(dx * dx + dy * dy);
            float suctionRadius = holeRadius + ball.radius * 2.5f;

            if (dist < suctionRadius && dist > 0.01f) {
                float strength = SUCTION_STRENGTH * (1f - dist / suctionRadius);
                ball.vx -= dx / dist * strength * deltaTime * 2f;
                ball.vy -= dy / dist * strength * deltaTime * 2f;

                if (dist < holeRadius + ball.radius) {
                    AppLogger.log(getContext(), TAG, "🌀 Ball " + (ball.isRed ? "🔴" : "⚪") + " being sucked into hole! dist=" + (int)dist);
                }
            }
        }

        // Столкновение с другими шариками
        for (Ball other : balls) {
            if (other == ball || other.inHole) continue;
            collideBalls(ball, other);
        }
        if (redBall != null && redBall != ball && !redBall.inHole) {
            collideBalls(ball, redBall);
        }
    }

    private void collideBalls(Ball a, Ball b) {
        float dx = b.x - a.x;
        float dy = b.y - a.y;
        float dist = (float) Math.sqrt(dx * dx + dy * dy);
        float minDist = a.radius + b.radius;

        if (dist < minDist && dist > 0.01f) {
            float overlap = (minDist - dist) * 0.5f;
            float nx = dx / dist;
            float ny = dy / dist;
            a.x -= nx * overlap;
            a.y -= ny * overlap;
            b.x += nx * overlap;
            b.y += ny * overlap;

            float relVx = a.vx - b.vx;
            float relVy = a.vy - b.vy;
            float relVn = relVx * nx + relVy * ny;

            if (relVn > 0) {
                float impulse = relVn * 0.5f;
                a.vx -= impulse * nx;
                a.vy -= impulse * ny;
                b.vx += impulse * nx;
                b.vy += impulse * ny;
            }
        }
    }

    private boolean isInHole(Ball ball) {
        float dx = ball.x - holeX;
        float dy = ball.y - holeY;
        float dist = (float) Math.sqrt(dx * dx + dy * dy);
        boolean inHole = dist < holeRadius;
        if (inHole) {
            AppLogger.log(getContext(), TAG, "🎯 Ball " + (ball.isRed ? "🔴" : "⚪") + " entered hole! dist=" + (int)dist + " < holeRadius=" + (int)holeRadius);
        }
        return inHole;
    }

    private int getWhiteBallsRemaining() {
        int count = 0;
        for (Ball b : balls) {
            if (!b.inHole) count++;
        }
        return count;
    }

    public int getRemainingBalls() {
        int count = 0;
        for (Ball b : balls) {
            if (!b.inHole) count++;
        }
        if (redBall != null && !redBall.inHole) count++;
        return count;
    }

    public int getTotalBalls() {
        return totalBalls;
    }

    public int getBallsInHole() {
        return ballsInHole;
    }

    // ==================== ОТРИСОВКА ====================

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        if (width == 0 || height == 0) return;

        canvas.drawRect(0, 0, width, height, bgPaint);

        Paint gridPaint = new Paint();
        gridPaint.setColor(0x11FFFFFF);
        gridPaint.setStrokeWidth(1);
        gridPaint.setStyle(Paint.Style.STROKE);
        float step = 80f;
        for (float x = 0; x < width; x += step) {
            canvas.drawLine(x, 0, x, height, gridPaint);
        }
        for (float y = 0; y < height; y += step) {
            canvas.drawLine(0, y, width, y, gridPaint);
        }

        shadowPaint.setColor(0x44000000);
        canvas.drawCircle(holeX + 8, holeY + 8, holeRadius + 10, shadowPaint);

        RadialGradient holeGrad = new RadialGradient(
                holeX, holeY, holeRadius,
                new int[]{0xFF222222, 0xFF000000},
                new float[]{0.3f, 1f},
                Shader.TileMode.CLAMP
        );
        holePaint.setShader(holeGrad);
        canvas.drawCircle(holeX, holeY, holeRadius, holePaint);
        holePaint.setShader(null);

        RadialGradient glow = new RadialGradient(
                holeX, holeY, holeRadius * 2.5f,
                new int[]{0x33FFFFFF, 0x00000000},
                new float[]{0.2f, 1f},
                Shader.TileMode.CLAMP
        );
        glowPaint.setShader(glow);
        canvas.drawCircle(holeX, holeY, holeRadius * 2.5f, glowPaint);
        glowPaint.setShader(null);

        for (Ball ball : balls) {
            if (!ball.inHole) {
                drawBall(canvas, ball);
            }
        }

        if (redBall != null && !redBall.inHole) {
            drawBall(canvas, redBall);
        }

        if (ballsInHole > 0) {
            ballPaint.setColor(0xCCFFFFFF);
            ballPaint.setTextSize(18);
            ballPaint.setTextAlign(Paint.Align.CENTER);
            canvas.drawText("+" + ballsInHole, holeX, holeY + holeRadius + 35, ballPaint);

            float angle = 0;
            float stepAngle = 2 * (float) Math.PI / Math.min(ballsInHole, 8);
            for (int i = 0; i < Math.min(ballsInHole, 8); i++) {
                float r = holeRadius * 0.5f;
                float x = holeX + (float) Math.cos(angle + i * stepAngle) * r;
                float y = holeY + (float) Math.sin(angle + i * stepAngle) * r;
                ballPaint.setColor(i == ballsInHole - 1 && redBallInHole ? 0xFFFF1744 : 0xFFE0E0E0);
                canvas.drawCircle(x, y, ballRadius * 0.3f, ballPaint);
            }
        }

        Paint statusPaint = new Paint();
        statusPaint.setColor(0xAA000000);
        statusPaint.setStyle(Paint.Style.FILL);
        canvas.drawRect(0, height - 60, width, height, statusPaint);

        statusPaint.setColor(levelComplete ? 0xFF4CAF50 : (levelFailed ? 0xFFFF5252 : 0xFFBDBDBD));
        statusPaint.setTextSize(18);
        statusPaint.setTextAlign(Paint.Align.CENTER);

        String status;
        if (levelComplete) {
            status = "🏆 УРОВЕНЬ ПРОЙДЕН!";
        } else if (levelFailed) {
            status = "❌ КРАСНЫЙ ШАРИК СЛИШКОМ РАНО! Попытка " + attempts;
        } else {
            int remaining = getRemainingBalls();
            status = "Шариков: " + remaining + "/" + totalBalls + " | В дырке: " + ballsInHole;
            if (remaining == 1 && redBall != null && !redBall.inHole) {
                status = "🔴 ОСТАЛСЯ ТОЛЬКО КРАСНЫЙ! ОСТОРОЖНО!";
                statusPaint.setColor(0xFFFF1744);
            }
        }
        canvas.drawText(status, width / 2, height - 24, statusPaint);
    }

    private void drawBall(Canvas canvas, Ball ball) {
        shadowPaint.setColor(0x44000000);
        canvas.drawCircle(ball.x + 4, ball.y + 6, ball.radius, shadowPaint);

        if (ball.isRed) {
            RadialGradient grad = new RadialGradient(
                    ball.x - ball.radius * 0.3f,
                    ball.y - ball.radius * 0.3f,
                    ball.radius,
                    new int[]{0xFFFF6B6B, 0xFFFF1744, 0xFFB71C1C},
                    new float[]{0.1f, 0.5f, 1f},
                    Shader.TileMode.CLAMP
            );
            ballPaint.setShader(grad);
            canvas.drawCircle(ball.x, ball.y, ball.radius, ballPaint);
            ballPaint.setShader(null);

            RadialGradient glow = new RadialGradient(
                    ball.x, ball.y, ball.radius * 2.5f,
                    new int[]{0x44FF1744, 0x00000000},
                    new float[]{0.2f, 1f},
                    Shader.TileMode.CLAMP
            );
            glowPaint.setShader(glow);
            canvas.drawCircle(ball.x, ball.y, ball.radius * 2.5f, glowPaint);
            glowPaint.setShader(null);

        } else {
            RadialGradient grad = new RadialGradient(
                    ball.x - ball.radius * 0.3f,
                    ball.y - ball.radius * 0.3f,
                    ball.radius,
                    new int[]{0xFFFFFFFF, 0xFFE0E0E0, 0xFFBDBDBD},
                    new float[]{0.1f, 0.5f, 1f},
                    Shader.TileMode.CLAMP
            );
            ballPaint.setShader(grad);
            canvas.drawCircle(ball.x, ball.y, ball.radius, ballPaint);
            ballPaint.setShader(null);

            RadialGradient glow = new RadialGradient(
                    ball.x, ball.y, ball.radius * 1.8f,
                    new int[]{0x22FFFFFF, 0x00000000},
                    new float[]{0.2f, 1f},
                    Shader.TileMode.CLAMP
            );
            glowPaint.setShader(glow);
            canvas.drawCircle(ball.x, ball.y, ball.radius * 1.8f, glowPaint);
            glowPaint.setShader(null);
        }

        ballPaint.setColor(0x88FFFFFF);
        canvas.drawCircle(
                ball.x - ball.radius * 0.25f,
                ball.y - ball.radius * 0.25f,
                ball.radius * 0.25f,
                ballPaint
        );
    }

    // ==================== ИГРОВОЙ ЦИКЛ ====================

    private void startLoop() {
        if (isRunning) return;
        isRunning = true;
        lastUpdateTime = System.currentTimeMillis();

        new Thread(() -> {
            while (isRunning) {
                try {
                    long now = System.currentTimeMillis();
                    float deltaTime = (now - lastUpdateTime) / 1000f;
                    lastUpdateTime = now;

                    if (deltaTime > 0.05f) deltaTime = 0.05f;

                    updatePhysics(deltaTime);
                    postInvalidate();

                    Thread.sleep(16);
                } catch (InterruptedException e) {
                    AppLogger.logException(getContext(), TAG, "Game loop interrupted", e);
                    break;
                } catch (Exception e) {
                    AppLogger.logException(getContext(), TAG, "Game loop error", e);
                }
            }
        }).start();
    }

    // ==================== ПУБЛИЧНЫЕ МЕТОДЫ ====================

    public void setGameCallback(GameCallback callback) {
        this.callback = callback;
        AppLogger.log(getContext(), TAG, "✅ Game callback set");
    }

    public void resume() {
        isPaused = false;
        AppLogger.log(getContext(), TAG, "▶️ resume()");
    }

    public void pause() {
        isPaused = true;
        AppLogger.log(getContext(), TAG, "⏸️ pause()");
    }

    public void resetGame() {
        AppLogger.log(getContext(), TAG, "🔄 resetGame() called");
        level = 1;
        attempts = 0;
        resetLevel();
    }

    // ==================== ЖИЗНЕННЫЙ ЦИКЛ VIEW ====================

    @Override
    protected void onSizeChanged(int w, int h, int oldw, int oldh) {
        super.onSizeChanged(w, h, oldw, oldh);
        width = w;
        height = h;
        AppLogger.log(getContext(), TAG, "📐 onSizeChanged: " + w + "x" + h);

        if (balls.isEmpty() && redBall == null) {
            generateLevel();
        } else {
            generateLevel();
        }
    }

    @Override
    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        AppLogger.log(getContext(), TAG, "🔗 onAttachedToWindow()");
        if (!isRunning) {
            startLoop();
        }
    }

    @Override
    protected void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        AppLogger.log(getContext(), TAG, "🔌 onDetachedFromWindow()");
        isRunning = false;
    }

    // ==================== ВНУТРЕННИЙ КЛАСС ====================

    private static class Ball {
        float x, y;
        float radius;
        float vx, vy;
        boolean isRed = false;
        boolean inHole = false;
        float speedMultiplier = 1f;
    }

    private static class Hole {
        float x, y, radius;

        Hole(float x, float y, float radius) {
            this.x = x;
            this.y = y;
            this.radius = radius;
        }
    }
}