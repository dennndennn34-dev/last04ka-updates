package com.last04ka.messenger.data;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import com.last04ka.messenger.utils.AppLogger;

import java.util.ArrayList;
import java.util.List;

public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DB_NAME = "last04ka.db";
    private static final int DB_VERSION = 12;
    private static final String FAVORITE_CHAT_ID = "FAVORITE_CHAT";

    private static final String TABLE_CHATS = "chats";
    private static final String TABLE_MESSAGES = "messages";
    private static final String TABLE_PROFILE = "profile";

    private static final String TABLE_DEVICE_KEYS = "device_keys";
    private static final String TABLE_SHARED_KEYS = "shared_keys";
    private static final String TABLE_PEER_PUBLIC_KEYS = "peer_public_keys";

    public DatabaseHelper(Context context) {
        super(context, DB_NAME, null, DB_VERSION);
        AppLogger.log(null, "DatabaseHelper", "DatabaseHelper created, version=" + DB_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        AppLogger.log(null, "DatabaseHelper", "onCreate: Creating database from scratch");

        db.execSQL("CREATE TABLE " + TABLE_CHATS + " (" +
                "id TEXT PRIMARY KEY, " +
                "name TEXT, " +
                "type INTEGER DEFAULT 0, " +
                "address TEXT, " +
                "device_address TEXT, " +
                "last_message TEXT, " +
                "last_time INTEGER DEFAULT 0, " +
                "timestamp INTEGER DEFAULT 0, " +
                "is_favorite INTEGER DEFAULT 0, " +
                "avatar TEXT, " +
                "unread_count INTEGER DEFAULT 0" +
                ")");

        try {
            db.execSQL("ALTER TABLE " + TABLE_CHATS + " ADD COLUMN theme TEXT DEFAULT 'default'");
        } catch (Exception e) {
            AppLogger.log(null, "DatabaseHelper", "   Theme column already exists or error: " + e.getMessage());
        }

        db.execSQL("CREATE TABLE " + TABLE_MESSAGES + " (" +
                "id TEXT PRIMARY KEY, " +
                "chat_id TEXT, " +
                "text TEXT, " +
                "timestamp INTEGER DEFAULT 0, " +
                "sent INTEGER DEFAULT 1, " +
                "is_voice INTEGER DEFAULT 0, " +
                "voice_path TEXT" +
                ")");

        // ========== НОВЫЕ ПОЛЯ ДЛЯ ФАЙЛОВ ==========
        try {
            db.execSQL("ALTER TABLE " + TABLE_MESSAGES + " ADD COLUMN has_file INTEGER DEFAULT 0");
        } catch (Exception e) {}
        try {
            db.execSQL("ALTER TABLE " + TABLE_MESSAGES + " ADD COLUMN file_name TEXT");
        } catch (Exception e) {}
        try {
            db.execSQL("ALTER TABLE " + TABLE_MESSAGES + " ADD COLUMN file_path TEXT");
        } catch (Exception e) {}
        try {
            db.execSQL("ALTER TABLE " + TABLE_MESSAGES + " ADD COLUMN file_size INTEGER DEFAULT 0");
        } catch (Exception e) {}
        try {
            db.execSQL("ALTER TABLE " + TABLE_MESSAGES + " ADD COLUMN mime_type TEXT");
        } catch (Exception e) {}

        db.execSQL("CREATE TABLE " + TABLE_PROFILE + " (" +
                "key TEXT PRIMARY KEY, " +
                "value TEXT" +
                ")");

        db.execSQL("CREATE TABLE " + TABLE_DEVICE_KEYS + " (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "private_key TEXT NOT NULL, " +
                "public_key TEXT NOT NULL, " +
                "created_at INTEGER DEFAULT 0" +
                ")");

        db.execSQL("CREATE TABLE " + TABLE_SHARED_KEYS + " (" +
                "chat_id TEXT PRIMARY KEY, " +
                "shared_secret TEXT NOT NULL, " +
                "updated_at INTEGER DEFAULT 0" +
                ")");

        db.execSQL("CREATE TABLE " + TABLE_PEER_PUBLIC_KEYS + " (" +
                "chat_id TEXT PRIMARY KEY, " +
                "public_key TEXT NOT NULL, " +
                "updated_at INTEGER DEFAULT 0" +
                ")");

        // Добавляем поля для статистики
        try {
            db.execSQL("ALTER TABLE " + TABLE_PROFILE + " ADD COLUMN streak_days INTEGER DEFAULT 0");
        } catch (Exception e) {}
        try {
            db.execSQL("ALTER TABLE " + TABLE_PROFILE + " ADD COLUMN best_streak INTEGER DEFAULT 0");
        } catch (Exception e) {}
        try {
            db.execSQL("ALTER TABLE " + TABLE_PROFILE + " ADD COLUMN total_time_minutes INTEGER DEFAULT 0");
        } catch (Exception e) {}
        try {
            db.execSQL("ALTER TABLE " + TABLE_PROFILE + " ADD COLUMN today_time_minutes INTEGER DEFAULT 0");
        } catch (Exception e) {}
        try {
            db.execSQL("ALTER TABLE " + TABLE_PROFILE + " ADD COLUMN last_active_date TEXT DEFAULT ''");
        } catch (Exception e) {}
        try {
            db.execSQL("ALTER TABLE " + TABLE_PROFILE + " ADD COLUMN ring_color TEXT DEFAULT ''");
        } catch (Exception e) {}

        createFavoriteChat(db);
        AppLogger.log(null, "DatabaseHelper", "onCreate: Database created successfully");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        AppLogger.log(null, "DatabaseHelper", "onUpgrade: Upgrading from " + oldVersion + " to " + newVersion);

        if (oldVersion < 9) {
            try {
                db.execSQL("ALTER TABLE " + TABLE_CHATS + " ADD COLUMN address TEXT");
            } catch (Exception e) {}
            try {
                db.execSQL("ALTER TABLE " + TABLE_CHATS + " ADD COLUMN last_time INTEGER DEFAULT 0");
            } catch (Exception e) {}
            try {
                db.execSQL("ALTER TABLE " + TABLE_CHATS + " ADD COLUMN avatar TEXT");
            } catch (Exception e) {}
            try {
                db.execSQL("ALTER TABLE " + TABLE_CHATS + " ADD COLUMN unread_count INTEGER DEFAULT 0");
            } catch (Exception e) {}
            try {
                db.execSQL("ALTER TABLE " + TABLE_MESSAGES + " ADD COLUMN is_voice INTEGER DEFAULT 0");
            } catch (Exception e) {}
            try {
                db.execSQL("ALTER TABLE " + TABLE_MESSAGES + " ADD COLUMN voice_path TEXT");
            } catch (Exception e) {}
        }

        if (oldVersion < 10) {
            try {
                db.execSQL("ALTER TABLE " + TABLE_PROFILE + " ADD COLUMN streak_days INTEGER DEFAULT 0");
            } catch (Exception e) {}
            try {
                db.execSQL("ALTER TABLE " + TABLE_PROFILE + " ADD COLUMN best_streak INTEGER DEFAULT 0");
            } catch (Exception e) {}
            try {
                db.execSQL("ALTER TABLE " + TABLE_PROFILE + " ADD COLUMN total_time_minutes INTEGER DEFAULT 0");
            } catch (Exception e) {}
            try {
                db.execSQL("ALTER TABLE " + TABLE_PROFILE + " ADD COLUMN today_time_minutes INTEGER DEFAULT 0");
            } catch (Exception e) {}
            try {
                db.execSQL("ALTER TABLE " + TABLE_PROFILE + " ADD COLUMN last_active_date TEXT DEFAULT ''");
            } catch (Exception e) {}
            try {
                db.execSQL("ALTER TABLE " + TABLE_PROFILE + " ADD COLUMN ring_color TEXT DEFAULT ''");
            } catch (Exception e) {}
        }

        // ========== НОВЫЕ ПОЛЯ ДЛЯ ФАЙЛОВ ==========
        if (oldVersion < 11) {
            try {
                db.execSQL("ALTER TABLE " + TABLE_MESSAGES + " ADD COLUMN has_file INTEGER DEFAULT 0");
            } catch (Exception e) {}
            try {
                db.execSQL("ALTER TABLE " + TABLE_MESSAGES + " ADD COLUMN file_name TEXT");
            } catch (Exception e) {}
            try {
                db.execSQL("ALTER TABLE " + TABLE_MESSAGES + " ADD COLUMN file_path TEXT");
            } catch (Exception e) {}
            try {
                db.execSQL("ALTER TABLE " + TABLE_MESSAGES + " ADD COLUMN file_size INTEGER DEFAULT 0");
            } catch (Exception e) {}
            try {
                db.execSQL("ALTER TABLE " + TABLE_MESSAGES + " ADD COLUMN mime_type TEXT");
            } catch (Exception e) {}
        }

        // ========== НОВАЯ КОЛОНКА ДЛЯ ТЕМЫ ЧАТА ==========
        if (oldVersion < 12) {
            try {
                db.execSQL("ALTER TABLE " + TABLE_CHATS + " ADD COLUMN theme TEXT DEFAULT 'default'");
            } catch (Exception e) {
                AppLogger.log(null, "DatabaseHelper", "   Theme column migration error: " + e.getMessage());
            }
        }

        // Создаём таблицы ключей, если их нет
        try {
            db.execSQL("CREATE TABLE IF NOT EXISTS " + TABLE_DEVICE_KEYS + " (" +
                    "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    "private_key TEXT NOT NULL, " +
                    "public_key TEXT NOT NULL, " +
                    "created_at INTEGER DEFAULT 0" +
                    ")");
        } catch (Exception e) {}
        try {
            db.execSQL("CREATE TABLE IF NOT EXISTS " + TABLE_SHARED_KEYS + " (" +
                    "chat_id TEXT PRIMARY KEY, " +
                    "shared_secret TEXT NOT NULL, " +
                    "updated_at INTEGER DEFAULT 0" +
                    ")");
        } catch (Exception e) {}
        try {
            db.execSQL("CREATE TABLE IF NOT EXISTS " + TABLE_PEER_PUBLIC_KEYS + " (" +
                    "chat_id TEXT PRIMARY KEY, " +
                    "public_key TEXT NOT NULL, " +
                    "updated_at INTEGER DEFAULT 0" +
                    ")");
        } catch (Exception e) {}

        createFavoriteChat(db);
        AppLogger.log(null, "DatabaseHelper", "onUpgrade: Upgrade completed to version " + newVersion);
    }

    private void createFavoriteChat(SQLiteDatabase db) {
        try {
            Cursor c = db.rawQuery("SELECT id FROM " + TABLE_CHATS + " WHERE id=?", new String[]{FAVORITE_CHAT_ID});
            if (!c.moveToFirst()) {
                ContentValues cv = new ContentValues();
                cv.put("id", FAVORITE_CHAT_ID);
                cv.put("name", "★ Избранное");
                cv.put("type", 0);
                cv.put("address", "");
                cv.put("device_address", "");
                cv.put("last_message", "Сообщения из избранных чатов");
                cv.put("last_time", System.currentTimeMillis());
                cv.put("timestamp", System.currentTimeMillis());
                cv.put("is_favorite", 1);
                cv.put("avatar", "");
                cv.put("unread_count", 0);
                cv.put("theme", "default");
                db.insert(TABLE_CHATS, null, cv);
                AppLogger.log(null, "DatabaseHelper", "Favorite chat created");
            }
            c.close();
        } catch (Exception e) {
            AppLogger.log(null, "DatabaseHelper", "⚠️ Error creating favorite chat: " + e.getMessage());
        }
    }

    // ==================== ЧАТЫ ====================
    public void addChat(Chat chat) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put("id", chat.getId());
        cv.put("name", chat.getName());
        cv.put("type", chat.getType());
        cv.put("address", chat.getAddress() != null ? chat.getAddress() : "");
        cv.put("device_address", chat.getDeviceAddress() != null ? chat.getDeviceAddress() : "");
        cv.put("last_message", chat.getLastMessage() != null ? chat.getLastMessage() : "");
        cv.put("last_time", chat.getLastTime());
        cv.put("timestamp", chat.getTimestamp());
        cv.put("is_favorite", chat.isFavorite() ? 1 : 0);
        cv.put("avatar", chat.getAvatar() != null ? chat.getAvatar() : "");
        cv.put("unread_count", chat.getUnreadCount());
        cv.put("theme", chat.getTheme() != null ? chat.getTheme() : "default");
        try {
            db.insertWithOnConflict(TABLE_CHATS, null, cv, SQLiteDatabase.CONFLICT_REPLACE);
        } catch (Exception e) {
            AppLogger.logException(null, "DatabaseHelper", "addChat error", e);
        }
    }

    public List<Chat> getAllChatsSorted() {
        List<Chat> list = new ArrayList<>();
        SQLiteDatabase db = getReadableDatabase();
        try {
            createFavoriteChat(db);
            Cursor c = db.rawQuery("SELECT * FROM " + TABLE_CHATS + " ORDER BY is_favorite DESC, last_time DESC", null);
            while (c.moveToNext()) {
                Chat chat = new Chat();
                chat.setId(c.getString(0));
                chat.setName(c.getString(1));
                chat.setType(c.getInt(2));
                chat.setAddress(c.getString(3));
                chat.setDeviceAddress(c.getString(4));
                chat.setLastMessage(c.getString(5));
                chat.setLastTime(c.getLong(6));
                chat.setTimestamp(c.getLong(7));
                chat.setFavorite(c.getInt(8) == 1);
                chat.setAvatar(c.getString(9));
                chat.setUnreadCount(c.getInt(10));
                chat.setTheme(c.getString(11));
                list.add(chat);
            }
            c.close();
        } catch (Exception e) {
            AppLogger.logException(null, "DatabaseHelper", "getAllChatsSorted error", e);
        }
        return list;
    }

    public Chat getChat(String chatId) {
        SQLiteDatabase db = getReadableDatabase();
        Cursor c = db.rawQuery("SELECT * FROM " + TABLE_CHATS + " WHERE id=?", new String[]{chatId});
        if (c.moveToFirst()) {
            Chat chat = new Chat();
            chat.setId(c.getString(0));
            chat.setName(c.getString(1));
            chat.setType(c.getInt(2));
            chat.setAddress(c.getString(3));
            chat.setDeviceAddress(c.getString(4));
            chat.setLastMessage(c.getString(5));
            chat.setLastTime(c.getLong(6));
            chat.setTimestamp(c.getLong(7));
            chat.setFavorite(c.getInt(8) == 1);
            chat.setAvatar(c.getString(9));
            chat.setUnreadCount(c.getInt(10));
            chat.setTheme(c.getString(11));
            c.close();
            return chat;
        }
        c.close();
        return null;
    }

    public void deleteChat(String chatId) {
        if (FAVORITE_CHAT_ID.equals(chatId)) return;
        SQLiteDatabase db = getWritableDatabase();
        db.delete(TABLE_CHATS, "id=?", new String[]{chatId});
        db.delete(TABLE_MESSAGES, "chat_id=?", new String[]{chatId});
        db.delete(TABLE_SHARED_KEYS, "chat_id=?", new String[]{chatId});
        db.delete(TABLE_PEER_PUBLIC_KEYS, "chat_id=?", new String[]{chatId});
    }

    public void setFavorite(String chatId, boolean favorite) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put("is_favorite", favorite ? 1 : 0);
        db.update(TABLE_CHATS, cv, "id=?", new String[]{chatId});
    }

    public void saveChatAvatar(String chatId, String avatarPath) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put("avatar", avatarPath);
        db.update(TABLE_CHATS, cv, "id=?", new String[]{chatId});
    }

    public String getChatAvatar(String chatId) {
        SQLiteDatabase db = getReadableDatabase();
        Cursor c = db.rawQuery("SELECT avatar FROM " + TABLE_CHATS + " WHERE id=?", new String[]{chatId});
        String path = null;
        if (c.moveToFirst()) {
            path = c.getString(0);
        }
        c.close();
        return path;
    }

    public void incrementUnreadCount(String chatId) {
        SQLiteDatabase db = getWritableDatabase();
        db.execSQL("UPDATE " + TABLE_CHATS + " SET unread_count = unread_count + 1 WHERE id = ?", new String[]{chatId});
    }

    public void resetUnreadCount(String chatId) {
        SQLiteDatabase db = getWritableDatabase();
        db.execSQL("UPDATE " + TABLE_CHATS + " SET unread_count = 0 WHERE id = ?", new String[]{chatId});
    }

    public int getUnreadCount(String chatId) {
        SQLiteDatabase db = getReadableDatabase();
        Cursor c = db.rawQuery("SELECT unread_count FROM " + TABLE_CHATS + " WHERE id=?", new String[]{chatId});
        int count = 0;
        if (c.moveToFirst()) {
            count = c.getInt(0);
        }
        c.close();
        return count;
    }

    public void updateChatName(String chatId, String newName) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put("name", newName);
        db.update(TABLE_CHATS, cv, "id=?", new String[]{chatId});
    }

    public void saveChatTheme(String chatId, String theme) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put("theme", theme);
        db.update(TABLE_CHATS, cv, "id=?", new String[]{chatId});
        AppLogger.log(null, "DatabaseHelper", "Theme saved: " + chatId + " -> " + theme);
    }

    public String getChatTheme(String chatId) {
        SQLiteDatabase db = getReadableDatabase();
        Cursor c = db.rawQuery("SELECT theme FROM " + TABLE_CHATS + " WHERE id=?", new String[]{chatId});
        String theme = "default";
        if (c.moveToFirst()) {
            theme = c.getString(0);
        }
        c.close();
        return theme != null ? theme : "default";
    }

    // ==================== СООБЩЕНИЯ ====================
    public void addMessage(Message msg) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put("id", msg.getId());
        cv.put("chat_id", msg.getChatId());
        cv.put("text", msg.getText());
        cv.put("timestamp", msg.getTimestamp());
        cv.put("sent", msg.isSent() ? 1 : 0);
        cv.put("is_voice", msg.isVoice() ? 1 : 0);
        cv.put("voice_path", msg.getVoicePath());
        cv.put("has_file", msg.hasFile() ? 1 : 0);
        cv.put("file_name", msg.getFileName());
        cv.put("file_path", msg.getFilePath());
        cv.put("file_size", msg.getFileSize());
        cv.put("mime_type", msg.getMimeType());
        db.insertWithOnConflict(TABLE_MESSAGES, null, cv, SQLiteDatabase.CONFLICT_REPLACE);
    }

    public List<Message> getMessagesForChat(String chatId) {
        List<Message> list = new ArrayList<>();
        SQLiteDatabase db = getReadableDatabase();
        Cursor c = db.rawQuery("SELECT * FROM " + TABLE_MESSAGES + " WHERE chat_id=? ORDER BY timestamp ASC", new String[]{chatId});
        while (c.moveToNext()) {
            Message msg = new Message();
            msg.setId(c.getString(0));
            msg.setChatId(c.getString(1));
            msg.setText(c.getString(2));
            msg.setTimestamp(c.getLong(3));
            msg.setSent(c.getInt(4) == 1);
            msg.setVoice(c.getInt(5) == 1);
            msg.setVoicePath(c.getString(6));
            msg.setHasFile(c.getInt(c.getColumnIndex("has_file")) == 1);
            msg.setFileName(c.getString(c.getColumnIndex("file_name")));
            msg.setFilePath(c.getString(c.getColumnIndex("file_path")));
            msg.setFileSize(c.getLong(c.getColumnIndex("file_size")));
            msg.setMimeType(c.getString(c.getColumnIndex("mime_type")));
            list.add(msg);
        }
        c.close();
        return list;
    }

    public void deleteMessage(String messageId) {
        SQLiteDatabase db = getWritableDatabase();
        db.delete(TABLE_MESSAGES, "id=?", new String[]{messageId});
        AppLogger.log(null, "DatabaseHelper", "🗑️ Message deleted: " + messageId);
    }

    // ==================== УДАЛЕНИЕ ВСЕХ СООБЩЕНИЙ В ЧАТЕ (НОВЫЙ МЕТОД) ====================

    public void deleteMessagesForChat(String chatId) {
        AppLogger.log(null, "DatabaseHelper", "🗑️ deleteMessagesForChat() called for chatId: " + chatId);
        SQLiteDatabase db = getWritableDatabase();
        
        // Удаляем все сообщения чата
        int deleted = db.delete(TABLE_MESSAGES, "chat_id=?", new String[]{chatId});
        AppLogger.log(null, "DatabaseHelper", "   Deleted " + deleted + " messages");
        
        // Обновляем последнее сообщение в чате (очищаем)
        ContentValues cv = new ContentValues();
        cv.put("last_message", "");
        cv.put("last_time", System.currentTimeMillis());
        int updated = db.update(TABLE_CHATS, cv, "id=?", new String[]{chatId});
        AppLogger.log(null, "DatabaseHelper", "   Updated chat last_message: " + (updated > 0 ? "✅" : "❌"));
    }

    // ==================== ПОИСК СООБЩЕНИЙ ====================

    public List<Message> searchMessages(String chatId, String query) {
        List<Message> list = new ArrayList<>();
        SQLiteDatabase db = getReadableDatabase();
        String like = "%" + query + "%";
        Cursor c = db.rawQuery("SELECT * FROM " + TABLE_MESSAGES + " WHERE chat_id=? AND text LIKE ? ORDER BY timestamp DESC",
                new String[]{chatId, like});
        while (c.moveToNext()) {
            Message msg = new Message();
            msg.setId(c.getString(0));
            msg.setChatId(c.getString(1));
            msg.setText(c.getString(2));
            msg.setTimestamp(c.getLong(3));
            msg.setSent(c.getInt(4) == 1);
            msg.setVoice(c.getInt(5) == 1);
            msg.setVoicePath(c.getString(6));
            msg.setHasFile(c.getInt(c.getColumnIndex("has_file")) == 1);
            msg.setFileName(c.getString(c.getColumnIndex("file_name")));
            msg.setFilePath(c.getString(c.getColumnIndex("file_path")));
            msg.setFileSize(c.getLong(c.getColumnIndex("file_size")));
            msg.setMimeType(c.getString(c.getColumnIndex("mime_type")));
            list.add(msg);
        }
        c.close();
        return list;
    }

    // ==================== ПРОФИЛЬ ====================
    public void saveProfileName(String name) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put("key", "name");
        cv.put("value", name);
        db.insertWithOnConflict(TABLE_PROFILE, null, cv, SQLiteDatabase.CONFLICT_REPLACE);
    }

    public String getProfileName() {
        SQLiteDatabase db = getReadableDatabase();
        Cursor c = db.rawQuery("SELECT value FROM " + TABLE_PROFILE + " WHERE key='name'", null);
        String name = c.moveToFirst() ? c.getString(0) : "Пользователь";
        c.close();
        return name;
    }

    public void saveProfileAvatar(String path) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put("key", "avatar");
        cv.put("value", path);
        db.insertWithOnConflict(TABLE_PROFILE, null, cv, SQLiteDatabase.CONFLICT_REPLACE);
    }

    public String getProfileAvatar() {
        SQLiteDatabase db = getReadableDatabase();
        Cursor c = db.rawQuery("SELECT value FROM " + TABLE_PROFILE + " WHERE key='avatar'", null);
        String path = c.moveToFirst() ? c.getString(0) : null;
        c.close();
        return path;
    }

    public void saveConnectionMode(int mode) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put("key", "mode");
        cv.put("value", String.valueOf(mode));
        db.insertWithOnConflict(TABLE_PROFILE, null, cv, SQLiteDatabase.CONFLICT_REPLACE);
    }

    public int getConnectionMode() {
        SQLiteDatabase db = getReadableDatabase();
        Cursor c = db.rawQuery("SELECT value FROM " + TABLE_PROFILE + " WHERE key='mode'", null);
        int mode = c.moveToFirst() ? Integer.parseInt(c.getString(0)) : 0;
        c.close();
        return mode;
    }

    public void saveTheme(int theme) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put("key", "theme");
        cv.put("value", String.valueOf(theme));
        db.insertWithOnConflict(TABLE_PROFILE, null, cv, SQLiteDatabase.CONFLICT_REPLACE);
    }

    public int getTheme() {
        SQLiteDatabase db = getReadableDatabase();
        Cursor c = db.rawQuery("SELECT value FROM " + TABLE_PROFILE + " WHERE key='theme'", null);
        int theme = c.moveToFirst() ? Integer.parseInt(c.getString(0)) : 0;
        c.close();
        return theme;
    }

    // ==================== СТАТИСТИКА И СЕРИЯ ====================
    public void saveStreakDays(int days) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put("key", "streak_days");
        cv.put("value", String.valueOf(days));
        db.insertWithOnConflict(TABLE_PROFILE, null, cv, SQLiteDatabase.CONFLICT_REPLACE);
    }

    public int getStreakDays() {
        SQLiteDatabase db = getReadableDatabase();
        Cursor c = db.rawQuery("SELECT value FROM " + TABLE_PROFILE + " WHERE key='streak_days'", null);
        int days = c.moveToFirst() ? Integer.parseInt(c.getString(0)) : 0;
        c.close();
        return days;
    }

    public void saveBestStreak(int days) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put("key", "best_streak");
        cv.put("value", String.valueOf(days));
        db.insertWithOnConflict(TABLE_PROFILE, null, cv, SQLiteDatabase.CONFLICT_REPLACE);
    }

    public int getBestStreak() {
        SQLiteDatabase db = getReadableDatabase();
        Cursor c = db.rawQuery("SELECT value FROM " + TABLE_PROFILE + " WHERE key='best_streak'", null);
        int days = c.moveToFirst() ? Integer.parseInt(c.getString(0)) : 0;
        c.close();
        return days;
    }

    public void saveTotalTimeMinutes(int minutes) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put("key", "total_time_minutes");
        cv.put("value", String.valueOf(minutes));
        db.insertWithOnConflict(TABLE_PROFILE, null, cv, SQLiteDatabase.CONFLICT_REPLACE);
    }

    public int getTotalTimeMinutes() {
        SQLiteDatabase db = getReadableDatabase();
        Cursor c = db.rawQuery("SELECT value FROM " + TABLE_PROFILE + " WHERE key='total_time_minutes'", null);
        int minutes = c.moveToFirst() ? Integer.parseInt(c.getString(0)) : 0;
        c.close();
        return minutes;
    }

    public void saveTodayTimeMinutes(int minutes) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put("key", "today_time_minutes");
        cv.put("value", String.valueOf(minutes));
        db.insertWithOnConflict(TABLE_PROFILE, null, cv, SQLiteDatabase.CONFLICT_REPLACE);
    }

    public int getTodayTimeMinutes() {
        SQLiteDatabase db = getReadableDatabase();
        Cursor c = db.rawQuery("SELECT value FROM " + TABLE_PROFILE + " WHERE key='today_time_minutes'", null);
        int minutes = c.moveToFirst() ? Integer.parseInt(c.getString(0)) : 0;
        c.close();
        return minutes;
    }

    public void saveLastActiveDate(String date) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put("key", "last_active_date");
        cv.put("value", date);
        db.insertWithOnConflict(TABLE_PROFILE, null, cv, SQLiteDatabase.CONFLICT_REPLACE);
    }

    public String getLastActiveDate() {
        SQLiteDatabase db = getReadableDatabase();
        Cursor c = db.rawQuery("SELECT value FROM " + TABLE_PROFILE + " WHERE key='last_active_date'", null);
        String date = c.moveToFirst() ? c.getString(0) : "";
        c.close();
        return date;
    }

    public void saveRingColor(String color) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put("key", "ring_color");
        cv.put("value", color);
        db.insertWithOnConflict(TABLE_PROFILE, null, cv, SQLiteDatabase.CONFLICT_REPLACE);
    }

    public String getRingColor() {
        SQLiteDatabase db = getReadableDatabase();
        Cursor c = db.rawQuery("SELECT value FROM " + TABLE_PROFILE + " WHERE key='ring_color'", null);
        String color = c.moveToFirst() ? c.getString(0) : "";
        c.close();
        return color;
    }

    // ==================== ШИФРОВАНИЕ ====================
    public void saveDeviceKeyPair(String privateKeyBase64, String publicKeyBase64) {
        SQLiteDatabase db = getWritableDatabase();
        db.delete(TABLE_DEVICE_KEYS, null, null);
        ContentValues cv = new ContentValues();
        cv.put("private_key", privateKeyBase64);
        cv.put("public_key", publicKeyBase64);
        cv.put("created_at", System.currentTimeMillis());
        db.insert(TABLE_DEVICE_KEYS, null, cv);
    }

    public String[] getDeviceKeyPair() {
        SQLiteDatabase db = getReadableDatabase();
        Cursor c = db.rawQuery("SELECT private_key, public_key FROM " + TABLE_DEVICE_KEYS + " LIMIT 1", null);
        if (c.moveToFirst()) {
            String[] keys = {c.getString(0), c.getString(1)};
            c.close();
            return keys;
        }
        c.close();
        return null;
    }

    public void saveSharedSecret(String chatId, String secretBase64) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put("chat_id", chatId);
        cv.put("shared_secret", secretBase64);
        cv.put("updated_at", System.currentTimeMillis());
        db.insertWithOnConflict(TABLE_SHARED_KEYS, null, cv, SQLiteDatabase.CONFLICT_REPLACE);
    }

    public String getSharedSecret(String chatId) {
        SQLiteDatabase db = getReadableDatabase();
        Cursor c = db.rawQuery("SELECT shared_secret FROM " + TABLE_SHARED_KEYS + " WHERE chat_id=?", new String[]{chatId});
        if (c.moveToFirst()) {
            String secret = c.getString(0);
            c.close();
            return secret;
        }
        c.close();
        return null;
    }

    public void savePeerPublicKey(String chatId, String publicKeyBase64) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put("chat_id", chatId);
        cv.put("public_key", publicKeyBase64);
        cv.put("updated_at", System.currentTimeMillis());
        db.insertWithOnConflict(TABLE_PEER_PUBLIC_KEYS, null, cv, SQLiteDatabase.CONFLICT_REPLACE);
    }

    public String getPeerPublicKey(String chatId) {
        SQLiteDatabase db = getReadableDatabase();
        Cursor c = db.rawQuery("SELECT public_key FROM " + TABLE_PEER_PUBLIC_KEYS + " WHERE chat_id=?", new String[]{chatId});
        if (c.moveToFirst()) {
            String key = c.getString(0);
            c.close();
            return key;
        }
        c.close();
        return null;
    }
}