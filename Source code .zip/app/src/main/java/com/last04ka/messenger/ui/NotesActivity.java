package com.last04ka.messenger.ui;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.app.Activity;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.os.Environment;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.view.animation.OvershootInterpolator;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import com.last04ka.messenger.utils.AppLogger;
import java.io.File;
import java.io.FileWriter;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class NotesActivity extends Activity {

    private LinearLayout notesList;
    private EditText inputTitle, inputText, searchNotes;
    private SQLiteDatabase db;
    private String currentFilter = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        try {
            AppLogger.log(this, "Notes", "onCreate started v2");
            AppLogger.logUI(this, "Notes", "NotesActivity layout", true);
            AppLogger.logTexture(this, "Notes", "Gradient note cards", true);

            db = openOrCreateDatabase("notes.db", MODE_PRIVATE, null);
            db.execSQL("CREATE TABLE IF NOT EXISTS notes (id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT, text TEXT, category TEXT, color INTEGER, date TEXT)");

            LinearLayout mainLayout = new LinearLayout(this);
            mainLayout.setOrientation(LinearLayout.VERTICAL);
            mainLayout.setPadding(12, 12, 12, 12);
            mainLayout.setBackgroundColor(0xFF1A1A2E);

            TextView titleLabel = new TextView(this);
            titleLabel.setText("📝 Заметки"); titleLabel.setTextSize(20);
            titleLabel.setTextColor(0xFFFFFFFF); titleLabel.setGravity(Gravity.CENTER);
            mainLayout.addView(titleLabel);

            searchNotes = new EditText(this);
            searchNotes.setHint("🔍 Поиск по заметкам"); searchNotes.setTextColor(0xFFFFFFFF);
            searchNotes.setHintTextColor(0xFF888888); searchNotes.setBackgroundColor(0xFF333333);
            searchNotes.setPadding(12, 8, 12, 8); mainLayout.addView(searchNotes);
            searchNotes.addTextChangedListener(new TextWatcher() {
                @Override public void beforeTextChanged(CharSequence s, int st, int c, int a) {}
                @Override public void onTextChanged(CharSequence s, int st, int b, int c) { currentFilter = s.toString(); loadNotes(); }
                @Override public void afterTextChanged(Editable s) {}
            });

            inputTitle = new EditText(this);
            inputTitle.setHint("Заголовок"); inputTitle.setTextColor(0xFFFFFFFF);
            inputTitle.setHintTextColor(0xFF888888); inputTitle.setBackgroundColor(0xFF333333);
            inputTitle.setPadding(12, 8, 12, 8); mainLayout.addView(inputTitle);

            inputText = new EditText(this);
            inputText.setHint("Текст заметки"); inputText.setTextColor(0xFFFFFFFF);
            inputText.setHintTextColor(0xFF888888); inputText.setBackgroundColor(0xFF333333);
            inputText.setPadding(12, 8, 12, 8); inputText.setMinHeight(80); mainLayout.addView(inputText);

            LinearLayout btnRow = new LinearLayout(this);
            btnRow.setOrientation(LinearLayout.HORIZONTAL);
            Button btnAdd = new Button(this); btnAdd.setText("Добавить");
            btnAdd.setOnClickListener(v -> addNote()); btnRow.addView(btnAdd);
            Button btnExport = new Button(this); btnExport.setText("Экспорт");
            btnExport.setOnClickListener(v -> exportNotes()); btnRow.addView(btnExport);
            mainLayout.addView(btnRow);

            notesList = new LinearLayout(this);
            notesList.setOrientation(LinearLayout.VERTICAL);
            ScrollView scrollView = new ScrollView(this);
            scrollView.addView(notesList);
            LinearLayout.LayoutParams scrollParams = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1);
            scrollView.setLayoutParams(scrollParams); mainLayout.addView(scrollView);

            setContentView(mainLayout); setTitle("📝 Заметки");
            loadNotes();
            AppLogger.log(this, "Notes", "onCreate completed, filter='" + currentFilter + "'");
        } catch (Exception e) { AppLogger.logException(this, "Notes", e); finish(); }
    }

    private void addNote() {
        String title = inputTitle.getText().toString().trim();
        String text = inputText.getText().toString().trim();
        if (title.isEmpty() && text.isEmpty()) { Toast.makeText(this, "Введите заголовок или текст", Toast.LENGTH_SHORT).show(); return; }
        String date = new SimpleDateFormat("dd.MM.yyyy HH:mm", Locale.getDefault()).format(new Date());
        int color = 0xFF424242;
        db.execSQL("INSERT INTO notes (title, text, category, color, date) VALUES (?, ?, ?, ?, ?)", new Object[]{title, text, "", color, date});
        inputTitle.setText(""); inputText.setText("");
        loadNotes();
        Toast.makeText(this, "Заметка добавлена", Toast.LENGTH_SHORT).show();
        AppLogger.log(this, "Notes", "Note added: " + (title.isEmpty() ? text.substring(0, Math.min(20, text.length())) : title));
    }

    private void exportNotes() {
        try {
            File dir = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), "Last04ka");
            if (!dir.exists()) dir.mkdirs();
            File file = new File(dir, "notes_" + System.currentTimeMillis() + ".txt");
            FileWriter writer = new FileWriter(file);
            Cursor cursor = currentFilter.isEmpty() ? db.rawQuery("SELECT * FROM notes ORDER BY id DESC", null) :
                db.rawQuery("SELECT * FROM notes WHERE title LIKE ? OR text LIKE ? ORDER BY id DESC", new String[]{"%" + currentFilter + "%", "%" + currentFilter + "%"});
            while (cursor.moveToNext()) { writer.write("=== " + cursor.getString(1) + " ===\n"); writer.write("Дата: " + cursor.getString(5) + "\n"); writer.write(cursor.getString(2) + "\n\n"); }
            cursor.close(); writer.close();
            Toast.makeText(this, "Экспортировано: " + file.getName(), Toast.LENGTH_LONG).show();
            AppLogger.log(this, "Notes", "Exported to " + file.getAbsolutePath() + ", notes: " + cursor.getCount());
        } catch (Exception e) { Toast.makeText(this, "Ошибка экспорта", Toast.LENGTH_SHORT).show(); AppLogger.logException(this, "Notes", e); }
    }

    private void loadNotes() {
        notesList.removeAllViews();
        Cursor cursor = currentFilter.isEmpty() ? db.rawQuery("SELECT * FROM notes ORDER BY id DESC", null) :
            db.rawQuery("SELECT * FROM notes WHERE title LIKE ? OR text LIKE ? ORDER BY id DESC", new String[]{"%" + currentFilter + "%", "%" + currentFilter + "%"});

        int count = 0;
        while (cursor.moveToNext()) {
            count++;
            int id = cursor.getInt(0);
            String title = cursor.getString(1);
            String text = cursor.getString(2);
            String date = cursor.getString(5);
            int color = cursor.getInt(4);

            LinearLayout item = new LinearLayout(this);
            item.setOrientation(LinearLayout.VERTICAL);
            item.setPadding(14, 10, 14, 10);
            GradientDrawable bg = new GradientDrawable();
            bg.setColor(color);
            bg.setCornerRadius(10);
            item.setBackground(bg);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
            lp.setMargins(0, 0, 0, 8);
            item.setLayoutParams(lp);

            if (!title.isEmpty()) {
                TextView tvTitle = new TextView(this);
                tvTitle.setText(title); tvTitle.setTextSize(15); tvTitle.setTextColor(0xFFFFD740);
                item.addView(tvTitle);
            }
            TextView tvDate = new TextView(this);
            tvDate.setText(date); tvDate.setTextSize(10); tvDate.setTextColor(0xFF888888);
            item.addView(tvDate);
            TextView tvText = new TextView(this);
            tvText.setText(text); tvText.setTextSize(13); tvText.setTextColor(0xFFFFFFFF);
            item.addView(tvText);

            Button btnDel = new Button(this);
            btnDel.setText("Удалить"); btnDel.setTextSize(11);
            int noteId = id;
            btnDel.setOnClickListener(v -> {
                item.animate().alpha(0f).translationX(300).setDuration(300).setListener(new AnimatorListenerAdapter() {
                    @Override public void onAnimationEnd(Animator a) {
                        db.execSQL("DELETE FROM notes WHERE id = ?", new Object[]{noteId});
                        loadNotes();
                        Toast.makeText(NotesActivity.this, "Заметка удалена", Toast.LENGTH_SHORT).show();
                        AppLogger.log(NotesActivity.this, "Notes", "Note deleted, id=" + noteId);
                    }
                }).start();
            });
            item.addView(btnDel);

            // Анимация появления
            item.setAlpha(0f);
            item.setTranslationX(-100);
            item.animate().alpha(1f).translationX(0f).setDuration(400).setStartDelay(count * 40).setInterpolator(new OvershootInterpolator(0.5f)).start();

            notesList.addView(item);
        }
        cursor.close();
        AppLogger.log(this, "Notes", "Loaded " + count + " notes, filter='" + currentFilter + "'");
    }

    @Override
    protected void onDestroy() { super.onDestroy(); if (db != null && db.isOpen()) db.close(); }
}