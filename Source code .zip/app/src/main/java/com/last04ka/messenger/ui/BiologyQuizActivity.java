package com.last04ka.messenger.ui;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import com.last04ka.messenger.utils.AppLogger;
import com.last04ka.messenger.utils.GameScores;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Random;

public class BiologyQuizActivity extends Activity {

    private TextView questionText, scoreText;
    private Button[] btns = new Button[5];
    private int current = 0, score = 0, total = 25;
    private List<String[]> pool = new ArrayList<>(), selected = new ArrayList<>();
    private Random r = new Random();

    private String[][] data = {
        {"Сколько камер в сердце человека?", "2", "3", "4", "5", "6", "2"},
        {"Какая самая большая кость человека?", "Позвоночник", "Бедренная", "Череп", "Тазовая", "Ребро", "1"},
        {"Сколько хромосом у человека?", "23", "44", "46", "48", "50", "2"},
        {"Какой орган вырабатывает инсулин?", "Печень", "Почки", "Поджелудочная", "Селезёнка", "Желудок", "2"},
        {"Сколько литров крови в теле человека?", "2-3", "3-4", "5-6", "7-8", "9-10", "2"},
        {"Какая группа крови — универсальный донор?", "I", "II", "III", "IV", "Все", "0"},
        {"Где происходит газообмен в лёгких?", "Бронхи", "Трахея", "Альвеолы", "Диафрагма", "Плевра", "2"},
        {"Сколько зубов у взрослого человека?", "28", "30", "32", "34", "36", "2"},
        {"Какой витамин вырабатывается на солнце?", "A", "B", "C", "D", "E", "3"},
        {"Самая большая клетка человека?", "Нейрон", "Яйцеклетка", "Эритроцит", "Гепатоцит", "Миоцит", "1"},
        {"Сколько костей в теле человека?", "156", "186", "206", "226", "256", "2"},
        {"Какой пигмент отвечает за цвет кожи?", "Кератин", "Меланин", "Коллаген", "Эластин", "Гемоглобин", "1"},
        {"Какое животное самое быстрое на суше?", "Лев", "Гепард", "Антилопа", "Страус", "Волк", "1"},
        {"Какая змея самая ядовитая?", "Кобра", "Гадюка", "Тайпан", "Мамба", "Гремучая", "2"},
        {"Сколько ног у паука?", "4", "6", "8", "10", "12", "2"},
        {"Какое млекопитающее умеет летать?", "Белка", "Летучая мышь", "Опоссум", "Лемур", "Крыса", "1"},
        {"Где живут пингвины?", "Арктика", "Антарктида", "Аляска", "Гренландия", "Сибирь", "1"},
        {"Какое дерево самое высокое?", "Дуб", "Секвойя", "Эвкалипт", "Сосна", "Баобаб", "1"},
        {"Сколько живёт майская муха?", "1 час", "1 день", "1 неделя", "1 месяц", "1 год", "1"},
        {"Как называется наука о растениях?", "Зоология", "Ботаника", "Экология", "Микология", "Анатомия", "1"},
        {"Какая птица самая маленькая?", "Воробей", "Колибри", "Синица", "Королёк", "Канарейка", "1"},
        {"Сколько дней курица высиживает яйца?", "14", "21", "28", "30", "35", "1"},
        {"Какой орган чувств у акулы самый развитый?", "Зрение", "Слух", "Обоняние", "Осязание", "Вкус", "2"},
        {"Какая рыба может жить без воды дольше всех?", "Карп", "Сом", "Двоякодышащая", "Угорь", "Камбала", "2"},
        {"Сколько сердец у осьминога?", "1", "2", "3", "4", "5", "2"},
        // ... ещё 275+ вопросов
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        try {
            AppLogger.log(this, "BioQuiz", "onCreate started");
            LinearLayout layout = new LinearLayout(this);
            layout.setOrientation(LinearLayout.VERTICAL);
            layout.setPadding(24, 24, 24, 24);
            layout.setBackgroundColor(0xFF252525);

            scoreText = new TextView(this);
            scoreText.setText("Счёт: 0 / " + total + " | Рекорд: " + GameScores.getScore(this, "bioquiz"));
            scoreText.setTextSize(14); scoreText.setTextColor(0xFFBDBDBD);
            layout.addView(scoreText);

            questionText = new TextView(this);
            questionText.setTextSize(16); questionText.setTextColor(0xFFFFFFFF);
            questionText.setPadding(0, 16, 0, 16); layout.addView(questionText);

            for (int i = 0; i < 5; i++) {
                final int idx = i;
                btns[i] = new Button(this); btns[i].setTextSize(14); btns[i].setAllCaps(false);
                btns[i].setPadding(8, 12, 8, 12);
                btns[i].setOnClickListener(new View.OnClickListener() {
                    @Override public void onClick(View v) { checkAnswer(idx); }
                });
                layout.addView(btns[i]);
            }

            pool.addAll(Arrays.asList(data));
            Collections.shuffle(pool, r);
            for (int i = 0; i < Math.min(total, pool.size()); i++) selected.add(pool.get(i));

            setContentView(layout);
            setTitle("🧬 Биология");
            showQuestion();
            AppLogger.log(this, "BioQuiz", "onCreate completed, questions: " + selected.size());
        } catch (Exception e) { AppLogger.logException(this, "BioQuiz", e); finish(); }
    }

    private void showQuestion() {
        if (current >= selected.size()) {
            questionText.setText("🏆 Итог: " + score + " из " + total);
            for (Button b : btns) b.setVisibility(View.GONE);
            GameScores.saveScore(this, "bioquiz", score);
            return;
        }
        String[] q = selected.get(current);
        questionText.setText("Вопрос " + (current + 1) + "/" + total + ": " + q[0]);
        for (int i = 0; i < 5; i++) btns[i].setText(q[i + 1]);
    }

    private void checkAnswer(int idx) {
        if (current >= selected.size()) return;
        String[] q = selected.get(current);
        int correct = Integer.parseInt(q[6]);
        if (idx == correct) { score++; Toast.makeText(this, "✅", Toast.LENGTH_SHORT).show(); }
        else Toast.makeText(this, "❌ " + q[correct + 1], Toast.LENGTH_SHORT).show();
        scoreText.setText("Счёт: " + score + " / " + total + " | Рекорд: " + GameScores.getScore(this, "bioquiz"));
        current++;
        showQuestion();
    }
}