package com.last04ka.messenger.ui;

import android.animation.ArgbEvaluator;
import android.animation.ValueAnimator;
import android.app.Activity;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import com.last04ka.messenger.utils.AppLogger;
import java.util.ArrayList;
import java.util.List;

public class CalculatorActivity extends Activity {

    private EditText display;
    private TextView historyView;
    private List<String> history = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        try {
            AppLogger.log(this, "Calculator", "onCreate started with animations");

            LinearLayout layout = new LinearLayout(this);
            layout.setOrientation(LinearLayout.VERTICAL);
            layout.setPadding(10, 10, 10, 10);
            layout.setBackgroundColor(0xFF1A1A2E);

            // История
            historyView = new TextView(this);
            historyView.setTextSize(12);
            historyView.setTextColor(0xFF888888);
            historyView.setPadding(8, 4, 8, 4);
            historyView.setGravity(Gravity.END);
            historyView.setMinHeight(60);
            layout.addView(historyView);

            // Дисплей с градиентным фоном
            display = new EditText(this);
            display.setTextSize(32);
            display.setTextColor(0xFFFFFFFF);
            GradientDrawable displayBg = new GradientDrawable();
            displayBg.setColors(new int[]{0xFF2A2A4E, 0xFF1A1A3E});
            displayBg.setCornerRadius(12);
            display.setBackground(displayBg);
            display.setPadding(16, 12, 16, 12);
            display.setGravity(Gravity.END | Gravity.CENTER_VERTICAL);
            display.setFocusable(false);
            display.setText("0");
            layout.addView(display);

            // Кнопки
            String[][] btnLayout = {
                {"C", "(", ")", "÷"},
                {"7", "8", "9", "×"},
                {"4", "5", "6", "-"},
                {"1", "2", "3", "+"},
                {"%", "0", ".", "="},
                {"√", "^", "⌫", "H"}
            };

            int[][] btnColors = {
                {0xFFFF5252, 0xFF616161, 0xFF616161, 0xFFFF9800},
                {0xFF424242, 0xFF424242, 0xFF424242, 0xFFFF9800},
                {0xFF424242, 0xFF424242, 0xFF424242, 0xFFFF9800},
                {0xFF424242, 0xFF424242, 0xFF424242, 0xFFFF9800},
                {0xFF616161, 0xFF424242, 0xFF424242, 0xFF4CAF50},
                {0xFF616161, 0xFF616161, 0xFF616161, 0xFF2196F3}
            };

            for (int r = 0; r < btnLayout.length; r++) {
                LinearLayout btnRow = new LinearLayout(this);
                btnRow.setOrientation(LinearLayout.HORIZONTAL);
                for (int c = 0; c < btnLayout[r].length; c++) {
                    final String label = btnLayout[r][c];
                    Button btn = new Button(this);
                    btn.setText(label);
                    btn.setTextSize(18);
                    btn.setAllCaps(false);
                    btn.setTextColor(0xFFFFFFFF);
                    GradientDrawable btnBg = new GradientDrawable();
                    btnBg.setColor(btnColors[r][c]);
                    btnBg.setCornerRadius(12);
                    btn.setBackground(btnBg);
                    LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                        0, LinearLayout.LayoutParams.WRAP_CONTENT, 1);
                    lp.setMargins(4, 4, 4, 4);
                    btn.setLayoutParams(lp);
                    btn.setOnTouchListener((v, event) -> {
                        if (event.getAction() == MotionEvent.ACTION_DOWN) {
                            v.animate().scaleX(0.9f).scaleY(0.9f).setDuration(100).start();
                        } else if (event.getAction() == MotionEvent.ACTION_UP) {
                            v.animate().scaleX(1f).scaleY(1f).setDuration(100).start();
                            onButtonClick(label);
                        }
                        return true;
                    });
                    btnRow.addView(btn);
                }
                layout.addView(btnRow);
            }

            setContentView(layout);
            setTitle("🔢 Калькулятор");
            AppLogger.log(this, "Calculator", "UI loaded: gradient display, animated buttons");
        } catch (Exception e) { 
            AppLogger.logException(this, "Calculator", e);
            AppLogger.log(this, "Calculator", "ERROR: Calculator UI failed");
            finish(); 
        }
    }

    private void onButtonClick(String cmd) {
        String current = display.getText().toString();
        switch (cmd) {
            case "C": display.setText("0"); break;
            case "⌫":
                if (current.length() <= 1) display.setText("0");
                else display.setText(current.substring(0, current.length() - 1));
                break;
            case "=": calculate(); break;
            case "H": showHistory(); break;
            case "√":
                try {
                    double val = Double.parseDouble(current);
                    if (val < 0) { Toast.makeText(this, "Ошибка", Toast.LENGTH_SHORT).show(); return; }
                    String result = formatResult(Math.sqrt(val));
                    history.add(current + " √ = " + result);
                    display.setText(result);
                } catch (Exception e) { Toast.makeText(this, "Ошибка", Toast.LENGTH_SHORT).show(); }
                break;
            case "%": display.setText(current + "%"); break;
            case "^": display.setText(current + "^"); break;
            case "÷": display.setText(current + "/"); break;
            case "×": display.setText(current + "*"); break;
            default:
                if (current.equals("0") && cmd.matches("[0-9]")) display.setText(cmd);
                else display.setText(current + cmd);
                break;
        }
        AppLogger.log(this, "Calculator", "Button: " + cmd);
    }

    private void calculate() {
        String expr = display.getText().toString();
        try {
            expr = expr.replaceAll("(\\d+)%", "($1/100.0)");
            expr = expr.replace("^", "**");
            double result = evaluateExpression(expr);
            String resStr = formatResult(result);
            history.add(display.getText().toString() + " = " + resStr);
            display.setText(resStr);
            AppLogger.log(this, "Calculator", "Calc: " + expr + " = " + resStr);
        } catch (Exception e) {
            Toast.makeText(this, "Ошибка в выражении", Toast.LENGTH_SHORT).show();
            AppLogger.log(this, "Calculator", "Calc ERROR: " + expr);
        }
    }

    private double evaluateExpression(String expr) {
        expr = expr.replaceAll("\\s+", "");
        List<Double> numbers = new ArrayList<>();
        List<Character> ops = new ArrayList<>();
        StringBuilder num = new StringBuilder();

        for (int i = 0; i < expr.length(); i++) {
            char c = expr.charAt(i);
            if (Character.isDigit(c) || c == '.' || (c == '-' && (i == 0 || expr.charAt(i-1) == '(' || "+-*/".indexOf(expr.charAt(i-1)) >= 0))) {
                num.append(c);
            } else if ("+-*/".indexOf(c) >= 0) {
                if (num.length() > 0) { numbers.add(Double.parseDouble(num.toString())); num = new StringBuilder(); }
                ops.add(c);
            } else if (c == '(') {
                int depth = 1, j = i + 1;
                while (j < expr.length() && depth > 0) { if (expr.charAt(j) == '(') depth++; if (expr.charAt(j) == ')') depth--; j++; }
                double sub = evaluateExpression(expr.substring(i+1, j-1));
                num = new StringBuilder(String.valueOf(sub));
                i = j - 1;
            }
        }
        if (num.length() > 0) numbers.add(Double.parseDouble(num.toString()));
        for (int i = 0; i < ops.size(); ) {
            if (ops.get(i) == '*' || ops.get(i) == '/') {
                double a = numbers.get(i), b = numbers.get(i+1);
                double r = ops.get(i) == '*' ? a * b : a / b;
                numbers.set(i, r); numbers.remove(i+1); ops.remove(i);
            } else i++;
        }
        for (int i = 0; i < ops.size(); ) {
            double a = numbers.get(i), b = numbers.get(i+1);
            double r = ops.get(i) == '+' ? a + b : a - b;
            numbers.set(i, r); numbers.remove(i+1); ops.remove(i);
        }
        return numbers.get(0);
    }

    private String formatResult(double d) {
        if (d == (long) d) return String.valueOf((long) d);
        return String.format("%.8f", d).replaceAll("0+$", "").replaceAll("\\.$", "");
    }

    private void showHistory() {
        if (history.isEmpty()) { Toast.makeText(this, "История пуста", Toast.LENGTH_SHORT).show(); return; }
        StringBuilder sb = new StringBuilder();
        for (int i = Math.max(0, history.size() - 10); i < history.size(); i++) {
            sb.append(history.get(i)).append("\n");
        }
        historyView.setText(sb.toString());
    }
}