package com.last04ka.messenger.ui;

import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.last04ka.messenger.R;
import com.last04ka.messenger.utils.AppLogger;
import com.last04ka.messenger.utils.EmailManager;
import com.last04ka.messenger.utils.ThemeManager;

import java.util.ArrayList;
import java.util.List;

public class EmailActivity extends AppCompatActivity {
    private static final String TAG = "EmailActivity";

    private RecyclerView recyclerView;
    private TextView tvEmpty, tvAccount, tvFolder;
    private ProgressBar progressBar;
    private LinearLayout folderBar;

    private EmailManager emailManager;
    private EmailAdapter adapter;
    private List<EmailManager.EmailMessage> messages = new ArrayList<>();
    private String currentFolder = "INBOX";

    private Handler handler = new Handler(Looper.getMainLooper());

    // ==================== ИНТЕРФЕЙС ВЫНЕСЕН НА УРОВЕНЬ КЛАССА ====================
    public interface OnMessageClickListener {
        void onMessageClick(EmailManager.EmailMessage message);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        setTheme(ThemeManager.getThemeResource(this));
        super.onCreate(savedInstanceState);
        AppLogger.log(this, TAG, "📧 EmailActivity onCreate START");

        try {
            setContentView(R.layout.activity_email);

            emailManager = new EmailManager(this);

            initViews();
            AppLogger.log(this, TAG, "✅ Views initialized");

            setupRecyclerView();
            AppLogger.log(this, TAG, "✅ RecyclerView setup");

            loadAccountInfo();
            AppLogger.log(this, TAG, "✅ Account info loaded");

            loadFolders();
            AppLogger.log(this, TAG, "✅ Folders loaded");

            loadMessages();
            AppLogger.log(this, TAG, "✅ Messages loaded");

            setTitle("📧 Почта");

        } catch (Exception e) {
            AppLogger.logException(this, TAG, "❌ onCreate error", e);
            Toast.makeText(this, "Ошибка: " + e.getMessage(), Toast.LENGTH_LONG).show();
            finish();
        }
    }

    private void initViews() {
        recyclerView = findViewById(R.id.email_recycler);
        tvEmpty = findViewById(R.id.tv_empty);
        tvAccount = findViewById(R.id.tv_email_account);
        tvFolder = findViewById(R.id.tv_email_folder);
        progressBar = findViewById(R.id.email_progress);
        folderBar = findViewById(R.id.folder_bar);

        Button btnRefresh = findViewById(R.id.btn_refresh);
        if (btnRefresh != null) {
            btnRefresh.setOnClickListener(v -> loadMessages());
        }
    }

    private void setupRecyclerView() {
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        adapter = new EmailAdapter(messages, new OnMessageClickListener() {
            @Override
            public void onMessageClick(EmailManager.EmailMessage message) {
                AppLogger.log(EmailActivity.this, TAG, "📧 Message clicked: " + message.subject);
                openMessage(message);
            }
        });
        recyclerView.setAdapter(adapter);
    }

    private void loadAccountInfo() {
        EmailManager.Account account = emailManager.getActiveAccount();
        if (account != null) {
            tvAccount.setText("📧 " + account.email);
            AppLogger.log(this, TAG, "   Account: " + account.email);
        } else {
            tvAccount.setText("⚠️ Нет аккаунта");
            AppLogger.log(this, TAG, "   No active account");
        }
    }

    private void loadFolders() {
        AppLogger.log(this, TAG, "📂 loadFolders() called");
        showProgress(true);

        new Thread(() -> {
            try {
                List<String> folders = new ArrayList<>();
                folders.add("INBOX");
                folders.add("Sent");
                folders.add("Trash");
                folders.add("Spam");
                folders.add("Drafts");

                handler.post(() -> {
                    showProgress(false);
                    updateFolderBar();
                    AppLogger.log(EmailActivity.this, TAG, "   Folders setup complete");
                });
            } catch (Exception e) {
                AppLogger.logException(EmailActivity.this, TAG, "❌ loadFolders error", e);
                handler.post(() -> {
                    showProgress(false);
                    Toast.makeText(EmailActivity.this, "Ошибка загрузки папок", Toast.LENGTH_SHORT).show();
                });
            }
        }).start();
    }

    private void updateFolderBar() {
        if (folderBar == null) return;
        folderBar.removeAllViews();

        String[] defaultFolders = {"INBOX", "Sent", "Trash", "Spam"};
        for (String name : defaultFolders) {
            Button btn = new Button(this);
            btn.setText(name);
            btn.setTextSize(11);
            btn.setAllCaps(false);
            btn.setPadding(16, 8, 16, 8);
            btn.setBackgroundColor(ThemeManager.getCardColor(this));
            btn.setTextColor(ThemeManager.getTextColor(this));
            LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.WRAP_CONTENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
            );
            params.setMargins(4, 4, 4, 4);
            btn.setLayoutParams(params);

            btn.setOnClickListener(v -> switchFolder(name));
            folderBar.addView(btn);
        }
    }

    private void switchFolder(String folder) {
        AppLogger.log(this, TAG, "📂 switchFolder() called: " + folder);
        currentFolder = folder;
        tvFolder.setText("📁 " + folder);
        loadMessages();
    }

    private void loadMessages() {
        AppLogger.log(this, TAG, "📨 loadMessages() called, folder=" + currentFolder);
        showProgress(true);
        messages.clear();
        adapter.notifyDataSetChanged();

        new Thread(() -> {
            try {
                List<EmailManager.EmailMessage> loaded = emailManager.getMessages(currentFolder, 50);
                handler.post(() -> {
                    messages.clear();
                    messages.addAll(loaded);
                    adapter.notifyDataSetChanged();
                    showProgress(false);
                    tvEmpty.setVisibility(messages.isEmpty() ? View.VISIBLE : View.GONE);
                    AppLogger.log(EmailActivity.this, TAG, "✅ Loaded " + messages.size() + " messages");
                });
            } catch (Exception e) {
                AppLogger.logException(EmailActivity.this, TAG, "❌ loadMessages error", e);
                handler.post(() -> {
                    showProgress(false);
                    Toast.makeText(EmailActivity.this, "Ошибка загрузки: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                });
            }
        }).start();
    }

    private void openMessage(EmailManager.EmailMessage message) {
        AppLogger.log(this, TAG, "📖 openMessage() called: " + message.subject);

        android.app.AlertDialog.Builder builder = new android.app.AlertDialog.Builder(this);
        builder.setTitle(message.subject != null ? message.subject : "(без темы)");
        builder.setMessage(
            "📩 От: " + message.fromName + " <" + message.from + ">\n" +
            "📅 " + message.getDateFormatted() + "\n\n" +
            message.body
        );
        builder.setPositiveButton("Закрыть", null);
        builder.setNeutralButton("📤 Ответить", (d, w) -> {
            AppLogger.log(EmailActivity.this, TAG, "📤 Reply clicked for: " + message.subject);
            composeEmail(message);
        });
        builder.show();
    }

    private void composeEmail(EmailManager.EmailMessage replyTo) {
        AppLogger.log(this, TAG, "✏️ composeEmail() called");

        final android.widget.EditText etTo = new android.widget.EditText(this);
        etTo.setHint("Кому");
        if (replyTo != null) {
            etTo.setText(replyTo.from);
        }

        final android.widget.EditText etSubject = new android.widget.EditText(this);
        etSubject.setHint("Тема");
        if (replyTo != null) {
            etSubject.setText("Re: " + replyTo.subject);
        }

        final android.widget.EditText etBody = new android.widget.EditText(this);
        etBody.setHint("Текст письма");
        etBody.setMinHeight(200);

        android.widget.LinearLayout layout = new android.widget.LinearLayout(this);
        layout.setOrientation(android.widget.LinearLayout.VERTICAL);
        layout.setPadding(32, 16, 32, 16);
        layout.addView(etTo);
        layout.addView(etSubject);
        layout.addView(etBody);

        android.app.AlertDialog.Builder builder = new android.app.AlertDialog.Builder(this);
        builder.setTitle("✏️ Написать письмо");
        builder.setView(layout);
        builder.setPositiveButton("Отправить", (d, w) -> {
            String to = etTo.getText().toString().trim();
            String subject = etSubject.getText().toString().trim();
            String body = etBody.getText().toString().trim();

            if (to.isEmpty()) {
                Toast.makeText(EmailActivity.this, "Введите получателя", Toast.LENGTH_SHORT).show();
                return;
            }
            if (body.isEmpty()) {
                Toast.makeText(EmailActivity.this, "Введите текст", Toast.LENGTH_SHORT).show();
                return;
            }

            sendEmail(to, subject, body);
        });
        builder.setNegativeButton("Отмена", null);
        builder.show();
    }

    private void sendEmail(String to, String subject, String body) {
        AppLogger.log(this, TAG, "📤 sendEmail() called: to=" + to);
        showProgress(true);

        new Thread(() -> {
            boolean success = emailManager.sendEmail(to, subject, body);
            handler.post(() -> {
                showProgress(false);
                if (success) {
                    Toast.makeText(EmailActivity.this, "✅ Письмо отправлено!", Toast.LENGTH_SHORT).show();
                    AppLogger.log(EmailActivity.this, TAG, "✅ Email sent");
                } else {
                    Toast.makeText(EmailActivity.this, "❌ Ошибка отправки", Toast.LENGTH_SHORT).show();
                    AppLogger.log(EmailActivity.this, TAG, "❌ Email send failed");
                }
            });
        }).start();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_email, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();

        if (id == R.id.menu_email_compose) {
            composeEmail(null);
            return true;
        } else if (id == R.id.menu_email_refresh) {
            loadMessages();
            return true;
        } else if (id == R.id.menu_email_accounts) {
            showAccountManager();
            return true;
        } else if (id == R.id.menu_email_add_account) {
            startActivity(new android.content.Intent(this, EmailLoginActivity.class));
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    private void showAccountManager() {
        AppLogger.log(this, TAG, "👤 showAccountManager() called");
        List<EmailManager.Account> accounts = emailManager.getAccounts();

        if (accounts.isEmpty()) {
            Toast.makeText(this, "Нет аккаунтов. Добавьте новый.", Toast.LENGTH_SHORT).show();
            startActivity(new android.content.Intent(this, EmailLoginActivity.class));
            return;
        }

        String[] items = new String[accounts.size()];
        for (int i = 0; i < accounts.size(); i++) {
            EmailManager.Account a = accounts.get(i);
            items[i] = (a.isActive ? "✅ " : "   ") + a.email;
        }

        new android.app.AlertDialog.Builder(this)
            .setTitle("👤 Управление аккаунтами")
            .setItems(items, (dialog, which) -> {
                EmailManager.Account selected = accounts.get(which);
                showAccountActions(selected);
            })
            .setPositiveButton("➕ Добавить", (d, w) -> {
                startActivity(new android.content.Intent(this, EmailLoginActivity.class));
            })
            .setNegativeButton("Закрыть", null)
            .show();
    }

    private void showAccountActions(EmailManager.Account account) {
        String[] actions = {
            "📌 Сделать активным",
            "🗑️ Удалить"
        };

        new android.app.AlertDialog.Builder(this)
            .setTitle("👤 " + account.email)
            .setItems(actions, (dialog, which) -> {
                if (which == 0) {
                    AppLogger.log(EmailActivity.this, TAG, "📌 Set active: " + account.email);
                    emailManager.setActiveAccount(account.id);
                    loadAccountInfo();
                    loadMessages();
                    Toast.makeText(EmailActivity.this, "✅ Аккаунт активен", Toast.LENGTH_SHORT).show();
                } else if (which == 1) {
                    new android.app.AlertDialog.Builder(EmailActivity.this)
                        .setTitle("🗑️ Удалить аккаунт?")
                        .setMessage("Вы уверены? Аккаунт будет удалён с устройства.")
                        .setPositiveButton("Удалить", (d, w) -> {
                            AppLogger.log(EmailActivity.this, TAG, "🗑️ Delete account: " + account.email);
                            emailManager.deleteAccount(account.id);
                            emailManager.disconnect();
                            loadAccountInfo();
                            loadMessages();
                            Toast.makeText(EmailActivity.this, "✅ Аккаунт удалён", Toast.LENGTH_SHORT).show();
                        })
                        .setNegativeButton("Отмена", null)
                        .show();
                }
            })
            .setNegativeButton("Отмена", null)
            .show();
    }

    private void showProgress(boolean show) {
        progressBar.setVisibility(show ? View.VISIBLE : View.GONE);
    }

    // ==================== АДАПТЕР (исправлен) ====================

    public class EmailAdapter extends RecyclerView.Adapter<EmailAdapter.ViewHolder> {
        private List<EmailManager.EmailMessage> messages;
        private OnMessageClickListener listener;

        public EmailAdapter(List<EmailManager.EmailMessage> messages, OnMessageClickListener listener) {
            this.messages = messages;
            this.listener = listener;
        }

        @Override
        public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_email, parent, false);
            return new ViewHolder(view);
        }

        @Override
        public void onBindViewHolder(ViewHolder holder, int position) {
            EmailManager.EmailMessage msg = messages.get(position);

            holder.tvFrom.setText(msg.fromName != null ? msg.fromName : msg.from);
            holder.tvSubject.setText(msg.subject != null ? msg.subject : "(без темы)");
            holder.tvDate.setText(msg.getShortDate());
            holder.tvPreview.setText(msg.body != null ? msg.body.replace("\n", " ") : "");

            if (!msg.isRead) {
                holder.tvSubject.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
                holder.itemView.setBackgroundColor(ThemeManager.getCardColor(EmailActivity.this) & 0x55FFFFFF);
            } else {
                holder.tvSubject.setTypeface(android.graphics.Typeface.DEFAULT);
                holder.itemView.setBackgroundColor(ThemeManager.getCardColor(EmailActivity.this));
            }

            holder.itemView.setOnClickListener(v -> {
                if (listener != null) {
                    listener.onMessageClick(msg);
                    msg.isRead = true;
                    notifyItemChanged(position);
                }
            });
        }

        @Override
        public int getItemCount() {
            return messages.size();
        }

        class ViewHolder extends RecyclerView.ViewHolder {
            TextView tvFrom, tvSubject, tvDate, tvPreview;

            ViewHolder(View itemView) {
                super(itemView);
                tvFrom = itemView.findViewById(R.id.email_from);
                tvSubject = itemView.findViewById(R.id.email_subject);
                tvDate = itemView.findViewById(R.id.email_date);
                tvPreview = itemView.findViewById(R.id.email_preview);
            }
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        emailManager.disconnect();
        AppLogger.log(this, TAG, "📧 EmailActivity destroyed");
    }
}