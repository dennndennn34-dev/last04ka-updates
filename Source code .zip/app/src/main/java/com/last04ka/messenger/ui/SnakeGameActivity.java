package com.last04ka.messenger.ui;

import android.app.Activity;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Shader;
import android.os.Bundle;
import android.os.Handler;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;
import com.last04ka.messenger.utils.AppLogger;
import com.last04ka.messenger.utils.GameScores;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class SnakeGameActivity extends Activity {

    private GameView gameView;
    private TextView scoreText, bestText, speedText, levelText;
    private Button btnUp, btnDown, btnLeft, btnRight, btnNew;
    private SeekBar speedBar;
    private int score = 0, best = 0, level = 1;
    private int gameSpeed = 150;
    private Handler handler = new Handler();
    private boolean gameOver = false;
    private boolean gameStarted = false;
    private volatile boolean running = false;

    private int cols = 20, rows = 30;
    private List<SnakeSegment> snake = new ArrayList<>();
    private int[] food = new int[2];
    private int foodType = 0;
    private int dirX = 0, dirY = -1;
    private int nextDirX = 0, nextDirY = -1;
    private Random rand = new Random();
    private List<Sparkle> sparkles = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        try {
            AppLogger.log(this, "Snake", "onCreate v3.2 visible buttons");
            AppLogger.logUI(this, "Snake", "Layout fixed", true);

            LinearLayout layout = new LinearLayout(this);
            layout.setOrientation(LinearLayout.VERTICAL);
            layout.setBackgroundColor(0xFF0A0A1A);

            // Статистика
            LinearLayout stats = new LinearLayout(this);
            stats.setGravity(Gravity.CENTER);
            stats.setPadding(8, 4, 8, 2);
            scoreText = new TextView(this);
            scoreText.setText("Счёт: 0"); scoreText.setTextSize(14);
            scoreText.setTextColor(0xFFFFD740); stats.addView(scoreText);
            bestText = new TextView(this);
            best = GameScores.getScore(this, "snake");
            bestText.setText("  Рекорд: " + best); bestText.setTextSize(12);
            bestText.setTextColor(0xFFFFFFFF); stats.addView(bestText);
            levelText = new TextView(this);
            levelText.setText("  Ур.1"); levelText.setTextSize(12);
            levelText.setTextColor(0xFF4FC3F7); stats.addView(levelText);
            layout.addView(stats);

            // Панель скорости
            LinearLayout speedPanel = new LinearLayout(this);
            speedPanel.setGravity(Gravity.CENTER);
            speedPanel.setPadding(8, 4, 8, 4);
            speedPanel.setBackgroundColor(0xFF1A1A3E);
            speedText = new TextView(this);
            speedText.setText("Скорость: Средняя"); speedText.setTextSize(12);
            speedText.setTextColor(0xFFFFFFFF); speedPanel.addView(speedText);
            speedBar = new SeekBar(this);
            speedBar.setMax(9);
            speedBar.setProgress(4);
            LinearLayout.LayoutParams sbp = new LinearLayout.LayoutParams(250, -2);
            sbp.setMargins(8, 0, 8, 0);
            speedBar.setLayoutParams(sbp);
            speedBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
                @Override public void onProgressChanged(SeekBar s, int p, boolean u) {
                    int[] speeds = {250, 220, 190, 160, 130, 100, 80, 60, 45, 30};
                    String[] names = {"Черепаха", "Очень медл.", "Медленная", "Ниже сред.", "Средняя",
                                     "Выше сред.", "Быстрая", "Очень быстр.", "Молния", "Невозможная"};
                    gameSpeed = speeds[p];
                    speedText.setText(names[p] + " (" + gameSpeed + "мс)");
                }
                @Override public void onStartTrackingTouch(SeekBar s) {}
                @Override public void onStopTrackingTouch(SeekBar s) {}
            });
            speedPanel.addView(speedBar);
            layout.addView(speedPanel);

            // Игровое поле (с весом 1 — занимает оставшееся место)
            gameView = new GameView(this);
            LinearLayout.LayoutParams gvp = new LinearLayout.LayoutParams(-1, 0, 1);
            gameView.setLayoutParams(gvp);
            layout.addView(gameView);

            // Кнопка СТАРТ
            btnNew = new Button(this);
            btnNew.setText("▶ СТАРТ");
            btnNew.setTextSize(18);
            btnNew.setBackgroundColor(0xFF4CAF50);
            btnNew.setTextColor(Color.WHITE);
            btnNew.setPadding(0, 12, 0, 12);
            btnNew.setOnClickListener(v -> startGame());
            layout.addView(btnNew);

            // Кнопки управления
            LinearLayout dpad = new LinearLayout(this);
            dpad.setOrientation(LinearLayout.VERTICAL);
            dpad.setGravity(Gravity.CENTER);
            dpad.setPadding(4, 4, 4, 8);

            btnUp = new Button(this);
            btnUp.setText("▲"); btnUp.setTextSize(24);
            btnUp.setBackgroundColor(0xFF1565C0); btnUp.setTextColor(Color.WHITE);
            btnUp.setPadding(30, 8, 30, 8);
            btnUp.setOnTouchListener((v, e) -> {
                if (e.getAction() == MotionEvent.ACTION_DOWN) { setDirection(0, -1); v.animate().scaleX(0.9f).scaleY(0.9f).setDuration(60).start(); }
                else { v.animate().scaleX(1f).scaleY(1f).setDuration(60).start(); }
                return true;
            });
            dpad.addView(btnUp);

            LinearLayout midRow = new LinearLayout(this);
            midRow.setGravity(Gravity.CENTER);

            btnLeft = new Button(this);
            btnLeft.setText("◄"); btnLeft.setTextSize(24);
            btnLeft.setBackgroundColor(0xFF1565C0); btnLeft.setTextColor(Color.WHITE);
            btnLeft.setPadding(30, 8, 30, 8);
            btnLeft.setOnTouchListener((v, e) -> {
                if (e.getAction() == MotionEvent.ACTION_DOWN) { setDirection(-1, 0); v.animate().scaleX(0.9f).scaleY(0.9f).setDuration(60).start(); }
                else { v.animate().scaleX(1f).scaleY(1f).setDuration(60).start(); }
                return true;
            });
            midRow.addView(btnLeft);

            btnRight = new Button(this);
            btnRight.setText("►"); btnRight.setTextSize(24);
            btnRight.setBackgroundColor(0xFF1565C0); btnRight.setTextColor(Color.WHITE);
            btnRight.setPadding(30, 8, 30, 8);
            btnRight.setOnTouchListener((v, e) -> {
                if (e.getAction() == MotionEvent.ACTION_DOWN) { setDirection(1, 0); v.animate().scaleX(0.9f).scaleY(0.9f).setDuration(60).start(); }
                else { v.animate().scaleX(1f).scaleY(1f).setDuration(60).start(); }
                return true;
            });
            midRow.addView(btnRight);

            dpad.addView(midRow);

            btnDown = new Button(this);
            btnDown.setText("▼"); btnDown.setTextSize(24);
            btnDown.setBackgroundColor(0xFF1565C0); btnDown.setTextColor(Color.WHITE);
            btnDown.setPadding(30, 8, 30, 8);
            btnDown.setOnTouchListener((v, e) -> {
                if (e.getAction() == MotionEvent.ACTION_DOWN) { setDirection(0, 1); v.animate().scaleX(0.9f).scaleY(0.9f).setDuration(60).start(); }
                else { v.animate().scaleX(1f).scaleY(1f).setDuration(60).start(); }
                return true;
            });
            dpad.addView(btnDown);

            layout.addView(dpad);

            setContentView(layout);
            setTitle("🐍 Змейка");
            initSnake();
            startGameLoop();
            AppLogger.log(this, "Snake", "onCreate completed, layout with weight");
        } catch (Exception e) { AppLogger.logException(this, "Snake", e); finish(); }
    }

    private void initSnake() {
        snake.clear();
        int sx = cols / 2, sy = rows / 2;
        for (int i = 0; i < 4; i++) snake.add(new SnakeSegment(sx, sy + i, i == 0));
        dirX = 0; dirY = -1; nextDirX = 0; nextDirY = -1;
        score = 0; level = 1; gameOver = false; gameStarted = false;
        sparkles.clear(); spawnFood(); updateUI();
    }

    private void startGame() {
        if (gameStarted) { initSnake(); gameStarted = true; btnNew.setText("🔄 НОВАЯ ИГРА"); }
        else { gameStarted = true; btnNew.setText("🔄 НОВАЯ ИГРА"); }
        AppLogger.log(this, "Snake", gameStarted ? "Game started" : "New game");
    }

    private void setDirection(int dx, int dy) {
        if (!gameStarted || gameOver) return;
        if (dx != -dirX || dy != -dirY) { nextDirX = dx; nextDirY = dy; }
    }

    private void spawnFood() {
        do { food[0] = rand.nextInt(cols); food[1] = rand.nextInt(rows); } while (isSnake(food[0], food[1]));
        float r = rand.nextFloat();
        foodType = r < 0.15 ? 1 : r < 0.30 ? 2 : 0;
    }

    private boolean isSnake(int x, int y) { for (SnakeSegment s : snake) if (s.x == x && s.y == y) return true; return false; }

    private void updateUI() {
        scoreText.setText("Счёт: " + score);
        if (score > best) { best = score; GameScores.saveScore(this, "snake", best); }
        bestText.setText("  Рекорд: " + best);
        levelText.setText("  Ур." + level);
    }

    private void startGameLoop() {
        running = true;
        new Thread(() -> {
            while (running) {
                try {
                    Thread.sleep(gameSpeed);
                    if (gameStarted && !gameOver) {
                        dirX = nextDirX; dirY = nextDirY;
                        SnakeSegment head = snake.get(0); head.isHead = false;
                        int hx = head.x + dirX, hy = head.y + dirY;
                        if (hx < 0 || hx >= cols || hy < 0 || hy >= rows || isSnake(hx, hy)) {
                            gameOver = true; gameStarted = false;
                            runOnUiThread(() -> { btnNew.setText("▶ СТАРТ"); Toast.makeText(SnakeGameActivity.this, "💀 Game Over! Счёт: " + score, Toast.LENGTH_SHORT).show(); });
                            for (SnakeSegment s : snake) sparkles.add(new Sparkle(s.x, s.y, 0xFF4CAF50));
                        } else {
                            snake.add(0, new SnakeSegment(hx, hy, true));
                            if (hx == food[0] && hy == food[1]) {
                                score += foodType == 1 ? 3 : foodType == 2 ? 2 : 1;
                                int sc = foodType == 1 ? 0xFFFFD740 : foodType == 2 ? 0xFFFF5252 : 0xFF4CAF50;
                                for (int i = 0; i < 8; i++) sparkles.add(new Sparkle(food[0], food[1], sc));
                                spawnFood(); level = 1 + score / 5;
                                if (gameSpeed > 30) gameSpeed = Math.max(30, gameSpeed - 2);
                                runOnUiThread(this::updateUI);
                            } else snake.remove(snake.size() - 1);
                        }
                    }
                    for (int i = sparkles.size() - 1; i >= 0; i--) {
                        Sparkle s = sparkles.get(i); s.life -= 12; s.alpha = Math.max(0, s.life);
                        if (s.life <= 0) sparkles.remove(i);
                    }
                    gameView.postInvalidate();
                } catch (Exception e) { AppLogger.logException(SnakeGameActivity.this, "Snake", e); }
            }
        }).start();
    }

    class GameView extends View {
        private Paint paint = new Paint();
        public GameView(Context ctx) { super(ctx); }

        @Override
        protected void onDraw(Canvas c) {
            try {
                super.onDraw(c);
                int w = getWidth(), h = getHeight();
                if (w <= 0 || h <= 0) return;
                float cell = Math.min(w / (float) cols, h / (float) rows);
                float ox = (w - cell * cols) / 2f, oy = (h - cell * rows) / 2f;

                paint.setColor(0xFF0A0A1A); c.drawRect(ox - 4, oy - 4, ox + cell * cols + 4, oy + cell * rows + 4, paint);
                paint.setColor(0xFF0D1B2A); c.drawRect(ox, oy, ox + cell * cols, oy + cell * rows, paint);
                paint.setColor(0x11222230);
                for (int r = 0; r < rows; r++) for (int cc = 0; cc < cols; cc++)
                    c.drawRect(ox + cc * cell + 1, oy + r * cell + 1, ox + cc * cell + cell - 1, oy + r * cell + cell - 1, paint);

                float fx = ox + food[0] * cell + cell / 2f, fy = oy + food[1] * cell + cell / 2f, fs = cell * 0.38f;
                int go = foodType == 1 ? Color.argb(0x44, 0xFF, 0xD7, 0x40) : foodType == 2 ? Color.argb(0x44, 0xFF, 0x52, 0x52) : Color.argb(0x44, 0x4C, 0xAF, 0x50);
                int gi = foodType == 1 ? Color.argb(0x66, 0xFF, 0xD7, 0x40) : foodType == 2 ? Color.argb(0x66, 0xFF, 0x52, 0x52) : Color.argb(0x66, 0x4C, 0xAF, 0x50);
                int fc = foodType == 1 ? 0xFFFFD740 : foodType == 2 ? 0xFFFF5252 : 0xFFFF1744;
                paint.setColor(go); c.drawCircle(fx, fy, fs * 2f, paint);
                paint.setColor(gi); c.drawCircle(fx, fy, fs * 1.4f, paint);
                paint.setColor(fc); c.drawCircle(fx, fy, fs, paint);
                paint.setColor(0x44FFFFFF); c.drawCircle(fx - fs * 0.3f, fy - fs * 0.3f, fs * 0.4f, paint);

                for (int i = 0; i < snake.size(); i++) {
                    SnakeSegment seg = snake.get(i);
                    float sx = ox + seg.x * cell, sy = oy + seg.y * cell, pad = cell * 0.06f;
                    if (seg.isHead) {
                        LinearGradient hg = new LinearGradient(sx, sy, sx + cell, sy + cell, 0xFF4CAF50, 0xFF2E7D32, Shader.TileMode.CLAMP);
                        paint.setShader(hg); c.drawCircle(sx + cell / 2, sy + cell / 2, cell * 0.42f, paint); paint.setShader(null);
                        float ex = sx + cell / 2f, ey = sy + cell / 2f; paint.setColor(Color.WHITE);
                        if (dirX == 0 && dirY == -1) { c.drawCircle(ex - cell * 0.15f, ey - cell * 0.12f, cell * 0.12f, paint); c.drawCircle(ex + cell * 0.15f, ey - cell * 0.12f, cell * 0.12f, paint); }
                        else if (dirX == 0 && dirY == 1) { c.drawCircle(ex - cell * 0.15f, ey + cell * 0.12f, cell * 0.12f, paint); c.drawCircle(ex + cell * 0.15f, ey + cell * 0.12f, cell * 0.12f, paint); }
                        else if (dirX == -1) { c.drawCircle(ex - cell * 0.12f, ey - cell * 0.15f, cell * 0.12f, paint); c.drawCircle(ex - cell * 0.12f, ey + cell * 0.15f, cell * 0.12f, paint); }
                        else { c.drawCircle(ex + cell * 0.12f, ey - cell * 0.15f, cell * 0.12f, paint); c.drawCircle(ex + cell * 0.12f, ey + cell * 0.15f, cell * 0.12f, paint); }
                        paint.setColor(Color.BLACK);
                        if (dirX == 0 && dirY == -1) { c.drawCircle(ex - cell * 0.14f, ey - cell * 0.14f, cell * 0.05f, paint); c.drawCircle(ex + cell * 0.16f, ey - cell * 0.14f, cell * 0.05f, paint); }
                        else if (dirX == 0 && dirY == 1) { c.drawCircle(ex - cell * 0.14f, ey + cell * 0.10f, cell * 0.05f, paint); c.drawCircle(ex + cell * 0.16f, ey + cell * 0.10f, cell * 0.05f, paint); }
                        else if (dirX == -1) { c.drawCircle(ex - cell * 0.14f, ey - cell * 0.13f, cell * 0.05f, paint); c.drawCircle(ex - cell * 0.14f, ey + cell * 0.17f, cell * 0.05f, paint); }
                        else { c.drawCircle(ex + cell * 0.14f, ey - cell * 0.13f, cell * 0.05f, paint); c.drawCircle(ex + cell * 0.14f, ey + cell * 0.17f, cell * 0.05f, paint); }
                    } else {
                        float t = i / (float) Math.max(1, snake.size() - 1);
                        LinearGradient bg = new LinearGradient(sx, sy, sx + cell, sy + cell, lerpColor(0xFF81C784, 0xFF388E3C, t), lerpColor(0xFF66BB6A, 0xFF2E7D32, t), Shader.TileMode.CLAMP);
                        paint.setShader(bg); c.drawRoundRect(sx + pad, sy + pad, sx + cell - pad, sy + cell - pad, cell * 0.2f, cell * 0.2f, paint); paint.setShader(null);
                    }
                    paint.setColor(0x22000000); paint.setStyle(Paint.Style.STROKE); paint.setStrokeWidth(1);
                    if (seg.isHead) c.drawCircle(sx + cell / 2, sy + cell / 2, cell * 0.42f, paint);
                    else c.drawRoundRect(sx + pad, sy + pad, sx + cell - pad, sy + cell - pad, cell * 0.2f, cell * 0.2f, paint);
                    paint.setStyle(Paint.Style.FILL);
                }

                for (Sparkle s : sparkles) { paint.setColor(s.color); paint.setAlpha(s.alpha); c.drawCircle(ox + s.x * cell + cell / 2, oy + s.y * cell + cell / 2, s.size * cell, paint); }
                paint.setAlpha(255);

                if (!gameStarted && !gameOver) {
                    paint.setColor(0x88000000); c.drawRect(ox, oy, ox + cell * cols, oy + cell * rows, paint);
                    paint.setColor(Color.WHITE); paint.setTextSize(cell * 1.5f); paint.setTextAlign(Paint.Align.CENTER); paint.setFakeBoldText(true);
                    c.drawText("ЗМЕЙКА", ox + cell * cols / 2, oy + cell * rows / 2 - cell, paint);
                    paint.setTextSize(cell * 0.9f); paint.setFakeBoldText(false);
                    c.drawText("Выбери скорость и нажми", ox + cell * cols / 2, oy + cell * rows / 2 + cell * 0.5f, paint);
                    c.drawText("▶ СТАРТ", ox + cell * cols / 2, oy + cell * rows / 2 + cell * 2f, paint);
                    paint.setTextAlign(Paint.Align.LEFT);
                }
                if (gameOver) {
                    paint.setColor(0xAA000000); c.drawRect(ox, oy, ox + cell * cols, oy + cell * rows, paint);
                    paint.setColor(Color.WHITE); paint.setTextSize(cell * 1.8f); paint.setTextAlign(Paint.Align.CENTER); paint.setFakeBoldText(true);
                    c.drawText("GAME OVER", ox + cell * cols / 2, oy + cell * rows / 2 - cell, paint);
                    paint.setTextSize(cell * 1f); paint.setFakeBoldText(false);
                    c.drawText("Счёт: " + score + " | Ур." + level, ox + cell * cols / 2, oy + cell * rows / 2 + cell, paint);
                    c.drawText("Нажми СТАРТ", ox + cell * cols / 2, oy + cell * rows / 2 + cell * 2.5f, paint);
                    paint.setTextAlign(Paint.Align.LEFT);
                }
            } catch (Exception e) { AppLogger.logException(SnakeGameActivity.this, "Snake", e); }
        }
    }

    private int lerpColor(int c1, int c2, float t) { return Color.rgb((int)(Color.red(c1)+(Color.red(c2)-Color.red(c1))*t), (int)(Color.green(c1)+(Color.green(c2)-Color.green(c1))*t), (int)(Color.blue(c1)+(Color.blue(c2)-Color.blue(c1))*t)); }

    static class SnakeSegment { int x, y; boolean isHead; SnakeSegment(int x, int y, boolean h) { this.x=x; this.y=y; this.isHead=h; } }
    static class Sparkle { int x, y, color, life=180, alpha=255; float size; Sparkle(int x, int y, int c) { this.x=x; this.y=y; this.color=c; this.size=0.1f+new Random().nextFloat()*0.3f; } }

    @Override protected void onDestroy() { super.onDestroy(); running=false; handler.removeCallbacksAndMessages(null); }
}