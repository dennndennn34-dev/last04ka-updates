package com.last04ka.messenger.ui;

import android.app.Activity;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.os.Bundle;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.TextView;
import com.last04ka.messenger.utils.AppLogger;
import com.last04ka.messenger.utils.GameScores;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class FlappyBirdActivity extends Activity {

    private GameView gameView;
    private TextView scoreText, speedText;
    private SeekBar speedBar;
    private int score = 0;
    private boolean gameOver = false;
    private float gameSpeed = 1.0f;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        try {
            AppLogger.log(this, "FlappyBird", "onCreate v2.0 with speed control");
            AppLogger.logUI(this, "FlappyBird", "Layout with SeekBar", true);

            LinearLayout mainLayout = new LinearLayout(this);
            mainLayout.setOrientation(LinearLayout.VERTICAL);
            mainLayout.setBackgroundColor(0xFF4FC3F7);

            // Панель настроек
            LinearLayout settingsPanel = new LinearLayout(this);
            settingsPanel.setOrientation(LinearLayout.HORIZONTAL);
            settingsPanel.setGravity(Gravity.CENTER);
            settingsPanel.setPadding(8, 4, 8, 4);
            settingsPanel.setBackgroundColor(0xAA000000);

            speedText = new TextView(this);
            speedText.setText("Скорость: Средняя"); speedText.setTextSize(12);
            speedText.setTextColor(Color.WHITE);
            settingsPanel.addView(speedText);

            speedBar = new SeekBar(this);
            speedBar.setMax(2); speedBar.setProgress(1);
            speedBar.setLayoutParams(new LinearLayout.LayoutParams(200, -2));
            speedBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
                @Override public void onProgressChanged(SeekBar s, int p, boolean u) {
                    String[] names = {"Медленная", "Средняя", "Быстрая"};
                    float[] speeds = {0.7f, 1.0f, 1.4f};
                    gameSpeed = speeds[p];
                    speedText.setText("Скорость: " + names[p]);
                    AppLogger.log(FlappyBirdActivity.this, "FlappyBird", "Speed changed to " + names[p]);
                }
                @Override public void onStartTrackingTouch(SeekBar s) {}
                @Override public void onStopTrackingTouch(SeekBar s) {}
            });
            settingsPanel.addView(speedBar);

            mainLayout.addView(settingsPanel);

            FrameLayout gameLayout = new FrameLayout(this);
            gameView = new GameView(this);
            gameLayout.addView(gameView);

            scoreText = new TextView(this);
            scoreText.setTextSize(36);
            scoreText.setTextColor(Color.WHITE);
            scoreText.setShadowLayer(3, 1, 1, Color.BLACK);
            scoreText.setText("0");
            FrameLayout.LayoutParams p = new FrameLayout.LayoutParams(-2, -2);
            p.setMargins(24, 24, 0, 0);
            scoreText.setLayoutParams(p);
            gameLayout.addView(scoreText);

            mainLayout.addView(gameLayout, new LinearLayout.LayoutParams(-1, 0, 1));

            setContentView(mainLayout);
            setTitle("🐤 Флаппи Бёрд");
            AppLogger.log(this, "FlappyBird", "onCreate completed");
        } catch (Exception e) { AppLogger.logException(this, "FlappyBird", e); finish(); }
    }

    class GameView extends View {
        private Paint paint = new Paint();
        private Random random = new Random();
        private float birdY, birdVelocity, birdX = 120, birdRadius = 22;
        private float gravity = 0.55f, jumpVelocity = -9f, maxFallSpeed = 12f;
        private List<Pipe> pipes = new ArrayList<>();
        private float pipeWidth = 100f, pipeGap = 280f;
        private int pipeSpawnTimer = 0, pipeSpawnInterval = 100;
        private boolean running = false, started = false;
        private float wingAngle = 0f, wingFlapDir = 1f;
        private List<Feather> feathers = new ArrayList<>();
        private List<Cloud> clouds = new ArrayList<>();

        public GameView(Context ctx) { super(ctx); setFocusable(true); initClouds(); }

        private void initClouds() { clouds.clear(); for (int i=0;i<5;i++) clouds.add(new Cloud(random.nextFloat()*getWidth(), random.nextFloat()*getHeight()*0.4f, random.nextFloat()*60+40)); }
        private void reset() {
            int h=getHeight(); if(h==0)h=800;
            birdRadius=h*0.025f; birdX=getWidth()*0.2f; pipeWidth=getWidth()*0.22f; pipeGap=h*0.38f;
            birdY=h/2f; birdVelocity=0; pipes.clear(); score=0; feathers.clear(); gameOver=false; running=false; started=false; pipeSpawnTimer=0;
            runOnUiThread(()->scoreText.setText("0")); invalidate();
        }

        @Override
        protected void onDraw(Canvas c) {
            super.onDraw(c); int w=getWidth(),h=getHeight(); if(w==0||h==0)return;
            paint.setColor(0xFF4FC3F7);c.drawRect(0,0,w,h,paint);
            for(Cloud cl:clouds){paint.setColor(0x88FFFFFF);c.drawCircle(cl.x,cl.y,cl.size,paint);c.drawCircle(cl.x+cl.size*0.6f,cl.y-cl.size*0.2f,cl.size*0.7f,paint);}
            paint.setColor(0xFF8BC34A);c.drawRect(0,h*0.88f,w,h,paint);paint.setColor(0xFF689F38);c.drawRect(0,h*0.88f,w,h*0.90f,paint);
            if(!started){drawBird(c,birdX,birdY,birdRadius,0);paint.setColor(Color.WHITE);paint.setTextSize(h*0.04f);paint.setTextAlign(Paint.Align.CENTER);c.drawText("Тап для старта",w/2f,h*0.45f,paint);paint.setTextAlign(Paint.Align.LEFT);return;}
            for(Pipe p:pipes){RectF r=p.rect;paint.setColor(0xFF4CAF50);c.drawRect(r,paint);paint.setColor(0xFF388E3C);if(p.isTop)c.drawRect(r.left-8,r.bottom-30,r.right+8,r.bottom,paint);else c.drawRect(r.left-8,r.top,r.right+8,r.top+30,paint);}
            drawBird(c,birdX,birdY,birdRadius,wingAngle);
            paint.setColor(0xFF8BC34A);c.drawRect(0,h*0.88f,w,h,paint);paint.setColor(0xFF689F38);c.drawRect(0,h*0.88f,w,h*0.90f,paint);
            for(Feather f:feathers){paint.setColor(0xFFFFEB3B);paint.setAlpha(f.alpha);c.drawCircle(f.x,f.y,f.size,paint);}paint.setAlpha(255);
            if(gameOver){paint.setColor(0xAA000000);c.drawRect(0,h*0.35f,w,h*0.55f,paint);paint.setColor(Color.WHITE);paint.setTextSize(h*0.05f);paint.setTextAlign(Paint.Align.CENTER);c.drawText("Game Over",w/2f,h*0.42f,paint);paint.setTextSize(h*0.03f);c.drawText("Счёт: "+score,w/2f,h*0.47f,paint);c.drawText("Тап для рестарта",w/2f,h*0.51f,paint);paint.setTextAlign(Paint.Align.LEFT);}
        }

        private void drawBird(Canvas c,float x,float y,float r,float wa){
            paint.setColor(0xFFFFEB3B);c.drawCircle(x,y,r,paint);
            c.save();c.rotate(wa*15,x+r*0.1f,y+r*0.3f);paint.setColor(0xFFFFC107);c.drawOval(new RectF(x-r*0.5f,y-r*0.1f,x+r*0.3f,y+r*0.8f),paint);c.restore();
            paint.setColor(Color.WHITE);c.drawCircle(x+r*0.35f,y-r*0.25f,r*0.4f,paint);paint.setColor(Color.BLACK);c.drawCircle(x+r*0.45f,y-r*0.25f,r*0.18f,paint);
            paint.setColor(0xFFFF5722);c.drawCircle(x+r*0.8f,y+r*0.1f,r*0.2f,paint);
        }

        public void update() {
            if(gameOver||!running)return; int w=getWidth(),h=getHeight(); if(w==0||h==0)return;
            wingAngle+=wingFlapDir*0.3f;if(Math.abs(wingAngle)>0.6f)wingFlapDir=-wingFlapDir;
            for(Cloud cl:clouds){cl.x-=0.3f*gameSpeed;if(cl.x<-100)cl.x=w+50;}
            birdVelocity+=gravity;if(birdVelocity>maxFallSpeed)birdVelocity=maxFallSpeed;birdY+=birdVelocity*gameSpeed;
            float groundY=h*0.88f-birdRadius;if(birdY+birdRadius>groundY){birdY=groundY;gameOver=true;running=false;spawnFeathers();saveScore();return;}
            if(birdY-birdRadius<0){birdY=birdRadius;birdVelocity=0;}
            pipeSpawnTimer++;if(pipeSpawnTimer>=pipeSpawnInterval){pipeSpawnTimer=0;float avail=groundY-pipeGap;float gapY=30+random.nextFloat()*Math.max(0,avail-60);pipes.add(new Pipe(new RectF(w,0,w+pipeWidth,gapY),true));pipes.add(new Pipe(new RectF(w,gapY+pipeGap,w+pipeWidth,groundY),false));}
            for(int i=pipes.size()-1;i>=0;i--){Pipe p=pipes.get(i);p.rect.offset(-4.5f*gameSpeed,0);if(p.rect.right<-pipeWidth)pipes.remove(i);}
            for(Pipe p:pipes){RectF r=p.rect;if(birdX+birdRadius-5>r.left&&birdX-birdRadius+5<r.right)if(birdY-birdRadius+5<r.bottom&&birdY+birdRadius-5>r.top){gameOver=true;running=false;spawnFeathers();saveScore();break;}}
            for(int i=0;i<pipes.size();i+=2){Pipe tp=pipes.get(i);if(!tp.scored&&tp.rect.right<birdX){tp.scored=true;pipes.get(i+1).scored=true;score++;runOnUiThread(()->scoreText.setText(String.valueOf(score)));}}
            for(int i=feathers.size()-1;i>=0;i--){Feather f=feathers.get(i);f.y+=f.vy;f.x+=f.vx;f.vy+=0.2f;f.life-=10;f.alpha=Math.max(0,f.life);if(f.life<=0)feathers.remove(i);}
        }

        private void spawnFeathers(){for(int i=0;i<15;i++)feathers.add(new Feather(birdX,birdY));}
        @Override public boolean onTouchEvent(MotionEvent e){if(e.getAction()==MotionEvent.ACTION_DOWN){if(gameOver){reset();}else if(!started){started=true;running=true;birdY=getHeight()/2f;birdVelocity=jumpVelocity;AppLogger.log(FlappyBirdActivity.this,"FlappyBird","Game started");}else if(running){birdVelocity=jumpVelocity;}}return true;}
        public void saveScore(){GameScores.saveScore(getContext(),"flappybird",score);AppLogger.log(FlappyBirdActivity.this,"FlappyBird","Game over, score="+score);}
        public void startGameLoop(){new Thread(()->{while(true){try{Thread.sleep(16);update();postInvalidate();}catch(InterruptedException e){break;}}}).start();}
        @Override protected void onAttachedToWindow(){super.onAttachedToWindow();startGameLoop();}
        @Override protected void onDetachedFromWindow(){super.onDetachedFromWindow();running=false;}
    }

    static class Pipe { RectF rect; boolean scored=false, isTop; Pipe(RectF r, boolean t){rect=r;isTop=t;} }
    static class Feather { float x,y,vx,vy,size; int life=200,alpha=200; Feather(float x,float y){Random r=new Random();this.x=x;this.y=y;this.vx=(r.nextFloat()-0.5f)*8f;this.vy=-r.nextFloat()*6f-2f;this.size=r.nextFloat()*4+2;} }
    static class Cloud { float x,y,size; Cloud(float x,float y,float size){this.x=x;this.y=y;this.size=size;} }
}