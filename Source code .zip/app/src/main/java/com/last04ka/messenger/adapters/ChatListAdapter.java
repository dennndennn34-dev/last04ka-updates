package com.last04ka.messenger.adapters;

import android.graphics.Typeface;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.last04ka.messenger.R;
import com.last04ka.messenger.data.Chat;
import com.last04ka.messenger.utils.AppLogger;
import com.last04ka.messenger.utils.ThemeManager;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class ChatListAdapter extends RecyclerView.Adapter<ChatListAdapter.ViewHolder> {

    private List<Chat> chats;
    private OnChatClickListener clickListener;
    private OnChatLongClickListener longClickListener;
    private SimpleDateFormat dateFormat = new SimpleDateFormat("dd.MM HH:mm", Locale.getDefault());

    public interface OnChatClickListener { void onChatClick(Chat chat); }
    public interface OnChatLongClickListener { void onChatLongClick(Chat chat); }

    public ChatListAdapter(List<Chat> chats, OnChatClickListener listener) {
        this.chats = chats;
        this.clickListener = listener;
        AppLogger.log(null, "ChatListAdapter", "Adapter created with " + (chats != null ? chats.size() : 0) + " chats");
    }

    public void setOnChatLongClickListener(OnChatLongClickListener listener) {
        this.longClickListener = listener;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        try {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_chat, parent, false);
            AppLogger.log(null, "ChatListAdapter", "onCreateViewHolder OK");
            return new ViewHolder(view);
        } catch (Exception e) {
            AppLogger.logException(null, "ChatListAdapter", "onCreateViewHolder error", e);
            throw e;
        }
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {
        try {
            AppLogger.log(null, "ChatListAdapter", "onBindViewHolder position=" + position + ", size=" + chats.size());
            if (position >= chats.size()) {
                AppLogger.log(null, "ChatListAdapter", "ERROR: position >= chats.size()");
                return;
            }
            
            Chat chat = chats.get(position);
            if (chat == null) {
                AppLogger.log(null, "ChatListAdapter", "ERROR: chat is null at position " + position);
                return;
            }

            AppLogger.log(null, "ChatListAdapter", "Binding chat: " + chat.getName());

            // Устанавливаем имя
            String name = chat.getName() != null ? chat.getName() : "Без имени";
            holder.nameText.setText(name);

            // Устанавливаем последнее сообщение
            String lastMsg = chat.getLastMessage() != null ? chat.getLastMessage() : "";
            holder.messageText.setText(lastMsg);

            // Устанавливаем время
            long time = chat.getTimestamp() > 0 ? chat.getTimestamp() : chat.getLastTime();
            if (time > 0) {
                holder.timeText.setText(dateFormat.format(new Date(time)));
            } else {
                holder.timeText.setText("");
            }

            // Избранное
            holder.favoriteIndicator.setVisibility(chat.isFavorite() ? View.VISIBLE : View.GONE);

            // Цвета темы
            try {
                int nameColor = ThemeManager.getChatNameColor(holder.itemView.getContext());
                int msgColor = ThemeManager.getLastMessageColor(holder.itemView.getContext());
                holder.nameText.setTextColor(nameColor);
                holder.messageText.setTextColor(msgColor);
            } catch (Exception e) {
                AppLogger.logException(null, "ChatListAdapter", "Theme colors error", e);
            }

            // Клик
            holder.itemView.setOnClickListener(v -> {
                if (clickListener != null) {
                    AppLogger.log(null, "ChatListAdapter", "Chat clicked: " + chat.getName());
                    clickListener.onChatClick(chat);
                }
            });

            // Длинный клик
            holder.itemView.setOnLongClickListener(v -> {
                if (longClickListener != null) {
                    AppLogger.log(null, "ChatListAdapter", "Chat long clicked: " + chat.getName());
                    longClickListener.onChatLongClick(chat);
                }
                return true;
            });

        } catch (Exception e) {
            AppLogger.logException(null, "ChatListAdapter", "onBindViewHolder error at position " + position, e);
        }
    }

    @Override
    public int getItemCount() {
        int count = chats != null ? chats.size() : 0;
        return count;
    }

    static class ViewHolder extends RecyclerView.ViewHolder {
        TextView nameText, messageText, timeText, favoriteIndicator;
        ViewHolder(View v) {
            super(v);
            try {
                nameText = v.findViewById(R.id.chat_name);
                messageText = v.findViewById(R.id.last_message);
                timeText = v.findViewById(R.id.chat_time);
                favoriteIndicator = v.findViewById(R.id.favorite_indicator);
                
                if (nameText == null) AppLogger.log(null, "ChatListAdapter", "WARNING: chat_name is null");
                if (messageText == null) AppLogger.log(null, "ChatListAdapter", "WARNING: last_message is null");
                if (timeText == null) AppLogger.log(null, "ChatListAdapter", "WARNING: chat_time is null");
                if (favoriteIndicator == null) AppLogger.log(null, "ChatListAdapter", "WARNING: favorite_indicator is null");
            } catch (Exception e) {
                AppLogger.logException(null, "ChatListAdapter", "ViewHolder init error", e);
            }
        }
    }
}