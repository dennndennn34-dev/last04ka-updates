package com.last04ka.messenger.ui;

import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import com.last04ka.messenger.utils.AppLogger;
import java.util.Random;

public class JokesActivity extends Activity {

    private TextView jokeText;
    private Button btnRandom, btnCopy;
    private String currentJoke = "";
    private Random r = new Random();

    private String[] jokes = {
        "Почему программисты путают Рождество и Хеллоуин? Потому что Oct 31 == Dec 25!",
        "— Доктор, я слишком много сплю. — Вам нужно меньше лежать.",
        "Купил мужик шляпу, а она ему как раз.",
        "Идёт медведь по лесу, видит — машина горит. Сел в неё и сгорел.",
        "— Почему ты не женат? — Я жду ту самую. — А она? — А она не ждёт.",
        "Колобок повесился.",
        "Встретились два одиночества. Разошлись, недовольные друг другом.",
        "Объявление: 'Продам котят. Ручные, ласковые, мяукают басом.'",
        "— Ты где был? — Гулял. — А почему мокрый? — Гулял под дождём.",
        "Заходит как-то бармен в бар, а там никого. И бармена нет.",
        "Стук в дверь. — Кто там? — Это я, твоя совесть. — А, это ты. Ну заходи, только не начинай.",
        "Жизнь — это когда есть кого любить, что делать и на что надеяться. Ну или просто пятница.",
        "— Почему ты грустный? — Да вот, думаю о смысле жизни. — И как? — Пока смысла нет, но я продолжаю искать. В основном в холодильнике.",
        "Оптимист видит стакан наполовину полным. Пессимист — наполовину пустым. Программист видит стакан удвоенной точности.",
        "— Как дела на работе? — Как в армии: сначала два года ждёшь дембеля, а потом всю жизнь вспоминаешь.",
        "Решил начать новую жизнь с понедельника. В понедельник передумал.",
        "— Ты зачем в магазин ходил? — За хлебом. — А где хлеб? — Его там не было, пришлось взять пирожные.",
        "— Почему ты не пользуешься своим абонементом в спортзал? — Я пользуюсь! Я им дверь подпираю.",
        "Иногда кажется, что ты всё понимаешь. А потом просыпаешься.",
        "Лучший способ запомнить, что сделал — записать. Но записать тоже надо не забыть."
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        try {
            AppLogger.log(this, "Jokes", "onCreate started");
            LinearLayout layout = new LinearLayout(this);
            layout.setOrientation(LinearLayout.VERTICAL);
            layout.setPadding(24, 24, 24, 24);
            layout.setBackgroundColor(0xFF1A1A2E);

            TextView title = new TextView(this);
            title.setText("🎭 Генератор анекдотов");
            title.setTextSize(20); title.setTextColor(0xFFFFFFFF);
            title.setGravity(android.view.Gravity.CENTER);
            title.setPadding(0, 0, 0, 16);
            layout.addView(title);

            ScrollView sv = new ScrollView(this);
            jokeText = new TextView(this);
            jokeText.setText("Нажмите 'Случайный'");
            jokeText.setTextSize(18); jokeText.setTextColor(0xFFFFFFFF);
            jokeText.setPadding(16, 16, 16, 16);
            jokeText.setBackgroundColor(0xFF333333);
            jokeText.setMinHeight(200);
            sv.addView(jokeText);
            layout.addView(sv);

            LinearLayout btns = new LinearLayout(this);
            btns.setOrientation(LinearLayout.HORIZONTAL);

            btnRandom = new Button(this); btnRandom.setText("Случайный");
            btnRandom.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    currentJoke = jokes[r.nextInt(jokes.length)];
                    jokeText.setText(currentJoke);
                    AppLogger.log(JokesActivity.this, "Jokes", "New joke shown");
                }
            });
            btns.addView(btnRandom);

            btnCopy = new Button(this); btnCopy.setText("Копировать");
            btnCopy.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (!currentJoke.isEmpty()) {
                        ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
                        cm.setPrimaryClip(ClipData.newPlainText("joke", currentJoke));
                        Toast.makeText(JokesActivity.this, "Скопировано!", Toast.LENGTH_SHORT).show();
                    }
                }
            });
            btns.addView(btnCopy);
            layout.addView(btns);

            setContentView(layout);
            setTitle("🎭 Анекдоты");
            AppLogger.log(this, "Jokes", "onCreate completed");
        } catch (Exception e) { AppLogger.logException(this, "Jokes", e); finish(); }
    }
}