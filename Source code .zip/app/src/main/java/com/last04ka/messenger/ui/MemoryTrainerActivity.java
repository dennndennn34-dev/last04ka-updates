package com.last04ka.messenger.ui;

import android.app.Activity;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import com.last04ka.messenger.utils.AppLogger;
import com.last04ka.messenger.utils.GameScores;
import java.util.Random;

public class MemoryTrainerActivity extends Activity {

    private TextView targetText, scoreText, levelText;
    private EditText inputText;
    private Button btnStart, btnCheck;
    private Handler handler = new Handler();
    private String currentSequence = "";
    private int level = 1, score = 0;
    private boolean showing = false;
    private Random r = new Random();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        try {
            AppLogger.log(this, "MemoryTrainer", "onCreate started");
            LinearLayout layout = new LinearLayout(this);
            layout.setOrientation(LinearLayout.VERTICAL);
            layout.setPadding(32, 32, 32, 32);
            layout.setBackgroundColor(0xFF1A1A2E);

            levelText = new TextView(this);
            levelText.setText("Уровень: 1 | Рекорд: " + GameScores.getScore(this, "memorytrainer"));
            levelText.setTextSize(16); levelText.setTextColor(0xFFBDBDBD);
            layout.addView(levelText);

            scoreText = new TextView(this);
            scoreText.setText("Счёт: 0");
            scoreText.setTextSize(14); scoreText.setTextColor(0xFFFFFFFF);
            layout.addView(scoreText);

            targetText = new TextView(this);
            targetText.setText("Нажмите Старт");
            targetText.setTextSize(36); targetText.setTextColor(0xFFFFD740);
            targetText.setGravity(android.view.Gravity.CENTER);
            targetText.setPadding(0, 32, 0, 32);
            targetText.setMinHeight(100);
            layout.addView(targetText);

            inputText = new EditText(this);
            inputText.setHint("Введите что запомнили...");
            inputText.setTextColor(0xFFFFFFFF); inputText.setHintTextColor(0xFF757575);
            inputText.setEnabled(false);
            layout.addView(inputText);

            LinearLayout btns = new LinearLayout(this);

            btnStart = new Button(this); btnStart.setText("Старт");
            btnStart.setOnClickListener(v -> startRound());
            btns.addView(btnStart);

            btnCheck = new Button(this); btnCheck.setText("Проверить");
            btnCheck.setEnabled(false);
            btnCheck.setOnClickListener(v -> checkAnswer());
            btns.addView(btnCheck);

            layout.addView(btns);
            setContentView(layout);
            setTitle("🧠 Тренировка памяти");
            AppLogger.log(this, "MemoryTrainer", "onCreate completed");
        } catch (Exception e) { AppLogger.logException(this, "MemoryTrainer", e); finish(); }
    }

    private void startRound() {
        btnStart.setEnabled(false); btnCheck.setEnabled(false);
        inputText.setEnabled(false); inputText.setText("");

        StringBuilder sb = new StringBuilder();
        if (level <= 3) {
            for (int i = 0; i < level + 2; i++) sb.append(r.nextInt(10));
        } else if (level <= 6) {
            String chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
            for (int i = 0; i < level; i++) sb.append(chars.charAt(r.nextInt(26)));
        } else {
            String[] words = {"кот","дом","лес","сон","мир","шар","лук","мед","рис","век","зуб","рот","нос","год","час"};
            for (int i = 0; i < Math.min(level - 5, 5); i++) {
                if (i > 0) sb.append(" ");
                sb.append(words[r.nextInt(words.length)]);
            }
        }
        currentSequence = sb.toString();
        targetText.setText(currentSequence);
        showing = true;
        AppLogger.log(this, "MemoryTrainer", "Level " + level + ": " + currentSequence);

        int showTime = 2000 + level * 500;
        handler.postDelayed(() -> {
            targetText.setText("???");
            showing = false;
            inputText.setEnabled(true);
            btnCheck.setEnabled(true);
            inputText.requestFocus();
        }, showTime);
    }

    private void checkAnswer() {
        if (showing) return;
        String answer = inputText.getText().toString().trim();
        if (answer.equalsIgnoreCase(currentSequence)) {
            score += level * 10;
            level++;
            Toast.makeText(this, "✅ Правильно! Уровень " + level, Toast.LENGTH_SHORT).show();
        } else {
            score = Math.max(0, score - 5);
            Toast.makeText(this, "❌ Неправильно! Было: " + currentSequence, Toast.LENGTH_SHORT).show();
        }
        GameScores.saveScore(this, "memorytrainer", score);
        levelText.setText("Уровень: " + level + " | Рекорд: " + GameScores.getScore(this, "memorytrainer"));
        scoreText.setText("Счёт: " + score);
        btnStart.setEnabled(true);
    }
}