package com.last04ka.messenger.utils;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class LanguageData {

    public static class Letter {
        private String letter;
        private String pronunciation;
        private String translation;
        private String example;

        public Letter(String letter, String pronunciation, String translation, String example) {
            this.letter = letter;
            this.pronunciation = pronunciation;
            this.translation = translation;
            this.example = example;
        }

        public String getLetter() { return letter; }
        public String getPronunciation() { return pronunciation; }
        public String getTranslation() { return translation; }
        public String getExample() { return example; }
    }

    public static class Language {
        private String name;
        private String flag;
        private String nativeName;
        private List<Letter> letters;

        public Language(String name, String flag, String nativeName, List<Letter> letters) {
            this.name = name;
            this.flag = flag;
            this.nativeName = nativeName;
            this.letters = letters;
        }

        public String getName() { return name; }
        public String getFlag() { return flag; }
        public String getNativeName() { return nativeName; }
        public List<Letter> getLetters() { return letters; }
    }

    public static List<Language> getAllLanguages() {
        List<Language> languages = new ArrayList<>();

        // 1. Русский
        languages.add(new Language("Русский", "🇷🇺", "Русский", Arrays.asList(
            new Letter("А", "А", "A", "Арбуз"),
            new Letter("Б", "Бэ", "B", "Банан"),
            new Letter("В", "Вэ", "V", "Волк"),
            new Letter("Г", "Гэ", "G", "Город"),
            new Letter("Д", "Дэ", "D", "Дом"),
            new Letter("Е", "Е", "Ye", "Ель"),
            new Letter("Ё", "Ё", "Yo", "Ёж"),
            new Letter("Ж", "Жэ", "Zh", "Жук"),
            new Letter("З", "Зэ", "Z", "Зебра"),
            new Letter("И", "И", "I", "Игла"),
            new Letter("Й", "Й", "Y", "Йогурт"),
            new Letter("К", "Ка", "K", "Кот"),
            new Letter("Л", "Эль", "L", "Лес"),
            new Letter("М", "Эм", "M", "Море"),
            new Letter("Н", "Эн", "N", "Нос"),
            new Letter("О", "О", "O", "Окно"),
            new Letter("П", "Пэ", "P", "Парк"),
            new Letter("Р", "Эр", "R", "Рука"),
            new Letter("С", "Эс", "S", "Солнце"),
            new Letter("Т", "Тэ", "T", "Трава"),
            new Letter("У", "У", "U", "Утро"),
            new Letter("Ф", "Эф", "F", "Флаг"),
            new Letter("Х", "Ха", "Kh", "Хлеб"),
            new Letter("Ц", "Цэ", "Ts", "Цирк"),
            new Letter("Ч", "Чэ", "Ch", "Чай"),
            new Letter("Ш", "Ша", "Sh", "Шапка"),
            new Letter("Щ", "Ща", "Shch", "Щука"),
            new Letter("Ъ", "Твёрдый знак", "Hard sign", "Объём"),
            new Letter("Ы", "Ы", "Y", "Мышь"),
            new Letter("Ь", "Мягкий знак", "Soft sign", "Конь"),
            new Letter("Э", "Э", "E", "Экран"),
            new Letter("Ю", "Ю", "Yu", "Юла"),
            new Letter("Я", "Я", "Ya", "Яблоко")
        )));

        // 2. Английский
        languages.add(new Language("Английский", "🇬🇧", "English", Arrays.asList(
            new Letter("A", "Эй", "A", "Apple"),
            new Letter("B", "Би", "B", "Ball"),
            new Letter("C", "Си", "C", "Cat"),
            new Letter("D", "Ди", "D", "Dog"),
            new Letter("E", "И", "E", "Elephant"),
            new Letter("F", "Эф", "F", "Fish"),
            new Letter("G", "Джи", "G", "Garden"),
            new Letter("H", "Эйч", "H", "House"),
            new Letter("I", "Ай", "I", "Ice"),
            new Letter("J", "Джей", "J", "Jump"),
            new Letter("K", "Кей", "K", "King"),
            new Letter("L", "Эл", "L", "Lemon"),
            new Letter("M", "Эм", "M", "Moon"),
            new Letter("N", "Эн", "N", "Night"),
            new Letter("O", "Оу", "O", "Ocean"),
            new Letter("P", "Пи", "P", "Panda"),
            new Letter("Q", "Кью", "Q", "Queen"),
            new Letter("R", "Ар", "R", "Rain"),
            new Letter("S", "Эс", "S", "Sun"),
            new Letter("T", "Ти", "T", "Tree"),
            new Letter("U", "Ю", "U", "Umbrella"),
            new Letter("V", "Ви", "V", "Violin"),
            new Letter("W", "Дабл-ю", "W", "Water"),
            new Letter("X", "Экс", "X", "X-ray"),
            new Letter("Y", "Уай", "Y", "Yellow"),
            new Letter("Z", "Зэд", "Z", "Zebra")
        )));

        // 3. Немецкий
        languages.add(new Language("Немецкий", "🇩🇪", "Deutsch", Arrays.asList(
            new Letter("A", "А", "A", "Apfel"),
            new Letter("B", "Бе", "B", "Brot"),
            new Letter("C", "Це", "C", "Computer"),
            new Letter("D", "Де", "D", "Dach"),
            new Letter("E", "Е", "E", "Ei"),
            new Letter("F", "Эф", "F", "Fisch"),
            new Letter("G", "Ге", "G", "Garten"),
            new Letter("H", "Ха", "H", "Haus"),
            new Letter("I", "И", "I", "Insel"),
            new Letter("J", "Йот", "J", "Jahr"),
            new Letter("K", "Ка", "K", "Kind"),
            new Letter("L", "Эль", "L", "Luft"),
            new Letter("M", "Эм", "M", "Mond"),
            new Letter("N", "Эн", "N", "Nacht"),
            new Letter("O", "О", "O", "Ohr"),
            new Letter("P", "Пе", "P", "Pferd"),
            new Letter("Q", "Ку", "Q", "Quelle"),
            new Letter("R", "Эр", "R", "Regen"),
            new Letter("S", "Эс", "S", "Sonne"),
            new Letter("T", "Те", "T", "Tisch"),
            new Letter("U", "У", "U", "Uhr"),
            new Letter("V", "Фау", "V", "Vogel"),
            new Letter("W", "Ве", "W", "Wasser"),
            new Letter("X", "Икс", "X", "Xylophon"),
            new Letter("Y", "Ипсилон", "Y", "Yacht"),
            new Letter("Z", "Цет", "Z", "Zeit"),
            new Letter("Ä", "А-умлаут", "Ae", "Äpfel"),
            new Letter("Ö", "О-умлаут", "Oe", "Öl"),
            new Letter("Ü", "У-умлаут", "Ue", "Über"),
            new Letter("ß", "Эсцет", "Ss", "Straße")
        )));

        // 4. Французский
        languages.add(new Language("Французский", "🇫🇷", "Français", Arrays.asList(
            new Letter("A", "А", "A", "Ami"),
            new Letter("B", "Бе", "B", "Bonjour"),
            new Letter("C", "Се", "C", "Chat"),
            new Letter("D", "Де", "D", "Dame"),
            new Letter("E", "Ё", "E", "École"),
            new Letter("F", "Эф", "F", "Fleur"),
            new Letter("G", "Же", "G", "Garçon"),
            new Letter("H", "Аш", "H", "Homme"),
            new Letter("I", "И", "I", "Ile"),
            new Letter("J", "Жи", "J", "Jour"),
            new Letter("K", "Ка", "K", "Kilo"),
            new Letter("L", "Эль", "L", "Lune"),
            new Letter("M", "Эм", "M", "Maison"),
            new Letter("N", "Эн", "N", "Nuit"),
            new Letter("O", "О", "O", "Oiseau"),
            new Letter("P", "Пе", "P", "Père"),
            new Letter("Q", "Кю", "Q", "Quatre"),
            new Letter("R", "Эр", "R", "Rouge"),
            new Letter("S", "Эс", "S", "Soleil"),
            new Letter("T", "Те", "T", "Table"),
            new Letter("U", "Ю", "U", "Univers"),
            new Letter("V", "Ве", "V", "Ville"),
            new Letter("W", "Дубль-ве", "W", "Week-end"),
            new Letter("X", "Икс", "X", "Xylophone"),
            new Letter("Y", "Игрек", "Y", "Yoga"),
            new Letter("Z", "Зед", "Z", "Zèbre"),
            new Letter("À", "А-граф", "A", "À"),
            new Letter("Â", "А-циркумфлекс", "A", "Âge"),
            new Letter("Ç", "С-седиль", "C", "Français"),
            new Letter("É", "Е-аксент", "E", "Été"),
            new Letter("È", "Е-граф", "E", "Père"),
            new Letter("Ê", "Е-циркумфлекс", "E", "Fête"),
            new Letter("Î", "И-циркумфлекс", "I", "Île"),
            new Letter("Ô", "О-циркумфлекс", "O", "Ô"),
            new Letter("Ù", "У-граф", "U", "Où")
        )));

        // 5. Испанский
        languages.add(new Language("Испанский", "🇪🇸", "Español", Arrays.asList(
            new Letter("A", "А", "A", "Amigo"),
            new Letter("B", "Бе", "B", "Bueno"),
            new Letter("C", "Се", "C", "Casa"),
            new Letter("D", "Де", "D", "Día"),
            new Letter("E", "Е", "E", "España"),
            new Letter("F", "Эфе", "F", "Fiesta"),
            new Letter("G", "Хе", "G", "Gato"),
            new Letter("H", "Аче", "H", "Hola"),
            new Letter("I", "И", "I", "Isla"),
            new Letter("J", "Хота", "J", "Juego"),
            new Letter("K", "Ка", "K", "Kilo"),
            new Letter("L", "Эле", "L", "Luz"),
            new Letter("M", "Эме", "M", "Madre"),
            new Letter("N", "Эне", "N", "Noche"),
            new Letter("Ñ", "Энье", "Ñ", "Niño"),
            new Letter("O", "О", "O", "Oro"),
            new Letter("P", "Пе", "P", "Padre"),
            new Letter("Q", "Ку", "Q", "Queso"),
            new Letter("R", "Эре", "R", "Rosa"),
            new Letter("S", "Эсе", "S", "Sol"),
            new Letter("T", "Те", "T", "Tierra"),
            new Letter("U", "У", "U", "Uno"),
            new Letter("V", "Уве", "V", "Vino"),
            new Letter("W", "Уве-добле", "W", "Web"),
            new Letter("X", "Экис", "X", "Xilófono"),
            new Letter("Y", "И", "Y", "Yate"),
            new Letter("Z", "Сета", "Z", "Zorro")
        )));

        // 6. Итальянский
        languages.add(new Language("Итальянский", "🇮🇹", "Italiano", Arrays.asList(
            new Letter("A", "А", "A", "Amore"),
            new Letter("B", "Би", "B", "Bambino"),
            new Letter("C", "Чи", "C", "Ciao"),
            new Letter("D", "Ди", "D", "Donna"),
            new Letter("E", "Е", "E", "Elefante"),
            new Letter("F", "Эффе", "F", "Fiore"),
            new Letter("G", "Джи", "G", "Gatto"),
            new Letter("H", "Акка", "H", "Hotel"),
            new Letter("I", "И", "I", "Isola"),
            new Letter("J", "И-лунга", "J", "Jazz"),
            new Letter("K", "Каппа", "K", "Kilo"),
            new Letter("L", "Элле", "L", "Luna"),
            new Letter("M", "Эмме", "M", "Madre"),
            new Letter("N", "Энне", "N", "Notte"),
            new Letter("O", "О", "O", "Occhio"),
            new Letter("P", "Пи", "P", "Padre"),
            new Letter("Q", "Ку", "Q", "Questo"),
            new Letter("R", "Эрре", "R", "Rosa"),
            new Letter("S", "Эссе", "S", "Sole"),
            new Letter("T", "Ти", "T", "Terra"),
            new Letter("U", "У", "U", "Uva"),
            new Letter("V", "Ви", "V", "Vino"),
            new Letter("W", "Доппия-ву", "W", "Web"),
            new Letter("X", "Икс", "X", "Xilofono"),
            new Letter("Y", "Ипсилон", "Y", "Yogurt"),
            new Letter("Z", "Зета", "Z", "Zebra")
        )));

        // 7. Японский (хирагана)
        languages.add(new Language("Японский", "🇯🇵", "日本語", Arrays.asList(
            new Letter("あ", "А", "A", "あさ (утро)"),
            new Letter("い", "И", "I", "いぬ (собака)"),
            new Letter("う", "У", "U", "うみ (море)"),
            new Letter("え", "Э", "E", "えき (вокзал)"),
            new Letter("お", "О", "O", "おと (звук)"),
            new Letter("か", "Ка", "Ka", "かぜ (ветер)"),
            new Letter("き", "Ки", "Ki", "きのう (вчера)"),
            new Letter("く", "Ку", "Ku", "くも (облако)"),
            new Letter("け", "Кэ", "Ke", "けい (стиль)"),
            new Letter("こ", "Ко", "Ko", "こども (ребёнок)"),
            new Letter("さ", "Са", "Sa", "さかな (рыба)"),
            new Letter("し", "Си", "Shi", "しろ (белый)"),
            new Letter("す", "Су", "Su", "すず (колокольчик)"),
            new Letter("せ", "Сэ", "Se", "せん (тысяча)"),
            new Letter("そ", "Со", "So", "そら (небо)"),
            new Letter("た", "Та", "Ta", "たけ (бамбук)"),
            new Letter("ち", "Ти", "Chi", "ちい (маленький)"),
            new Letter("つ", "Цу", "Tsu", "つき (луна)"),
            new Letter("て", "Тэ", "Te", "てん (небо)"),
            new Letter("と", "То", "To", "とも (друг)"),
            new Letter("な", "На", "Na", "なつ (лето)"),
            new Letter("に", "Ни", "Ni", "にほん (Япония)"),
            new Letter("ぬ", "Ну", "Nu", "ぬま (болото)"),
            new Letter("ね", "Нэ", "Ne", "ねこ (кошка)"),
            new Letter("の", "Но", "No", "のり (водоросли)"),
            new Letter("は", "Ха", "Ha", "はな (цветок)"),
            new Letter("ひ", "Хи", "Hi", "ひかり (свет)"),
            new Letter("ふ", "Фу", "Fu", "ふね (корабль)"),
            new Letter("へ", "Хэ", "He", "へや (комната)"),
            new Letter("ほ", "Хо", "Ho", "ほし (звезда)"),
            new Letter("ま", "Ма", "Ma", "まち (город)"),
            new Letter("み", "Ми", "Mi", "みず (вода)"),
            new Letter("む", "Му", "Mu", "むし (насекомое)"),
            new Letter("め", "Мэ", "Me", "めがね (очки)"),
            new Letter("も", "Мо", "Mo", "もり (лес)"),
            new Letter("や", "Я", "Ya", "やま (гора)"),
            new Letter("ゆ", "Ю", "Yu", "ゆき (снег)"),
            new Letter("よ", "Ё", "Yo", "よる (ночь)"),
            new Letter("ら", "Ра", "Ra", "らくだ (верблюд)"),
            new Letter("り", "Ри", "Ri", "りんご (яблоко)"),
            new Letter("る", "Ру", "Ru", "るす (отсутствие)"),
            new Letter("れ", "Рэ", "Re", "れきし (история)"),
            new Letter("ろ", "Ро", "Ro", "ろう (волк)"),
            new Letter("わ", "Ва", "Wa", "わたし (я)"),
            new Letter("を", "Во", "Wo", "を (частица)"),
            new Letter("ん", "Н", "N", "ん (носовой звук)")
        )));

        // 8. Китайский (пиньинь)
        languages.add(new Language("Китайский", "🇨🇳", "中文", Arrays.asList(
            new Letter("a", "А", "A", "ā (звук)"),
            new Letter("o", "О", "O", "ō (звук)"),
            new Letter("e", "Э", "E", "ē (звук)"),
            new Letter("i", "И", "I", "ī (звук)"),
            new Letter("u", "У", "U", "ū (звук)"),
            new Letter("ü", "Ю", "Ü", "ǖ (звук)"),
            new Letter("b", "Б", "B", "bā (восемь)"),
            new Letter("p", "П", "P", "pá (ползти)"),
            new Letter("m", "М", "M", "mā (мама)"),
            new Letter("f", "Ф", "F", "fā (отправлять)"),
            new Letter("d", "Д", "D", "dā (отвечать)"),
            new Letter("t", "Т", "T", "tā (он/она)"),
            new Letter("n", "Н", "N", "nā (тот)"),
            new Letter("l", "Л", "L", "lā (тянуть)"),
            new Letter("g", "Г", "G", "gā (звук)"),
            new Letter("k", "К", "K", "kā (звук)"),
            new Letter("h", "Х", "H", "hā (звук)"),
            new Letter("j", "Дж", "J", "jī (курица)"),
            new Letter("q", "Ц", "Q", "qī (семь)"),
            new Letter("x", "С", "X", "xī (запад)"),
            new Letter("zh", "Чж", "Zh", "zhā (колоть)"),
            new Letter("ch", "Ч", "Ch", "chā (вставлять)"),
            new Letter("sh", "Ш", "Sh", "shā (песок)"),
            new Letter("r", "Р", "R", "rā (звук)"),
            new Letter("z", "Цз", "Z", "zā (связывать)"),
            new Letter("c", "Ц", "C", "cā (тереть)"),
            new Letter("s", "С", "S", "sā (звук)"),
            new Letter("y", "Й", "Y", "yā (утка)"),
            new Letter("w", "В", "W", "wā (головастик)")
        )));

        // 9. Корейский (хангыль)
        languages.add(new Language("Корейский", "🇰🇷", "한국어", Arrays.asList(
            new Letter("ㄱ", "Г", "G/K", "가 (идти)"),
            new Letter("ㄴ", "Н", "N", "나 (я)"),
            new Letter("ㄷ", "Д", "D", "다 (все)"),
            new Letter("ㄹ", "Л", "L/R", "라 (звук)"),
            new Letter("ㅁ", "М", "M", "마 (конопля)"),
            new Letter("ㅂ", "Б", "B/P", "바 (река)"),
            new Letter("ㅅ", "С", "S", "사 (покупать)"),
            new Letter("ㅇ", "Н/Ё", "Ng", "아 (ребёнок)"),
            new Letter("ㅈ", "Дж", "J", "자 (сон)"),
            new Letter("ㅊ", "Ч", "Ch", "차 (машина)"),
            new Letter("ㅋ", "К", "K", "카 (карта)"),
            new Letter("ㅌ", "Т", "T", "타 (звук)"),
            new Letter("ㅍ", "П", "P", "파 (лук)"),
            new Letter("ㅎ", "Х", "H", "하 (небо)"),
            new Letter("ㅏ", "А", "A", "가 (идти)"),
            new Letter("ㅑ", "Я", "Ya", "야 (эй)"),
            new Letter("ㅓ", "О", "Eo", "거 (тот)"),
            new Letter("ㅕ", "Ё", "Ye", "여 (женщина)"),
            new Letter("ㅗ", "О", "O", "고 (идти)"),
            new Letter("ㅛ", "Ё", "Yo", "교 (школа)"),
            new Letter("ㅜ", "У", "U", "구 (девять)"),
            new Letter("ㅠ", "Ю", "Yu", "규 (правило)"),
            new Letter("ㅡ", "Ы", "Eu", "그 (тот)"),
            new Letter("ㅣ", "И", "I", "기 (энергия)")
        )));

        // 10. Арабский
        languages.add(new Language("Арабский", "🇸🇦", "العربية", Arrays.asList(
            new Letter("ا", "Алиф", "Alif", "أب (отец)"),
            new Letter("ب", "Ба", "Ba", "باب (дверь)"),
            new Letter("ت", "Та", "Ta", "تاج (корона)"),
            new Letter("ث", "Са", "Tha", "ثلج (снег)"),
            new Letter("ج", "Джим", "Jim", "جمل (верблюд)"),
            new Letter("ح", "Ха", "Ha", "حمار (осёл)"),
            new Letter("خ", "Ха", "Kha", "خبز (хлеб)"),
            new Letter("د", "Даль", "Dal", "دب (медведь)"),
            new Letter("ذ", "Заль", "Dhal", "ذهب (золото)"),
            new Letter("ر", "Ра", "Ra", "رجل (мужчина)"),
            new Letter("ز", "Зай", "Zay", "زيت (масло)"),
            new Letter("س", "Син", "Sin", "سمك (рыба)"),
            new Letter("ش", "Шин", "Shin", "شمس (солнце)"),
            new Letter("ص", "Сад", "Sad", "صقر (сокол)"),
            new Letter("ض", "Дад", "Dad", "ضفدع (лягушка)"),
            new Letter("ط", "Та", "Ta", "طائر (птица)"),
            new Letter("ظ", "За", "Za", "ظل (тень)"),
            new Letter("ع", "Айн", "Ayn", "عين (глаз)"),
            new Letter("غ", "Гайн", "Ghayn", "غصن (ветка)"),
            new Letter("ف", "Фа", "Fa", "فيل (слон)"),
            new Letter("ق", "Каф", "Qaf", "قمر (луна)"),
            new Letter("ك", "Каф", "Kaf", "كتاب (книга)"),
            new Letter("ل", "Лям", "Lam", "لبن (молоко)"),
            new Letter("م", "Мим", "Mim", "ماء (вода)"),
            new Letter("ن", "Нун", "Nun", "نار (огонь)"),
            new Letter("ه", "Ха", "Ha", "هواء (воздух)"),
            new Letter("و", "Вав", "Waw", "وجه (лицо)"),
            new Letter("ي", "Я", "Ya", "يوم (день)")
        )));

        return languages;
    }
}