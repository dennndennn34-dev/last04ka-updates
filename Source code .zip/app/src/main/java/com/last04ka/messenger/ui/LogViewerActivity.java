package com.last04ka.messenger.ui;

import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.text.method.ScrollingMovementMethod;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import com.last04ka.messenger.R;
import com.last04ka.messenger.utils.AppLogger;
import com.last04ka.messenger.utils.ThemeManager;

public class LogViewerActivity extends AppCompatActivity {

    private TextView logTextView;
    private Button btnCopyLog;
    private Button btnClearLog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        setTheme(ThemeManager.getThemeResource(this));
        super.onCreate(savedInstanceState);
        try {
            setContentView(R.layout.activity_log_viewer);

            setTitle("Лог приложения");

            logTextView = findViewById(R.id.log_text_view);
            btnCopyLog = findViewById(R.id.btn_copy_log);
            btnClearLog = findViewById(R.id.btn_clear_log);

            if (logTextView == null) {
                Toast.makeText(this, "Ошибка: logTextView не найден", Toast.LENGTH_LONG).show();
                finish();
                return;
            }

            logTextView.setMovementMethod(new ScrollingMovementMethod());
            logTextView.setTextIsSelectable(true);

            loadLog();

            btnCopyLog.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    try {
                        String log = logTextView.getText().toString();
                        if (log.isEmpty() || log.contains("Лог пуст")) {
                            Toast.makeText(LogViewerActivity.this, "Нечего копировать", Toast.LENGTH_SHORT).show();
                            return;
                        }
                        ClipboardManager clipboard = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
                        ClipData clip = ClipData.newPlainText("app_log", log);
                        clipboard.setPrimaryClip(clip);
                        Toast.makeText(LogViewerActivity.this, "Лог скопирован", Toast.LENGTH_SHORT).show();
                    } catch (Exception e) {
                        Toast.makeText(LogViewerActivity.this, "Ошибка копирования: " + e.getMessage(), Toast.LENGTH_LONG).show();
                    }
                }
            });

            btnClearLog.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    try {
                        AppLogger.clearLog(LogViewerActivity.this);
                        loadLog();
                        Toast.makeText(LogViewerActivity.this, "Лог очищен", Toast.LENGTH_SHORT).show();
                    } catch (Exception e) {
                        Toast.makeText(LogViewerActivity.this, "Ошибка очистки: " + e.getMessage(), Toast.LENGTH_LONG).show();
                    }
                }
            });

        } catch (Exception e) {
            Toast.makeText(this, "Ошибка создания LogViewer: " + e.getMessage(), Toast.LENGTH_LONG).show();
            finish();
        }
    }

    private void loadLog() {
        try {
            String log = AppLogger.getFullLog(this);
            if (logTextView != null) {
                logTextView.setText(log);
            }
        } catch (Exception e) {
            if (logTextView != null) {
                logTextView.setText("Ошибка загрузки лога: " + e.getMessage());
            }
        }
    }
}