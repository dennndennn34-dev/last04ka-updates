package com.last04ka.messenger.utils;

import java.util.HashMap;
import java.util.Map;

public class OfflineTranslator {

    private static final Map<String, String> RU_TO_EN = new HashMap<>();
    private static final Map<String, String> EN_TO_RU = new HashMap<>();

    static {
        // ========================
        // МЕСТОИМЕНИЯ
        // ========================
        add("я", "i"); add("ты", "you"); add("он", "he"); add("она", "she");
        add("оно", "it"); add("мы", "we"); add("вы", "you"); add("они", "they");
        add("меня", "me"); add("тебя", "you"); add("его", "him"); add("её", "her");
        add("нас", "us"); add("их", "them"); add("мой", "my"); add("твой", "your");
        add("его", "his"); add("её", "her"); add("наш", "our"); add("ваш", "your");
        add("свой", "own"); add("себя", "myself"); add("сам", "self");
        add("кто", "who"); add("что", "what"); add("который", "which");
        add("чей", "whose"); add("сколько", "how many"); add("какой", "what kind of");

        // ========================
        // ПРИВЕТСТВИЯ И ВЕЖЛИВОСТЬ
        // ========================
        add("привет", "hello"); add("здравствуйте", "hello"); add("здравствуй", "hello");
        add("доброе утро", "good morning"); add("добрый день", "good afternoon");
        add("добрый вечер", "good evening"); add("доброй ночи", "good night");
        add("приветствую", "greetings"); add("рад видеть", "glad to see you");
        add("как дела", "how are you"); add("как жизнь", "how is life");
        add("как поживаешь", "how are you doing"); add("что нового", "whats new");
        add("давно не виделись", "long time no see");
        add("пока", "bye"); add("до свидания", "goodbye"); add("до встречи", "see you");
        add("до скорого", "see you soon"); add("до завтра", "see you tomorrow");
        add("счастливо", "take care"); add("удачи", "good luck");
        add("спасибо", "thank you"); add("большое спасибо", "thank you very much");
        add("благодарю", "i appreciate it"); add("не за что", "youre welcome");
        add("пожалуйста", "please"); add("будьте добры", "be so kind");
        add("извините", "sorry"); add("простите", "excuse me");
        add("извиняюсь", "i apologize"); add("ничего страшного", "no problem");
        add("всё в порядке", "its okay"); add("не беспокойтесь", "dont worry");
        add("да", "yes"); add("нет", "no"); add("конечно", "of course");
        add("разумеется", "certainly"); add("возможно", "maybe");
        add("вероятно", "probably"); add("наверное", "perhaps");
        add("хорошо", "okay"); add("ладно", "alright"); add("отлично", "great");
        add("прекрасно", "wonderful"); add("замечательно", "marvelous");
        add("ужасно", "terrible"); add("плохо", "bad");

        // ========================
        // ВОПРОСИТЕЛЬНЫЕ СЛОВА
        // ========================
        add("где", "where"); add("когда", "when"); add("почему", "why");
        add("зачем", "what for"); add("как", "how"); add("куда", "where to");
        add("откуда", "where from"); add("сколько", "how much");
        add("который час", "what time is it"); add("как пройти", "how to get to");
        add("что случилось", "what happened"); add("в чём дело", "whats the matter");
        add("ты где", "where are you"); add("ты кто", "who are you");

        // ========================
        // ГЛАГОЛЫ (САМЫЕ ЧАСТЫЕ)
        // ========================
        add("быть", "be"); add("иметь", "have"); add("делать", "do");
        add("сказать", "say"); add("идти", "go"); add("мочь", "can");
        add("знать", "know"); add("думать", "think"); add("хотеть", "want");
        add("видеть", "see"); add("слышать", "hear"); add("говорить", "speak");
        add("сказать", "tell"); add("спросить", "ask"); add("ответить", "answer");
        add("работать", "work"); add("учиться", "study"); add("читать", "read");
        add("писать", "write"); add("слушать", "listen"); add("смотреть", "watch");
        add("любить", "love"); add("ненавидеть", "hate"); add("бояться", "fear");
        add("жить", "live"); add("умереть", "die"); add("спать", "sleep");
        add("есть", "eat"); add("пить", "drink"); add("готовить", "cook");
        add("брать", "take"); add("давать", "give"); add("покупать", "buy");
        add("продавать", "sell"); add("платить", "pay"); add("стоить", "cost");
        add("открыть", "open"); add("закрыть", "close"); add("начать", "start");
        add("закончить", "finish"); add("остановить", "stop"); add("продолжить", "continue");
        add("ждать", "wait"); add("найти", "find"); add("потерять", "lose");
        add("помнить", "remember"); add("забыть", "forget"); add("понимать", "understand");
        add("верить", "believe"); add("надеяться", "hope"); add("помогать", "help");
        add("звонить", "call"); add("отправлять", "send"); add("получать", "receive");
        add("приходить", "come"); add("уходить", "leave"); add("возвращаться", "return");
        add("входить", "enter"); add("выходить", "exit"); add("бежать", "run");
        add("лететь", "fly"); add("плыть", "swim"); add("ехать", "drive");
        add("играть", "play"); add("петь", "sing"); add("танцевать", "dance");
        add("рисовать", "draw"); add("строить", "build"); add("ломать", "break");
        add("чинить", "fix"); add("мыть", "wash"); add("чистить", "clean");
        add("одевать", "dress"); add("снимать", "take off"); add("носить", "wear");
        add("включать", "turn on"); add("выключать", "turn off");
        add("заряжать", "charge"); add("устанавливать", "install");
        add("обновлять", "update"); add("удалять", "delete");
        add("копировать", "copy"); add("вставить", "paste"); add("сохранить", "save");

        // ========================
        // СУЩЕСТВИТЕЛЬНЫЕ — ЧЕЛОВЕК И ОБЩЕСТВО
        // ========================
        add("человек", "person"); add("люди", "people"); add("мужчина", "man");
        add("женщина", "woman"); add("ребёнок", "child"); add("дети", "children");
        add("мальчик", "boy"); add("девочка", "girl"); add("парень", "guy");
        add("девушка", "girl"); add("друг", "friend"); add("подруга", "friend");
        add("семья", "family"); add("родители", "parents"); add("мама", "mother");
        add("папа", "father"); add("брат", "brother"); add("сестра", "sister");
        add("сын", "son"); add("дочь", "daughter"); add("муж", "husband");
        add("жена", "wife"); add("бабушка", "grandmother"); add("дедушка", "grandfather");
        add("внук", "grandson"); add("внучка", "granddaughter");
        add("дядя", "uncle"); add("тётя", "aunt"); add("племянник", "nephew");
        add("племянница", "niece"); add("сосед", "neighbor"); add("гость", "guest");
        add("хозяин", "host"); add("начальник", "boss"); add("коллега", "colleague");
        add("доктор", "doctor"); add("врач", "physician"); add("медсестра", "nurse");
        add("учитель", "teacher"); add("студент", "student"); add("ученик", "pupil");
        add("полицейский", "police officer"); add("пожарный", "firefighter");
        add("водитель", "driver"); add("пилот", "pilot"); add("повар", "chef");
        add("продавец", "seller"); add("покупатель", "buyer");
        add("турист", "tourist"); add("путешественник", "traveler");

        // ========================
        // СУЩЕСТВИТЕЛЬНЫЕ — МЕСТА
        // ========================
        add("дом", "house"); add("квартира", "apartment"); add("комната", "room");
        add("кухня", "kitchen"); add("ванная", "bathroom"); add("туалет", "toilet");
        add("спальня", "bedroom"); add("гостиная", "living room"); add("коридор", "corridor");
        add("балкон", "balcony"); add("гараж", "garage"); add("подвал", "basement");
        add("крыша", "roof"); add("стена", "wall"); add("пол", "floor");
        add("потолок", "ceiling"); add("окно", "window"); add("дверь", "door");
        add("лестница", "stairs"); add("лифт", "elevator");
        add("улица", "street"); add("дорога", "road"); add("площадь", "square");
        add("город", "city"); add("деревня", "village"); add("посёлок", "settlement");
        add("страна", "country"); add("столица", "capital"); add("область", "region");
        add("район", "district"); add("центр", "center"); add("окраина", "outskirts");
        add("магазин", "shop"); add("супермаркет", "supermarket");
        add("школа", "school"); add("университет", "university");
        add("больница", "hospital"); add("аптека", "pharmacy"); add("банк", "bank");
        add("ресторан", "restaurant"); add("кафе", "cafe"); add("бар", "bar");
        add("отель", "hotel"); add("гостиница", "inn"); add("общежитие", "dormitory");
        add("аэропорт", "airport"); add("вокзал", "station"); add("метро", "metro");
        add("остановка", "bus stop"); add("парк", "park"); add("сад", "garden");
        add("мост", "bridge"); add("церковь", "church"); add("музей", "museum");
        add("театр", "theater"); add("кинотеатр", "cinema"); add("библиотека", "library");
        add("почта", "post office"); add("рынок", "market"); add("пляж", "beach");
        add("гора", "mountain"); add("лес", "forest"); add("озеро", "lake");
        add("река", "river"); add("море", "sea"); add("океан", "ocean");

        // ========================
        // СУЩЕСТВИТЕЛЬНЫЕ — ЕДА И НАПИТКИ
        // ========================
        add("еда", "food"); add("напиток", "drink"); add("вода", "water");
        add("хлеб", "bread"); add("молоко", "milk"); add("яйцо", "egg");
        add("мясо", "meat"); add("рыба", "fish"); add("птица", "poultry");
        add("овощи", "vegetables"); add("фрукты", "fruit"); add("ягоды", "berries");
        add("яблоко", "apple"); add("банан", "banana"); add("апельсин", "orange");
        add("лимон", "lemon"); add("виноград", "grapes"); add("арбуз", "watermelon");
        add("дыня", "melon"); add("клубника", "strawberry"); add("малина", "raspberry");
        add("вишня", "cherry"); add("персик", "peach"); add("груша", "pear");
        add("слива", "plum"); add("огурец", "cucumber"); add("помидор", "tomato");
        add("картофель", "potato"); add("морковь", "carrot"); add("лук", "onion");
        add("чеснок", "garlic"); add("перец", "pepper"); add("капуста", "cabbage");
        add("сахар", "sugar"); add("соль", "salt"); add("масло", "butter");
        add("сыр", "cheese"); add("колбаса", "sausage"); add("сосиски", "hot dogs");
        add("курица", "chicken"); add("говядина", "beef"); add("свинина", "pork");
        add("рис", "rice"); add("макароны", "pasta"); add("каша", "porridge");
        add("суп", "soup"); add("салат", "salad"); add("пицца", "pizza");
        add("бутерброд", "sandwich"); add("торт", "cake"); add("мороженое", "ice cream");
        add("шоколад", "chocolate"); add("конфета", "candy"); add("печенье", "cookie");
        add("чай", "tea"); add("кофе", "coffee"); add("сок", "juice");
        add("пиво", "beer"); add("вино", "wine"); add("водка", "vodka");
        add("завтрак", "breakfast"); add("обед", "lunch"); add("ужин", "dinner");

        // ========================
        // ПРИЛАГАТЕЛЬНЫЕ
        // ========================
        add("хороший", "good"); add("плохой", "bad"); add("большой", "big");
        add("маленький", "small"); add("новый", "new"); add("старый", "old");
        add("молодой", "young"); add("красивый", "beautiful"); add("уродливый", "ugly");
        add("вкусный", "tasty"); add("невкусный", "tasteless");
        add("горячий", "hot"); add("холодный", "cold"); add("тёплый", "warm");
        add("прохладный", "cool"); add("быстрый", "fast"); add("медленный", "slow");
        add("дорогой", "expensive"); add("дешёвый", "cheap"); add("богатый", "rich");
        add("бедный", "poor"); add("важный", "important"); add("опасный", "dangerous");
        add("безопасный", "safe"); add("лёгкий", "easy"); add("сложный", "difficult");
        add("простой", "simple"); add("свободный", "free"); add("занятый", "busy");
        add("чистый", "clean"); add("грязный", "dirty"); add("сухой", "dry");
        add("мокрый", "wet"); add("твёрдый", "hard"); add("мягкий", "soft");
        add("сильный", "strong"); add("слабый", "weak"); add("умный", "smart");
        add("глупый", "stupid"); add("весёлый", "funny"); add("грустный", "sad");
        add("счастливый", "happy"); add("несчастный", "unhappy"); add("злой", "angry");
        add("добрый", "kind"); add("сердитый", "mad"); add("спокойный", "calm");
        add("нервный", "nervous"); add("уставший", "tired"); add("бодрый", "energetic");
        add("голодный", "hungry"); add("сытый", "full"); add("больной", "sick");
        add("здоровый", "healthy"); add("правильный", "correct"); add("неправильный", "wrong");
        add("открытый", "open"); add("закрытый", "closed"); add("полный", "full");
        add("пустой", "empty"); add("длинный", "long"); add("короткий", "short");
        add("высокий", "tall"); add("низкий", "low"); add("широкий", "wide");
        add("узкий", "narrow"); add("толстый", "thick"); add("тонкий", "thin");
        add("глубокий", "deep"); add("мелкий", "shallow"); add("ранний", "early");
        add("поздний", "late"); add("светлый", "bright"); add("тёмный", "dark");

        // ========================
        // ЦВЕТА
        // ========================
        add("красный", "red"); add("синий", "blue"); add("зелёный", "green");
        add("жёлтый", "yellow"); add("чёрный", "black"); add("белый", "white");
        add("серый", "gray"); add("коричневый", "brown"); add("оранжевый", "orange");
        add("розовый", "pink"); add("фиолетовый", "purple"); add("голубой", "light blue");
        add("золотой", "gold"); add("серебряный", "silver");

        // ========================
        // ЧИСЛА
        // ========================
        add("ноль", "zero"); add("один", "one"); add("два", "two");
        add("три", "three"); add("четыре", "four"); add("пять", "five");
        add("шесть", "six"); add("семь", "seven"); add("восемь", "eight");
        add("девять", "nine"); add("десять", "ten"); add("одиннадцать", "eleven");
        add("двенадцать", "twelve"); add("тринадцать", "thirteen");
        add("четырнадцать", "fourteen"); add("пятнадцать", "fifteen");
        add("шестнадцать", "sixteen"); add("семнадцать", "seventeen");
        add("восемнадцать", "eighteen"); add("девятнадцать", "nineteen");
        add("двадцать", "twenty"); add("тридцать", "thirty"); add("сорок", "forty");
        add("пятьдесят", "fifty"); add("шестьдесят", "sixty"); add("семьдесят", "seventy");
        add("восемьдесят", "eighty"); add("девяносто", "ninety"); add("сто", "hundred");
        add("тысяча", "thousand"); add("миллион", "million");
        add("первый", "first"); add("второй", "second"); add("третий", "third");

        // ========================
        // ВРЕМЯ
        // ========================
        add("сегодня", "today"); add("завтра", "tomorrow"); add("вчера", "yesterday");
        add("сейчас", "now"); add("потом", "later"); add("раньше", "earlier");
        add("утро", "morning"); add("день", "day"); add("вечер", "evening");
        add("ночь", "night"); add("полдень", "noon"); add("полночь", "midnight");
        add("час", "hour"); add("минута", "minute"); add("секунда", "second");
        add("неделя", "week"); add("месяц", "month"); add("год", "year");
        add("век", "century"); add("понедельник", "monday"); add("вторник", "tuesday");
        add("среда", "wednesday"); add("четверг", "thursday"); add("пятница", "friday");
        add("суббота", "saturday"); add("воскресенье", "sunday");
        add("январь", "january"); add("февраль", "february"); add("март", "march");
        add("апрель", "april"); add("май", "may"); add("июнь", "june");
        add("июль", "july"); add("август", "august"); add("сентябрь", "september");
        add("октябрь", "october"); add("ноябрь", "november"); add("декабрь", "december");
        add("весна", "spring"); add("лето", "summer"); add("осень", "autumn");
        add("зима", "winter"); add("праздник", "holiday"); add("выходной", "day off");

        // ========================
        // ТЕХНОЛОГИИ И КОМПЬЮТЕРЫ
        // ========================
        add("компьютер", "computer"); add("ноутбук", "laptop"); add("телефон", "phone");
        add("смартфон", "smartphone"); add("планшет", "tablet"); add("экран", "screen");
        add("клавиатура", "keyboard"); add("мышка", "mouse"); add("принтер", "printer");
        add("наушники", "headphones"); add("колонка", "speaker"); add("камера", "camera");
        add("микрофон", "microphone"); add("зарядка", "charger"); add("батарея", "battery");
        add("интернет", "internet"); add("wi-fi", "wi-fi"); add("вайфай", "wi-fi");
        add("сайт", "website"); add("страница", "page"); add("почта", "email");
        add("логин", "login"); add("пароль", "password"); add("аккаунт", "account");
        add("профиль", "profile"); add("настройки", "settings"); add("программа", "program");
        add("приложение", "app"); add("файл", "file"); add("папка", "folder");
        add("ссылка", "link"); add("браузер", "browser"); add("поиск", "search");
        add("скачать", "download"); add("загрузить", "upload"); add("установить", "install");
        add("обновить", "update"); add("удалить", "delete"); add("копировать", "copy");
        add("вставить", "paste"); add("сохранить", "save"); add("отменить", "cancel");
        add("сообщение", "message"); add("чат", "chat"); add("звонок", "call");
        add("видео", "video"); add("фото", "photo"); add("аудио", "audio");
        add("блютуз", "bluetooth"); add("симка", "sim card"); add("память", "memory");

        // ========================
        // ОДЕЖДА
        // ========================
        add("одежда", "clothes"); add("обувь", "shoes"); add("рубашка", "shirt");
        add("футболка", "t-shirt"); add("брюки", "pants"); add("джинсы", "jeans");
        add("шорты", "shorts"); add("юбка", "skirt"); add("платье", "dress");
        add("куртка", "jacket"); add("пальто", "coat"); add("шапка", "hat");
        add("шарф", "scarf"); add("перчатки", "gloves"); add("носки", "socks");
        add("ботинки", "boots"); add("кроссовки", "sneakers"); add("тапочки", "slippers");

        // ========================
        // ТРАНСПОРТ
        // ========================
        add("машина", "car"); add("автомобиль", "automobile"); add("автобус", "bus");
        add("троллейбус", "trolleybus"); add("трамвай", "tram"); add("такси", "taxi");
        add("поезд", "train"); add("электричка", "commuter train");
        add("самолёт", "airplane"); add("вертолёт", "helicopter");
        add("корабль", "ship"); add("лодка", "boat"); add("велосипед", "bicycle");
        add("мотоцикл", "motorcycle"); add("скутер", "scooter"); add("самокат", "kick scooter");
        add("бензин", "gasoline"); add("дизель", "diesel"); add("электричество", "electricity");

        // ========================
        // ПОГОДА И ПРИРОДА
        // ========================
        add("погода", "weather"); add("солнце", "sun"); add("дождь", "rain");
        add("снег", "snow"); add("ветер", "wind"); add("облако", "cloud");
        add("облачно", "cloudy"); add("туман", "fog"); add("гроза", "thunderstorm");
        add("молния", "lightning"); add("гром", "thunder"); add("радуга", "rainbow");
        add("град", "hail"); add("мороз", "frost"); add("жара", "heat");
        add("небо", "sky"); add("земля", "earth"); add("воздух", "air");
        add("огонь", "fire"); add("дерево", "tree"); add("цветок", "flower");
        add("трава", "grass"); add("лист", "leaf"); add("камень", "stone");
        add("песок", "sand"); add("звезда", "star"); add("луна", "moon");

        // ========================
        // ЖИВОТНЫЕ
        // ========================
        add("собака", "dog"); add("кошка", "cat"); add("птица", "bird");
        add("лошадь", "horse"); add("корова", "cow"); add("свинья", "pig");
        add("овца", "sheep"); add("коза", "goat"); add("курица", "chicken");
        add("утка", "duck"); add("гусь", "goose"); add("индейка", "turkey");
        add("кролик", "rabbit"); add("хомяк", "hamster"); add("мышь", "mouse");
        add("крыса", "rat"); add("лиса", "fox"); add("волк", "wolf");
        add("медведь", "bear"); add("олень", "deer"); add("кабан", "wild boar");
        add("слон", "elephant"); add("тигр", "tiger"); add("лев", "lion");
        add("жираф", "giraffe"); add("обезьяна", "monkey"); add("змея", "snake");
        add("черепаха", "turtle"); add("акула", "shark"); add("дельфин", "dolphin");
        add("кит", "whale"); add("пингвин", "penguin");

        // ========================
        // ЗДОРОВЬЕ И МЕДИЦИНА
        // ========================
        add("здоровье", "health"); add("болезнь", "illness"); add("боль", "pain");
        add("голова", "head"); add("рука", "hand"); add("нога", "leg");
        add("спина", "back"); add("живот", "stomach"); add("сердце", "heart");
        add("лёгкие", "lungs"); add("глаз", "eye"); add("ухо", "ear");
        add("нос", "nose"); add("рот", "mouth"); add("зуб", "tooth");
        add("язык", "tongue"); add("кровь", "blood"); add("кость", "bone");
        add("лекарство", "medicine"); add("таблетка", "pill"); add("витамин", "vitamin");
        add("рецепт", "prescription"); add("прививка", "vaccine"); add("анализ", "test");
        add("температура", "temperature"); add("давление", "pressure"); add("пульс", "pulse");

        // ========================
        // ДОМ И БЫТ
        // ========================
        add("мебель", "furniture"); add("стол", "table"); add("стул", "chair");
        add("кровать", "bed"); add("шкаф", "wardrobe"); add("диван", "sofa");
        add("зеркало", "mirror"); add("лампа", "lamp"); add("часы", "clock");
        add("ключ", "key"); add("замок", "lock"); add("подушка", "pillow");
        add("одеяло", "blanket"); add("полотенце", "towel"); add("мыло", "soap");
        add("шампунь", "shampoo"); add("зубная паста", "toothpaste"); add("щетка", "brush");
        add("расческа", "comb"); add("ножницы", "scissors"); add("иголка", "needle");
        add("нитка", "thread"); add("инструмент", "tool"); add("молоток", "hammer");
        add("отвертка", "screwdriver"); add("гвоздь", "nail"); add("веревка", "rope");

        // ========================
        // АБСТРАКТНЫЕ ПОНЯТИЯ
        // ========================
        add("жизнь", "life"); add("смерть", "death"); add("любовь", "love");
        add("счастье", "happiness"); add("радость", "joy"); add("грусть", "sadness");
        add("страх", "fear"); add("надежда", "hope"); add("вера", "faith");
        add("правда", "truth"); add("ложь", "lie"); add("мечта", "dream");
        add("цель", "goal"); add("успех", "success"); add("ошибка", "mistake");
        add("проблема", "problem"); add("решение", "solution"); add("идея", "idea");
        add("мысль", "thought"); add("чувство", "feeling"); add("настроение", "mood");
        add("опыт", "experience"); add("знание", "knowledge"); add("информация", "information");
        add("новость", "news"); add("секрет", "secret"); add("тайна", "mystery");
        add("власть", "power"); add("сила", "strength"); add("свобода", "freedom");
        add("мир", "world");
    }

    private static void add(String ru, String en) {
        RU_TO_EN.put(ru.toLowerCase(), en.toLowerCase());
        EN_TO_RU.put(en.toLowerCase(), ru.toLowerCase());
    }

    public static String translateRuToEn(String text) {
        String lower = text.toLowerCase().trim();
        if (RU_TO_EN.containsKey(lower)) {
            return RU_TO_EN.get(lower);
        }
        for (Map.Entry<String, String> entry : RU_TO_EN.entrySet()) {
            if (lower.contains(entry.getKey())) {
                return entry.getValue();
            }
        }
        return null;
    }

    public static String translateEnToRu(String text) {
        String lower = text.toLowerCase().trim();
        if (EN_TO_RU.containsKey(lower)) {
            return EN_TO_RU.get(lower);
        }
        for (Map.Entry<String, String> entry : EN_TO_RU.entrySet()) {
            if (lower.contains(entry.getKey())) {
                return entry.getValue();
            }
        }
        return null;
    }
}