package com.last04ka.messenger.ui;

import android.app.Activity;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import com.last04ka.messenger.utils.AppLogger;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

public class CurrencyConverterActivity extends Activity {

    private static final String[] CURRENCIES = {"RUB", "USD", "EUR", "GBP", "CNY", "JPY", "KZT", "UAH", "BYN", "TRY"};
    private static final String[] CURRENCY_NAMES = {"₽ Рубль", "$ Доллар", "€ Евро", "£ Фунт", "¥ Юань", "¥ Иена", "₸ Тенге", "₴ Гривна", "Br Рубль", "₺ Лира"};
    private static final double[] MANUAL_RATES = {1, 95.5, 103.0, 120.0, 13.1, 0.62, 0.19, 2.56, 28.5, 3.12};

    private Spinner fromSpinner, toSpinner;
    private EditText inputAmount;
    private TextView resultText;
    private Button btnSwap, btnUpdate;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        try {
            AppLogger.log(this, "Currency", "onCreate started");

            LinearLayout layout = new LinearLayout(this);
            layout.setOrientation(LinearLayout.VERTICAL);
            layout.setPadding(16, 16, 16, 16);
            layout.setBackgroundColor(0xFF1A1A2E);

            TextView title = new TextView(this);
            title.setText("💰 Конвертер валют");
            title.setTextSize(20); title.setTextColor(0xFFFFFFFF);
            title.setGravity(Gravity.CENTER); layout.addView(title);

            inputAmount = new EditText(this);
            inputAmount.setHint("Сумма"); inputAmount.setText("1");
            inputAmount.setTextColor(0xFFFFFFFF); inputAmount.setHintTextColor(0xFF888888);
            inputAmount.setBackgroundColor(0xFF333333); inputAmount.setPadding(12, 10, 12, 10);
            layout.addView(inputAmount);

            fromSpinner = new Spinner(this);
            fromSpinner.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, CURRENCY_NAMES));
            layout.addView(fromSpinner);

            btnSwap = new Button(this);
            btnSwap.setText("⇅ Поменять"); btnSwap.setOnClickListener(v -> {
                int from = fromSpinner.getSelectedItemPosition();
                int to = toSpinner.getSelectedItemPosition();
                fromSpinner.setSelection(to); toSpinner.setSelection(from);
                convert();
            });
            layout.addView(btnSwap);

            toSpinner = new Spinner(this);
            toSpinner.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, CURRENCY_NAMES));
            toSpinner.setSelection(1);
            layout.addView(toSpinner);

            resultText = new TextView(this);
            resultText.setTextSize(24); resultText.setTextColor(0xFFFFD740);
            resultText.setGravity(Gravity.CENTER); resultText.setPadding(16, 16, 16, 16);
            resultText.setBackgroundColor(0xFF333333);
            layout.addView(resultText);

            btnUpdate = new Button(this);
            btnUpdate.setText("Обновить курсы (online)");
            btnUpdate.setOnClickListener(v -> updateRatesOnline());
            layout.addView(btnUpdate);

            Button btnCalc = new Button(this);
            btnCalc.setText("Конвертировать");
            btnCalc.setOnClickListener(v -> convert());
            layout.addView(btnCalc);

            setContentView(layout);
            setTitle("💰 Конвертер валют");
            convert();
            AppLogger.log(this, "Currency", "onCreate completed");
        } catch (Exception e) { AppLogger.logException(this, "Currency", e); finish(); }
    }

    private void convert() {
        try {
            double amount = Double.parseDouble(inputAmount.getText().toString());
            int fromIdx = fromSpinner.getSelectedItemPosition();
            int toIdx = toSpinner.getSelectedItemPosition();
            double fromRate = MANUAL_RATES[fromIdx];
            double toRate = MANUAL_RATES[toIdx];
            double rubAmount = amount * fromRate;
            double result = rubAmount / toRate;
            resultText.setText(String.format("%.2f %s = %.2f %s", amount, CURRENCIES[fromIdx], result, CURRENCIES[toIdx]));
            AppLogger.log(this, "Currency", "Converted: " + amount + " " + CURRENCIES[fromIdx] + " -> " + result + " " + CURRENCIES[toIdx]);
        } catch (Exception e) {
            resultText.setText("Ошибка");
        }
    }

    private void updateRatesOnline() {
        Toast.makeText(this, "Попытка обновления...", Toast.LENGTH_SHORT).show();
        new Thread(() -> {
            try {
                URL url = new URL("https://www.cbr-xml-daily.ru/daily_json.js");
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setConnectTimeout(10000); conn.setReadTimeout(10000);
                BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream()));
                StringBuilder sb = new StringBuilder(); String line;
                while ((line = reader.readLine()) != null) sb.append(line);
                reader.close(); conn.disconnect();

                // Парсим JSON (упрощённо, без библиотек)
                String json = sb.toString();
                String[] currencies = {"USD", "EUR", "GBP", "CNY", "JPY", "KZT", "UAH", "BYN", "TRY"};
                for (String curr : currencies) {
                    int idx = json.indexOf("\"" + curr + "\"");
                    if (idx > 0) {
                        int valIdx = json.indexOf("\"Value\":", idx);
                        int endIdx = json.indexOf(",", valIdx);
                        if (valIdx > 0 && endIdx > valIdx) {
                            String valStr = json.substring(valIdx + 8, endIdx).trim();
                            double val = Double.parseDouble(valStr);
                            for (int i = 0; i < CURRENCIES.length; i++) {
                                if (CURRENCIES[i].equals(curr)) MANUAL_RATES[i] = val;
                            }
                        }
                    }
                }
                runOnUiThread(() -> {
                    Toast.makeText(this, "Курсы обновлены!", Toast.LENGTH_SHORT).show();
                    convert();
                });
                AppLogger.log(this, "Currency", "Rates updated from CBR");
            } catch (Exception e) {
                runOnUiThread(() -> Toast.makeText(this, "Ошибка обновления", Toast.LENGTH_SHORT).show());
                AppLogger.logException(this, "Currency", e);
            }
        }).start();
    }
}