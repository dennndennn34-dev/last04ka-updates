package com.last04ka.messenger.ui;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.LinearLayout;
import android.widget.TextView;
import com.last04ka.messenger.utils.AppLogger;
import com.last04ka.messenger.utils.GameScores;
import com.last04ka.messenger.utils.ThemeManager;

public class ProfileStatsActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        setTheme(ThemeManager.getThemeResource(this));
        super.onCreate(savedInstanceState);
        try {
            AppLogger.log(this, "ProfileStats", "onCreate started");

            LinearLayout layout = new LinearLayout(this);
            layout.setOrientation(LinearLayout.VERTICAL);
            layout.setPadding(32, 32, 32, 32);
            layout.setBackgroundColor(ThemeManager.getBackgroundColor(this));

            TextView title = new TextView(this);
            title.setText("🏆 Игровая статистика");
            title.setTextSize(22);
            title.setTextColor(ThemeManager.getTextColor(this));
            title.setPadding(0, 16, 0, 24);
            layout.addView(title);

            addStat(layout, "🐍 Змейка", "snake");
            addStat(layout, "🧱 Тетрис", "tetris");
            addStat(layout, "🔢 2048", "2048");
            addStat(layout, "💣 Сапёр", "minesweeper");
            addStat(layout, "🧠 Память", "memory");
            addStat(layout, "🎲 Кости", "dice");
            addStat(layout, "⚡ Тайминг", "timing");
            addStat(layout, "🏓 Пинг-понг", "pong");
            addStat(layout, "🎯 Угадай число", "guessnumber");
            addStat(layout, "🧠 Викторина", "quiz");

            int total = GameScores.getTotalScore(this);
            int count = GameScores.getGamesCount(this);

            TextView totalText = new TextView(this);
            totalText.setText("\n⭐ Общий счёт: " + total + "\n🎮 Игр сыграно: " + count + " / 10");
            totalText.setTextSize(18);
            totalText.setTextColor(ThemeManager.getTextColor(this));
            totalText.setPadding(0, 24, 0, 0);
            layout.addView(totalText);

            setContentView(layout);
            setTitle("Игровая статистика");
            AppLogger.log(this, "ProfileStats", "Total: " + total + " Games: " + count);
        } catch (Exception e) {
            AppLogger.logException(this, "ProfileStats", e);
            finish();
        }
    }

    private void addStat(LinearLayout layout, String name, String key) {
        TextView tv = new TextView(this);
        int sc = GameScores.getScore(this, key);
        tv.setText(name + ": " + sc + " очков");
        tv.setTextSize(16);
        tv.setTextColor(ThemeManager.getTextSecondaryColor(this));
        tv.setPadding(0, 8, 0, 0);
        layout.addView(tv);
    }
}