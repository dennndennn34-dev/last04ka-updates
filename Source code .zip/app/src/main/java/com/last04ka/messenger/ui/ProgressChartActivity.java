package com.last04ka.messenger.ui;

import android.app.Activity;
import android.content.SharedPreferences;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.os.Bundle;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;
import com.last04ka.messenger.utils.AppLogger;
import com.last04ka.messenger.utils.GameScores;

public class ProgressChartActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        try {
            AppLogger.log(this, "ProgressChart", "onCreate started");
            LinearLayout layout = new LinearLayout(this);
            layout.setOrientation(LinearLayout.VERTICAL);
            layout.setPadding(16, 16, 16, 16);
            layout.setBackgroundColor(0xFF1A1A2E);

            TextView title = new TextView(this);
            title.setText("📊 График прогресса");
            title.setTextSize(18); title.setTextColor(0xFFFFFFFF);
            title.setGravity(android.view.Gravity.CENTER);
            title.setPadding(0, 0, 0, 16);
            layout.addView(title);

            ChartView chart = new ChartView(this);
            LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 400);
            chart.setLayoutParams(cp);
            layout.addView(chart);

            setContentView(layout);
            setTitle("📊 Прогресс");
            AppLogger.log(this, "ProgressChart", "onCreate completed");
        } catch (Exception e) { AppLogger.logException(this, "ProgressChart", e); finish(); }
    }

    class ChartView extends View {
        private Paint paint = new Paint();
        private String[] games = {"Змейка","Тетрис","2048","Сапёр","Кости","Тайминг","Пинг-понг","Викторина","Флаги","Столицы","Литература","Биология","Мат.блиц","Реакция","Умножение","Печать"};

        public ChartView(Activity ctx) { super(ctx); }

        @Override
        protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            float w = getWidth(), h = getHeight();
            canvas.drawColor(Color.rgb(30, 30, 40));

            int[] scores = new int[games.length];
            String[] keys = {"snake","tetris","2048","minesweeper","dice","timing","pong","quiz","flagsquiz","capitalsquiz","litquiz","bioquiz","mathblitz","reaction","multiplication","typingspeed"};
            int maxScore = 10;
            for (int i = 0; i < keys.length; i++) {
                scores[i] = GameScores.getScore(getContext(), keys[i]);
                if (scores[i] > maxScore) maxScore = scores[i];
            }
            if (maxScore == 0) maxScore = 100;

            float barW = w / games.length - 8;
            for (int i = 0; i < games.length; i++) {
                float barH = (scores[i] / (float) maxScore) * (h - 80);
                float x = i * (w / games.length) + 4;
                float y = h - 40 - barH;

                paint.setColor(Color.rgb(0, 150 + (i * 6) % 100, 200 - (i * 3) % 50));
                canvas.drawRect(x, y, x + barW, h - 40, paint);

                paint.setColor(Color.WHITE);
                paint.setTextSize(16);
                paint.setTextAlign(Paint.Align.CENTER);
                canvas.drawText(String.valueOf(scores[i]), x + barW / 2, y - 10, paint);
            }
        }
    }
}