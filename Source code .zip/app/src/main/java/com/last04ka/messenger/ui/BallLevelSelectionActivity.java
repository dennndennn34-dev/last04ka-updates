package com.last04ka.messenger.ui;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.last04ka.messenger.R;
import com.last04ka.messenger.game.LevelManager;
import com.last04ka.messenger.utils.AppLogger;
import com.last04ka.messenger.utils.ThemeManager;

public class BallLevelSelectionActivity extends AppCompatActivity {
    private RecyclerView recyclerView;
    private LevelAdapter adapter;
    private int totalLevels = 30;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        setTheme(ThemeManager.getThemeResource(this));
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ball_level_selection);
        setTitle("Выбор уровня");

        recyclerView = findViewById(R.id.level_recycler);
        recyclerView.setLayoutManager(new GridLayoutManager(this, 5));

        adapter = new LevelAdapter();
        recyclerView.setAdapter(adapter);
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (adapter != null) {
            adapter.notifyDataSetChanged();
            AppLogger.log(this, "BallLevelSelection", "Levels refreshed onResume");
        }
    }

    private class LevelAdapter extends RecyclerView.Adapter<LevelAdapter.ViewHolder> {
        private int unlocked;

        @Override
        public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_ball_level, parent, false);
            return new ViewHolder(v);
        }

        @Override
        public void onBindViewHolder(ViewHolder holder, int position) {
            int level = position + 1;
            unlocked = LevelManager.getUnlockedLevel(BallLevelSelectionActivity.this);
            holder.tvLevel.setText(String.valueOf(level));

            boolean isUnlocked = level <= unlocked;
            if (isUnlocked) {
                holder.ivLock.setVisibility(View.GONE);
                holder.itemView.setOnClickListener(v -> {
                    Intent i = new Intent(BallLevelSelectionActivity.this, BallGameActivity.class);
                    i.putExtra("level", level);
                    startActivity(i);
                });
            } else {
                holder.ivLock.setVisibility(View.VISIBLE);
                holder.itemView.setOnClickListener(null);
            }
        }

        @Override
        public int getItemCount() {
            return totalLevels;
        }

        class ViewHolder extends RecyclerView.ViewHolder {
            TextView tvLevel;
            ImageView ivLock;

            ViewHolder(View v) {
                super(v);
                tvLevel = v.findViewById(R.id.tv_level);
                ivLock = v.findViewById(R.id.iv_lock);
            }
        }
    }
}