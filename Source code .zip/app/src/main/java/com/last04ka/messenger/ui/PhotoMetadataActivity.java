package com.last04ka.messenger.ui;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.media.ExifInterface;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.provider.Settings;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import com.last04ka.messenger.R;
import com.last04ka.messenger.utils.AppLogger;
import com.last04ka.messenger.utils.ThemeManager;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class PhotoMetadataActivity extends AppCompatActivity {
    private static final String TAG = "PhotoMetadata";
    private static final int PICK_IMAGE_REQUEST = 2001;
    private static final int OPEN_DOCUMENT_REQUEST = 2002;

    private ImageView ivPreview;
    private ScrollView scrollView;
    private LinearLayout metadataContainer;
    private Button btnSelectImage, btnSaveMetadata, btnEditGps, btnEditDate, btnOpenMap;
    private TextView tvFileName, tvFileSize, tvLocationInfo;
    private ProgressBar progressBar;
    
    private File workingFile;           // Копия файла в кэше для редактирования
    private Uri currentImageUri;        // Оригинальный Uri
    private ExifInterface exifInterface;
    private Animation fadeInAnimation;
    
    private ProgressDialog progressDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        setTheme(ThemeManager.getThemeResource(this));
        super.onCreate(savedInstanceState);
        AppLogger.log(this, TAG, "========== PhotoMetadataActivity onCreate START ==========");
        
        try {
            setContentView(R.layout.activity_photo_metadata);
            
            initViews();
            initProgressDialog();
            setupListeners();
            loadAnimation();
            applyThemeColors();
            
            AppLogger.log(this, TAG, "PhotoMetadataActivity initialized successfully");
        } catch (Exception e) {
            AppLogger.logException(this, TAG, "onCreate error", e);
            Toast.makeText(this, "Ошибка: " + e.getMessage(), Toast.LENGTH_SHORT).show();
            finish();
        }
    }
    
    private void initViews() {
        ivPreview = findViewById(R.id.iv_preview);
        scrollView = findViewById(R.id.scroll_view);
        metadataContainer = findViewById(R.id.metadata_container);
        btnSelectImage = findViewById(R.id.btn_select_image);
        btnSaveMetadata = findViewById(R.id.btn_save_metadata);
        btnEditGps = findViewById(R.id.btn_edit_gps);
        btnEditDate = findViewById(R.id.btn_edit_date);
        btnOpenMap = findViewById(R.id.btn_open_map);
        tvFileName = findViewById(R.id.tv_file_name);
        tvFileSize = findViewById(R.id.tv_file_size);
        tvLocationInfo = findViewById(R.id.tv_location_info);
        progressBar = findViewById(R.id.progress_bar);
        
        // Скрываем кнопку карты, если нет GPS
        btnOpenMap.setVisibility(View.GONE);
        
        AppLogger.log(this, TAG, "Views initialized");
    }
    
    private void initProgressDialog() {
        progressDialog = new ProgressDialog(this);
        progressDialog.setCancelable(false);
        progressDialog.setMessage("Загрузка...");
    }
    
    private void setupListeners() {
        btnSelectImage.setOnClickListener(v -> showImageSourceDialog());
        btnSaveMetadata.setOnClickListener(v -> saveMetadata());
        btnEditGps.setOnClickListener(v -> editGps());
        btnEditDate.setOnClickListener(v -> editDate());
        btnOpenMap.setOnClickListener(v -> openInGoogleMaps());
        
        AppLogger.log(this, TAG, "Listeners setup complete");
    }
    
    private void loadAnimation() {
        fadeInAnimation = AnimationUtils.loadAnimation(this, android.R.anim.fade_in);
        AppLogger.log(this, TAG, "Animation loaded");
    }
    
    private void showImageSourceDialog() {
        AppLogger.log(this, TAG, "showImageSourceDialog() called");
        
        final String[] options = {
            "📸 Галерея (ACTION_PICK)",
            "📁 Файловый менеджер (SAF)"
        };
        
        new AlertDialog.Builder(this)
            .setTitle("Выберите источник")
            .setItems(options, (dialog, which) -> {
                if (which == 0) {
                    selectImageFromGallery();
                } else {
                    selectImageFromDocumentPicker();
                }
            })
            .show();
    }
    
    private void selectImageFromGallery() {
        AppLogger.log(this, TAG, "selectImageFromGallery() called");
        Intent intent = new Intent(Intent.ACTION_PICK);
        intent.setType("image/*");
        startActivityForResult(intent, PICK_IMAGE_REQUEST);
    }
    
    private void selectImageFromDocumentPicker() {
        AppLogger.log(this, TAG, "selectImageFromDocumentPicker() called");
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.setType("image/*");
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.addFlags(Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        intent.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
        startActivityForResult(intent, OPEN_DOCUMENT_REQUEST);
    }
    
    private void processSelectedImage(Uri uri) {
        AppLogger.log(this, TAG, "processSelectedImage() called for URI: " + uri);
        showProgress(true);
        
        new Thread(() -> {
            try {
                // 1. Создаём рабочую копию файла в кэше
                workingFile = createWorkingCopy(uri);
                if (workingFile == null) {
                    runOnUiThread(() -> {
                        showProgress(false);
                        Toast.makeText(PhotoMetadataActivity.this, "Не удалось скопировать файл", Toast.LENGTH_SHORT).show();
                    });
                    return;
                }
                
                // 2. Загружаем ExifInterface из рабочего файла
                exifInterface = new ExifInterface(workingFile.getAbsolutePath());
                
                // 3. Загружаем превью
                final Bitmap preview = loadPreview(uri);
                
                // 4. Получаем информацию о файле
                final String fileName = workingFile.getName();
                final long fileSize = workingFile.length();
                
                runOnUiThread(() -> {
                    ivPreview.setImageBitmap(preview);
                    tvFileName.setText("📄 Файл: " + fileName);
                    tvFileSize.setText("💾 Размер: " + formatFileSize(fileSize));
                    loadMetadata();
                    showProgress(false);
                    Toast.makeText(PhotoMetadataActivity.this, "✓ Метаданные загружены", Toast.LENGTH_SHORT).show();
                });
                
                AppLogger.log(this, TAG, "Image processed: " + workingFile.getAbsolutePath());
                
            } catch (Exception e) {
                AppLogger.logException(PhotoMetadataActivity.this, TAG, "Process image error", e);
                runOnUiThread(() -> {
                    showProgress(false);
                    Toast.makeText(PhotoMetadataActivity.this, "Ошибка: " + e.getMessage(), Toast.LENGTH_LONG).show();
                });
            }
        }).start();
    }
    
    private File createWorkingCopy(Uri sourceUri) throws Exception {
        // Создаём временный файл в кэше приложения
        String timestamp = new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(new Date());
        File tempFile = new File(getCacheDir(), "metadata_" + timestamp + ".jpg");
        
        // Копируем содержимое
        try (InputStream input = getContentResolver().openInputStream(sourceUri);
             OutputStream output = new FileOutputStream(tempFile)) {
            
            byte[] buffer = new byte[8192];
            int bytesRead;
            while ((bytesRead = input.read(buffer)) != -1) {
                output.write(buffer, 0, bytesRead);
            }
            output.flush();
        }
        
        // Для SAF: запрашиваем постоянный доступ
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            try {
                final int takeFlags = Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION;
                getContentResolver().takePersistableUriPermission(sourceUri, takeFlags);
                AppLogger.log(this, TAG, "Persistable URI permission taken");
            } catch (Exception e) {
                AppLogger.logException(this, TAG, "Take persistable permission error", e);
            }
        }
        
        return tempFile;
    }
    
    private Bitmap loadPreview(Uri uri) {
        try {
            BitmapFactory.Options options = new BitmapFactory.Options();
            options.inSampleSize = 2; // Уменьшаем в 2 раза для экономии памяти
            
            InputStream is = getContentResolver().openInputStream(uri);
            Bitmap bitmap = BitmapFactory.decodeStream(is, null, options);
            if (is != null) is.close();
            return bitmap;
        } catch (Exception e) {
            AppLogger.logException(this, TAG, "Load preview error", e);
            return null;
        }
    }
    
    private void loadMetadata() {
        if (exifInterface == null) {
            metadataContainer.removeAllViews();
            addInfoRow("⚠️ Статус", "Метаданные не загружены");
            return;
        }
        
        metadataContainer.removeAllViews();
        
        // Основные метаданные
        addMetadataRow("📷 Производитель", getExifValue(ExifInterface.TAG_MAKE));
        addMetadataRow("📱 Модель", getExifValue(ExifInterface.TAG_MODEL));
        addMetadataRow("📅 Дата съёмки", getExifValue(ExifInterface.TAG_DATETIME));
        addMetadataRow("🖼️ Ширина", getExifValue(ExifInterface.TAG_IMAGE_WIDTH) + " px");
        addMetadataRow("📏 Высота", getExifValue(ExifInterface.TAG_IMAGE_LENGTH) + " px");
        addMetadataRow("🔬 ISO", getExifValue(ExifInterface.TAG_ISO));
        addMetadataRow("⚡ Выдержка", formatExposureTime(getExifValue(ExifInterface.TAG_EXPOSURE_TIME)));
        addMetadataRow("🎚️ Диафрагма", formatAperture(getExifValue(ExifInterface.TAG_F_NUMBER)));
        addMetadataRow("📸 Фокусное", getExifValue(ExifInterface.TAG_FOCAL_LENGTH) + " mm");
        addMetadataRow("🔆 Экспокоррекция", getExifValue(ExifInterface.TAG_EXPOSURE_BIAS_VALUE) + " EV");
        addMetadataRow("⚪ Баланс белого", parseWhiteBalance(getExifValue(ExifInterface.TAG_WHITE_BALANCE)));
        addMetadataRow("💡 Вспышка", parseFlash(getExifValue(ExifInterface.TAG_FLASH)));
        addMetadataRow("📱 Ориентация", parseOrientation(getExifValue(ExifInterface.TAG_ORIENTATION)));
        addMetadataRow("🏷️ ПО", getExifValue(ExifInterface.TAG_SOFTWARE));
        addMetadataRow("📝 Описание", getExifValue(ExifInterface.TAG_IMAGE_DESCRIPTION));
        addMetadataRow("© Авторские права", getExifValue(ExifInterface.TAG_COPYRIGHT));
        
        // GPS координаты
        String gpsLat = getExifValue(ExifInterface.TAG_GPS_LATITUDE);
        String gpsLatRef = getExifValue(ExifInterface.TAG_GPS_LATITUDE_REF);
        String gpsLon = getExifValue(ExifInterface.TAG_GPS_LONGITUDE);
        String gpsLonRef = getExifValue(ExifInterface.TAG_GPS_LONGITUDE_REF);
        
        if (!gpsLat.equals("—") && !gpsLon.equals("—")) {
            double latitude = parseGpsCoordinate(gpsLat, gpsLatRef);
            double longitude = parseGpsCoordinate(gpsLon, gpsLonRef);
            
            addMetadataRow("🗺️ GPS Широта", String.format(Locale.US, "%.6f° %s", Math.abs(latitude), gpsLatRef));
            addMetadataRow("🗺️ GPS Долгота", String.format(Locale.US, "%.6f° %s", Math.abs(longitude), gpsLonRef));
            
            final double finalLat = latitude;
            final double finalLon = longitude;
            runOnUiThread(() -> {
                tvLocationInfo.setText(String.format(Locale.US, "📍 %.6f, %.6f", finalLat, finalLon));
                btnOpenMap.setVisibility(View.VISIBLE);
            });
        } else {
            addMetadataRow("🗺️ GPS", "❌ Не определены");
            runOnUiThread(() -> {
                tvLocationInfo.setText("📍 GPS не найдены");
                btnOpenMap.setVisibility(View.GONE);
            });
        }
        
        addMetadataRow("🕐 GPS Время", getExifValue(ExifInterface.TAG_GPS_TIMESTAMP));
        
        scrollView.startAnimation(fadeInAnimation);
        AppLogger.log(this, TAG, "Metadata loaded");
    }
    
    private void saveMetadata() {
        if (exifInterface == null || workingFile == null) {
            Toast.makeText(this, "Нет файла для сохранения", Toast.LENGTH_SHORT).show();
            return;
        }
        
        showProgress(true);
        AppLogger.log(this, TAG, "Saving metadata...");
        
        new Thread(() -> {
            try {
                exifInterface.saveAttributes();
                
                runOnUiThread(() -> {
                    showProgress(false);
                    Toast.makeText(PhotoMetadataActivity.this, "✓ Метаданные сохранены", Toast.LENGTH_SHORT).show();
                    loadMetadata(); // Обновляем отображение
                    AppLogger.log(PhotoMetadataActivity.this, TAG, "Metadata saved to: " + workingFile.getAbsolutePath());
                });
            } catch (Exception e) {
                AppLogger.logException(PhotoMetadataActivity.this, TAG, "Save metadata error", e);
                runOnUiThread(() -> {
                    showProgress(false);
                    Toast.makeText(PhotoMetadataActivity.this, "Ошибка: " + e.getMessage(), Toast.LENGTH_LONG).show();
                });
            }
        }).start();
    }
    
    private void editGps() {
        if (exifInterface == null) {
            Toast.makeText(this, "Сначала выберите фото", Toast.LENGTH_SHORT).show();
            return;
        }
        
        AppLogger.log(this, TAG, "editGps() called");
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("📍 Редактировать GPS координаты");
        
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(40, 40, 40, 40);
        
        final EditText inputLat = new EditText(this);
        inputLat.setHint("Широта (пример: 55.751244)");
        layout.addView(inputLat);
        
        final EditText inputLng = new EditText(this);
        inputLng.setHint("Долгота (пример: 37.618423)");
        layout.addView(inputLng);
        
        // Подставляем текущие координаты, если есть
        String gpsLat = getExifValue(ExifInterface.TAG_GPS_LATITUDE);
        String gpsLatRef = getExifValue(ExifInterface.TAG_GPS_LATITUDE_REF);
        String gpsLon = getExifValue(ExifInterface.TAG_GPS_LONGITUDE);
        String gpsLonRef = getExifValue(ExifInterface.TAG_GPS_LONGITUDE_REF);
        
        if (!gpsLat.equals("—") && !gpsLon.equals("—")) {
            double lat = parseGpsCoordinate(gpsLat, gpsLatRef);
            double lon = parseGpsCoordinate(gpsLon, gpsLonRef);
            inputLat.setText(String.format(Locale.US, "%.6f", lat));
            inputLng.setText(String.format(Locale.US, "%.6f", lon));
        }
        
        builder.setView(layout);
        builder.setPositiveButton("Сохранить", (dialog, which) -> {
            setGpsCoordinates(inputLat.getText().toString(), inputLng.getText().toString());
        });
        builder.setNeutralButton("Удалить GPS", (dialog, which) -> removeGpsCoordinates());
        builder.setNegativeButton("Отмена", null);
        builder.show();
    }
    
    private void setGpsCoordinates(String latStr, String lngStr) {
        try {
            double latitude = Double.parseDouble(latStr);
            double longitude = Double.parseDouble(lngStr);
            
            String latRef = latitude >= 0 ? "N" : "S";
            String lngRef = longitude >= 0 ? "E" : "W";
            
            latitude = Math.abs(latitude);
            longitude = Math.abs(longitude);
            
            // Конвертируем в градусы/минуты/секунды для EXIF
            int latDeg = (int) latitude;
            double latMinRaw = (latitude - latDeg) * 60;
            int latMin = (int) latMinRaw;
            int latSec = (int) ((latMinRaw - latMin) * 60);
            
            int lngDeg = (int) longitude;
            double lngMinRaw = (longitude - lngDeg) * 60;
            int lngMin = (int) lngMinRaw;
            int lngSec = (int) ((lngMinRaw - lngMin) * 60);
            
            exifInterface.setAttribute(ExifInterface.TAG_GPS_LATITUDE, 
                latDeg + "/1," + latMin + "/1," + latSec + "/1");
            exifInterface.setAttribute(ExifInterface.TAG_GPS_LATITUDE_REF, latRef);
            exifInterface.setAttribute(ExifInterface.TAG_GPS_LONGITUDE, 
                lngDeg + "/1," + lngMin + "/1," + lngSec + "/1");
            exifInterface.setAttribute(ExifInterface.TAG_GPS_LONGITUDE_REF, lngRef);
            exifInterface.setAttribute(ExifInterface.TAG_GPS_TIMESTAMP, 
                new SimpleDateFormat("yyyy:MM:dd HH:mm:ss", Locale.US).format(new Date()));
            
            Toast.makeText(this, String.format(Locale.US, "GPS установлен: %.6f°, %.6f°", 
                latitude * (latRef.equals("N") ? 1 : -1), 
                longitude * (lngRef.equals("E") ? 1 : -1)), Toast.LENGTH_SHORT).show();
            loadMetadata();
            AppLogger.log(this, TAG, "GPS set: " + latStr + ", " + lngStr);
            
        } catch (NumberFormatException e) {
            Toast.makeText(this, "❌ Неверный формат координат", Toast.LENGTH_SHORT).show();
            AppLogger.logException(this, TAG, "Set GPS error", e);
        }
    }
    
    private void removeGpsCoordinates() {
        exifInterface.setAttribute(ExifInterface.TAG_GPS_LATITUDE, null);
        exifInterface.setAttribute(ExifInterface.TAG_GPS_LATITUDE_REF, null);
        exifInterface.setAttribute(ExifInterface.TAG_GPS_LONGITUDE, null);
        exifInterface.setAttribute(ExifInterface.TAG_GPS_LONGITUDE_REF, null);
        exifInterface.setAttribute(ExifInterface.TAG_GPS_TIMESTAMP, null);
        Toast.makeText(this, "GPS данные удалены", Toast.LENGTH_SHORT).show();
        loadMetadata();
        AppLogger.log(this, TAG, "GPS removed");
    }
    
    private void openInGoogleMaps() {
        String gpsLat = getExifValue(ExifInterface.TAG_GPS_LATITUDE);
        String gpsLatRef = getExifValue(ExifInterface.TAG_GPS_LATITUDE_REF);
        String gpsLon = getExifValue(ExifInterface.TAG_GPS_LONGITUDE);
        String gpsLonRef = getExifValue(ExifInterface.TAG_GPS_LONGITUDE_REF);
        
        if (gpsLat.equals("—") || gpsLon.equals("—")) {
            Toast.makeText(this, "GPS данные отсутствуют", Toast.LENGTH_SHORT).show();
            return;
        }
        
        double latitude = parseGpsCoordinate(gpsLat, gpsLatRef);
        double longitude = parseGpsCoordinate(gpsLon, gpsLonRef);
        
        AppLogger.log(this, TAG, "Opening Google Maps at: " + latitude + ", " + longitude);
        
        Uri gmmIntentUri = Uri.parse("geo:" + latitude + "," + longitude + "?q=" + latitude + "," + longitude);
        Intent mapIntent = new Intent(Intent.ACTION_VIEW, gmmIntentUri);
        mapIntent.setPackage("com.google.android.apps.maps");
        
        if (mapIntent.resolveActivity(getPackageManager()) != null) {
            startActivity(mapIntent);
        } else {
            // Запасной вариант - открыть в браузере
            Intent browserIntent = new Intent(Intent.ACTION_VIEW, 
                Uri.parse("https://maps.google.com/?q=" + latitude + "," + longitude));
            startActivity(browserIntent);
        }
    }
    
    private void editDate() {
        if (exifInterface == null) {
            Toast.makeText(this, "Сначала выберите фото", Toast.LENGTH_SHORT).show();
            return;
        }
        
        AppLogger.log(this, TAG, "editDate() called");
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("📅 Редактировать дату");
        
        final EditText input = new EditText(this);
        input.setHint("Формат: YYYY:MM:DD HH:MM:SS");
        String currentDate = getExifValue(ExifInterface.TAG_DATETIME);
        if (!currentDate.equals("—")) {
            input.setText(currentDate);
        } else {
            input.setText(new SimpleDateFormat("yyyy:MM:dd HH:mm:ss", Locale.US).format(new Date()));
        }
        
        builder.setView(input);
        builder.setPositiveButton("Сохранить", (dialog, which) -> {
            String dateTime = input.getText().toString();
            if (dateTime.matches("\\d{4}:\\d{2}:\\d{2} \\d{2}:\\d{2}:\\d{2}")) {
                exifInterface.setAttribute(ExifInterface.TAG_DATETIME, dateTime);
                exifInterface.setAttribute(ExifInterface.TAG_DATETIME_ORIGINAL, dateTime);
                exifInterface.setAttribute(ExifInterface.TAG_DATETIME_DIGITIZED, dateTime);
                Toast.makeText(PhotoMetadataActivity.this, "✓ Дата изменена", Toast.LENGTH_SHORT).show();
                loadMetadata();
                AppLogger.log(PhotoMetadataActivity.this, TAG, "Date set to: " + dateTime);
            } else {
                Toast.makeText(PhotoMetadataActivity.this, "❌ Неверный формат. Используйте: YYYY:MM:DD HH:MM:SS", Toast.LENGTH_LONG).show();
            }
        });
        builder.setNegativeButton("Отмена", null);
        builder.show();
    }
    
    // ==================== ВСПОМОГАТЕЛЬНЫЕ МЕТОДЫ ====================
    
    private String getExifValue(String tag) {
        if (exifInterface == null) return "—";
        String value = exifInterface.getAttribute(tag);
        return (value == null || value.isEmpty()) ? "—" : value;
    }
    
    private double parseGpsCoordinate(String coord, String ref) {
        try {
            String[] parts = coord.split(",");
            if (parts.length == 3) {
                double degrees = Double.parseDouble(parts[0].split("/")[0]);
                double minutes = Double.parseDouble(parts[1].split("/")[0]);
                double seconds = Double.parseDouble(parts[2].split("/")[0]);
                double result = degrees + minutes / 60.0 + seconds / 3600.0;
                if (ref.equals("S") || ref.equals("W")) result = -result;
                return result;
            }
        } catch (Exception e) {
            AppLogger.logException(this, TAG, "Parse GPS error", e);
        }
        return 0.0;
    }
    
    private String parseOrientation(String orientation) {
        if (orientation == null || orientation.equals("—")) return "—";
        switch (orientation) {
            case "1": return "Нормальная (0°)";
            case "3": return "Повёрнуто на 180°";
            case "6": return "Повёрнуто на 90° CW";
            case "8": return "Повёрнуто на 90° CCW";
            default: return orientation;
        }
    }
    
    private String parseWhiteBalance(String value) {
        if (value == null || value.equals("—")) return "—";
        switch (value) {
            case "0": return "Авто";
            case "1": return "Ручной";
            default: return value;
        }
    }
    
    private String parseFlash(String value) {
        if (value == null || value.equals("—")) return "—";
        try {
            int flash = Integer.parseInt(value);
            if ((flash & 0x1) != 0) return "✅ Сработала";
            return "❌ Не сработала";
        } catch (NumberFormatException e) {
            return value;
        }
    }
    
    private String formatExposureTime(String value) {
        if (value == null || value.equals("—")) return "—";
        try {
            String[] parts = value.split("/");
            if (parts.length == 2) {
                double val = Double.parseDouble(parts[0]) / Double.parseDouble(parts[1]);
                if (val < 1) return "1/" + (int) (1.0 / val) + " сек";
                return val + " сек";
            }
        } catch (Exception e) {}
        return value + " сек";
    }
    
    private String formatAperture(String value) {
        if (value == null || value.equals("—")) return "—";
        try {
            String[] parts = value.split("/");
            if (parts.length == 2) {
                double val = Double.parseDouble(parts[0]) / Double.parseDouble(parts[1]);
                return String.format(Locale.US, "f/%.1f", val);
            }
        } catch (Exception e) {}
        return "f/" + value;
    }
    
    private String formatFileSize(long bytes) {
        if (bytes < 1024) return bytes + " B";
        if (bytes < 1024 * 1024) return String.format("%.2f KB", bytes / 1024.0);
        if (bytes < 1024 * 1024 * 1024) return String.format("%.2f MB", bytes / (1024.0 * 1024));
        return String.format("%.2f GB", bytes / (1024.0 * 1024 * 1024));
    }
    
    private void addMetadataRow(String label, String value) {
        if (value == null || value.equals("—") || value.isEmpty()) return;
        
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setPadding(20, 14, 20, 14);
        row.setBackgroundColor(ThemeManager.getCardColor(this));
        
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        );
        params.setMargins(0, 0, 0, 6);
        row.setLayoutParams(params);
        
        TextView tvLabel = new TextView(this);
        tvLabel.setText(label);
        tvLabel.setTextSize(13);
        tvLabel.setWidth(getResources().getDisplayMetrics().widthPixels / 3);
        tvLabel.setTextColor(ThemeManager.getTextSecondaryColor(this));
        
        TextView tvValue = new TextView(this);
        tvValue.setText(value);
        tvValue.setTextSize(14);
        tvValue.setTextColor(ThemeManager.getTextColor(this));
        tvValue.setLayoutParams(new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        ));
        
        row.addView(tvLabel);
        row.addView(tvValue);
        metadataContainer.addView(row);
    }
    
    private void addInfoRow(String label, String value) {
        TextView tv = new TextView(this);
        tv.setText(label + ": " + value);
        tv.setTextSize(16);
        tv.setPadding(24, 24, 24, 24);
        tv.setTextColor(ThemeManager.getTextColor(this));
        metadataContainer.addView(tv);
    }
    
    private void showProgress(boolean show) {
        progressBar.setVisibility(show ? View.VISIBLE : View.GONE);
        btnSelectImage.setEnabled(!show);
        btnSaveMetadata.setEnabled(!show);
        btnEditGps.setEnabled(!show);
        btnEditDate.setEnabled(!show);
        btnOpenMap.setEnabled(!show);
    }
    
    private void applyThemeColors() {
        int bg = ThemeManager.getBackgroundColor(this);
        int actionBarColor = ThemeManager.isDarkTheme(this) ? 0xFF424242 : 0xFF1565C0;
        
        scrollView.setBackgroundColor(bg);
        findViewById(R.id.metadata_layout).setBackgroundColor(bg);
        tvFileName.setTextColor(ThemeManager.getTextColor(this));
        tvFileSize.setTextColor(ThemeManager.getTextColor(this));
        tvLocationInfo.setTextColor(ThemeManager.getTextSecondaryColor(this));
        
        if (getSupportActionBar() != null) {
            getSupportActionBar().setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(actionBarColor));
        }
        
        AppLogger.log(this, TAG, "Theme colors applied");
    }
    
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        AppLogger.log(this, TAG, "onActivityResult: requestCode=" + requestCode + ", resultCode=" + resultCode);
        
        if (resultCode == RESULT_OK && data != null) {
            if (requestCode == PICK_IMAGE_REQUEST || requestCode == OPEN_DOCUMENT_REQUEST) {
                currentImageUri = data.getData();
                if (currentImageUri != null) {
                    // Сохраняем URI для SAF
                    if (requestCode == OPEN_DOCUMENT_REQUEST && Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
                        final int takeFlags = Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION;
                        getContentResolver().takePersistableUriPermission(currentImageUri, takeFlags);
                    }
                    processSelectedImage(currentImageUri);
                }
            }
        }
    }
}