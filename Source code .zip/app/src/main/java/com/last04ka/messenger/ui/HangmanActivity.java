package com.last04ka.messenger.ui;

import android.app.Activity;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import com.last04ka.messenger.utils.AppLogger;
import java.util.Random;

public class HangmanActivity extends Activity {

    private GameView gameView;
    private TextView wordText, statusText, scoreText;
    private Button[] letterButtons = new Button[33];
    private Button btnNew;
    private String[] words = {"ПРОГРАММИСТ","КОМПЬЮТЕР","АЛГОРИТМ","ДЖАВА","АНДРОИД","МЕССЕНДЖЕР",
        "БЛЮТУЗ","ИНТЕРНЕТ","БРАУЗЕР","ПРИЛОЖЕНИЕ","КЛАВИАТУРА","МОНИТОР","ПРОЦЕССОР",
        "ПАМЯТЬ","БАТАРЕЯ","СМАРТФОН","ПЛАНШЕТ","НОУТБУК","СЕРВЕР","КОДИРОВКА"};
    private String currentWord;
    private boolean[] guessed;
    private int mistakes = 0, maxMistakes = 6;
    private int score = 0;
    private Random rand = new Random();

    // 6 рядов по 5-6 букв = все 33 буквы
    private static final String[] ROWS = {
        "АБВГДЕ",   // 6
        "ЁЖЗИЙК",   // 6
        "ЛМНОПР",   // 6
        "СТУФХЦ",   // 6
        "ЧШЩЪЫЬ",   // 6
        "ЭЮЯ"       // 3
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        try {
            AppLogger.log(this, "Hangman", "onCreate v5");
            LinearLayout layout = new LinearLayout(this);
            layout.setOrientation(LinearLayout.VERTICAL);
            layout.setBackgroundColor(0xFF1A1A2E);
            layout.setPadding(4, 6, 4, 6);

            // Статус
            statusText = new TextView(this);
            statusText.setText("Виселица"); statusText.setTextSize(16);
            statusText.setTextColor(0xFFFFD740); statusText.setGravity(Gravity.CENTER);
            layout.addView(statusText);

            scoreText = new TextView(this);
            scoreText.setText("Счёт: 0"); scoreText.setTextSize(13);
            scoreText.setTextColor(0xFFFFFFFF); scoreText.setGravity(Gravity.CENTER);
            layout.addView(scoreText);

            // Виселица
            gameView = new GameView(this);
            LinearLayout.LayoutParams gvp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 220);
            gameView.setLayoutParams(gvp);
            layout.addView(gameView);

            // Загаданное слово
            wordText = new TextView(this);
            wordText.setTextSize(22); wordText.setTextColor(0xFF4FC3F7);
            wordText.setGravity(Gravity.CENTER); wordText.setPadding(0, 6, 0, 6);
            layout.addView(wordText);

            // Клавиатура — 6 рядов
            for (String row : ROWS) {
                LinearLayout kb = new LinearLayout(this);
                kb.setGravity(Gravity.CENTER);
                kb.setPadding(0, 2, 0, 2);
                for (int i = 0; i < row.length(); i++) {
                    final char c = row.charAt(i);
                    Button btn = new Button(this);
                    btn.setText(String.valueOf(c));
                    btn.setTextSize(14);
                    btn.setPadding(10, 6, 10, 6);
                    btn.setMinWidth(0);
                    btn.setMinimumWidth(0);
                    btn.setOnClickListener(v -> guessLetter(c));
                    kb.addView(btn);
                    // Сохраняем кнопку по индексу буквы
                    int idx = getIndex(c);
                    if (idx >= 0 && idx < 33) letterButtons[idx] = btn;
                }
                layout.addView(kb);
            }

            btnNew = new Button(this);
            btnNew.setText("Новое слово");
            btnNew.setOnClickListener(v -> newGame());
            layout.addView(btnNew);

            setContentView(layout);
            setTitle("💀 Виселица");
            newGame();
            AppLogger.log(this, "Hangman", "onCreate completed, 6 rows, 33 buttons");
        } catch (Exception e) {
            AppLogger.logException(this, "Hangman", e);
            Toast.makeText(this, "Ошибка", Toast.LENGTH_SHORT).show();
            finish();
        }
    }

    // Индекс буквы: А=0, Б=1, ..., Я=32, Ё=6
    private int getIndex(char c) {
        String alphabet = "АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯ";
        return alphabet.indexOf(c);
    }

    private void newGame() {
        currentWord = words[rand.nextInt(words.length)];
        guessed = new boolean[currentWord.length()];
        mistakes = 0;
        for (Button b : letterButtons) if (b != null) b.setEnabled(true);
        updateDisplay();
        gameView.invalidate();
        AppLogger.log(this, "Hangman", "New word: " + currentWord.length());
    }

    private void guessLetter(char c) {
        int idx = getIndex(c);
        if (idx < 0 || idx >= 33 || letterButtons[idx] == null) return;
        letterButtons[idx].setEnabled(false);
        boolean hit = false;
        for (int i = 0; i < currentWord.length(); i++)
            if (currentWord.charAt(i) == c) { guessed[i] = true; hit = true; }
        if (!hit) mistakes++;
        updateDisplay();
        gameView.invalidate();
        boolean won = true;
        for (boolean g : guessed) if (!g) { won = false; break; }
        if (won) {
            score++;
            scoreText.setText("Счёт: " + score);
            statusText.setText("🏆 Победа!");
            for (Button b : letterButtons) if (b != null) b.setEnabled(false);
            AppLogger.log(this, "Hangman", "Won, score=" + score);
        } else if (mistakes >= maxMistakes) {
            statusText.setText("💀 Проигрыш: " + currentWord);
            for (Button b : letterButtons) if (b != null) b.setEnabled(false);
            AppLogger.log(this, "Hangman", "Lost, word=" + currentWord);
        }
    }

    private void updateDisplay() {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < currentWord.length(); i++)
            sb.append(guessed[i] ? currentWord.charAt(i) : "_").append(" ");
        wordText.setText(sb.toString().trim());
        if (mistakes < maxMistakes && !statusText.getText().toString().contains("🏆")
            && !statusText.getText().toString().contains("💀"))
            statusText.setText("Ошибок: " + mistakes + "/" + maxMistakes);
        scoreText.setText("Счёт: " + score);
    }

    class GameView extends View {
        private Paint paint = new Paint();
        public GameView(Context ctx) { super(ctx); }
        @Override
        protected void onDraw(Canvas c) {
            super.onDraw(c);
            int w = getWidth(), h = getHeight();
            float s = Math.min(w, h) / 200f, cx = w / 2f, y = 8 * s;
            paint.setColor(Color.WHITE);
            paint.setStrokeWidth(4 * s);
            c.drawLine(cx - 40 * s, y + 100 * s, cx + 40 * s, y + 100 * s, paint);
            c.drawLine(cx - 30 * s, y + 100 * s, cx - 30 * s, y, paint);
            c.drawLine(cx - 30 * s, y, cx + 10 * s, y, paint);
            c.drawLine(cx + 10 * s, y, cx + 10 * s, y + 18 * s, paint);
            if (mistakes >= 1) c.drawCircle(cx + 10 * s, y + 30 * s, 11 * s, paint);
            if (mistakes >= 2) c.drawLine(cx + 10 * s, y + 41 * s, cx + 10 * s, y + 72 * s, paint);
            if (mistakes >= 3) c.drawLine(cx + 10 * s, y + 48 * s, cx - 4 * s, y + 60 * s, paint);
            if (mistakes >= 4) c.drawLine(cx + 10 * s, y + 48 * s, cx + 24 * s, y + 60 * s, paint);
            if (mistakes >= 5) c.drawLine(cx + 10 * s, y + 72 * s, cx, y + 90 * s, paint);
            if (mistakes >= 6) c.drawLine(cx + 10 * s, y + 72 * s, cx + 20 * s, y + 90 * s, paint);
        }
    }
}