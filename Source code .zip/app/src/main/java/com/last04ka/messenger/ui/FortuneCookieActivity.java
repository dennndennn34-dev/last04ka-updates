package com.last04ka.messenger.ui;

import android.app.Activity;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.view.Gravity;
import android.view.animation.Animation;
import android.view.animation.RotateAnimation;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import com.last04ka.messenger.utils.AppLogger;
import java.util.Random;

public class FortuneCookieActivity extends Activity {

    private TextView fortuneText, counterText;
    private Button btnCrack;
    private Handler handler = new Handler();
    private Random rand = new Random();
    private int cookiesOpened = 0;

    private String[] fortunes = {
        "Сегодня удача на твоей стороне! 🍀", "Скоро ты получишь важное сообщение 💬",
        "Деньги придут оттуда, откуда не ждёшь 💰", "Новая возможность уже в пути 🚀",
        "Друг познаётся в беде 🤝", "Твоя идея изменит всё 💡",
        "Приключения зовут! 🗺️", "Время действовать, не откладывай ⏰",
        "Кто-то думает о тебе прямо сейчас 💭", "Сегодня лучший день для начала 🏁",
        "Тайный поклонник рядом 💕", "Не бойся перемен — они к лучшему 🌈",
        "Твой код скомпилируется с первого раза 💻", "Баги исчезнут сами собой 🐛",
        "Верь в себя — и всё получится! ✨"
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        try {
            AppLogger.log(this, "FortuneCookie", "onCreate started");
            LinearLayout layout = new LinearLayout(this);
            layout.setOrientation(LinearLayout.VERTICAL);
            layout.setPadding(24, 24, 24, 24);
            layout.setBackgroundColor(0xFF1A1A2E);
            layout.setGravity(Gravity.CENTER);

            TextView title = new TextView(this);
            title.setText("🥠 Печенье с предсказаниями"); title.setTextSize(18);
            title.setTextColor(0xFFFFFFFF); title.setGravity(Gravity.CENTER);
            layout.addView(title);

            TextView emoji = new TextView(this);
            emoji.setText("🥠"); emoji.setTextSize(80);
            emoji.setGravity(Gravity.CENTER);
            layout.addView(emoji);

            fortuneText = new TextView(this);
            fortuneText.setText("Нажми, чтобы разломить печенье");
            fortuneText.setTextSize(16); fortuneText.setTextColor(0xFFFFD740);
            fortuneText.setGravity(Gravity.CENTER); fortuneText.setPadding(16, 20, 16, 20);
            fortuneText.setBackgroundColor(0xFF333333); fortuneText.setMinHeight(100);
            layout.addView(fortuneText);

            btnCrack = new Button(this);
            btnCrack.setText("🥠 Разломить печенье"); btnCrack.setTextSize(18);
            btnCrack.setOnClickListener(v -> crackCookie());
            layout.addView(btnCrack);

            counterText = new TextView(this);
            counterText.setText("Открыто: 0"); counterText.setTextSize(12);
            counterText.setTextColor(0xFF888888); counterText.setGravity(Gravity.CENTER);
            counterText.setPadding(0, 12, 0, 0);
            layout.addView(counterText);

            setContentView(layout); setTitle("🥠 Печенье с предсказаниями");
            AppLogger.log(this, "FortuneCookie", "onCreate completed");
        } catch (Exception e) { AppLogger.logException(this, "FortuneCookie", e); finish(); }
    }

    private void crackCookie() {
        btnCrack.setEnabled(false);
        fortuneText.setText("🥠 Ломаем...");
        RotateAnimation ra = new RotateAnimation(0, 15, Animation.RELATIVE_TO_SELF, 0.5f, Animation.RELATIVE_TO_SELF, 0.5f);
        ra.setDuration(200); ra.setRepeatCount(5); ra.setRepeatMode(Animation.REVERSE);
        fortuneText.startAnimation(ra);

        handler.postDelayed(() -> {
            String fortune = fortunes[rand.nextInt(fortunes.length)];
            fortuneText.clearAnimation();
            fortuneText.setText(fortune);
            cookiesOpened++;
            counterText.setText("Открыто: " + cookiesOpened);
            btnCrack.setEnabled(true);
            AppLogger.log(FortuneCookieActivity.this, "FortuneCookie", "Fortune #" + cookiesOpened + ": " + fortune);
        }, 1200);
    }
}