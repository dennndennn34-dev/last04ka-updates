package com.last04ka.messenger.ui;

import android.app.Activity;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;
import com.last04ka.messenger.utils.AppLogger;

public class CompassActivity extends Activity implements SensorEventListener {

    private CompassView compassView;
    private TextView degreeText, coordsText;
    private SensorManager sensorManager;
    private Sensor accelerometer, magnetometer;
    private float[] gravity, geomagnetic;
    private float azimuth = 0;
    private LocationManager locationManager;
    private double lat = 0, lon = 0, alt = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        try {
            AppLogger.log(this, "Compass", "onCreate started");
            LinearLayout layout = new LinearLayout(this);
            layout.setOrientation(LinearLayout.VERTICAL);
            layout.setBackgroundColor(0xFF1A1A2E);

            compassView = new CompassView(this);
            LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(400, 400);
            cp.gravity = android.view.Gravity.CENTER;
            compassView.setLayoutParams(cp);
            layout.addView(compassView);

            degreeText = new TextView(this);
            degreeText.setText("0° N");
            degreeText.setTextSize(24); degreeText.setTextColor(0xFFFFFFFF);
            degreeText.setGravity(android.view.Gravity.CENTER);
            layout.addView(degreeText);

            coordsText = new TextView(this);
            coordsText.setText("GPS: поиск...");
            coordsText.setTextSize(14); coordsText.setTextColor(0xFFBDBDBD);
            coordsText.setGravity(android.view.Gravity.CENTER);
            coordsText.setPadding(0, 8, 0, 0);
            layout.addView(coordsText);

            sensorManager = (SensorManager) getSystemService(Context.SENSOR_SERVICE);
            accelerometer = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
            magnetometer = sensorManager.getDefaultSensor(Sensor.TYPE_MAGNETIC_FIELD);

            locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
            try {
                locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 3000, 0, new LocationListener() {
                    @Override public void onLocationChanged(Location loc) { lat = loc.getLatitude(); lon = loc.getLongitude(); alt = loc.getAltitude(); updateCoords(); }
                    @Override public void onStatusChanged(String p, int s, Bundle b) {}
                    @Override public void onProviderEnabled(String p) { AppLogger.log(CompassActivity.this, "Compass", "GPS enabled"); }
                    @Override public void onProviderDisabled(String p) { AppLogger.log(CompassActivity.this, "Compass", "GPS disabled"); }
                });
            } catch (SecurityException e) { AppLogger.logException(this, "Compass", e); }

            setContentView(layout);
            setTitle("🧭 Компас");
            AppLogger.log(this, "Compass", "onCreate completed");
        } catch (Exception e) { AppLogger.logException(this, "Compass", e); finish(); }
    }

    private void updateCoords() {
        coordsText.setText(String.format("📍 %.5f, %.5f | Alt: %.0f м", lat, lon, alt));
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (accelerometer != null) sensorManager.registerListener(this, accelerometer, SensorManager.SENSOR_DELAY_UI);
        if (magnetometer != null) sensorManager.registerListener(this, magnetometer, SensorManager.SENSOR_DELAY_UI);
    }

    @Override
    protected void onPause() {
        super.onPause();
        sensorManager.unregisterListener(this);
    }

    @Override
    public void onSensorChanged(SensorEvent event) {
        if (event.sensor.getType() == Sensor.TYPE_ACCELEROMETER) gravity = event.values;
        if (event.sensor.getType() == Sensor.TYPE_MAGNETIC_FIELD) geomagnetic = event.values;
        if (gravity != null && geomagnetic != null) {
            float[] R = new float[9], I = new float[9];
            if (SensorManager.getRotationMatrix(R, I, gravity, geomagnetic)) {
                float[] orientation = new float[3];
                SensorManager.getOrientation(R, orientation);
                azimuth = (float) Math.toDegrees(orientation[0]);
                if (azimuth < 0) azimuth += 360;
                String dir;
                if (azimuth < 22.5 || azimuth > 337.5) dir = "N";
                else if (azimuth < 67.5) dir = "NE";
                else if (azimuth < 112.5) dir = "E";
                else if (azimuth < 157.5) dir = "SE";
                else if (azimuth < 202.5) dir = "S";
                else if (azimuth < 247.5) dir = "SW";
                else if (azimuth < 292.5) dir = "W";
                else dir = "NW";
                degreeText.setText(String.format("%.0f° %s", azimuth, dir));
                compassView.setAzimuth(azimuth);
                compassView.invalidate();
            }
        }
    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {}

    class CompassView extends View {
        private Paint paint = new Paint();
        private float currentAzimuth = 0;

        public CompassView(Context ctx) { super(ctx); setBackgroundColor(Color.rgb(30,30,30)); }
        public void setAzimuth(float az) { this.currentAzimuth = az; }

        @Override
        protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            float cx = getWidth() / 2f, cy = getHeight() / 2f;
            float r = Math.min(cx, cy) * 0.85f;
            paint.setColor(Color.rgb(50,50,50));
            canvas.drawCircle(cx, cy, r, paint);
            paint.setColor(Color.WHITE);
            paint.setTextSize(24);
            paint.setTextAlign(Paint.Align.CENTER);
            String[] dirs = {"N","NE","E","SE","S","SW","W","NW"};
            for (int i = 0; i < 8; i++) {
                double angle = Math.toRadians(i * 45 - currentAzimuth);
                float x = cx + (float) Math.sin(angle) * r * 0.75f;
                float y = cy - (float) Math.cos(angle) * r * 0.75f;
                if (i == 0) paint.setColor(Color.RED); else paint.setColor(0xFFBDBDBD);
                canvas.drawText(dirs[i], x, y + 8, paint);
            }
            paint.setColor(Color.RED);
            paint.setStrokeWidth(4);
            float arrowAngle = (float) Math.toRadians(-currentAzimuth);
            float ax = cx + (float) Math.sin(arrowAngle) * r * 0.9f;
            float ay = cy - (float) Math.cos(arrowAngle) * r * 0.9f;
            canvas.drawLine(cx, cy, ax, ay, paint);
            paint.setColor(Color.WHITE);
            canvas.drawCircle(cx, cy, 6, paint);
        }
    }
}