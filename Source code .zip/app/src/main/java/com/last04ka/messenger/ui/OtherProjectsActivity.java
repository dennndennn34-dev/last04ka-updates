package com.last04ka.messenger.ui;

import android.app.DownloadManager;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.support.v4.content.FileProvider;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.last04ka.messenger.R;
import com.last04ka.messenger.utils.AppLogger;
import com.last04ka.messenger.utils.ThemeManager;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

public class OtherProjectsActivity extends AppCompatActivity {

    private static final String TAG = "OtherProjects";
    
    // ==================== UMBRA BROWSER ====================
    private static final String UMBRA_DOWNLOAD_URL = "https://github.com/dennndennn34-dev/umbra-releases/releases/download/1.0/Umbra_Browser.apk";
    private static final String UMBRA_VERSION = "v1.0";
    private static final String UMBRA_SIZE = "~5.8 MB";
    private static final String UMBRA_REPO_URL = "https://github.com/dennndennn34-dev/umbra-releases";

    private RecyclerView rvProjects;
    private ProjectsAdapter adapter;
    private List<ProjectItem> projects = new ArrayList<>();
    private Handler handler = new Handler(Looper.getMainLooper());
    private boolean isDownloading = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        setTheme(ThemeManager.getThemeResource(this));
        super.onCreate(savedInstanceState);
        AppLogger.log(this, TAG, "═══════════════════════════════════════════════════════════");
        AppLogger.log(this, TAG, "📦 OtherProjectsActivity onCreate START");
        AppLogger.log(this, TAG, "═══════════════════════════════════════════════════════════");

        try {
            setContentView(R.layout.activity_other_projects);
            setTitle("Мои другие проекты");

            initProjects();
            initRecyclerView();
            applyThemeColors();

            AppLogger.log(this, TAG, "✅ OtherProjectsActivity initialized, projects: " + projects.size());
            AppLogger.log(this, TAG, "═══════════════════════════════════════════════════════════");

        } catch (Exception e) {
            AppLogger.logException(this, TAG, "❌ onCreate error", e);
            Toast.makeText(this, "Ошибка: " + e.getMessage(), Toast.LENGTH_LONG).show();
            finish();
        }
    }

    private void initProjects() {
        projects.clear();

        // ==================== ПРОЕКТ 1: PRIVATE BROWSER UMBRA ====================
        projects.add(new ProjectItem(
            "🌑 Приватный браузер Umbra",
            "Анонимный браузер с защитой от слежки и встроенным VPN",
            UMBRA_VERSION,
            UMBRA_SIZE,
            true,
            UMBRA_REPO_URL,
            UMBRA_DOWNLOAD_URL
        ));

        // ==================== ПУСТЫЕ СЛОТЫ ====================
        projects.add(new ProjectItem(
            "📱 (Пусто)",
            "Здесь будет новый проект",
            "—",
            "—",
            false,
            null,
            null
        ));

        projects.add(new ProjectItem(
            "📱 (Пусто)",
            "Здесь будет новый проект",
            "—",
            "—",
            false,
            null,
            null
        ));

        projects.add(new ProjectItem(
            "📱 (Пусто)",
            "Здесь будет новый проект",
            "—",
            "—",
            false,
            null,
            null
        ));

        projects.add(new ProjectItem(
            "📱 (Пусто)",
            "Здесь будет новый проект",
            "—",
            "—",
            false,
            null,
            null
        ));

        AppLogger.log(this, TAG, "Projects initialized: " + projects.size() + " items");
    }

    private void initRecyclerView() {
        rvProjects = findViewById(R.id.rv_projects);
        rvProjects.setLayoutManager(new LinearLayoutManager(this));
        adapter = new ProjectsAdapter(projects);
        rvProjects.setAdapter(adapter);
    }

    private void applyThemeColors() {
        int bg = ThemeManager.getBackgroundColor(this);
        findViewById(R.id.projects_container).setBackgroundColor(bg);

        if (getSupportActionBar() != null) {
            getSupportActionBar().setBackgroundDrawable(
                new android.graphics.drawable.ColorDrawable(
                    ThemeManager.isDarkTheme(this) ? 0xFF424242 : 0xFF1565C0
                )
            );
        }
    }

    // ==================== DATA CLASS ====================

    public static class ProjectItem {
        public String name;
        public String description;
        public String version;
        public String size;
        public boolean available;
        public String repoUrl;
        public String downloadUrl;

        public ProjectItem(String name, String description, String version, String size,
                          boolean available, String repoUrl, String downloadUrl) {
            this.name = name;
            this.description = description;
            this.version = version;
            this.size = size;
            this.available = available;
            this.repoUrl = repoUrl;
            this.downloadUrl = downloadUrl;
        }
    }

    // ==================== ADAPTER ====================

    private class ProjectsAdapter extends RecyclerView.Adapter<ProjectsAdapter.ViewHolder> {

        private List<ProjectItem> items;
        private Animation fadeInAnimation;

        public ProjectsAdapter(List<ProjectItem> items) {
            this.items = items;
            fadeInAnimation = AnimationUtils.loadAnimation(OtherProjectsActivity.this, android.R.anim.fade_in);
        }

        @Override
        public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            View view = LayoutInflater.from(parent.getContext())
                    .inflate(R.layout.item_project, parent, false);
            return new ViewHolder(view);
        }

        @Override
        public void onBindViewHolder(ViewHolder holder, int position) {
            ProjectItem item = items.get(position);

            holder.tvName.setText(item.name);
            holder.tvDescription.setText(item.description);

            if (item.available && item.downloadUrl != null) {
                holder.tvVersion.setVisibility(View.VISIBLE);
                holder.tvSize.setVisibility(View.VISIBLE);
                holder.tvVersion.setText("Версия: " + item.version);
                holder.tvSize.setText("Размер: " + item.size);
                holder.btnDownload.setVisibility(View.VISIBLE);
                holder.btnDownload.setEnabled(true);
                holder.btnDownload.setText("⬇ Скачать");
                holder.btnDownload.setOnClickListener(v -> {
                    AppLogger.log(OtherProjectsActivity.this, TAG,
                        "Download button clicked for: " + item.name);
                    showDownloadDialog(item);
                });

                holder.itemView.setOnClickListener(v -> {
                    AppLogger.log(OtherProjectsActivity.this, TAG,
                        "Item clicked: " + item.name);
                    showProjectInfoDialog(item);
                });
                holder.itemView.setAlpha(1.0f);

            } else {
                holder.tvVersion.setVisibility(View.GONE);
                holder.tvSize.setVisibility(View.GONE);
                holder.btnDownload.setVisibility(View.GONE);
                holder.btnDownload.setEnabled(false);
                holder.itemView.setOnClickListener(null);
                holder.itemView.setAlpha(0.4f);
            }

            if (position == 0) {
                holder.itemView.startAnimation(fadeInAnimation);
            }
        }

        @Override
        public int getItemCount() {
            return items.size();
        }

        public class ViewHolder extends RecyclerView.ViewHolder {
            TextView tvName, tvDescription, tvVersion, tvSize;
            Button btnDownload;

            public ViewHolder(View itemView) {
                super(itemView);
                tvName = itemView.findViewById(R.id.tv_project_name);
                tvDescription = itemView.findViewById(R.id.tv_project_description);
                tvVersion = itemView.findViewById(R.id.tv_project_version);
                tvSize = itemView.findViewById(R.id.tv_project_size);
                btnDownload = itemView.findViewById(R.id.btn_download);
            }
        }
    }

    // ==================== ДИАЛОГИ ====================

    private void showProjectInfoDialog(ProjectItem item) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("📦 " + item.name);
        builder.setMessage(
            "Версия: " + item.version + "\n" +
            "Размер: " + item.size + "\n\n" +
            item.description + "\n\n" +
            "🔗 Репозиторий: " + item.repoUrl
        );
        builder.setPositiveButton("Скачать", (dialog, which) -> {
            showDownloadDialog(item);
        });
        builder.setNeutralButton("Закрыть", null);
        builder.show();
    }

    private void showDownloadDialog(ProjectItem item) {
        if (isDownloading) {
            Toast.makeText(this, "Скачивание уже выполняется", Toast.LENGTH_SHORT).show();
            return;
        }

        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("⬇ Скачать " + item.name);
        builder.setMessage(
            "Вы уверены, что хотите скачать " + item.name + "?\n\n" +
            "Версия: " + item.version + "\n" +
            "Размер: " + item.size + "\n\n" +
            "⚠️ Приложение будет загружено из интернета."
        );
        builder.setPositiveButton("Скачать", (dialog, which) -> {
            AppLogger.log(OtherProjectsActivity.this, TAG, "Download confirmed for: " + item.name);
            startDownload(item);
        });
        builder.setNegativeButton("Отмена", null);
        builder.show();
    }

    // ==================== СКАЧИВАНИЕ ====================

    private void startDownload(ProjectItem item) {
        if (isDownloading) return;
        isDownloading = true;

        try {
            String downloadUrl = item.downloadUrl;
            String fileName = "Umbra_Browser.apk";

            AppLogger.log(this, TAG, "📥 Starting download from: " + downloadUrl);
            AppLogger.log(this, TAG, "📁 File name: " + fileName);

            File dir = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), "Last04ka");
            if (!dir.exists()) {
                dir.mkdirs();
                AppLogger.log(this, TAG, "📁 Created directory: " + dir.getAbsolutePath());
            }

            File file = new File(dir, fileName);
            if (file.exists()) {
                file.delete();
                AppLogger.log(this, TAG, "🗑️ Old file deleted");
            }

            DownloadManager.Request request = new DownloadManager.Request(Uri.parse(downloadUrl));
            request.setTitle("📦 " + item.name);
            request.setDescription("Скачивание " + item.version + "...");
            request.setDestinationUri(Uri.fromFile(file));
            request.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
            request.setMimeType("application/vnd.android.package-archive");
            request.setAllowedNetworkTypes(DownloadManager.Request.NETWORK_WIFI | DownloadManager.Request.NETWORK_MOBILE);

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                request.setRequiresDeviceIdle(false);
                request.setRequiresCharging(false);
            }

            DownloadManager downloadManager = (DownloadManager) getSystemService(Context.DOWNLOAD_SERVICE);
            if (downloadManager != null) {
                long downloadId = downloadManager.enqueue(request);
                AppLogger.log(this, TAG, "✅ Download queued, ID: " + downloadId);

                Toast.makeText(this, "Скачивание началось...", Toast.LENGTH_SHORT).show();

                monitorDownload(downloadId, file, item);

            } else {
                AppLogger.log(this, TAG, "❌ DownloadManager is null");
                Toast.makeText(this, "Ошибка: DownloadManager недоступен", Toast.LENGTH_SHORT).show();
                isDownloading = false;
            }

        } catch (Exception e) {
            AppLogger.logException(this, TAG, "❌ Download error", e);
            Toast.makeText(this, "Ошибка скачивания: " + e.getMessage(), Toast.LENGTH_SHORT).show();
            isDownloading = false;
        }
    }

    private void monitorDownload(long downloadId, File file, ProjectItem item) {
        AppLogger.log(this, TAG, "🔍 Monitoring download ID: " + downloadId);

        new Thread(() -> {
            boolean finished = false;
            int attempts = 0;
            int maxAttempts = 180; // 3 минуты максимум

            while (!finished && attempts < maxAttempts) {
                try {
                    Thread.sleep(1000);
                    attempts++;

                    DownloadManager downloadManager = (DownloadManager) getSystemService(Context.DOWNLOAD_SERVICE);
                    if (downloadManager == null) break;

                    DownloadManager.Query query = new DownloadManager.Query();
                    query.setFilterById(downloadId);

                    android.database.Cursor cursor = downloadManager.query(query);
                    if (cursor != null && cursor.moveToFirst()) {
                        int status = cursor.getInt(cursor.getColumnIndex(DownloadManager.COLUMN_STATUS));

                        if (status == DownloadManager.STATUS_SUCCESSFUL) {
                            finished = true;
                            AppLogger.log(this, TAG, "✅ Download completed successfully");
                            handler.post(() -> {
                                isDownloading = false;
                                Toast.makeText(OtherProjectsActivity.this, "✅ Скачивание завершено!", Toast.LENGTH_LONG).show();
                                installAPK(file);
                            });
                        } else if (status == DownloadManager.STATUS_FAILED) {
                            finished = true;
                            int reason = cursor.getInt(cursor.getColumnIndex(DownloadManager.COLUMN_REASON));
                            AppLogger.log(this, TAG, "❌ Download failed, reason: " + reason);
                            handler.post(() -> {
                                isDownloading = false;
                                Toast.makeText(OtherProjectsActivity.this, "❌ Ошибка скачивания. Проверьте интернет.", Toast.LENGTH_SHORT).show();
                            });
                        }
                        cursor.close();
                    }

                } catch (Exception e) {
                    AppLogger.logException(this, TAG, "Download monitoring error", e);
                    break;
                }
            }

            if (!finished) {
                AppLogger.log(this, TAG, "⚠️ Download monitoring timeout");
                handler.post(() -> {
                    isDownloading = false;
                    Toast.makeText(OtherProjectsActivity.this, "⏱️ Время ожидания скачивания истекло", Toast.LENGTH_SHORT).show();
                });
            }

        }).start();
    }

    private void installAPK(File file) {
        AppLogger.log(this, TAG, "📲 Installing APK: " + file.getAbsolutePath());

        if (!file.exists()) {
            AppLogger.log(this, TAG, "❌ File not found: " + file.getAbsolutePath());
            Toast.makeText(this, "Файл не найден", Toast.LENGTH_SHORT).show();
            return;
        }

        AppLogger.log(this, TAG, "   File size: " + file.length() + " bytes");

        try {
            Intent intent = new Intent(Intent.ACTION_VIEW);
            Uri uri;

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                uri = FileProvider.getUriForFile(this,
                        getPackageName() + ".provider",
                        file);
                intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                intent.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
                AppLogger.log(this, TAG, "   Using FileProvider URI: " + uri.toString());
            } else {
                uri = Uri.fromFile(file);
                AppLogger.log(this, TAG, "   Using file URI: " + uri.toString());
            }

            intent.setDataAndType(uri, "application/vnd.android.package-archive");
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);

            AppLogger.log(this, TAG, "✅ Starting installation intent");
            startActivity(intent);

        } catch (Exception e) {
            AppLogger.logException(this, TAG, "❌ Installation error", e);
            Toast.makeText(this, "Ошибка установки: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        AppLogger.log(this, TAG, "onDestroy()");
    }
}