package com.last04ka.messenger.ui;

import android.Manifest;
import android.app.DownloadManager;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Environment;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.speech.RecognizerIntent;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.RotateAnimation;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.webkit.CookieManager;
import android.webkit.DownloadListener;
import android.webkit.URLUtil;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;
import com.last04ka.messenger.R;
import com.last04ka.messenger.utils.AdBlocker;
import com.last04ka.messenger.utils.AppLogger;
import com.last04ka.messenger.utils.ThemeManager;
import java.io.ByteArrayInputStream;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class BrowserActivity extends AppCompatActivity {

    private static final int REQUEST_WRITE_STORAGE = 1;
    private static final int REQUEST_QR_SCAN = 2;
    private static final int REQUEST_VOICE = 3;
    private static final String PREFS_SEARCH = "browser_prefs";
    private static final String PREFS_BROWSER = "browser_settings";
    private static final String PREFS_BOOKMARKS = "bookmarks";
    private static final String KEY_SEARCH_ENGINE = "search_engine";
    private static final String KEY_SEARCH_CHOSEN = "search_chosen";
    private static final String KEY_HOME_URL = "home_url";

    private LinearLayout tabsContainer;
    private EditText urlInput, searchInput;
    private TextView searchCount, adBlockCounter;
    private ImageButton btnBack, btnForward, btnRefresh, btnHome, btnSearchEngine;
    private ImageButton btnVoice, btnQr, btnSearchClose, btnSearchUp, btnSearchDown;
    private ImageButton btnTabs, btnSharePage, btnBookmark;
    private ProgressBar progressBar;
    private FrameLayout webviewContainer;
    private TextView tabCountText;
    private LinearLayout searchPanel;

    private List<WebView> webViews = new ArrayList<>();
    private List<String> tabUrls = new ArrayList<>();
    private List<String> tabTitles = new ArrayList<>();
    private List<View> tabViews = new ArrayList<>();
    private List<Boolean> tabIncognito = new ArrayList<>();
    private int currentTab = 0;
    private boolean isDesktopMode = false;
    private int blockedAdsCount = 0;
    private int blockedAdsTotal = 0;

    private int searchEngine = 0;
    private boolean searchChosen = false;
    private String homeUrl = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        setTheme(ThemeManager.getThemeResource(this));
        super.onCreate(savedInstanceState);
        try {
            setContentView(R.layout.activity_browser);
            AppLogger.log(this, "Browser", "onCreate started");

            setTitle("Браузер");

            loadPrefs();

            tabsContainer = findViewById(R.id.tabs_container);
            urlInput = findViewById(R.id.url_input);
            btnBack = findViewById(R.id.btn_back);
            btnForward = findViewById(R.id.btn_forward);
            btnRefresh = findViewById(R.id.btn_refresh);
            btnHome = findViewById(R.id.btn_home);
            btnSearchEngine = findViewById(R.id.btn_search_engine);
            btnVoice = findViewById(R.id.btn_voice);
            btnQr = findViewById(R.id.btn_qr);
            btnTabs = findViewById(R.id.btn_tabs);
            btnSharePage = findViewById(R.id.btn_share_page);
            btnBookmark = findViewById(R.id.btn_bookmark);
            progressBar = findViewById(R.id.progress_bar);
            webviewContainer = findViewById(R.id.webview_container);
            adBlockCounter = findViewById(R.id.ad_block_counter);

            searchPanel = findViewById(R.id.search_panel);
            searchInput = findViewById(R.id.search_input);
            searchCount = findViewById(R.id.search_count);
            btnSearchClose = findViewById(R.id.btn_search_close);
            btnSearchUp = findViewById(R.id.btn_search_up);
            btnSearchDown = findViewById(R.id.btn_search_down);

            updateSearchEngineIcon();
            applyThemeColors();

            if (android.os.Build.VERSION.SDK_INT <= 28) {
                if (ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                    ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, REQUEST_WRITE_STORAGE);
                }
            }

            btnRefresh.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    AppLogger.log(BrowserActivity.this, "Browser", "Refresh clicked");
                    if (webViews.size() > currentTab) {
                        RotateAnimation rotate = new RotateAnimation(0, 360,
                            Animation.RELATIVE_TO_SELF, 0.5f, Animation.RELATIVE_TO_SELF, 0.5f);
                        rotate.setDuration(500);
                        btnRefresh.startAnimation(rotate);
                        webViews.get(currentTab).reload();
                        blockedAdsCount = 0;
                        updateAdBlockCounter();
                    }
                }
            });

            btnHome.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    AppLogger.log(BrowserActivity.this, "Browser", "Home clicked");
                    if (homeUrl.isEmpty()) { showHomeUrlDialog(); }
                    else { if (webViews.size() > currentTab) webViews.get(currentTab).loadUrl(homeUrl); }
                }
            });

            btnHome.setOnLongClickListener(new View.OnLongClickListener() {
                @Override public boolean onLongClick(View v) { showHomeUrlDialog(); return true; }
            });

            btnVoice.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) { startVoiceSearch(); }
            });

            btnQr.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) { startQrScanner(); }
            });

            btnSharePage.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    String url = getCurrentUrl();
                    if (!url.isEmpty()) shareUrl(url);
                    else Toast.makeText(BrowserActivity.this, "Нет открытой страницы", Toast.LENGTH_SHORT).show();
                }
            });

            btnBookmark.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    String url = getCurrentUrl();
                    if (!url.isEmpty()) {
                        saveBookmarkToDb(url, getCurrentTitle());
                        Toast.makeText(BrowserActivity.this, "⭐ Добавлено в закладки!", Toast.LENGTH_SHORT).show();
                    } else {
                        Toast.makeText(BrowserActivity.this, "Нет открытой страницы", Toast.LENGTH_SHORT).show();
                    }
                }
            });

            btnSearchClose.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) {
                    searchPanel.setVisibility(View.GONE);
                    if (webViews.size() > currentTab) webViews.get(currentTab).clearMatches();
                    InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
                    imm.hideSoftInputFromWindow(searchInput.getWindowToken(), 0);
                }
            });

            btnSearchUp.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) { if (webViews.size() > currentTab) webViews.get(currentTab).findNext(false); }
            });

            btnSearchDown.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) { if (webViews.size() > currentTab) webViews.get(currentTab).findNext(true); }
            });

            searchInput.setOnEditorActionListener(new TextView.OnEditorActionListener() {
                @Override
                public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
                    if (actionId == EditorInfo.IME_ACTION_SEARCH || (event != null && event.getKeyCode() == KeyEvent.KEYCODE_ENTER)) {
                        String query = searchInput.getText().toString();
                        if (!query.isEmpty() && webViews.size() > currentTab) webViews.get(currentTab).findAllAsync(query);
                        return true;
                    }
                    return false;
                }
            });

            btnSearchEngine.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) { showSearchEngineDialog(false); }
            });

            btnBack.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) { if (webViews.size() > currentTab && webViews.get(currentTab).canGoBack()) webViews.get(currentTab).goBack(); }
            });

            btnForward.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) { if (webViews.size() > currentTab && webViews.get(currentTab).canGoForward()) webViews.get(currentTab).goForward(); }
            });

            btnTabs.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) { toggleTabsVisibility(); }
            });

            tabCountText = new TextView(this);
            tabCountText.setText("1"); tabCountText.setTextSize(10);
            tabCountText.setGravity(android.view.Gravity.CENTER);
            tabCountText.setTextColor(ThemeManager.isDarkTheme(this) ? 0xFFFFFFFF : 0xFF212121);

            urlInput.setOnEditorActionListener(new TextView.OnEditorActionListener() {
                @Override
                public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
                    if (actionId == EditorInfo.IME_ACTION_GO) { navigateToUrl(); return true; }
                    return false;
                }
            });

            if (savedInstanceState != null) {
                currentTab = savedInstanceState.getInt("currentTab", 0);
                tabUrls = savedInstanceState.getStringArrayList("tabUrls");
                tabTitles = savedInstanceState.getStringArrayList("tabTitles");
                blockedAdsTotal = savedInstanceState.getInt("blockedAdsTotal", 0);
                if (tabUrls == null) tabUrls = new ArrayList<>();
                if (tabTitles == null) tabTitles = new ArrayList<>();
                boolean[] incognitoArray = savedInstanceState.getBooleanArray("tabIncognito");
                if (incognitoArray != null) for (boolean b : incognitoArray) tabIncognito.add(b);
                for (int i = 0; i < tabUrls.size(); i++) createNewWebView(false, tabIncognito.size() > i && tabIncognito.get(i));
                switchToTab(currentTab);
            } else {
                createNewWebView(false, false);
            }

            if (!searchChosen) showSearchEngineDialog(true);
            String engineName = searchEngine == 0 ? "Яндекс" : "Google";
            urlInput.setHint("Поиск в " + engineName + " или введите URL");
        } catch (Exception e) {
            AppLogger.logException(this, "Browser", e);
            Toast.makeText(this, "Ошибка браузера", Toast.LENGTH_LONG).show();
            finish();
        }
    }

    private void saveBookmarkToDb(String url, String title) {
        SharedPreferences prefs = getSharedPreferences(PREFS_BOOKMARKS, MODE_PRIVATE);
        String bookmarks = prefs.getString("list", "");
        if (!bookmarks.contains(url)) {
            String entry = title + "|" + url + "\n";
            prefs.edit().putString("list", bookmarks + entry).apply();
            AppLogger.log(this, "Browser", "Bookmark added: " + title);
        }
    }

    private void loadPrefs() {
        SharedPreferences prefs = getSharedPreferences(PREFS_SEARCH, Context.MODE_PRIVATE);
        searchEngine = prefs.getInt(KEY_SEARCH_ENGINE, 0);
        searchChosen = prefs.getBoolean(KEY_SEARCH_CHOSEN, false);
        SharedPreferences browserPrefs = getSharedPreferences(PREFS_BROWSER, Context.MODE_PRIVATE);
        homeUrl = browserPrefs.getString(KEY_HOME_URL, "");
    }

    private void showHomeUrlDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Домашняя страница");
        final EditText input = new EditText(this);
        input.setText(homeUrl.isEmpty() ? (searchEngine == 1 ? "https://www.google.com" : "https://ya.ru") : homeUrl);
        input.setHint("Введите URL"); input.setSingleLine(true);
        builder.setView(input);
        builder.setPositiveButton("Сохранить", new DialogInterface.OnClickListener() {
            @Override public void onClick(DialogInterface dialog, int which) {
                homeUrl = input.getText().toString().trim();
                if (!homeUrl.startsWith("http")) homeUrl = "https://" + homeUrl;
                getSharedPreferences(PREFS_BROWSER, Context.MODE_PRIVATE).edit().putString(KEY_HOME_URL, homeUrl).apply();
                Toast.makeText(BrowserActivity.this, "Домашняя страница сохранена", Toast.LENGTH_SHORT).show();
            }
        });
        builder.setNeutralButton("Сбросить", new DialogInterface.OnClickListener() {
            @Override public void onClick(DialogInterface dialog, int which) {
                homeUrl = "";
                getSharedPreferences(PREFS_BROWSER, Context.MODE_PRIVATE).edit().remove(KEY_HOME_URL).apply();
                Toast.makeText(BrowserActivity.this, "Домашняя страница сброшена", Toast.LENGTH_SHORT).show();
            }
        });
        builder.setNegativeButton("Отмена", null);
        builder.show();
    }

    private void updateAdBlockCounter() {
        blockedAdsCount++; blockedAdsTotal++;
        if (adBlockCounter != null) {
            adBlockCounter.setText("🛡️ Заблокировано рекламы: " + blockedAdsTotal + " (на странице: " + blockedAdsCount + ")");
            adBlockCounter.setVisibility(View.VISIBLE);
            adBlockCounter.postDelayed(new Runnable() { @Override public void run() { adBlockCounter.setVisibility(View.GONE); } }, 5000);
        }
    }

    private void startVoiceSearch() {
        AppLogger.log(this, "Browser", "Voice search started");
        Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault());
        intent.putExtra(RecognizerIntent.EXTRA_PROMPT, "Говорите...");
        try { startActivityForResult(intent, REQUEST_VOICE); }
        catch (Exception e) { AppLogger.logException(this, "Browser", e); Toast.makeText(this, "Голосовой поиск не поддерживается", Toast.LENGTH_SHORT).show(); }
    }

    private void startQrScanner() {
        AppLogger.log(this, "Browser", "QR scanner started");
        Toast.makeText(this, "Наведите камеру на QR-код", Toast.LENGTH_SHORT).show();
        try {
            Intent intent = new Intent("com.google.zxing.client.android.SCAN");
            intent.putExtra("SCAN_MODE", "QR_CODE_MODE"); intent.putExtra("SAVE_HISTORY", false);
            startActivityForResult(intent, REQUEST_QR_SCAN);
        } catch (Exception e) {
            try { Intent intent = new Intent("android.media.action.IMAGE_CAPTURE"); Toast.makeText(this, "Сфотографируйте QR-код.", Toast.LENGTH_LONG).show(); }
            catch (Exception e2) { AppLogger.logException(this, "Browser", e2); Toast.makeText(this, "Не удалось запустить сканер QR", Toast.LENGTH_SHORT).show(); }
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_VOICE && resultCode == RESULT_OK && data != null) {
            ArrayList<String> results = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
            if (results != null && !results.isEmpty()) { urlInput.setText(results.get(0)); navigateToUrl(); AppLogger.log(this, "Browser", "Voice result: " + results.get(0)); }
        }
        if (requestCode == REQUEST_QR_SCAN && resultCode == RESULT_OK && data != null) {
            String qrResult = data.getStringExtra("SCAN_RESULT");
            if (qrResult != null && !qrResult.isEmpty()) { urlInput.setText(qrResult); navigateToUrl(); AppLogger.log(this, "Browser", "QR result: " + qrResult); }
        }
    }

    private void saveSearchEnginePrefs() {
        SharedPreferences prefs = getSharedPreferences(PREFS_SEARCH, Context.MODE_PRIVATE);
        prefs.edit().putInt(KEY_SEARCH_ENGINE, searchEngine).putBoolean(KEY_SEARCH_CHOSEN, true).apply();
    }

    private void updateSearchEngineIcon() { btnSearchEngine.setColorFilter(searchEngine == 0 ? 0xFFFF0000 : 0xFF4285F4); }

    private void showSearchEngineDialog(final boolean isFirstTime) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        LayoutInflater inflater = getLayoutInflater();
        View dialogView = inflater.inflate(R.layout.dialog_search_engine, null);
        final RadioGroup radioGroup = dialogView.findViewById(R.id.search_engine_group);
        final RadioButton radioYandex = dialogView.findViewById(R.id.radio_yandex);
        final RadioButton radioGoogle = dialogView.findViewById(R.id.radio_google);
        final CheckBox checkboxRemember = dialogView.findViewById(R.id.checkbox_remember);
        if (searchEngine == 1) radioGoogle.setChecked(true); else radioYandex.setChecked(true);
        if (!isFirstTime) checkboxRemember.setVisibility(View.GONE);
        builder.setView(dialogView);
        builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
            @Override public void onClick(DialogInterface dialog, int which) {
                int checkedId = radioGroup.getCheckedRadioButtonId();
                searchEngine = (checkedId == R.id.radio_google) ? 1 : 0;
                searchChosen = true; saveSearchEnginePrefs(); updateSearchEngineIcon();
                String engineName = searchEngine == 0 ? "Яндекс" : "Google";
                urlInput.setHint("Поиск в " + engineName + " или введите URL");
                Toast.makeText(BrowserActivity.this, "Поисковик: " + engineName, Toast.LENGTH_SHORT).show();
            }
        });
        if (isFirstTime) builder.setCancelable(false); else builder.setNegativeButton("Отмена", null);
        builder.show();
    }

    private void applyThemeColors() {
        int bgColor = ThemeManager.getBackgroundColor(this);
        int textColor = ThemeManager.getTextColor(this);
        int inputBgColor = ThemeManager.getInputBgColor(this);
        int dividerColor = ThemeManager.getDividerColor(this);
        int hintColor = ThemeManager.getHintColor(this);
        findViewById(R.id.browser_layout).setBackgroundColor(bgColor);
        urlInput.setTextColor(textColor); urlInput.setHintTextColor(hintColor);
        GradientDrawable inputBg = new GradientDrawable();
        inputBg.setColor(inputBgColor); inputBg.setCornerRadius(24); inputBg.setStroke(1, dividerColor);
        urlInput.setBackground(inputBg);
        if (getSupportActionBar() != null) getSupportActionBar().setBackgroundDrawable(new ColorDrawable(ThemeManager.isDarkTheme(this) ? 0xFF424242 : 0xFF1565C0));
    }

    private void createNewWebView(boolean switchToIt, boolean incognito) {
        AppLogger.log(this, "Browser", "New WebView, incognito: " + incognito);
        WebView webView = new WebView(this);
        WebSettings settings = webView.getSettings();

        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setSupportZoom(true);
        settings.setBuiltInZoomControls(true);
        settings.setDisplayZoomControls(false);
        settings.setUseWideViewPort(true);
        settings.setLoadWithOverviewMode(true);
        settings.setAllowFileAccess(false);
        settings.setAllowContentAccess(false);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);

        if (incognito) {
            settings.setSaveFormData(false);
            settings.setSavePassword(false);
            settings.setDatabaseEnabled(false);
            // setAppCacheEnabled удалён в Android 9+
            // settings.setAppCacheEnabled(false);
            CookieManager.getInstance().removeAllCookies(null);
        } else {
            settings.setSaveFormData(true);
            settings.setDatabaseEnabled(true);
            // setAppCacheEnabled удалён в Android 9+
            // settings.setAppCacheEnabled(true);
            CookieManager.getInstance().setAcceptCookie(true);
        }

        if (isDesktopMode) {
            settings.setUserAgentString("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36");
        } else {
            settings.setUserAgentString("Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36");
        }

        if (ThemeManager.isDarkTheme(this)) {
            settings.setUserAgentString(settings.getUserAgentString() + " (Dark)");
        }

        webView.setWebViewClient(new WebViewClient() {
            @Override public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                String url = request.getUrl().toString();
                if (AdBlocker.isAd(url)) { runOnUiThread(new Runnable() { @Override public void run() { updateAdBlockCounter(); } }); return new WebResourceResponse("text/plain", "UTF-8", new ByteArrayInputStream("".getBytes())); }
                return super.shouldInterceptRequest(view, request);
            }
            @Override public void onPageStarted(WebView view, String url, android.graphics.Bitmap favicon) { super.onPageStarted(view, url, favicon); blockedAdsCount = 0; adBlockCounter.setVisibility(View.GONE); if (webViews.indexOf(view) == currentTab) urlInput.setText(url); }
            @Override public void onPageFinished(WebView view, String url) { super.onPageFinished(view, url); updateUI(); }
            @Override public void onReceivedError(WebView view, int errorCode, String description, String failingUrl) { super.onReceivedError(view, errorCode, description, failingUrl); AppLogger.log(BrowserActivity.this, "Browser", "Error [" + errorCode + "]: " + description); }
        });

        webView.setWebChromeClient(new WebChromeClient() {
            @Override public void onProgressChanged(WebView view, int newProgress) { if (webViews.indexOf(view) == currentTab) { progressBar.setProgress(newProgress); progressBar.setVisibility(newProgress < 100 ? View.VISIBLE : View.GONE); } }
            @Override public void onReceivedTitle(WebView view, String title) {
                int index = webViews.indexOf(view);
                if (index >= 0 && index < tabTitles.size()) { tabTitles.set(index, title); if (index == currentTab) { String prefix = tabIncognito.size() > index && tabIncognito.get(index) ? "🟣 " : ""; setTitle(prefix + title); } }
                updateTabViews();
            }
        });

        webView.setDownloadListener(new DownloadListener() {
            @Override public void onDownloadStart(String url, String userAgent, String contentDisposition, String mimetype, long contentLength) { AppLogger.log(BrowserActivity.this, "Browser", "Download: " + url); downloadFile(url, contentDisposition, mimetype); }
        });

        webviewContainer.addView(webView); webViews.add(webView); tabUrls.add(""); tabTitles.add("Новая вкладка"); tabIncognito.add(incognito);
        addTabView(incognito ? "🟣 Инкогнито" : "Новая вкладка", incognito);
        if (switchToIt) switchToTab(webViews.size() - 1);
    }

    private void addTabView(String title, boolean incognito) {
        View tabView = getLayoutInflater().inflate(R.layout.item_tab, null);
        TextView tabTitle = tabView.findViewById(R.id.tab_title);
        ImageButton tabClose = tabView.findViewById(R.id.tab_close);
        final int tabIndex = tabViews.size(); tabTitle.setText(title);
        tabView.setOnClickListener(new View.OnClickListener() { @Override public void onClick(View v) { switchToTab(tabIndex); } });
        tabClose.setOnClickListener(new View.OnClickListener() { @Override public void onClick(View v) { closeTab(tabIndex); } });
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.MATCH_PARENT);
        tabView.setLayoutParams(params); tabsContainer.addView(tabView); tabViews.add(tabView);
    }

    private void updateTabViews() {
        for (int i = 0; i < tabViews.size() && i < tabTitles.size(); i++) {
            View tabView = tabViews.get(i); TextView tabTitle = tabView.findViewById(R.id.tab_title);
            boolean isIncognito = tabIncognito.size() > i && tabIncognito.get(i);
            String prefix = isIncognito ? "🟣 " : ""; tabTitle.setText(prefix + tabTitles.get(i));
            GradientDrawable bg = new GradientDrawable();
            bg.setColor(i == currentTab ? (isIncognito ? 0xFF7B1FA2 : (ThemeManager.isDarkTheme(this) ? 0xFF616161 : 0xFF90CAF9)) : (isIncognito ? 0xFF4A148C : (ThemeManager.isDarkTheme(this) ? 0xFF424242 : 0xFFE0E0E0)));
            bg.setCornerRadius(8); tabView.setBackground(bg);
        }
        updateTabCountText();
    }

    private void updateTabCountText() { if (tabCountText != null) tabCountText.setText(String.valueOf(tabViews.size())); }

    private void switchToTab(int index) {
        if (index < 0 || index >= webViews.size()) return;
        for (int i = 0; i < webViews.size(); i++) webViews.get(i).setVisibility(i == index ? View.VISIBLE : View.GONE);
        currentTab = index; urlInput.setText(tabUrls.get(index));
        boolean incognito = tabIncognito.size() > index && tabIncognito.get(index);
        String prefix = incognito ? "🟣 " : ""; setTitle(prefix + tabTitles.get(index));
        updateUI(); updateTabViews();
    }

    private void closeTab(int index) {
        if (webViews.size() <= 1) { webViews.get(0).loadUrl("about:blank"); tabUrls.set(0, ""); tabTitles.set(0, "Новая вкладка"); if (tabIncognito.size() > 0) tabIncognito.set(0, false); urlInput.setText(""); updateTabViews(); return; }
        webviewContainer.removeView(webViews.get(index)); webViews.get(index).destroy(); webViews.remove(index); tabUrls.remove(index); tabTitles.remove(index);
        if (tabIncognito.size() > index) tabIncognito.remove(index);
        View tabView = tabViews.get(index); tabsContainer.removeView(tabView); tabViews.remove(index);
        if (currentTab >= webViews.size()) currentTab = webViews.size() - 1;
        switchToTab(currentTab);
    }

    private void navigateToUrl() {
        String input = urlInput.getText().toString().trim();
        if (input.isEmpty()) return;
        if (!input.startsWith("http://") && !input.startsWith("https://")) {
            if (input.contains(".") && !input.contains(" ")) input = "https://" + input;
            else { try { input = searchEngine == 1 ? "https://www.google.com/search?q=" + URLEncoder.encode(input, "UTF-8") : "https://yandex.ru/search/?text=" + URLEncoder.encode(input, "UTF-8"); } catch (Exception e) { input = searchEngine == 1 ? "https://www.google.com" : "https://yandex.ru"; } }
        }
        tabUrls.set(currentTab, input); urlInput.setText(input);
        InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        imm.hideSoftInputFromWindow(urlInput.getWindowToken(), 0);
        webViews.get(currentTab).loadUrl(input);
    }

    private void updateUI() {
        if (webViews.size() > currentTab) {
            WebView wv = webViews.get(currentTab); btnBack.setEnabled(wv.canGoBack()); btnForward.setEnabled(wv.canGoForward());
            String url = wv.getUrl();
            if (url != null && !url.isEmpty()) { tabUrls.set(currentTab, url); if (urlInput.getText().toString().isEmpty() || !urlInput.hasFocus()) urlInput.setText(url); }
        }
    }

    private void toggleTabsVisibility() {
        View tabsScroll = findViewById(R.id.tabs_scroll);
        tabsScroll.setVisibility(tabsScroll.getVisibility() == View.VISIBLE ? View.GONE : View.VISIBLE);
        if (tabsScroll.getVisibility() == View.VISIBLE) updateTabViews();
    }

    private void downloadFile(String url, String contentDisposition, String mimetype) {
        String fileName = URLUtil.guessFileName(url, contentDisposition, mimetype);
        DownloadManager.Request request = new DownloadManager.Request(Uri.parse(url));
        request.setTitle("Скачивание файла"); request.setDescription(fileName);
        request.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
        request.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, fileName);
        request.allowScanningByMediaScanner();
        DownloadManager dm = (DownloadManager) getSystemService(Context.DOWNLOAD_SERVICE);
        if (dm != null) { dm.enqueue(request); Toast.makeText(this, "Скачивание: " + fileName, Toast.LENGTH_SHORT).show(); }
    }

    private void translatePage() {
        String currentUrl = getCurrentUrl();
        if (currentUrl.isEmpty()) { Toast.makeText(this, "Нет открытой страницы", Toast.LENGTH_SHORT).show(); return; }
        Toast.makeText(this, "Перевожу страницу...", Toast.LENGTH_SHORT).show();
        String translateUrl = "https://translate.yandex.ru/translate?lang=auto-ru&url=" + Uri.encode(currentUrl);
        if (webViews.size() > currentTab) webViews.get(currentTab).loadUrl(translateUrl);
    }

    @Override public boolean onCreateOptionsMenu(Menu menu) { getMenuInflater().inflate(R.menu.browser_menu, menu); MenuItem di = menu.findItem(R.id.menu_desktop); di.setChecked(isDesktopMode); return true; }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (id == R.id.menu_new_tab) { createNewWebView(true, false); return true; }
        else if (id == R.id.menu_new_incognito_tab) { createNewWebView(true, true); Toast.makeText(this, "Инкогнито вкладка 🟣", Toast.LENGTH_SHORT).show(); return true; }
        else if (id == R.id.menu_find_on_page) { searchPanel.setVisibility(View.VISIBLE); searchInput.requestFocus(); InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE); imm.showSoftInput(searchInput, InputMethodManager.SHOW_IMPLICIT); return true; }
        else if (id == R.id.menu_translate) { translatePage(); return true; }
        else if (id == R.id.menu_bookmarks) {
            SharedPreferences prefs = getSharedPreferences(PREFS_BOOKMARKS, MODE_PRIVATE);
            String list = prefs.getString("list", "");
            if (list.isEmpty()) { Toast.makeText(this, "Нет закладок", Toast.LENGTH_SHORT).show(); }
            else {
                final String[] entries = list.split("\n");
                String[] titles = new String[entries.length];
                for (int i = 0; i < entries.length; i++) { String[] parts = entries[i].split("\\|", 2); titles[i] = parts.length > 0 ? parts[0] : entries[i]; }
                new AlertDialog.Builder(this).setTitle("Закладки").setItems(titles, new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface d, int w) { String[] parts = entries[w].split("\\|", 2); if (parts.length > 1) { urlInput.setText(parts[1]); navigateToUrl(); } }
                }).setNegativeButton("Закрыть", null).show();
            }
            return true;
        }
        else if (id == R.id.menu_history) { if (webViews.size() > currentTab) webViews.get(currentTab).loadUrl(searchEngine == 1 ? "https://www.google.com" : "https://yandex.ru"); return true; }
        else if (id == R.id.menu_desktop) { isDesktopMode = !isDesktopMode; item.setChecked(isDesktopMode); Toast.makeText(this, isDesktopMode ? "Режим ПК" : "Режим телефона", Toast.LENGTH_SHORT).show(); String url = getCurrentUrl(); if (!url.isEmpty() && webViews.size() > currentTab) webViews.get(currentTab).loadUrl(url); return true; }
        else if (id == R.id.menu_share) { String url = getCurrentUrl(); if (!url.isEmpty()) shareUrl(url); else Toast.makeText(this, "Нет открытой страницы", Toast.LENGTH_SHORT).show(); return true; }
        else if (id == R.id.menu_close_tab) { closeTab(currentTab); return true; }
        return super.onOptionsItemSelected(item);
    }

    private String getCurrentUrl() {
        if (webViews.size() > currentTab) { String url = webViews.get(currentTab).getUrl(); if (url != null && !url.isEmpty()) return url; if (tabUrls.size() > currentTab && !tabUrls.get(currentTab).isEmpty()) return tabUrls.get(currentTab); }
        return "";
    }

    private String getCurrentTitle() { if (tabTitles.size() > currentTab) return tabTitles.get(currentTab); return ""; }

    private void shareUrl(String url) {
        try { Intent si = new Intent(Intent.ACTION_SEND); si.setType("text/plain"); si.putExtra(Intent.EXTRA_TEXT, url); si.putExtra(Intent.EXTRA_SUBJECT, getCurrentTitle()); startActivity(Intent.createChooser(si, "Поделиться ссылкой")); }
        catch (Exception e) { Toast.makeText(this, "Не удалось открыть меню отправки", Toast.LENGTH_SHORT).show(); }
    }

    @Override public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_BACK) {
            if (searchPanel != null && searchPanel.getVisibility() == View.VISIBLE) { searchPanel.setVisibility(View.GONE); if (webViews.size() > currentTab) webViews.get(currentTab).clearMatches(); return true; }
            if (webViews.size() > currentTab && webViews.get(currentTab).canGoBack()) { webViews.get(currentTab).goBack(); return true; }
        }
        return super.onKeyDown(keyCode, event);
    }

    @Override protected void onSaveInstanceState(Bundle outState) { super.onSaveInstanceState(outState); outState.putInt("currentTab", currentTab); outState.putInt("blockedAdsTotal", blockedAdsTotal); outState.putStringArrayList("tabUrls", new ArrayList<>(tabUrls)); outState.putStringArrayList("tabTitles", new ArrayList<>(tabTitles)); boolean[] ia = new boolean[tabIncognito.size()]; for (int i = 0; i < tabIncognito.size(); i++) ia[i] = tabIncognito.get(i); outState.putBooleanArray("tabIncognito", ia); }

    @Override protected void onDestroy() { super.onDestroy(); for (WebView wv : webViews) wv.destroy(); webViews.clear(); }

    @Override public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQUEST_WRITE_STORAGE && grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) Toast.makeText(this, "Разрешение предоставлено", Toast.LENGTH_SHORT).show();
    }
}