package com.last04ka.messenger.ui;

import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.hardware.camera2.CameraAccessException;
import android.hardware.camera2.CameraCharacteristics;
import android.hardware.camera2.CameraManager;
import android.media.AudioAttributes;
import android.media.AudioFormat;
import android.media.AudioManager;
import android.media.AudioTrack;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import com.last04ka.messenger.utils.AppLogger;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MorseCodeActivity extends Activity {

    private static final int SAMPLE_RATE = 8000;
    private static final int FREQUENCY_HIGH = 1200;
    private static final int FREQUENCY_LOW = 600;
    private static final int VIBRATION_FREQ = 60;
    private static final int WPM_DEFAULT = 20;

    private EditText inputText, inputMorse;
    private TextView resultText, statsText, historyText, versionText;
    private Button btnLang, btnSpeedUp, btnSpeedDown, btnClear, btnCopy, btnShare, btnFlashlight, btnMode;
    private boolean isRussian = true;
    private int currentWpm = WPM_DEFAULT;
    private boolean useHighFreq = false;
    private boolean useFlashlight = false;
    private int mode = 0; // 0 - звук+вибрация, 1 - только звук, 2 - только вибрация
    private ExecutorService audioExecutor = Executors.newSingleThreadExecutor();
    private Handler mainHandler = new Handler(Looper.getMainLooper());
    private CameraManager cameraManager;
    private String cameraId;
    private boolean isFlashOn = false;
    private StringBuilder history = new StringBuilder();
    private boolean isPlaying = false;

    private static final Map<Character, String> RU_TO_MORSE = new HashMap<>();
    private static final Map<String, Character> MORSE_TO_RU = new HashMap<>();
    private static final Map<Character, String> EN_TO_MORSE = new HashMap<>();
    private static final Map<String, Character> MORSE_TO_EN = new HashMap<>();

    static {
        initRussianMorse();
        initEnglishMorse();
        initDigitsPunctuation();
    }

    private static void initRussianMorse() {
        String[][] ruMorse = {
            {"А", ".-"}, {"Б", "-..."}, {"В", ".--"}, {"Г", "--."}, {"Д", "-.."},
            {"Е", "."}, {"Ё", "."}, {"Ж", "...-"}, {"З", "--.."}, {"И", ".."},
            {"Й", ".---"}, {"К", "-.-"}, {"Л", ".-.."}, {"М", "--"}, {"Н", "-."},
            {"О", "---"}, {"П", ".--."}, {"Р", ".-."}, {"С", "..."}, {"Т", "-"},
            {"У", "..-"}, {"Ф", "..-."}, {"Х", "...."}, {"Ц", "-.-."}, {"Ч", "---."},
            {"Ш", "----"}, {"Щ", "--.-"}, {"Ъ", "--.--"}, {"Ы", "-.--"}, {"Ь", "-..-"},
            {"Э", "..-.."}, {"Ю", "..--"}, {"Я", ".-.-"}
        };
        for (String[] pair : ruMorse) {
            RU_TO_MORSE.put(pair[0].charAt(0), pair[1]);
            MORSE_TO_RU.put(pair[1], pair[0].charAt(0));
        }
    }

    private static void initEnglishMorse() {
        String[][] enMorse = {
            {"A", ".-"}, {"B", "-..."}, {"C", "-.-."}, {"D", "-.."}, {"E", "."},
            {"F", "..-."}, {"G", "--."}, {"H", "...."}, {"I", ".."}, {"J", ".---"},
            {"K", "-.-"}, {"L", ".-.."}, {"M", "--"}, {"N", "-."}, {"O", "---"},
            {"P", ".--."}, {"Q", "--.-"}, {"R", ".-."}, {"S", "..."}, {"T", "-"},
            {"U", "..-"}, {"V", "...-"}, {"W", ".--"}, {"X", "-..-"}, {"Y", "-.--"}, {"Z", "--.."}
        };
        for (String[] pair : enMorse) {
            EN_TO_MORSE.put(pair[0].charAt(0), pair[1]);
            MORSE_TO_EN.put(pair[1], pair[0].charAt(0));
        }
    }

    private static void initDigitsPunctuation() {
        String[][] digits = {
            {"0", "-----"}, {"1", ".----"}, {"2", "..---"}, {"3", "...--"}, {"4", "....-"},
            {"5", "....."}, {"6", "-...."}, {"7", "--..."}, {"8", "---.."}, {"9", "----."}
        };
        for (String[] pair : digits) {
            RU_TO_MORSE.put(pair[0].charAt(0), pair[1]);
            MORSE_TO_RU.put(pair[1], pair[0].charAt(0));
            EN_TO_MORSE.put(pair[0].charAt(0), pair[1]);
            MORSE_TO_EN.put(pair[1], pair[0].charAt(0));
        }

        String[][] punctuation = {
            {".", ".-.-.-"}, {",", "--..--"}, {"?", "..--.."}, {"!", "-.-.--"},
            {";", "-.-.-."}, {":", "---..."}, {"'", ".----."}, {"\"", ".-..-."},
            {"-", "-....-"}, {"/", "-..-."}, {"(", "-.--."}, {")", "-.--.-"},
            {"=", "-...-"}, {"+", ".-.-."}, {"@", ".--.-."}, {"&", ".-..."},
            {"_", "..--.-"}, {"$", "...-..-"}, {"#", "-....-."}, {"%", "-----.."}
        };
        for (String[] pair : punctuation) {
            RU_TO_MORSE.put(pair[0].charAt(0), pair[1]);
            MORSE_TO_RU.put(pair[1], pair[0].charAt(0));
            EN_TO_MORSE.put(pair[0].charAt(0), pair[1]);
            MORSE_TO_EN.put(pair[1], pair[0].charAt(0));
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        try {
            AppLogger.log(this, "MorseCode", "========== onCreate START ==========");
            
            initCamera();
            
            LinearLayout mainLayout = new LinearLayout(this);
            mainLayout.setOrientation(LinearLayout.VERTICAL);
            mainLayout.setPadding(20, 20, 20, 20);
            mainLayout.setBackgroundColor(0xFF1A1A2E);

            TextView title = new TextView(this);
            title.setText("📻 Азбука Морзе PRO");
            title.setTextSize(24);
            title.setTextColor(0xFFFFFFFF);
            title.setGravity(Gravity.CENTER);
            title.setPadding(0, 0, 0, 8);
            mainLayout.addView(title);

            versionText = new TextView(this);
            updateVersionText();
            mainLayout.addView(versionText);

            btnLang = new Button(this);
            btnLang.setText("🇷🇺 RU  ⇄  🇬🇧 EN");
            btnLang.setTextSize(18);
            btnLang.setTextColor(0xFF212121);
            btnLang.setBackgroundColor(0xFFFFD740);
            btnLang.setOnClickListener(v -> toggleLanguage());
            mainLayout.addView(btnLang);

            LinearLayout speedRow = new LinearLayout(this);
            speedRow.setOrientation(LinearLayout.HORIZONTAL);
            speedRow.setGravity(Gravity.CENTER);
            speedRow.setPadding(0, 8, 0, 8);
            
            btnSpeedDown = new Button(this);
            btnSpeedDown.setText("🐢 -");
            btnSpeedDown.setTextSize(16);
            btnSpeedDown.setOnClickListener(v -> changeSpeed(-5));
            speedRow.addView(btnSpeedDown);
            
            TextView speedLabel = new TextView(this);
            speedLabel.setText("  Скорость  ");
            speedLabel.setTextColor(0xFFFFFFFF);
            speedRow.addView(speedLabel);
            
            btnSpeedUp = new Button(this);
            btnSpeedUp.setText("+ 🐇");
            btnSpeedUp.setTextSize(16);
            btnSpeedUp.setOnClickListener(v -> changeSpeed(5));
            speedRow.addView(btnSpeedUp);
            
            mainLayout.addView(speedRow);

            TextView inputLabel1 = new TextView(this);
            inputLabel1.setText("📝 Входной текст:");
            inputLabel1.setTextColor(0xFF4FC3F7);
            inputLabel1.setPadding(0, 8, 0, 4);
            mainLayout.addView(inputLabel1);

            inputText = new EditText(this);
            inputText.setHint(isRussian ? "Введите текст на русском..." : "Enter text in English...");
            inputText.setTextColor(0xFFFFFFFF);
            inputText.setHintTextColor(0xFF888888);
            inputText.setBackgroundColor(0xFF333333);
            inputText.setPadding(16, 12, 16, 12);
            inputText.setMinHeight(48);
            mainLayout.addView(inputText);

            TextView inputLabel2 = new TextView(this);
            inputLabel2.setText("🎵 Код Морзе (. - / пробел):");
            inputLabel2.setTextColor(0xFF4FC3F7);
            inputLabel2.setPadding(0, 12, 0, 4);
            mainLayout.addView(inputLabel2);

            inputMorse = new EditText(this);
            inputMorse.setHint("Пример: .- -... / -.-.");
            inputMorse.setTextColor(0xFFFFFFFF);
            inputMorse.setHintTextColor(0xFF888888);
            inputMorse.setBackgroundColor(0xFF333333);
            inputMorse.setPadding(16, 12, 16, 12);
            inputMorse.setMinHeight(48);
            mainLayout.addView(inputMorse);

            LinearLayout btnRow = new LinearLayout(this);
            btnRow.setOrientation(LinearLayout.HORIZONTAL);
            btnRow.setGravity(Gravity.CENTER);
            btnRow.setPadding(0, 12, 0, 8);
            btnRow.setWeightSum(5);

            Button btnEncode = new Button(this);
            btnEncode.setText("→ Морзе");
            btnEncode.setLayoutParams(new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1));
            btnEncode.setOnClickListener(v -> encode());
            btnRow.addView(btnEncode);

            Button btnDecode = new Button(this);
            btnDecode.setText("→ Текст");
            btnDecode.setLayoutParams(new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1));
            btnDecode.setOnClickListener(v -> decode());
            btnRow.addView(btnDecode);

            Button btnPlay = new Button(this);
            btnPlay.setText("🔊");
            btnPlay.setLayoutParams(new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1));
            btnPlay.setOnClickListener(v -> playMorse());
            btnRow.addView(btnPlay);

            btnMode = new Button(this);
            updateModeButton();
            btnMode.setLayoutParams(new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1));
            btnMode.setOnClickListener(v -> toggleMode());
            btnRow.addView(btnMode);

            btnFlashlight = new Button(this);
            btnFlashlight.setText("🔦 OFF");
            btnFlashlight.setLayoutParams(new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1));
            btnFlashlight.setOnClickListener(v -> toggleFlashlightMode());
            btnRow.addView(btnFlashlight);
            
            mainLayout.addView(btnRow);

            LinearLayout btnRow2 = new LinearLayout(this);
            btnRow2.setOrientation(LinearLayout.HORIZONTAL);
            btnRow2.setGravity(Gravity.CENTER);
            btnRow2.setPadding(0, 4, 0, 8);
            btnRow2.setWeightSum(4);

            btnClear = new Button(this);
            btnClear.setText("🗑 Очистить");
            btnClear.setLayoutParams(new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1));
            btnClear.setOnClickListener(v -> clearAll());
            btnRow2.addView(btnClear);

            btnCopy = new Button(this);
            btnCopy.setText("📋 Копировать");
            btnCopy.setLayoutParams(new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1));
            btnCopy.setOnClickListener(v -> copyToClipboard());
            btnRow2.addView(btnCopy);

            btnShare = new Button(this);
            btnShare.setText("📤 Поделиться");
            btnShare.setLayoutParams(new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1));
            btnShare.setOnClickListener(v -> shareResult());
            btnRow2.addView(btnShare);
            
            Button btnFreq = new Button(this);
            btnFreq.setText(useHighFreq ? "🎵 Выс." : "🎵 Низк.");
            btnFreq.setLayoutParams(new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1));
            btnFreq.setOnClickListener(v -> toggleFrequency());
            btnRow2.addView(btnFreq);
            
            mainLayout.addView(btnRow2);

            resultText = new TextView(this);
            resultText.setTextSize(16);
            resultText.setTextColor(0xFFFFD740);
            resultText.setPadding(16, 16, 16, 16);
            resultText.setBackgroundColor(0xFF333333);
            resultText.setMinHeight(80);
            resultText.setText("Результат будет здесь");
            mainLayout.addView(resultText);

            statsText = new TextView(this);
            statsText.setTextSize(11);
            statsText.setTextColor(0xFF888888);
            statsText.setPadding(8, 8, 8, 8);
            statsText.setText("Статистика: символов 0 | слов 0");
            mainLayout.addView(statsText);

            TextView historyLabel = new TextView(this);
            historyLabel.setText("📜 История:");
            historyLabel.setTextColor(0xFF4FC3F7);
            historyLabel.setPadding(0, 12, 0, 4);
            mainLayout.addView(historyLabel);

            ScrollView scrollView = new ScrollView(this);
            historyText = new TextView(this);
            historyText.setTextSize(11);
            historyText.setTextColor(0xFFAAAAAA);
            historyText.setPadding(12, 8, 12, 8);
            historyText.setBackgroundColor(0xFF2A2A3E);
            historyText.setText("История пуста");
            scrollView.addView(historyText);
            scrollView.setLayoutParams(new LinearLayout.LayoutParams(-1, 200));
            mainLayout.addView(scrollView);

            setContentView(mainLayout);
            setTitle("📻 Азбука Морзе PRO");
            
            AppLogger.log(this, "MorseCode", "========== onCreate END ==========");
        } catch (Exception e) {
            AppLogger.logException(this, "MorseCode", e);
            Toast.makeText(this, "Ошибка: " + e.getMessage(), Toast.LENGTH_LONG).show();
            finish();
        }
    }

    private void updateVersionText() {
        if (versionText != null) {
            String modeText;
            if (mode == 0) modeText = "🔊+📳";
            else if (mode == 1) modeText = "🔊 only";
            else modeText = "📳 only";
            String flashlightStatus = useFlashlight ? (cameraId != null ? "🔦✓" : "🔦✗") : "🔦✗";
            versionText.setText("v3.5 | WPM:" + currentWpm + " | " + modeText + " | " + flashlightStatus);
            versionText.setTextSize(11);
            versionText.setTextColor(0xFFAAAAAA);
            versionText.setGravity(Gravity.CENTER);
            versionText.setPadding(0, 0, 0, 16);
        }
    }

    private void updateModeButton() {
        if (mode == 0) btnMode.setText("🔊+📳");
        else if (mode == 1) btnMode.setText("🔊 only");
        else btnMode.setText("📳 only");
    }

    private void toggleMode() {
        mode = (mode + 1) % 3;
        updateModeButton();
        updateVersionText();
        String modeName = mode == 0 ? "Звук + вибрация" : (mode == 1 ? "Только звук" : "Только вибрация");
        addToHistory("Режим: " + modeName);
        AppLogger.log(this, "MorseCode", "Mode toggled to " + mode);
        
        if (mode == 2) {
            playLowFrequencyTone(VIBRATION_FREQ, 150);
        } else if (mode == 1) {
            playTone(800, 150);
        }
    }

    private void doFeedback(int durationMs) {
        if (mode == 0) {
            playTone(800, durationMs);
            playLowFrequencyTone(VIBRATION_FREQ, durationMs);
        } else if (mode == 1) {
            playTone(800, durationMs);
        } else if (mode == 2) {
            playLowFrequencyTone(VIBRATION_FREQ, durationMs);
        }
    }

    private void playLowFrequencyTone(int frequency, int durationMs) {
        try {
            int samples = SAMPLE_RATE * durationMs / 1000;
            if (samples <= 0) samples = SAMPLE_RATE / 10;
            byte[] tone = new byte[samples];
            for (int i = 0; i < samples; i++) {
                tone[i] = (byte) (Math.sin(2 * Math.PI * frequency * i / SAMPLE_RATE) * 100);
            }
            
            int bufSize = AudioTrack.getMinBufferSize(SAMPLE_RATE, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_8BIT);
            AudioTrack track;
            if (Build.VERSION.SDK_INT >= 21) {
                track = new AudioTrack.Builder()
                        .setAudioAttributes(new AudioAttributes.Builder()
                                .setUsage(AudioAttributes.USAGE_MEDIA)
                                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                                .build())
                        .setAudioFormat(new AudioFormat.Builder()
                                .setEncoding(AudioFormat.ENCODING_PCM_8BIT)
                                .setSampleRate(SAMPLE_RATE)
                                .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                                .build())
                        .setBufferSizeInBytes(Math.max(bufSize, samples))
                        .setTransferMode(AudioTrack.MODE_STATIC)
                        .build();
            } else {
                track = new AudioTrack(AudioManager.STREAM_MUSIC, SAMPLE_RATE,
                        AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_8BIT,
                        Math.max(bufSize, samples), AudioTrack.MODE_STATIC);
            }
            track.write(tone, 0, samples);
            track.play();
            Thread.sleep(durationMs + 50);
            track.stop();
            track.release();
        } catch (Exception e) {
            AppLogger.logException(this, "MorseCode", e);
        }
    }

    private void initCamera() {
        try {
            cameraManager = (CameraManager) getSystemService(Context.CAMERA_SERVICE);
            if (cameraManager != null) {
                for (String id : cameraManager.getCameraIdList()) {
                    CameraCharacteristics chars = cameraManager.getCameraCharacteristics(id);
                    Boolean hasFlash = chars.get(CameraCharacteristics.FLASH_INFO_AVAILABLE);
                    if (hasFlash != null && hasFlash) {
                        cameraId = id;
                        AppLogger.log(this, "MorseCode", "Camera with flash found: " + cameraId);
                        break;
                    }
                }
            }
        } catch (CameraAccessException e) {
            AppLogger.logException(this, "MorseCode", e);
        }
        
        if (cameraId == null) {
            AppLogger.log(this, "MorseCode", "No flash available");
        } else {
            try {
                if (Build.VERSION.SDK_INT >= 23) {
                    cameraManager.setTorchMode(cameraId, true);
                    Thread.sleep(100);
                    cameraManager.setTorchMode(cameraId, false);
                }
            } catch (Exception e) {
                AppLogger.logException(this, "MorseCode", e);
            }
        }
    }

    private void toggleFlashlightMode() {
        if (cameraId == null) {
            Toast.makeText(this, "Фонарик не доступен", Toast.LENGTH_SHORT).show();
            return;
        }
        useFlashlight = !useFlashlight;
        btnFlashlight.setText(useFlashlight ? "🔦 ON" : "🔦 OFF");
        btnFlashlight.setBackgroundColor(useFlashlight ? 0xFF4CAF50 : 0xFF666666);
        updateVersionText();
        addToHistory("Фонарик: " + (useFlashlight ? "включен" : "выключен"));
        AppLogger.log(this, "MorseCode", "Flashlight mode toggled to " + useFlashlight);
    }

    private void setFlashlight(boolean on) {
        if (cameraId == null || !useFlashlight) return;
        try {
            if (Build.VERSION.SDK_INT >= 23) {
                cameraManager.setTorchMode(cameraId, on);
                isFlashOn = on;
            }
        } catch (CameraAccessException e) {
            AppLogger.logException(this, "MorseCode", e);
        }
    }

    private void toggleLanguage() {
        isRussian = !isRussian;
        btnLang.setText(isRussian ? "🇷🇺 RU  ⇄  🇬🇧 EN" : "🇬🇧 EN  ⇄  🇷🇺 RU");
        inputText.setHint(isRussian ? "Введите текст на русском..." : "Enter text in English...");
        resultText.setText("");
        AppLogger.log(this, "MorseCode", "Language switched to " + (isRussian ? "RU" : "EN"));
        addToHistory("Язык: " + (isRussian ? "Русский" : "English"));
        doFeedback(80);
    }

    private void changeSpeed(int delta) {
        int newWpm = currentWpm + delta;
        if (newWpm >= 10 && newWpm <= 60) {
            currentWpm = newWpm;
            updateVersionText();
            addToHistory("Скорость: " + currentWpm + " WPM");
            AppLogger.log(this, "MorseCode", "Speed changed to " + currentWpm + " WPM");
            doFeedback(60);
        } else {
            Toast.makeText(this, "Скорость от 10 до 60 WPM", Toast.LENGTH_SHORT).show();
        }
    }

    private void toggleFrequency() {
        useHighFreq = !useHighFreq;
        addToHistory("Тон: " + (useHighFreq ? "высокий" : "низкий"));
        AppLogger.log(this, "MorseCode", "Frequency toggled to " + (useHighFreq ? "HIGH" : "LOW"));
        doFeedback(80);
    }

    private void encode() {
        String text = inputText.getText().toString();
        if (text.isEmpty()) {
            Toast.makeText(this, "Введите текст", Toast.LENGTH_SHORT).show();
            return;
        }
        
        text = text.toUpperCase();
        Map<Character, String> table = isRussian ? RU_TO_MORSE : EN_TO_MORSE;
        StringBuilder morse = new StringBuilder();
        int unknownChars = 0;
        
        for (char c : text.toCharArray()) {
            if (c == ' ') {
                morse.append("/ ");
                continue;
            }
            String code = table.get(c);
            if (code != null) {
                morse.append(code).append(" ");
            } else {
                morse.append("? ");
                unknownChars++;
            }
        }
        
        String result = morse.toString().trim();
        inputMorse.setText(result);
        resultText.setText(result);
        updateStats(text, result);
        addToHistory("🔐 Закодировано: " + (text.length() > 30 ? text.substring(0, 30) + "..." : text));
        AppLogger.log(this, "MorseCode", "Encoded: " + text + " -> " + result);
        
        if (unknownChars > 0) {
            Toast.makeText(this, "⚠️ " + unknownChars + " символов не распознано", Toast.LENGTH_LONG).show();
        }
        
        doFeedback(80);
    }

    private void decode() {
        String morse = inputMorse.getText().toString().trim();
        if (morse.isEmpty()) {
            Toast.makeText(this, "Введите код Морзе", Toast.LENGTH_SHORT).show();
            return;
        }
        
        Map<String, Character> table = isRussian ? MORSE_TO_RU : MORSE_TO_EN;
        StringBuilder text = new StringBuilder();
        int unknownCodes = 0;
        
        for (String code : morse.split(" ")) {
            if (code.equals("/")) {
                text.append(" ");
                continue;
            }
            Character c = table.get(code);
            if (c != null) {
                text.append(c);
            } else {
                text.append("?");
                unknownCodes++;
            }
        }
        
        String result = text.toString();
        inputText.setText(result);
        resultText.setText(result);
        updateStats(result, morse);
        addToHistory("🔓 Раскодировано: " + (result.length() > 30 ? result.substring(0, 30) + "..." : result));
        AppLogger.log(this, "MorseCode", "Decoded: " + morse + " -> " + result);
        
        if (unknownCodes > 0) {
            Toast.makeText(this, "⚠️ " + unknownCodes + " кодов не распознано", Toast.LENGTH_LONG).show();
        }
        
        doFeedback(80);
    }

    private void updateStats(String text, String morse) {
        int charCount = text.length();
        int wordCount = text.trim().isEmpty() ? 0 : text.trim().split("\\s+").length;
        int morseCharCount = morse.replace(" ", "").replace("/", "").length();
        statsText.setText(String.format("📊 Статистика: символов %d | слов %d | символов Морзе %d", charCount, wordCount, morseCharCount));
    }

    private void playMorse() {
        String morse = inputMorse.getText().toString().trim();
        if (morse.isEmpty()) {
            Toast.makeText(this, "Нет кода для воспроизведения", Toast.LENGTH_SHORT).show();
            return;
        }
        
        if (isPlaying) {
            Toast.makeText(this, "Воспроизведение уже выполняется", Toast.LENGTH_SHORT).show();
            return;
        }
        
        int dotDuration = 1200 / currentWpm;
        int dashDuration = dotDuration * 3;
        int symbolPause = dotDuration;
        int letterPause = dotDuration * 3;
        int wordPause = dotDuration * 7;
        
        addToHistory("▶️ Воспроизведение: " + (morse.length() > 40 ? morse.substring(0, 40) + "..." : morse));
        AppLogger.log(this, "MorseCode", "Playing: " + morse + " at " + currentWpm + " WPM, mode=" + mode);
        
        isPlaying = true;
        
        audioExecutor.execute(() -> {
            try {
                int frequency = useHighFreq ? FREQUENCY_HIGH : FREQUENCY_LOW;
                
                for (char c : morse.toCharArray()) {
                    if (!isPlaying) break;
                    
                    if (c == '.') {
                        mainHandler.post(() -> setFlashlight(true));
                        if (mode == 0 || mode == 1) {
                            playTone(frequency, dotDuration);
                        }
                        if (mode == 0 || mode == 2) {
                            playLowFrequencyTone(VIBRATION_FREQ, dotDuration);
                        }
                        Thread.sleep(symbolPause);
                        mainHandler.post(() -> setFlashlight(false));
                    } else if (c == '-') {
                        mainHandler.post(() -> setFlashlight(true));
                        if (mode == 0 || mode == 1) {
                            playTone(frequency, dashDuration);
                        }
                        if (mode == 0 || mode == 2) {
                            playLowFrequencyTone(VIBRATION_FREQ, dashDuration);
                        }
                        Thread.sleep(symbolPause);
                        mainHandler.post(() -> setFlashlight(false));
                    } else if (c == ' ') {
                        Thread.sleep(letterPause);
                    } else if (c == '/') {
                        Thread.sleep(wordPause);
                    } else {
                        Thread.sleep(symbolPause);
                    }
                }
                
                mainHandler.post(() -> setFlashlight(false));
                
                mainHandler.post(() -> {
                    isPlaying = false;
                    Toast.makeText(MorseCodeActivity.this, "✅ Воспроизведение завершено", Toast.LENGTH_SHORT).show();
                });
                AppLogger.log(MorseCodeActivity.this, "MorseCode", "Playback completed");
            } catch (InterruptedException e) {
                AppLogger.logException(MorseCodeActivity.this, "MorseCode", e);
                mainHandler.post(() -> {
                    isPlaying = false;
                    setFlashlight(false);
                });
            }
        });
    }

    private void playTone(int frequency, int durationMs) {
        int samples = SAMPLE_RATE * durationMs / 1000;
        if (samples <= 0) samples = SAMPLE_RATE / 10;
        byte[] tone = new byte[samples];
        for (int i = 0; i < samples; i++) {
            tone[i] = (byte) (Math.sin(2 * Math.PI * frequency * i / SAMPLE_RATE) * 100);
        }
        
        AudioTrack track = null;
        try {
            int bufSize = AudioTrack.getMinBufferSize(SAMPLE_RATE, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_8BIT);
            if (Build.VERSION.SDK_INT >= 21) {
                track = new AudioTrack.Builder()
                        .setAudioAttributes(new AudioAttributes.Builder()
                                .setUsage(AudioAttributes.USAGE_MEDIA)
                                .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                                .build())
                        .setAudioFormat(new AudioFormat.Builder()
                                .setEncoding(AudioFormat.ENCODING_PCM_8BIT)
                                .setSampleRate(SAMPLE_RATE)
                                .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                                .build())
                        .setBufferSizeInBytes(Math.max(bufSize, samples))
                        .setTransferMode(AudioTrack.MODE_STATIC)
                        .build();
            } else {
                track = new AudioTrack(AudioManager.STREAM_MUSIC, SAMPLE_RATE,
                        AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_8BIT,
                        Math.max(bufSize, samples), AudioTrack.MODE_STATIC);
            }
            track.write(tone, 0, samples);
            track.play();
            Thread.sleep(durationMs + 20);
        } catch (Exception e) {
            AppLogger.logException(this, "MorseCode", e);
        } finally {
            if (track != null) {
                try {
                    track.stop();
                    track.release();
                } catch (Exception ex) {
                    AppLogger.logException(this, "MorseCode", ex);
                }
            }
        }
    }

    private void clearAll() {
        inputText.setText("");
        inputMorse.setText("");
        resultText.setText("Результат будет здесь");
        statsText.setText("Статистика: символов 0 | слов 0");
        addToHistory("🧹 Очищено всё");
        AppLogger.log(this, "MorseCode", "All cleared");
        Toast.makeText(this, "Очищено", Toast.LENGTH_SHORT).show();
        doFeedback(60);
    }

    private void copyToClipboard() {
        String result = resultText.getText().toString();
        if (result.isEmpty() || result.equals("Результат будет здесь")) {
            Toast.makeText(this, "Нет данных для копирования", Toast.LENGTH_SHORT).show();
            return;
        }
        
        ClipboardManager clipboard = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
        ClipData clip = ClipData.newPlainText("MorseCode", result);
        clipboard.setPrimaryClip(clip);
        addToHistory("📋 Скопировано: " + (result.length() > 30 ? result.substring(0, 30) + "..." : result));
        AppLogger.log(this, "MorseCode", "Copied to clipboard");
        Toast.makeText(this, "Скопировано", Toast.LENGTH_SHORT).show();
        doFeedback(60);
    }

    private void shareResult() {
        String result = resultText.getText().toString();
        if (result.isEmpty() || result.equals("Результат будет здесь")) {
            Toast.makeText(this, "Нет данных для отправки", Toast.LENGTH_SHORT).show();
            return;
        }
        
        Intent shareIntent = new Intent(Intent.ACTION_SEND);
        shareIntent.setType("text/plain");
        shareIntent.putExtra(Intent.EXTRA_TEXT, result);
        startActivity(Intent.createChooser(shareIntent, "Поделиться"));
        addToHistory("📤 Отправлено");
        AppLogger.log(this, "MorseCode", "Shared result");
        doFeedback(60);
    }

    private void addToHistory(String entry) {
        if (history.length() > 0) {
            history.insert(0, "• " + entry + "\n" + history.toString());
        } else {
            history = new StringBuilder("• " + entry + "\n");
        }
        
        if (history.length() > 5000) {
            history = new StringBuilder(history.substring(0, 4000));
        }
        
        if (historyText != null) {
            historyText.setText(history.toString());
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        isPlaying = false;
        if (useFlashlight && isFlashOn) {
            setFlashlight(false);
        }
        audioExecutor.shutdown();
        AppLogger.log(this, "MorseCode", "onDestroy()");
    }
}