package com.last04ka.messenger.utils;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Handler;
import android.os.Looper;
import android.widget.Toast;

public class UpdateCheckReceiver extends BroadcastReceiver {

    @Override
    public void onReceive(Context context, Intent intent) {
        // Если пришёл Intent с действием "DOWNLOAD_UPDATE" – запускаем скачивание
        if (intent != null && "DOWNLOAD_UPDATE".equals(intent.getAction())) {
            String downloadUrl = intent.getStringExtra("download_url");
            if (downloadUrl != null && !downloadUrl.isEmpty()) {
                UpdateManager manager = new UpdateManager(context);
                manager.downloadAndInstall(downloadUrl);
            }
            return;
        }

        // Иначе – обычная периодическая проверка
        new Thread(() -> {
            UpdateManager manager = new UpdateManager(context);
            manager.setListener(new UpdateManager.UpdateListener() {
                @Override
                public void onUpdateAvailable(String versionName, String message, String downloadUrl) {
                    // Показываем уведомление
                    UpdateNotificationHelper.showUpdateNotification(context, versionName, message, downloadUrl);
                }

                @Override
                public void onNoUpdate() {
                    // Ничего не делаем
                }

                @Override
                public void onError(String error) {
                    AppLogger.log(context, "UpdateCheckReceiver", "Error: " + error);
                }

                @Override
                public void onUpdateStarted() {
                    // Не используется
                }
            });
            manager.checkForUpdates(false);
        }).start();
    }
}