package com.last04ka.messenger.utils;

import android.content.Context;
import android.content.SharedPreferences;

public class GameScores {

    private static final String PREFS = "game_scores";

    public static void saveScore(Context context, String game, int score) {
        if (context == null) {
            AppLogger.log(null, "GameScores", "saveScore: context is null");
            return;
        }

        SharedPreferences prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        int current = prefs.getInt(game, 0);

        // Сохраняем рекорд, если нужно
        if (score > current) {
            prefs.edit().putInt(game, score).apply();
            AppLogger.log(context, "GameScores", "Saved " + game + " score: " + score + " (new record)");
        } else {
            AppLogger.log(context, "GameScores", "Score not saved (not higher): " + game + " = " + score + " (current " + current + ")");
        }

        // ========== ВСЕГДА вызываем unlock для достижений ==========
        AchievementManager.unlock(context, game, score);
    }

    public static int getScore(Context context, String game) {
        if (context == null) return 0;
        SharedPreferences prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        return prefs.getInt(game, 0);
    }

    public static int getTotalScore(Context context) {
        if (context == null) return 0;
        SharedPreferences prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        int total = 0;
        String[] games = {"snake", "tetris", "2048", "minesweeper", "memory", "dice", "timing", "pong", "guessnumber", "quiz", "flappybird", "doodle", "colortest", "reaction", "mathblitz", "multiplication", "typingspeed", "tictactoe", "arkanoid", "spaceshooter", "retroracer", "maze"};
        for (String game : games) {
            total += prefs.getInt(game, 0);
        }
        AppLogger.log(context, "GameScores", "Total score: " + total);
        return total;
    }

    public static int getGamesCount(Context context) {
        if (context == null) return 0;
        SharedPreferences prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        int count = 0;
        String[] games = {"snake", "tetris", "2048", "minesweeper", "memory", "dice", "timing", "pong", "guessnumber", "quiz", "flappybird", "doodle", "colortest", "reaction", "mathblitz", "multiplication", "typingspeed", "tictactoe", "arkanoid", "spaceshooter", "retroracer", "maze"};
        for (String game : games) {
            if (prefs.getInt(game, 0) > 0) count++;
        }
        AppLogger.log(context, "GameScores", "Games count: " + count);
        return count;
    }
}