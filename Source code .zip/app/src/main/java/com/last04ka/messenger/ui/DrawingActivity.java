package com.last04ka.messenger.ui;

import android.app.Activity;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.os.Bundle;
import android.os.Environment;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;
import com.last04ka.messenger.utils.AppLogger;
import java.io.File;
import java.io.FileOutputStream;
import java.util.Stack;

public class DrawingActivity extends Activity {

    private DrawView drawView;
    private SeekBar brushSize;
    private TextView sizeText;
    private int currentColor = Color.BLACK;
    private int strokeWidth = 8;
    private boolean eraserMode = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        try {
            AppLogger.log(this, "Drawing", "onCreate started");

            LinearLayout layout = new LinearLayout(this);
            layout.setOrientation(LinearLayout.VERTICAL);

            // Цвета
            LinearLayout colorRow = new LinearLayout(this);
            int[] colors = {Color.BLACK, Color.RED, Color.GREEN, Color.BLUE, Color.YELLOW, Color.MAGENTA, Color.WHITE, Color.GRAY};
            for (int c : colors) {
                ImageView iv = new ImageView(this);
                iv.setBackgroundColor(c);
                LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(60, 60);
                p.setMargins(4, 4, 4, 4);
                iv.setLayoutParams(p);
                iv.setOnClickListener(v -> { currentColor = c; eraserMode = false; });
                colorRow.addView(iv);
            }
            layout.addView(colorRow);

            // Размер кисти
            sizeText = new TextView(this);
            sizeText.setText("Толщина: " + strokeWidth); sizeText.setTextColor(0xFFFFFFFF);
            layout.addView(sizeText);
            brushSize = new SeekBar(this);
            brushSize.setMax(30); brushSize.setProgress(strokeWidth);
            brushSize.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
                @Override public void onProgressChanged(SeekBar s, int p, boolean u) { strokeWidth = p; sizeText.setText("Толщина: " + p); }
                @Override public void onStartTrackingTouch(SeekBar s) {}
                @Override public void onStopTrackingTouch(SeekBar s) {}
            });
            layout.addView(brushSize);

            // Кисть/ластик/отмена
            LinearLayout toolRow = new LinearLayout(this);
            Button btnBrush = new Button(this); btnBrush.setText("Кисть");
            btnBrush.setOnClickListener(v -> eraserMode = false); toolRow.addView(btnBrush);
            Button btnEraser = new Button(this); btnEraser.setText("Ластик");
            btnEraser.setOnClickListener(v -> eraserMode = true); toolRow.addView(btnEraser);
            Button btnUndo = new Button(this); btnUndo.setText("Отмена");
            btnUndo.setOnClickListener(v -> drawView.undo()); toolRow.addView(btnUndo);
            Button btnClear = new Button(this); btnClear.setText("Очистить");
            btnClear.setOnClickListener(v -> drawView.clear()); toolRow.addView(btnClear);
            Button btnSave = new Button(this); btnSave.setText("Сохранить");
            btnSave.setOnClickListener(v -> saveDrawing()); toolRow.addView(btnSave);
            layout.addView(toolRow);

            drawView = new DrawView(this);
            LinearLayout.LayoutParams dp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 1);
            drawView.setLayoutParams(dp);
            drawView.setBackgroundColor(Color.WHITE);
            layout.addView(drawView);

            setContentView(layout);
            setTitle("🎨 Рисовалка");
            AppLogger.log(this, "Drawing", "onCreate completed");
        } catch (Exception e) { AppLogger.logException(this, "Drawing", e); finish(); }
    }

    private void saveDrawing() {
        try {
            File dir = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES), "Last04ka");
            if (!dir.exists()) dir.mkdirs();
            File file = new File(dir, "drawing_" + System.currentTimeMillis() + ".png");
            FileOutputStream fos = new FileOutputStream(file);
            drawView.getBitmap().compress(Bitmap.CompressFormat.PNG, 100, fos);
            fos.close();
            Toast.makeText(this, "Сохранено: " + file.getName(), Toast.LENGTH_LONG).show();
            AppLogger.log(this, "Drawing", "Saved: " + file.getAbsolutePath());
        } catch (Exception e) { Toast.makeText(this, "Ошибка сохранения", Toast.LENGTH_SHORT).show(); }
    }

    class DrawView extends View {
        private Paint paint = new Paint();
        private Path currentPath = new Path();
        private Stack<PathWithColor> paths = new Stack<>();
        private Stack<PathWithColor> undone = new Stack<>();

        public DrawView(Context context) {
            super(context);
            setFocusable(true); setFocusableInTouchMode(true);
            paint.setAntiAlias(true); paint.setStyle(Paint.Style.STROKE);
            paint.setStrokeJoin(Paint.Join.ROUND); paint.setStrokeCap(Paint.Cap.ROUND);
        }

        @Override
        protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            for (PathWithColor pwc : paths) { paint.setColor(pwc.color); paint.setStrokeWidth(pwc.width); canvas.drawPath(pwc.path, paint); }
            if (eraserMode) { paint.setColor(Color.WHITE); paint.setStrokeWidth(strokeWidth * 2); }
            else { paint.setColor(currentColor); paint.setStrokeWidth(strokeWidth); }
            canvas.drawPath(currentPath, paint);
        }

        @Override
        public boolean onTouchEvent(MotionEvent event) {
            float x = event.getX(), y = event.getY();
            switch (event.getAction()) {
                case MotionEvent.ACTION_DOWN:
                    currentPath = new Path();
                    currentPath.moveTo(x, y);
                    invalidate();
                    break;
                case MotionEvent.ACTION_MOVE:
                    currentPath.lineTo(x, y);
                    invalidate();
                    break;
                case MotionEvent.ACTION_UP:
                    currentPath.lineTo(x, y);
                    int color = eraserMode ? Color.WHITE : currentColor;
                    int width = eraserMode ? strokeWidth * 2 : strokeWidth;
                    paths.push(new PathWithColor(currentPath, color, width));
                    currentPath = new Path();
                    undone.clear();
                    invalidate();
                    break;
            }
            return true;
        }

        public void undo() {
            if (!paths.isEmpty()) { undone.push(paths.pop()); invalidate(); }
        }

        public void clear() {
            paths.clear(); undone.clear(); invalidate();
        }

        public Bitmap getBitmap() {
            Bitmap bmp = Bitmap.createBitmap(getWidth(), getHeight(), Bitmap.Config.ARGB_8888);
            Canvas canvas = new Canvas(bmp);
            canvas.drawColor(Color.WHITE);
            for (PathWithColor pwc : paths) { paint.setColor(pwc.color); paint.setStrokeWidth(pwc.width); canvas.drawPath(pwc.path, paint); }
            return bmp;
        }

        class PathWithColor { Path path; int color, width;
            PathWithColor(Path p, int c, int w) { path = p; color = c; width = w; }
        }
    }
}