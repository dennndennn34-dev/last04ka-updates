package com.last04ka.messenger.ui;

import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import com.last04ka.messenger.utils.AppLogger;
import java.util.Random;

public class RockPaperScissorsActivity extends Activity {

    private TextView playerChoiceText, botChoiceText, resultText, scoreText;
    private Button btnRock, btnPaper, btnScissors;
    private int playerScore = 0, botScore = 0, draws = 0;
    private Random rand = new Random();
    private Handler handler = new Handler();
    private String[] choices = {"✊ Камень", "✋ Бумага", "✌ Ножницы"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        try {
            AppLogger.log(this, "RPS", "onCreate started");
            LinearLayout layout = new LinearLayout(this);
            layout.setOrientation(LinearLayout.VERTICAL);
            layout.setPadding(16, 16, 16, 16);
            layout.setBackgroundColor(0xFF1A1A2E);

            TextView title = new TextView(this);
            title.setText("✊✋✌ Камень-Ножницы-Бумага"); title.setTextSize(18);
            title.setTextColor(0xFFFFFFFF); title.setGravity(Gravity.CENTER);
            layout.addView(title);

            resultText = new TextView(this);
            resultText.setText("Выберите:"); resultText.setTextSize(16);
            resultText.setTextColor(0xFFFFD740); resultText.setGravity(Gravity.CENTER);
            resultText.setPadding(0, 12, 0, 12);
            layout.addView(resultText);

            playerChoiceText = new TextView(this);
            playerChoiceText.setText("Вы: -"); playerChoiceText.setTextSize(14);
            playerChoiceText.setTextColor(0xFF4FC3F7); playerChoiceText.setGravity(Gravity.CENTER);
            layout.addView(playerChoiceText);

            botChoiceText = new TextView(this);
            botChoiceText.setText("Бот: -"); botChoiceText.setTextSize(14);
            botChoiceText.setTextColor(0xFFFF5252); botChoiceText.setGravity(Gravity.CENTER);
            layout.addView(botChoiceText);

            scoreText = new TextView(this);
            scoreText.setText("Вы: 0 | Бот: 0 | Ничьи: 0"); scoreText.setTextSize(13);
            scoreText.setTextColor(0xFFFFFFFF); scoreText.setGravity(Gravity.CENTER);
            scoreText.setPadding(0, 8, 0, 12);
            layout.addView(scoreText);

            LinearLayout btnRow = new LinearLayout(this);
            btnRow.setGravity(Gravity.CENTER);
            btnRock = new Button(this); btnRock.setText("✊"); btnRock.setTextSize(40);
            btnRock.setOnClickListener(v -> play(0)); btnRow.addView(btnRock);
            btnPaper = new Button(this); btnPaper.setText("✋"); btnPaper.setTextSize(40);
            btnPaper.setOnClickListener(v -> play(1)); btnRow.addView(btnPaper);
            btnScissors = new Button(this); btnScissors.setText("✌"); btnScissors.setTextSize(40);
            btnScissors.setOnClickListener(v -> play(2)); btnRow.addView(btnScissors);
            layout.addView(btnRow);

            Button btnReset = new Button(this); btnReset.setText("Сбросить счёт");
            btnReset.setOnClickListener(v -> { playerScore = botScore = draws = 0; updateScore(); });
            layout.addView(btnReset);

            setContentView(layout); setTitle("✊✋✌ Камень-Ножницы-Бумага");
            AppLogger.log(this, "RPS", "onCreate completed");
        } catch (Exception e) { AppLogger.logException(this, "RPS", e); finish(); }
    }

    private void play(int playerChoice) {
        int botChoice = rand.nextInt(3);
        playerChoiceText.setText("Вы: " + choices[playerChoice]);
        botChoiceText.setText("Бот: " + choices[botChoice]);

        if (playerChoice == botChoice) { resultText.setText("🤝 Ничья!"); draws++; }
        else if ((playerChoice == 0 && botChoice == 2) || (playerChoice == 1 && botChoice == 0) || (playerChoice == 2 && botChoice == 1)) {
            resultText.setText("🏆 Вы выиграли!"); playerScore++;
        } else { resultText.setText("😞 Бот выиграл"); botScore++; }
        updateScore();
        AppLogger.log(this, "RPS", "Player=" + playerChoice + " Bot=" + botChoice + " Score=" + playerScore + "-" + botScore);
    }

    private void updateScore() {
        scoreText.setText("Вы: " + playerScore + " | Бот: " + botScore + " | Ничьи: " + draws);
    }
}