package com.last04ka.messenger.ui;

import android.app.Activity;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.os.Bundle;
import android.os.Handler;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import com.last04ka.messenger.utils.AppLogger;
import com.last04ka.messenger.utils.GameScores;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.Stack;

public class MazeActivity extends Activity {

    private MazeView mazeView;
    private TextView timerText, bestText, levelText;
    private Button btnUp, btnDown, btnLeft, btnRight, btnNew;
    private Handler handler = new Handler();
    private long startTime;
    private int bestTime = Integer.MAX_VALUE;
    private int mazeLevel = 1;
    private boolean finished = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        try {
            AppLogger.log(this, "Maze", "onCreate started");

            LinearLayout layout = new LinearLayout(this);
            layout.setOrientation(LinearLayout.VERTICAL);
            layout.setBackgroundColor(0xFF1A1A2E);

            LinearLayout stats = new LinearLayout(this);
            stats.setOrientation(LinearLayout.HORIZONTAL);
            stats.setGravity(Gravity.CENTER);
            stats.setPadding(8, 4, 8, 4);

            timerText = new TextView(this);
            timerText.setText("Время: 0.0с");
            timerText.setTextSize(13); timerText.setTextColor(0xFFFFD740);
            stats.addView(timerText);

            bestText = new TextView(this);
            bestText.setText("  Рекорд: --");
            bestText.setTextSize(12); bestText.setTextColor(0xFF4FC3F7);
            stats.addView(bestText);

            levelText = new TextView(this);
            levelText.setText("  Ур.1");
            levelText.setTextSize(12); levelText.setTextColor(0xFFFF9800);
            stats.addView(levelText);

            layout.addView(stats);

            mazeView = new MazeView(this);
            LinearLayout.LayoutParams mp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 1);
            mazeView.setLayoutParams(mp);
            layout.addView(mazeView);

            LinearLayout dpad = new LinearLayout(this);
            dpad.setOrientation(LinearLayout.VERTICAL);
            dpad.setGravity(Gravity.CENTER);
            dpad.setPadding(0, 8, 0, 8);

            btnUp = new Button(this); btnUp.setText("▲"); btnUp.setTextSize(20);
            btnUp.setOnClickListener(v -> { mazeView.movePlayer(0, -1); updateTimer(); });
            dpad.addView(btnUp);

            LinearLayout midRow = new LinearLayout(this);
            midRow.setGravity(Gravity.CENTER);
            btnLeft = new Button(this); btnLeft.setText("◄"); btnLeft.setTextSize(20);
            btnLeft.setOnClickListener(v -> { mazeView.movePlayer(-1, 0); updateTimer(); });
            midRow.addView(btnLeft);

            btnNew = new Button(this); btnNew.setText("↻"); btnNew.setTextSize(16);
            btnNew.setOnClickListener(v -> resetMaze());
            midRow.addView(btnNew);

            btnRight = new Button(this); btnRight.setText("►"); btnRight.setTextSize(20);
            btnRight.setOnClickListener(v -> { mazeView.movePlayer(1, 0); updateTimer(); });
            midRow.addView(btnRight);

            dpad.addView(midRow);

            btnDown = new Button(this); btnDown.setText("▼"); btnDown.setTextSize(20);
            btnDown.setOnClickListener(v -> { mazeView.movePlayer(0, 1); updateTimer(); });
            dpad.addView(btnDown);

            layout.addView(dpad);

            setContentView(layout);
            setTitle("🌀 Лабиринт");
            bestTime = GameScores.getScore(this, "maze");
            bestText.setText("  Рекорд: " + (bestTime < Integer.MAX_VALUE ? String.format("%.1fс", bestTime/1000.0) : "--"));
            AppLogger.log(this, "Maze", "onCreate completed, best=" + bestTime);
        } catch (Exception e) { AppLogger.logException(this, "Maze", e); finish(); }
    }

    private void resetMaze() {
        mazeLevel = 1;
        mazeView.generate(mazeLevel);
        startTime = System.currentTimeMillis();
        finished = false;
        levelText.setText("  Ур.1");
        updateTimer();
        mazeView.invalidate();
        AppLogger.log(this, "Maze", "Maze reset to level 1");
    }

    private void updateTimer() {
        if (finished) return;
        long elapsed = System.currentTimeMillis() - startTime;
        timerText.setText("Время: " + String.format("%.1fс", elapsed / 1000.0));
        handler.postDelayed(() -> { if (!finished) updateTimer(); }, 200);
    }

    private void checkWin() {
        finished = true;
        long elapsed = System.currentTimeMillis() - startTime;
        timerText.setText("Время: " + String.format("%.1fс", elapsed / 1000.0));
        if (elapsed < bestTime) {
            bestTime = (int)elapsed;
            GameScores.saveScore(this, "maze", bestTime);
            bestText.setText("  Рекорд: " + String.format("%.1fс", bestTime/1000.0));
            Toast.makeText(this, "🏆 Новый рекорд!", Toast.LENGTH_SHORT).show();
        }
        AppLogger.log(this, "Maze", "Maze level " + mazeLevel + " solved in " + elapsed + "ms");
        Toast.makeText(this, "🎉 Уровень " + mazeLevel + " пройден!", Toast.LENGTH_SHORT).show();

        // Следующий уровень через 1.5 сек
        handler.postDelayed(() -> {
            mazeLevel++;
            levelText.setText("  Ур." + mazeLevel);
            mazeView.generate(mazeLevel);
            startTime = System.currentTimeMillis();
            finished = false;
            updateTimer();
            AppLogger.log(this, "Maze", "Next level " + mazeLevel + " started");
        }, 1500);
    }

    class MazeView extends View {
        private Paint paint = new Paint();
        private int[][] maze;
        private int size = 15;
        private float cellSize;
        private int px = 1, py = 1;
        private int exitX, exitY;
        private Random rand = new Random();

        public MazeView(Context ctx) {
            super(ctx);
            setFocusable(true);
            generate(1);
        }

        public void generate(int level) {
            size = 14 + level;
            if (size > 25) size = 25;
            maze = new int[size][size];

            for (int i = 0; i < size; i++) for (int j = 0; j < size; j++) maze[i][j] = 0;

            Stack<int[]> stack = new Stack<>();
            int sx = 1, sy = 1;
            maze[sy][sx] = 1;
            stack.push(new int[]{sx, sy});

            while (!stack.isEmpty()) {
                int[] cur = stack.peek();
                int cx = cur[0], cy = cur[1];
                List<int[]> neighbors = new ArrayList<>();
                int[][] dirs = {{2,0},{-2,0},{0,2},{0,-2}};
                for (int[] d : dirs) {
                    int nx = cx + d[0], ny = cy + d[1];
                    if (nx > 0 && nx < size-1 && ny > 0 && ny < size-1 && maze[ny][nx] == 0) {
                        neighbors.add(new int[]{nx, ny});
                    }
                }
                if (!neighbors.isEmpty()) {
                    int[] next = neighbors.get(rand.nextInt(neighbors.size()));
                    int nx = next[0], ny = next[1];
                    maze[ny][nx] = 1;
                    maze[cy + (ny-cy)/2][cx + (nx-cx)/2] = 1;
                    stack.push(next);
                } else {
                    stack.pop();
                }
            }

            // Гарантируем путь до выхода (контрольная точка)
            exitX = size - 2;
            exitY = size - 2;
            maze[exitY][exitX] = 1;
            // Делаем проход к выходу
            if (maze[exitY-1][exitX] == 0 && maze[exitY][exitX-1] == 0) {
                maze[exitY-1][exitX] = 1;
            }

            px = 1; py = 1;
            startTime = System.currentTimeMillis();
            finished = false;
        }

        public void movePlayer(int dx, int dy) {
            if (finished) return;
            int nx = px + dx, ny = py + dy;

            if (nx >= 0 && nx < size && ny >= 0 && ny < size && maze[ny][nx] != 0) {
                px = nx; py = ny;
                if (px == exitX && py == exitY) {
                    checkWin();
                }
            }
            invalidate();
        }

        @Override
        protected void onDraw(Canvas c) {
            super.onDraw(c);
            int w = getWidth(), h = getHeight();
            cellSize = Math.min(w, h) / (float)size;

            float ox = (w - cellSize * size) / 2f;
            float oy = (h - cellSize * size) / 2f;

            for (int y = 0; y < size; y++) {
                for (int x = 0; x < size; x++) {
                    float lx = ox + x * cellSize, ly = oy + y * cellSize;
                    if (maze[y][x] == 0) {
                        paint.setColor(0xFF2E3B4E);
                        c.drawRect(lx, ly, lx + cellSize, ly + cellSize, paint);
                    } else {
                        paint.setColor(0xFF4A5D7E);
                        c.drawRect(lx+1, ly+1, lx+cellSize-1, ly+cellSize-1, paint);
                    }
                }
            }

            // Старт (игрок)
            float slx = ox + 1 * cellSize, sly = oy + 1 * cellSize;
            paint.setColor(0xFF1B5E20);
            c.drawRect(slx, sly, slx+cellSize, sly+cellSize, paint);
            paint.setColor(Color.WHITE);
            paint.setTextSize(cellSize*0.4f);
            paint.setTextAlign(Paint.Align.CENTER);
            c.drawText("СТАРТ", slx+cellSize/2, sly+cellSize*0.65f, paint);

            // Финиш
            float ex = ox + exitX * cellSize, ey = oy + exitY * cellSize;
            paint.setColor(0xFF4CAF50);
            c.drawRect(ex+1, ey+1, ex+cellSize-1, ey+cellSize-1, paint);
            paint.setColor(0xFF1B5E20);
            c.drawRect(ex+4, ey+4, ex+cellSize-4, ey+cellSize-4, paint);
            paint.setColor(Color.WHITE);
            c.drawText("🏁", ex+cellSize/2, ey+cellSize*0.7f, paint);

            // Игрок
            float plx = ox + px * cellSize, ply = oy + py * cellSize;
            paint.setColor(0xFFFFEB3B);
            c.drawCircle(plx+cellSize/2, ply+cellSize/2, cellSize*0.35f, paint);
            paint.setColor(0xFFFF9800);
            c.drawCircle(plx+cellSize/2+cellSize*0.1f, ply+cellSize/2-cellSize*0.1f, cellSize*0.12f, paint);

            paint.setTextAlign(Paint.Align.LEFT);
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        handler.removeCallbacksAndMessages(null);
    }
}