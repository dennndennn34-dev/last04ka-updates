package com.last04ka.messenger.ui;

import android.app.Activity;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.os.Bundle;
import android.os.Handler;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import com.last04ka.messenger.utils.AppLogger;
import java.util.Random;

public class DiceRollerActivity extends Activity {

    private DiceView diceView;
    private TextView resultText;
    private int diceValue = 1;
    private boolean rolling = false;
    private Handler handler = new Handler();
    private Random random = new Random();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        try {
            AppLogger.log(this, "DiceRoller", "onCreate started");

            LinearLayout layout = new LinearLayout(this);
            layout.setOrientation(LinearLayout.VERTICAL);
            layout.setBackgroundColor(0xFF1A1A2E);
            layout.setGravity(Gravity.CENTER);

            resultText = new TextView(this);
            resultText.setText("🎲 Бросьте кубик");
            resultText.setTextSize(18);
            resultText.setTextColor(0xFFFFFFFF);
            resultText.setGravity(Gravity.CENTER);
            resultText.setPadding(0, 24, 0, 16);
            layout.addView(resultText);

            diceView = new DiceView(this);
            LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(300, 300);
            diceView.setLayoutParams(params);
            layout.addView(diceView);

            Button btnRoll = new Button(this);
            btnRoll.setText("Бросить кубик 🎲");
            btnRoll.setTextSize(18);
            btnRoll.setOnClickListener(v -> rollDice());
            layout.addView(btnRoll);

            setContentView(layout);
            setTitle("🎲 Кубик");
            AppLogger.log(this, "DiceRoller", "onCreate completed");
        } catch (Exception e) { AppLogger.logException(this, "DiceRoller", e); finish(); }
    }

    private void rollDice() {
        if (rolling) return;
        rolling = true;

        final int[] animSteps = new int[]{10};
        handler.post(new Runnable() {
            @Override
            public void run() {
                diceValue = random.nextInt(6) + 1;
                diceView.invalidate();
                animSteps[0]--;
                if (animSteps[0] > 0) {
                    handler.postDelayed(this, 80);
                } else {
                    rolling = false;
                    resultText.setText("Выпало: " + diceValue);
                    AppLogger.log(DiceRollerActivity.this, "DiceRoller", "Rolled: " + diceValue);
                }
            }
        });
    }

    class DiceView extends View {
        private Paint paint = new Paint();

        public DiceView(Context context) {
            super(context);
            setFocusable(true);
        }

        @Override
        protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            int w = getWidth(), h = getHeight();
            int size = Math.min(w, h);
            float cx = w / 2f, cy = h / 2f;
            float r = size / 2f - 10;

            // Кубик
            paint.setColor(0xFFFFFFFF);
            paint.setStyle(Paint.Style.FILL);
            canvas.drawRoundRect(cx - r, cy - r, cx + r, cy + r, 20, 20, paint);

            paint.setColor(0xFF333333);
            paint.setStyle(Paint.Style.STROKE);
            paint.setStrokeWidth(6);
            canvas.drawRoundRect(cx - r, cy - r, cx + r, cy + r, 20, 20, paint);

            // Точки
            paint.setColor(0xFF212121);
            paint.setStyle(Paint.Style.FILL);
            float dotR = r * 0.12f;
            float d = r * 0.35f; // смещение от центра

            switch (diceValue) {
                case 1: drawDot(canvas, cx, cy, dotR); break;
                case 2: drawDot(canvas, cx - d, cy - d, dotR); drawDot(canvas, cx + d, cy + d, dotR); break;
                case 3: drawDot(canvas, cx, cy, dotR); drawDot(canvas, cx - d, cy - d, dotR); drawDot(canvas, cx + d, cy + d, dotR); break;
                case 4: drawDot(canvas, cx - d, cy - d, dotR); drawDot(canvas, cx + d, cy - d, dotR);
                        drawDot(canvas, cx - d, cy + d, dotR); drawDot(canvas, cx + d, cy + d, dotR); break;
                case 5: drawDot(canvas, cx, cy, dotR); drawDot(canvas, cx - d, cy - d, dotR); drawDot(canvas, cx + d, cy - d, dotR);
                        drawDot(canvas, cx - d, cy + d, dotR); drawDot(canvas, cx + d, cy + d, dotR); break;
                case 6: drawDot(canvas, cx - d, cy - d, dotR); drawDot(canvas, cx + d, cy - d, dotR);
                        drawDot(canvas, cx - d, cy, dotR); drawDot(canvas, cx + d, cy, dotR);
                        drawDot(canvas, cx - d, cy + d, dotR); drawDot(canvas, cx + d, cy + d, dotR); break;
            }
        }

        private void drawDot(Canvas canvas, float x, float y, float radius) {
            canvas.drawCircle(x, y, radius, paint);
        }
    }
}