package com.last04ka.messenger.ui;

import android.app.Activity;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import java.util.Random;

public class TypingSpeedActivity extends Activity {

    private TextView targetText, wpmText, accText;
    private EditText inputText;
    private Button btnStart, btnReset;
    private long startTime;
    private boolean started = false;
    private int correctChars = 0, totalChars = 0;
    private String target;

    private String[] sentences = {
        "Съешь ещё этих мягких французских булок да выпей чаю",
        "На дворе трава на траве дрова не руби дрова на траве двора",
        "Карл у Клары украл кораллы а Клара у Карла украла кларнет",
        "Ехал грека через реку видит грека в реке рак",
        "От топота копыт пыль по полю летит",
        "Шла Саша по шоссе и сосала сушку",
        "Кукушка кукушонку купила капюшон",
        "Три дроворуба на трёх дворах дрова рубят",
        "Бык тупогуб тупогубенький бычок у быка бела губа была тупа",
        "Корабли лавировали лавировали да не вылавировали",
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL); layout.setPadding(24,24,24,24); layout.setBackgroundColor(0xFF252525);

        wpmText = new TextView(this); wpmText.setText("WPM: 0"); wpmText.setTextSize(20); wpmText.setTextColor(0xFF00E676);
        wpmText.setGravity(android.view.Gravity.CENTER); layout.addView(wpmText);

        accText = new TextView(this); accText.setText("Точность: 100%"); accText.setTextSize(16); accText.setTextColor(0xFFBDBDBD);
        accText.setGravity(android.view.Gravity.CENTER); accText.setPadding(0,0,0,16); layout.addView(accText);

        targetText = new TextView(this); targetText.setTextSize(18); targetText.setTextColor(0xFFFFFFFF);
        targetText.setPadding(12,12,12,12); targetText.setBackgroundColor(0xFF333333); layout.addView(targetText);

        inputText = new EditText(this); inputText.setHint("Начните печатать здесь...");
        inputText.setTextColor(0xFFFFFFFF); inputText.setHintTextColor(0xFF757575); inputText.setTextSize(16);
        inputText.setPadding(12,12,12,12); inputText.setMinHeight(100); inputText.setEnabled(false);
        inputText.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int st, int c, int a) {}
            @Override public void onTextChanged(CharSequence s, int st, int b, int c) { if(started) checkTyping(); }
            @Override public void afterTextChanged(Editable s) {}
        });
        layout.addView(inputText);

        btnStart = new Button(this); btnStart.setText("Начать");
        btnStart.setOnClickListener(v->{ startTyping(); }); layout.addView(btnStart);

        btnReset = new Button(this); btnReset.setText("Сбросить");
        btnReset.setOnClickListener(v->{ resetTyping(); }); layout.addView(btnReset);

        setContentView(layout); setTitle("⌨️ Скорость печати");
        pickSentence();
    }

    private void pickSentence() { target = sentences[new Random().nextInt(sentences.length)]; targetText.setText(target); }

    private void startTyping() { inputText.setText(""); inputText.setEnabled(true); startTime=System.currentTimeMillis(); started=true;
        correctChars=0; totalChars=0; btnStart.setEnabled(false); inputText.requestFocus(); }

    private void checkTyping() {
        String typed = inputText.getText().toString();
        correctChars=0; totalChars=Math.min(typed.length(), target.length());
        for(int i=0;i<totalChars;i++) if(i<target.length()&&typed.charAt(i)==target.charAt(i)) correctChars++;
        long elapsed = Math.max(1, System.currentTimeMillis()-startTime);
        double minutes = elapsed/60000.0;
        int wpm = (int)((correctChars/5.0)/minutes);
        int acc = totalChars>0?(int)(correctChars*100.0/totalChars):100;
        wpmText.setText("WPM: "+wpm+" | Время: "+(elapsed/1000)+"с");
        accText.setText("Точность: "+acc+"%");
        if(typed.length()>=target.length()){ started=false; inputText.setEnabled(false); btnStart.setEnabled(true);
            Toast.makeText(this,"Готово! WPM: "+wpm+" Точность: "+acc+"%",Toast.LENGTH_LONG).show(); }
    }

    private void resetTyping() { inputText.setText(""); inputText.setEnabled(false); started=false; btnStart.setEnabled(true);
        wpmText.setText("WPM: 0"); accText.setText("Точность: 100%"); pickSentence(); }
}