package com.last04ka.messenger.ui;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.drawable.GradientDrawable;
import android.media.MediaPlayer;
import android.media.MediaRecorder;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Vibrator;
import android.speech.tts.TextToSpeech;
import android.support.annotation.NonNull;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.last04ka.messenger.R;
import com.last04ka.messenger.adapters.LanguageAdapter;
import com.last04ka.messenger.adapters.LetterAdapter;
import com.last04ka.messenger.utils.AppLogger;
import com.last04ka.messenger.utils.LanguageData;
import com.last04ka.messenger.utils.LanguageStats;
import com.last04ka.messenger.utils.ThemeManager;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Random;
import java.util.Timer;
import java.util.TimerTask;

public class LanguageLearningActivity extends AppCompatActivity {

    private static final String TAG = "LangLearning";
    private static final String PREFS = "lang_learning_prefs";
    private static final int REQUEST_RECORD_AUDIO = 300;

    // ==================== UI КОМПОНЕНТЫ ====================
    private RecyclerView rvLanguages;
    private RecyclerView rvLetters;
    private TextView tvTitle;
    private TextView tvProgress;
    private TextView tvStats;
    private TextView tvLetterDisplay;
    private TextView tvPronunciation;
    private EditText etSearch;
    private ImageButton btnSpeak;
    private ImageButton btnPlay;
    private ImageButton btnRecord;
    private ImageButton btnTest;
    private ImageButton btnFlashcards;
    private ImageButton btnTranslate;
    private Button btnLanguageSelect;
    private Button btnModeSwitch;
    private Button btnResetProgress;
    private ProgressBar progressBar;
    private FrameLayout mainContainer;

    // ==================== ДАННЫЕ ====================
    private LanguageAdapter languageAdapter;
    private LetterAdapter letterAdapter;
    private List<LanguageData.Language> languages;
    private List<LanguageData.Letter> currentLetters;
    private LanguageData.Language currentLanguage;
    private int currentLanguageIndex = 0;
    private int currentLetterIndex = 0;

    // ==================== TTS ====================
    private TextToSpeech tts;
    private boolean ttsReady = false;

    // ==================== АУДИО ЗАПИСЬ ====================
    private MediaRecorder mediaRecorder;
    private MediaPlayer mediaPlayer;
    private String recordingFilePath;
    private boolean isRecording = false;
    private boolean isPlaying = false;

    // ==================== СОСТОЯНИЕ ====================
    private int mode = 0; // 0 = alphabet, 1 = quiz, 2 = flashcards
    private int quizScore = 0;
    private int quizTotal = 0;
    private List<Integer> quizQuestions = new ArrayList<>();
    private int quizCurrentIndex = 0;
    private int quizTimerSeconds = 10;
    private Timer quizTimer;
    private AlertDialog quizDialog;
    private List<String> favoriteLetters = new ArrayList<>();
    private boolean isDarkTheme = false;
    private Handler handler = new Handler(Looper.getMainLooper());
    private Vibrator vibrator;
    private Random random = new Random();

    // ==================== ФЛЕШКАРТЫ ====================
    private int flashcardIndex = 0;
    private List<Integer> flashcardIndices = new ArrayList<>();
    private boolean flashcardActive = false;

    // ==================== ЛОГИРОВАНИЕ ====================
    private long startTime;
    private int actionCount = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        setTheme(ThemeManager.getThemeResource(this));
        super.onCreate(savedInstanceState);
        startTime = System.currentTimeMillis();

        AppLogger.log(this, TAG, "═══════════════════════════════════════════════════════════");
        AppLogger.log(this, TAG, "🌍 LanguageLearningActivity onCreate START");
        AppLogger.log(this, TAG, "📱 Device: " + Build.MODEL + " (" + Build.VERSION.RELEASE + ")");
        AppLogger.log(this, TAG, "⏱️ Start time: " + new SimpleDateFormat("HH:mm:ss.SSS", Locale.US).format(new Date()));
        AppLogger.log(this, TAG, "═══════════════════════════════════════════════════════════");

        try {
            isDarkTheme = ThemeManager.isDarkTheme(this);
            vibrator = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);

            AppLogger.log(this, TAG, "📌 Setting content view...");
            setContentView(R.layout.activity_language_learning);
            AppLogger.log(this, TAG, "✅ Content view set");

            AppLogger.log(this, TAG, "📌 Initializing views...");
            initViews();
            AppLogger.log(this, TAG, "✅ Views initialized");

            AppLogger.log(this, TAG, "📌 Initializing data...");
            initData();
            AppLogger.log(this, TAG, "✅ Data initialized");

            AppLogger.log(this, TAG, "📌 Initializing TTS...");
            initTTS();
            AppLogger.log(this, TAG, "✅ TTS initialized");

            AppLogger.log(this, TAG, "📌 Setting up listeners...");
            setupListeners();
            AppLogger.log(this, TAG, "✅ Listeners setup");

            AppLogger.log(this, TAG, "📌 Loading preferences...");
            loadPreferences();
            AppLogger.log(this, TAG, "✅ Preferences loaded");

            AppLogger.log(this, TAG, "📌 Updating UI...");
            updateUI();
            AppLogger.log(this, TAG, "✅ UI updated");

            AppLogger.log(this, TAG, "📌 Applying theme...");
            applyThemeColors();
            AppLogger.log(this, TAG, "✅ Theme applied");

            long initTime = System.currentTimeMillis() - startTime;
            AppLogger.log(this, TAG, "⏱️ Init time: " + initTime + "ms");

            AppLogger.log(this, TAG, "═══════════════════════════════════════════════════════════");
            AppLogger.log(this, TAG, "🌍 LanguageLearningActivity onCreate SUCCESS");
            AppLogger.log(this, TAG, "   Languages: " + languages.size());
            AppLogger.log(this, TAG, "   Current language: " + currentLanguage.getName());
            AppLogger.log(this, TAG, "   Letters: " + currentLetters.size());
            AppLogger.log(this, TAG, "   Mode: " + getModeName());
            AppLogger.log(this, TAG, "═══════════════════════════════════════════════════════════");

        } catch (Exception e) {
            AppLogger.logException(this, TAG, "❌ FATAL: onCreate error", e);
            Toast.makeText(this, "Ошибка: " + e.getMessage(), Toast.LENGTH_LONG).show();
            finish();
        }
    }

    private String getModeName() {
        switch (mode) {
            case 0: return "Алфавит";
            case 1: return "Викторина";
            case 2: return "Карточки";
            default: return "Неизвестно";
        }
    }

    private void initViews() {
        AppLogger.log(this, TAG, "initViews() START");

        rvLanguages = findViewById(R.id.rv_languages);
        rvLetters = findViewById(R.id.rv_letters);
        tvTitle = findViewById(R.id.tv_lang_title);
        tvProgress = findViewById(R.id.tv_progress);
        tvStats = findViewById(R.id.tv_stats);
        tvLetterDisplay = findViewById(R.id.tv_letter_display);
        tvPronunciation = findViewById(R.id.tv_pronunciation);
        etSearch = findViewById(R.id.et_search);
        btnSpeak = findViewById(R.id.btn_speak);
        btnPlay = findViewById(R.id.btn_play);
        btnRecord = findViewById(R.id.btn_record);
        btnTest = findViewById(R.id.btn_test);
        btnFlashcards = findViewById(R.id.btn_flashcards);
        btnTranslate = findViewById(R.id.btn_translate);
        btnLanguageSelect = findViewById(R.id.btn_language_select);
        btnModeSwitch = findViewById(R.id.btn_mode_switch);
        btnResetProgress = findViewById(R.id.btn_reset_progress);
        progressBar = findViewById(R.id.progress_bar);
        mainContainer = findViewById(R.id.main_container);

        // Проверка на null
        if (rvLanguages == null) AppLogger.log(this, TAG, "⚠️ rvLanguages is NULL!");
        if (rvLetters == null) AppLogger.log(this, TAG, "⚠️ rvLetters is NULL!");
        if (tvTitle == null) AppLogger.log(this, TAG, "⚠️ tvTitle is NULL!");

        AppLogger.log(this, TAG, "initViews() END");
    }

    private void initData() {
        AppLogger.log(this, TAG, "initData() START");

        languages = LanguageData.getAllLanguages();
        AppLogger.log(this, TAG, "   Total languages: " + languages.size());

        if (languages.isEmpty()) {
            AppLogger.log(this, TAG, "❌ No languages loaded!");
            Toast.makeText(this, "Ошибка загрузки языков", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        currentLanguageIndex = 0;
        currentLanguage = languages.get(0);
        currentLetters = currentLanguage.getLetters();
        AppLogger.log(this, TAG, "   Initial language: " + currentLanguage.getName() +
                " (" + currentLetters.size() + " letters)");

        // Language Adapter
        languageAdapter = new LanguageAdapter(languages, new LanguageAdapter.OnLanguageClickListener() {
            @Override
            public void onLanguageClick(int position) {
                AppLogger.log(LanguageLearningActivity.this, TAG,
                        "📌 Language clicked: position=" + position +
                        ", name=" + languages.get(position).getName());
                selectLanguage(position);
            }
        });
        rvLanguages.setLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false));
        rvLanguages.setAdapter(languageAdapter);

        // Letter Adapter
        letterAdapter = new LetterAdapter(currentLetters, new LetterAdapter.OnLetterClickListener() {
            @Override
            public void onLetterClick(int position) {
                AppLogger.log(LanguageLearningActivity.this, TAG,
                        "📌 Letter clicked: position=" + position +
                        ", letter=" + currentLetters.get(position).getLetter());
                showLetterDetails(position);
            }

            @Override
            public void onLetterLongClick(int position) {
                AppLogger.log(LanguageLearningActivity.this, TAG,
                        "📌 Letter long clicked: position=" + position +
                        ", letter=" + currentLetters.get(position).getLetter());
                toggleFavorite(position);
            }
        });
        rvLetters.setLayoutManager(new GridLayoutManager(this, 4));
        rvLetters.setAdapter(letterAdapter);

        // Инициализируем флешкарты
        flashcardIndices.clear();
        for (int i = 0; i < currentLetters.size(); i++) {
            flashcardIndices.add(i);
        }
        Collections.shuffle(flashcardIndices);

        AppLogger.log(this, TAG, "initData() END");
    }

    private void initTTS() {
        AppLogger.log(this, TAG, "initTTS() START");

        tts = new TextToSpeech(this, new TextToSpeech.OnInitListener() {
            @Override
            public void onInit(int status) {
                AppLogger.log(LanguageLearningActivity.this, TAG,
                        "TTS onInit: status=" + status +
                        (status == TextToSpeech.SUCCESS ? " (SUCCESS)" : " (FAILED)"));

                if (status == TextToSpeech.SUCCESS) {
                    ttsReady = true;
                    Locale locale = getLocaleForLanguage(currentLanguage);
                    if (locale != null) {
                        int result = tts.setLanguage(locale);
                        AppLogger.log(LanguageLearningActivity.this, TAG,
                                "TTS setLanguage: " + locale + " -> result=" + result);
                        if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
                            AppLogger.log(LanguageLearningActivity.this, TAG,
                                    "⚠️ Language not supported by TTS: " + locale);
                            tts.setLanguage(Locale.US);
                        }
                    } else {
                        AppLogger.log(LanguageLearningActivity.this, TAG,
                                "⚠️ No locale for language, using US default");
                        tts.setLanguage(Locale.US);
                    }
                    AppLogger.log(LanguageLearningActivity.this, TAG, "✅ TTS ready");
                } else {
                    AppLogger.log(LanguageLearningActivity.this, TAG, "❌ TTS initialization failed");
                    ttsReady = false;
                }
            }
        });
    }

    private Locale getLocaleForLanguage(LanguageData.Language lang) {
        String name = lang.getName();
        switch (name) {
            case "Русский": return new Locale("ru", "RU");
            case "Английский": return Locale.US;
            case "Немецкий": return Locale.GERMANY;
            case "Французский": return Locale.FRANCE;
            case "Испанский": return new Locale("es", "ES");
            case "Итальянский": return Locale.ITALY;
            case "Японский": return Locale.JAPAN;
            case "Китайский": return Locale.CHINA;
            case "Корейский": return Locale.KOREAN;
            case "Арабский": return new Locale("ar", "SA");
            default: return null;
        }
    }

    private void setupListeners() {
        AppLogger.log(this, TAG, "setupListeners() START");

        btnLanguageSelect.setOnClickListener(v -> {
            AppLogger.log(LanguageLearningActivity.this, TAG, "🔘 btnLanguageSelect clicked");
            showLanguageSelectorDialog();
        });

        btnModeSwitch.setOnClickListener(v -> {
            AppLogger.log(LanguageLearningActivity.this, TAG, "🔘 btnModeSwitch clicked, current mode=" + mode);
            mode = (mode + 1) % 3;
            updateMode();
        });

        btnSpeak.setOnClickListener(v -> {
            AppLogger.log(LanguageLearningActivity.this, TAG, "🔘 btnSpeak clicked");
            speakLetter();
        });

        btnPlay.setOnClickListener(v -> {
            AppLogger.log(LanguageLearningActivity.this, TAG, "🔘 btnPlay clicked");
            playPronunciation();
        });

        btnRecord.setOnClickListener(v -> {
            AppLogger.log(LanguageLearningActivity.this, TAG, "🔘 btnRecord clicked, isRecording=" + isRecording);
            toggleRecording();
        });

        btnTest.setOnClickListener(v -> {
            AppLogger.log(LanguageLearningActivity.this, TAG, "🔘 btnTest clicked");
            startQuiz();
        });

        btnFlashcards.setOnClickListener(v -> {
            AppLogger.log(LanguageLearningActivity.this, TAG, "🔘 btnFlashcards clicked");
            startFlashcards();
        });

        btnTranslate.setOnClickListener(v -> {
            AppLogger.log(LanguageLearningActivity.this, TAG, "🔘 btnTranslate clicked");
            showTranslateDialog();
        });

        btnResetProgress.setOnClickListener(v -> {
            AppLogger.log(LanguageLearningActivity.this, TAG, "🔘 btnResetProgress clicked");
            resetProgress();
        });

        // Поиск
        etSearch.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                filterLetters(s.toString());
            }

            @Override
            public void afterTextChanged(Editable s) {}
        });

        // Двойной тап по полю буквы для быстрого озвучивания
        tvLetterDisplay.setOnTouchListener(new View.OnTouchListener() {
            private long lastTapTime = 0;

            @Override
            public boolean onTouch(View v, MotionEvent event) {
                if (event.getAction() == MotionEvent.ACTION_DOWN) {
                    long currentTime = System.currentTimeMillis();
                    if (currentTime - lastTapTime < 300) {
                        speakLetter();
                        return true;
                    }
                    lastTapTime = currentTime;
                }
                return false;
            }
        });

        AppLogger.log(this, TAG, "setupListeners() END");
    }

    private void applyThemeColors() {
        AppLogger.log(this, TAG, "applyThemeColors() START");

        int bg = ThemeManager.getBackgroundColor(this);
        int text = ThemeManager.getTextColor(this);
        int textSecondary = ThemeManager.getTextSecondaryColor(this);
        int inputBg = ThemeManager.getInputBgColor(this);
        int divider = ThemeManager.getDividerColor(this);

        if (mainContainer != null) mainContainer.setBackgroundColor(bg);
        if (tvTitle != null) tvTitle.setTextColor(text);
        if (tvProgress != null) tvProgress.setTextColor(textSecondary);
        if (tvStats != null) tvStats.setTextColor(textSecondary);
        if (tvLetterDisplay != null) tvLetterDisplay.setTextColor(text);
        if (tvPronunciation != null) tvPronunciation.setTextColor(textSecondary);

        if (etSearch != null) {
            etSearch.setTextColor(text);
            etSearch.setHintTextColor(textSecondary);
            GradientDrawable inputBgDrawable = new GradientDrawable();
            inputBgDrawable.setColor(inputBg);
            inputBgDrawable.setCornerRadius(24);
            inputBgDrawable.setStroke(1, divider);
            etSearch.setBackground(inputBgDrawable);
        }

        if (getSupportActionBar() != null) {
            getSupportActionBar().setBackgroundDrawable(
                new android.graphics.drawable.ColorDrawable(
                    isDarkTheme ? 0xFF424242 : 0xFF1565C0
                )
            );
        }

        AppLogger.log(this, TAG, "applyThemeColors() END");
    }

    private void selectLanguage(int position) {
        AppLogger.log(this, TAG, "selectLanguage() START: position=" + position);

        if (position < 0 || position >= languages.size()) {
            AppLogger.log(this, TAG, "❌ Invalid position: " + position);
            return;
        }

        currentLanguageIndex = position;
        currentLanguage = languages.get(position);
        currentLetters = currentLanguage.getLetters();

        AppLogger.log(this, TAG, "   Language: " + currentLanguage.getName() +
                " (" + currentLanguage.getNativeName() + ")");
        AppLogger.log(this, TAG, "   Letters: " + currentLetters.size());

        // Обновляем TTS
        if (ttsReady) {
            Locale locale = getLocaleForLanguage(currentLanguage);
            if (locale != null) {
                tts.setLanguage(locale);
            }
        }

        // Сбрасываем состояние
        currentLetterIndex = 0;
        flashcardIndices.clear();
        for (int i = 0; i < currentLetters.size(); i++) {
            flashcardIndices.add(i);
        }
        Collections.shuffle(flashcardIndices);
        flashcardIndex = 0;
        quizQuestions.clear();

        // Обновляем адаптер
        if (letterAdapter != null) {
            letterAdapter.updateData(currentLetters);
        }

        // Обновляем UI
        updateUI();
        savePreferences();

        AppLogger.log(this, TAG, "selectLanguage() END");
    }

    private void showLetterDetails(int position) {
        AppLogger.log(this, TAG, "showLetterDetails() START: position=" + position);

        if (position < 0 || position >= currentLetters.size()) {
            AppLogger.log(this, TAG, "❌ Invalid position: " + position);
            return;
        }

        currentLetterIndex = position;
        LanguageData.Letter letter = currentLetters.get(position);

        if (tvLetterDisplay != null) {
            tvLetterDisplay.setText(letter.getLetter());
        }
        if (tvPronunciation != null) {
            tvPronunciation.setText("Произношение: " + letter.getPronunciation());
        }

        AppLogger.log(this, TAG, "   Letter: " + letter.getLetter() +
                " (" + letter.getPronunciation() + ")");

        if (tvLetterDisplay != null) {
            tvLetterDisplay.startAnimation(AnimationUtils.loadAnimation(this, android.R.anim.fade_in));
        }

        vibrate(50);
        AppLogger.log(this, TAG, "showLetterDetails() END");
    }

    private void toggleFavorite(int position) {
        AppLogger.log(this, TAG, "toggleFavorite() START: position=" + position);

        if (position < 0 || position >= currentLetters.size()) {
            AppLogger.log(this, TAG, "❌ Invalid position: " + position);
            return;
        }

        LanguageData.Letter letter = currentLetters.get(position);
        String key = currentLanguage.getName() + "_" + letter.getLetter();

        if (favoriteLetters.contains(key)) {
            favoriteLetters.remove(key);
            Toast.makeText(this, "⭐ Убрано из избранного", Toast.LENGTH_SHORT).show();
        } else {
            favoriteLetters.add(key);
            Toast.makeText(this, "⭐ Добавлено в избранное!", Toast.LENGTH_SHORT).show();
            vibrate(100);
        }

        savePreferences();
        if (letterAdapter != null) {
            letterAdapter.notifyItemChanged(position);
        }
        updateStats();
        AppLogger.log(this, TAG, "toggleFavorite() END");
    }

    private void speakLetter() {
        AppLogger.log(this, TAG, "speakLetter() START");

        if (tvLetterDisplay == null) {
            AppLogger.log(this, TAG, "❌ tvLetterDisplay is null");
            return;
        }

        String letter = tvLetterDisplay.getText().toString();
        AppLogger.log(this, TAG, "   Letter: '" + letter + "'");

        if (letter.isEmpty() || letter.equals("А") && currentLetters.isEmpty()) {
            if (!currentLetters.isEmpty()) {
                showLetterDetails(0);
                letter = currentLetters.get(0).getLetter();
            } else {
                Toast.makeText(this, "Нет букв для озвучивания", Toast.LENGTH_SHORT).show();
                return;
            }
        }

        if (ttsReady && tts != null) {
            AppLogger.log(this, TAG, "   TTS speaking: '" + letter + "'");
            tts.speak(letter, TextToSpeech.QUEUE_FLUSH, null, null);

            if (btnSpeak != null) {
                btnSpeak.startAnimation(AnimationUtils.loadAnimation(this, android.R.anim.fade_in));
            }
            vibrate(30);

            LanguageStats.recordAction(this, currentLanguage.getName(), "speak", letter);
            actionCount++;
        } else {
            AppLogger.log(this, TAG, "❌ TTS not ready");
            Toast.makeText(this, "Голосовой синтезатор не готов", Toast.LENGTH_SHORT).show();
        }

        AppLogger.log(this, TAG, "speakLetter() END");
    }

    private void playPronunciation() {
        AppLogger.log(this, TAG, "playPronunciation() START");

        if (tvPronunciation == null) {
            AppLogger.log(this, TAG, "❌ tvPronunciation is null");
            return;
        }

        String pronunciation = tvPronunciation.getText().toString()
                .replace("Произношение: ", "");
        AppLogger.log(this, TAG, "   Pronunciation: '" + pronunciation + "'");

        if (pronunciation.isEmpty() || pronunciation.equals("Произношение: ")) {
            if (tvLetterDisplay != null) {
                pronunciation = tvLetterDisplay.getText().toString();
            } else {
                Toast.makeText(this, "Нет произношения", Toast.LENGTH_SHORT).show();
                return;
            }
        }

        if (ttsReady && tts != null) {
            AppLogger.log(this, TAG, "   TTS pronouncing: '" + pronunciation + "'");
            tts.speak(pronunciation, TextToSpeech.QUEUE_FLUSH, null, null);

            if (btnPlay != null) {
                btnPlay.startAnimation(AnimationUtils.loadAnimation(this, android.R.anim.fade_in));
            }
            vibrate(30);

            LanguageStats.recordAction(this, currentLanguage.getName(), "pronounce", pronunciation);
            actionCount++;
        } else {
            AppLogger.log(this, TAG, "❌ TTS not ready");
            Toast.makeText(this, "Голосовой синтезатор не готов", Toast.LENGTH_SHORT).show();
        }

        AppLogger.log(this, TAG, "playPronunciation() END");
    }

    private void toggleRecording() {
        AppLogger.log(this, TAG, "toggleRecording() START: isRecording=" + isRecording);

        if (isRecording) {
            stopRecording();
        } else {
            startRecording();
        }
    }

    private void startRecording() {
        AppLogger.log(this, TAG, "startRecording() START");

        if (ContextCompat.checkSelfPermission(this, android.Manifest.permission.RECORD_AUDIO)
                != android.content.pm.PackageManager.PERMISSION_GRANTED) {
            AppLogger.log(this, TAG, "⚠️ RECORD_AUDIO permission not granted");
            ActivityCompat.requestPermissions(this,
                new String[]{android.Manifest.permission.RECORD_AUDIO}, REQUEST_RECORD_AUDIO);
            return;
        }

        try {
            File dir = new File(getCacheDir(), "lang_audio");
            if (!dir.exists()) {
                dir.mkdirs();
            }

            recordingFilePath = new File(dir, "rec_" + System.currentTimeMillis() + ".3gp").getAbsolutePath();
            AppLogger.log(this, TAG, "   Recording file: " + recordingFilePath);

            mediaRecorder = new MediaRecorder();
            mediaRecorder.setAudioSource(MediaRecorder.AudioSource.MIC);
            mediaRecorder.setOutputFormat(MediaRecorder.OutputFormat.THREE_GPP);
            mediaRecorder.setAudioEncoder(MediaRecorder.AudioEncoder.AMR_NB);
            mediaRecorder.setOutputFile(recordingFilePath);
            mediaRecorder.prepare();
            mediaRecorder.start();

            isRecording = true;
            if (btnRecord != null) {
                btnRecord.setImageResource(android.R.drawable.ic_media_pause);
            }

            Toast.makeText(this, "🎙️ Запись...", Toast.LENGTH_SHORT).show();
            vibrate(50);

            AppLogger.log(this, TAG, "✅ Recording started successfully");
        } catch (Exception e) {
            AppLogger.logException(this, TAG, "❌ Recording start error", e);
            Toast.makeText(this, "Ошибка записи: " + e.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }

    private void stopRecording() {
        AppLogger.log(this, TAG, "stopRecording() START");

        if (mediaRecorder == null) {
            AppLogger.log(this, TAG, "⚠️ mediaRecorder is null");
            return;
        }

        try {
            mediaRecorder.stop();
            mediaRecorder.release();
            mediaRecorder = null;
            isRecording = false;

            if (btnRecord != null) {
                btnRecord.setImageResource(android.R.drawable.ic_media_play);
            }

            Toast.makeText(this, "✅ Запись сохранена", Toast.LENGTH_SHORT).show();
            AppLogger.log(this, TAG, "   Recording saved: " + recordingFilePath);

            LanguageStats.recordAction(this, currentLanguage.getName(), "record", "audio");
            actionCount++;

            playRecording();

        } catch (Exception e) {
            AppLogger.logException(this, TAG, "❌ Recording stop error", e);
            Toast.makeText(this, "Ошибка остановки записи", Toast.LENGTH_SHORT).show();
        }

        AppLogger.log(this, TAG, "stopRecording() END");
    }

    private void playRecording() {
        AppLogger.log(this, TAG, "playRecording() START");

        if (recordingFilePath == null) {
            AppLogger.log(this, TAG, "⚠️ recordingFilePath is null");
            return;
        }

        File file = new File(recordingFilePath);
        if (!file.exists()) {
            AppLogger.log(this, TAG, "⚠️ Recording file does not exist");
            Toast.makeText(this, "Файл записи не найден", Toast.LENGTH_SHORT).show();
            return;
        }

        AppLogger.log(this, TAG, "   File size: " + file.length() + " bytes");

        try {
            if (mediaPlayer != null) {
                mediaPlayer.release();
                mediaPlayer = null;
            }

            mediaPlayer = new MediaPlayer();
            mediaPlayer.setDataSource(recordingFilePath);
            mediaPlayer.prepare();
            mediaPlayer.start();

            isPlaying = true;
            if (btnPlay != null) {
                btnPlay.setImageResource(android.R.drawable.ic_media_pause);
            }

            AppLogger.log(this, TAG, "✅ Playback started");

            mediaPlayer.setOnCompletionListener(mp -> {
                AppLogger.log(LanguageLearningActivity.this, TAG, "⏹️ Playback completed");
                isPlaying = false;
                if (btnPlay != null) {
                    btnPlay.setImageResource(android.R.drawable.ic_media_play);
                }
                mp.release();
                mediaPlayer = null;
            });

            mediaPlayer.setOnErrorListener((mp, what, extra) -> {
                AppLogger.log(LanguageLearningActivity.this, TAG,
                        "❌ Playback error: what=" + what + ", extra=" + extra);
                isPlaying = false;
                if (btnPlay != null) {
                    btnPlay.setImageResource(android.R.drawable.ic_media_play);
                }
                mp.release();
                mediaPlayer = null;
                Toast.makeText(LanguageLearningActivity.this, "Ошибка воспроизведения", Toast.LENGTH_SHORT).show();
                return true;
            });

        } catch (Exception e) {
            AppLogger.logException(this, TAG, "❌ Playback error", e);
            Toast.makeText(this, "Ошибка воспроизведения: " + e.getMessage(), Toast.LENGTH_SHORT).show();
        }

        AppLogger.log(this, TAG, "playRecording() END");
    }

    // ==================== ВИКТОРИНА ====================

    private void startQuiz() {
        AppLogger.log(this, TAG, "startQuiz() START");

        if (currentLetters.isEmpty()) {
            AppLogger.log(this, TAG, "❌ No letters for quiz");
            Toast.makeText(this, "Нет букв для викторины", Toast.LENGTH_SHORT).show();
            return;
        }

        mode = 1;
        updateMode();

        quizScore = 0;
        quizTotal = 0;
        quizQuestions.clear();
        quizCurrentIndex = 0;

        // Создаём список вопросов
        List<Integer> indices = new ArrayList<>();
        for (int i = 0; i < currentLetters.size(); i++) {
            indices.add(i);
        }
        Collections.shuffle(indices);

        quizTotal = Math.min(10, indices.size());
        for (int i = 0; i < quizTotal; i++) {
            quizQuestions.add(indices.get(i));
        }

        AppLogger.log(this, TAG, "   Quiz total: " + quizTotal + " questions");
        LanguageStats.recordAction(this, currentLanguage.getName(), "quiz_start", String.valueOf(quizTotal));

        showQuizQuestion();

        AppLogger.log(this, TAG, "startQuiz() END");
    }

    private void showQuizQuestion() {
        AppLogger.log(this, TAG, "showQuizQuestion() START: currentIndex=" + quizCurrentIndex +
                "/" + quizQuestions.size());

        // Отменяем предыдущий таймер
        if (quizTimer != null) {
            quizTimer.cancel();
            quizTimer = null;
        }

        if (quizCurrentIndex >= quizQuestions.size()) {
            AppLogger.log(this, TAG, "   Quiz finished");
            finishQuiz();
            return;
        }

        int index = quizQuestions.get(quizCurrentIndex);
        LanguageData.Letter letter = currentLetters.get(index);

        // Генерируем 4 варианта ответа
        List<String> options = new ArrayList<>();
        options.add(letter.getPronunciation());

        while (options.size() < 4) {
            String randomPron = getRandomPronunciation();
            if (!options.contains(randomPron)) {
                options.add(randomPron);
            }
        }
        Collections.shuffle(options);

        final String correctAnswer = letter.getPronunciation();
        final String letterDisplay = letter.getLetter();

        AppLogger.log(this, TAG, "   Question: " + letterDisplay + " -> " + correctAnswer);
        AppLogger.log(this, TAG, "   Options: " + options);

        // Создаём кастомный диалог с таймером
        AlertDialog.Builder builder = new AlertDialog.Builder(this);

        // Прогресс-бар
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(40, 20, 40, 20);

        TextView tvQuestion = new TextView(this);
        tvQuestion.setText("Буква: " + letterDisplay);
        tvQuestion.setTextSize(22);
        tvQuestion.setTextColor(ThemeManager.getTextColor(this));
        tvQuestion.setGravity(Gravity.CENTER);
        tvQuestion.setPadding(0, 0, 0, 16);
        layout.addView(tvQuestion);

        TextView tvTimer = new TextView(this);
        tvTimer.setText("⏱ " + quizTimerSeconds + "с");
        tvTimer.setTextSize(14);
        tvTimer.setTextColor(0xFFFF5252);
        tvTimer.setGravity(Gravity.CENTER);
        layout.addView(tvTimer);

        ProgressBar pbQuiz = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        pbQuiz.setMax(quizTimerSeconds);
        pbQuiz.setProgress(quizTimerSeconds);
        pbQuiz.setProgressTintList(android.content.res.ColorStateList.valueOf(0xFF4CAF50));
        LinearLayout.LayoutParams pbParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                (int) android.util.TypedValue.applyDimension(
                        android.util.TypedValue.COMPLEX_UNIT_DIP, 8, getResources().getDisplayMetrics()
                )
        );
        pbQuiz.setLayoutParams(pbParams);
        layout.addView(pbQuiz);

        // Список вариантов
        final String[] optionsArray = options.toArray(new String[0]);
        final int[] selectedIndex = {-1};

        // Создаём кнопки вариантов
        LinearLayout optionsLayout = new LinearLayout(this);
        optionsLayout.setOrientation(LinearLayout.VERTICAL);
        optionsLayout.setPadding(0, 16, 0, 0);

        final Button[] optionButtons = new Button[4];
        for (int i = 0; i < 4; i++) {
            final int idx = i;
            Button btn = new Button(this);
            btn.setText(optionsArray[i]);
            btn.setTextSize(16);
            btn.setAllCaps(false);
            btn.setPadding(16, 12, 16, 12);
            btn.setBackgroundColor(ThemeManager.getCardColor(this));
            btn.setTextColor(ThemeManager.getTextColor(this));
            LinearLayout.LayoutParams btnParams = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
            );
            btnParams.setMargins(0, 0, 0, 8);
            btn.setLayoutParams(btnParams);
            btn.setOnClickListener(v -> {
                if (selectedIndex[0] == -1) {
                    selectedIndex[0] = idx;
                    AppLogger.log(LanguageLearningActivity.this, TAG,
                            "   User selected: '" + optionsArray[idx] + "'");
                    checkQuizAnswer(idx, optionsArray, correctAnswer);
                }
            });
            optionButtons[i] = btn;
            optionsLayout.addView(btn);
        }
        layout.addView(optionsLayout);

        builder.setView(layout);

        // Кнопка пропуска
        builder.setNegativeButton("⏭ Пропустить", (dialog, which) -> {
            AppLogger.log(LanguageLearningActivity.this, TAG, "   Skipped question");
            if (quizTimer != null) {
                quizTimer.cancel();
                quizTimer = null;
            }
            quizCurrentIndex++;
            showQuizQuestion();
        });

        builder.setCancelable(false);
        quizDialog = builder.create();
        quizDialog.show();

        // Таймер на вопрос
        final int[] timeLeft = {quizTimerSeconds};
        quizTimer = new Timer();
        quizTimer.scheduleAtFixedRate(new TimerTask() {
            @Override
            public void run() {
                timeLeft[0]--;
                handler.post(() -> {
                    if (timeLeft[0] >= 0 && quizDialog != null && quizDialog.isShowing()) {
                        tvTimer.setText("⏱ " + timeLeft[0] + "с");
                        pbQuiz.setProgress(timeLeft[0]);
                        // Меняем цвет при таймере
                        if (timeLeft[0] < 3) {
                            pbQuiz.setProgressTintList(android.content.res.ColorStateList.valueOf(0xFFFF5252));
                        }
                    }
                    if (timeLeft[0] <= 0 && selectedIndex[0] == -1) {
                        // Время вышло — показываем правильный ответ
                        AppLogger.log(LanguageLearningActivity.this, TAG, "   Time's up!");
                        handler.post(() -> {
                            if (quizDialog != null && quizDialog.isShowing()) {
                                // Подсвечиваем правильный ответ
                                for (int i = 0; i < optionButtons.length; i++) {
                                    if (optionsArray[i].equals(correctAnswer)) {
                                        optionButtons[i].setBackgroundColor(0xFF4CAF50);
                                        optionButtons[i].setTextColor(0xFFFFFFFF);
                                    } else {
                                        optionButtons[i].setBackgroundColor(0xFFFF5252);
                                        optionButtons[i].setTextColor(0xFFFFFFFF);
                                    }
                                }
                                Toast.makeText(LanguageLearningActivity.this,
                                        "⏰ Время! Правильно: " + correctAnswer, Toast.LENGTH_SHORT).show();
                                handler.postDelayed(() -> {
                                    if (quizTimer != null) {
                                        quizTimer.cancel();
                                        quizTimer = null;
                                    }
                                    quizCurrentIndex++;
                                    showQuizQuestion();
                                }, 1500);
                            }
                        });
                        if (quizTimer != null) {
                            quizTimer.cancel();
                            quizTimer = null;
                        }
                    }
                });
            }
        }, 1000, 1000);

        AppLogger.log(this, TAG, "showQuizQuestion() END");
    }

    private void checkQuizAnswer(int idx, String[] options, String correctAnswer) {
        String selected = options[idx];
        boolean correct = selected.equals(correctAnswer);

        if (quizTimer != null) {
            quizTimer.cancel();
            quizTimer = null;
        }

        // Подсвечиваем правильный и неправильный ответы
        if (quizDialog != null && quizDialog.isShowing()) {
            // Получаем кнопки из диалога
            ViewGroup viewGroup = (ViewGroup) quizDialog.getWindow().getDecorView();
            findAndHighlightButtons(viewGroup, options, correctAnswer, idx);
        }

        if (correct) {
            quizScore++;
            Toast.makeText(this, "✅ Правильно!", Toast.LENGTH_SHORT).show();
            vibrate(50);
            AppLogger.log(this, TAG, "   Correct!");
        } else {
            Toast.makeText(this, "❌ Правильно: " + correctAnswer, Toast.LENGTH_SHORT).show();
            AppLogger.log(this, TAG, "   Wrong. Correct: " + correctAnswer);
        }

        handler.postDelayed(() -> {
            quizCurrentIndex++;
            showQuizQuestion();
        }, 1200);
    }

    private void findAndHighlightButtons(ViewGroup viewGroup, String[] options, String correctAnswer, int selectedIdx) {
        for (int i = 0; i < viewGroup.getChildCount(); i++) {
            View child = viewGroup.getChildAt(i);
            if (child instanceof Button) {
                Button btn = (Button) child;
                String text = btn.getText().toString();
                for (String opt : options) {
                    if (text.equals(opt)) {
                        if (opt.equals(correctAnswer)) {
                            btn.setBackgroundColor(0xFF4CAF50);
                            btn.setTextColor(0xFFFFFFFF);
                        } else if (text.equals(options[selectedIdx]) && !opt.equals(correctAnswer)) {
                            btn.setBackgroundColor(0xFFFF5252);
                            btn.setTextColor(0xFFFFFFFF);
                        }
                        break;
                    }
                }
            } else if (child instanceof ViewGroup) {
                findAndHighlightButtons((ViewGroup) child, options, correctAnswer, selectedIdx);
            }
        }
    }

    private void finishQuiz() {
        AppLogger.log(this, TAG, "finishQuiz() START: score=" + quizScore + "/" + quizTotal);

        if (quizTimer != null) {
            quizTimer.cancel();
            quizTimer = null;
        }

        if (quizDialog != null && quizDialog.isShowing()) {
            quizDialog.dismiss();
            quizDialog = null;
        }

        mode = 0;
        updateMode();

        // Сохраняем результат
        LanguageStats.recordQuizResult(this, currentLanguage.getName(), quizScore, quizTotal);
        LanguageStats.recordAction(this, currentLanguage.getName(), "quiz_finish",
                quizScore + "/" + quizTotal);

        // Обновляем прогресс изучения
        int learned = getLearnedCount();
        if (quizScore > 0) {
            learned += quizScore;
            SharedPreferences prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
            prefs.edit().putInt(currentLanguage.getName() + "_learned", learned).apply();
        }

        // Показываем результат с оценкой
        int percent = quizTotal > 0 ? (quizScore * 100 / quizTotal) : 0;
        String grade;
        if (percent >= 90) grade = "🏆 Отлично!";
        else if (percent >= 70) grade = "👏 Хорошо!";
        else if (percent >= 50) grade = "📖 Учите больше!";
        else grade = "💪 Тренируйтесь!";

        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("🏆 Результат викторины!");
        String message = grade + "\n\n" +
                "Правильно: " + quizScore + " из " + quizTotal + "\n" +
                "Точность: " + percent + "%";

        if (percent == 100 && quizTotal > 0) {
            message = "🎉 ИДЕАЛЬНО! 100%!";
            vibrate(300);
        }

        builder.setMessage(message);
        builder.setPositiveButton("OK", null);
        builder.show();

        updateStats();
        AppLogger.log(this, TAG, "finishQuiz() END: " + quizScore + "/" + quizTotal + " (" + percent + "%)");
    }

    private String getRandomPronunciation() {
        LanguageData.Language lang = languages.get(random.nextInt(languages.size()));
        List<LanguageData.Letter> letters = lang.getLetters();
        return letters.get(random.nextInt(letters.size())).getPronunciation();
    }

    // ==================== ФЛЕШКАРТЫ ====================

    private void startFlashcards() {
        AppLogger.log(this, TAG, "startFlashcards() START");

        if (currentLetters.isEmpty()) {
            AppLogger.log(this, TAG, "❌ No letters for flashcards");
            Toast.makeText(this, "Нет букв для карточек", Toast.LENGTH_SHORT).show();
            return;
        }

        mode = 2;
        updateMode();

        flashcardIndex = 0;
        flashcardIndices.clear();
        for (int i = 0; i < currentLetters.size(); i++) {
            flashcardIndices.add(i);
        }
        Collections.shuffle(flashcardIndices);
        flashcardActive = true;

        AppLogger.log(this, TAG, "   Total cards: " + flashcardIndices.size());
        LanguageStats.recordAction(this, currentLanguage.getName(), "flashcards_start",
                String.valueOf(flashcardIndices.size()));

        showFlashcard();

        AppLogger.log(this, TAG, "startFlashcards() END");
    }

    private void showFlashcard() {
        AppLogger.log(this, TAG, "showFlashcard() START: index=" + flashcardIndex +
                "/" + flashcardIndices.size());

        if (flashcardIndex >= flashcardIndices.size()) {
            AppLogger.log(this, TAG, "   All cards shown");
            finishFlashcards();
            return;
        }

        int index = flashcardIndices.get(flashcardIndex);
        LanguageData.Letter letter = currentLetters.get(index);

        AppLogger.log(this, TAG, "   Card: " + letter.getLetter() +
                " (" + letter.getPronunciation() + ")");

        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("🃏 Карточка " + (flashcardIndex + 1) + "/" + flashcardIndices.size());

        View view = getLayoutInflater().inflate(R.layout.item_letter, null);
        TextView tvLetter = view.findViewById(R.id.tv_letter);
        TextView tvPronunciation = view.findViewById(R.id.tv_pronunciation);

        tvLetter.setText(letter.getLetter());
        tvPronunciation.setText(letter.getPronunciation());

        builder.setView(view);
        builder.setPositiveButton("▶ Следующая", (dialog, which) -> {
            flashcardIndex++;
            showFlashcard();
        });

        builder.setNegativeButton("🔊 Произнести", (dialog, which) -> {
            if (ttsReady) {
                tts.speak(letter.getLetter(), TextToSpeech.QUEUE_FLUSH, null, null);
                AppLogger.log(LanguageLearningActivity.this, TAG,
                        "   Speaking from flashcard: " + letter.getLetter());
            }
        });

        builder.setNeutralButton("Выйти", (dialog, which) -> {
            AppLogger.log(LanguageLearningActivity.this, TAG, "   Exiting flashcards");
            flashcardActive = false;
            mode = 0;
            updateMode();
        });

        builder.setCancelable(false);
        builder.show();

        AppLogger.log(this, TAG, "showFlashcard() END");
    }

    private void finishFlashcards() {
        AppLogger.log(this, TAG, "finishFlashcards() START");

        flashcardActive = false;
        mode = 0;
        updateMode();

        Toast.makeText(this, "🏁 Карточки завершены!", Toast.LENGTH_SHORT).show();
        AppLogger.log(this, TAG, "finishFlashcards() END");
    }

    // ==================== ПЕРЕВОД ====================

    private void showTranslateDialog() {
        AppLogger.log(this, TAG, "showTranslateDialog() START");

        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("🔍 Перевод слова");

        final EditText input = new EditText(this);
        input.setHint("Введите слово для перевода");
        input.setTextColor(ThemeManager.getTextColor(this));
        input.setHintTextColor(ThemeManager.getHintColor(this));
        input.setBackgroundColor(ThemeManager.getInputBgColor(this));
        input.setPadding(16, 12, 16, 12);
        builder.setView(input);

        builder.setPositiveButton("Перевести", (dialog, which) -> {
            String word = input.getText().toString().trim();
            if (!word.isEmpty()) {
                translateWord(word);
            }
        });

        builder.setNegativeButton("Отмена", null);
        builder.show();

        AppLogger.log(this, TAG, "showTranslateDialog() END");
    }

    private void translateWord(String word) {
        AppLogger.log(this, TAG, "translateWord() START: '" + word + "'");

        if (ttsReady) {
            tts.speak(word, TextToSpeech.QUEUE_FLUSH, null, null);
            Toast.makeText(this, "🔊 Произносим: " + word, Toast.LENGTH_SHORT).show();
            AppLogger.log(this, TAG, "   TTS speaking: '" + word + "'");
            LanguageStats.recordAction(this, currentLanguage.getName(), "translate", word);
            actionCount++;
        } else {
            AppLogger.log(this, TAG, "❌ TTS not ready");
            Toast.makeText(this, "Голосовой синтезатор не готов", Toast.LENGTH_SHORT).show();
        }

        AppLogger.log(this, TAG, "translateWord() END");
    }

    // ==================== ПОИСК И ФИЛЬТРАЦИЯ ====================

    private void filterLetters(String query) {
        AppLogger.log(this, TAG, "filterLetters() START: query='" + query + "'");

        if (query.isEmpty()) {
            if (letterAdapter != null) {
                letterAdapter.updateData(currentLetters);
                AppLogger.log(this, TAG, "   Show all: " + currentLetters.size() + " letters");
            }
            return;
        }

        List<LanguageData.Letter> filtered = new ArrayList<>();
        String lowerQuery = query.toLowerCase();

        for (LanguageData.Letter letter : currentLetters) {
            if (letter.getLetter().toLowerCase().contains(lowerQuery) ||
                letter.getPronunciation().toLowerCase().contains(lowerQuery) ||
                letter.getTranslation().toLowerCase().contains(lowerQuery)) {
                filtered.add(letter);
            }
        }

        AppLogger.log(this, TAG, "   Filtered: " + filtered.size() + "/" + currentLetters.size());
        if (letterAdapter != null) {
            letterAdapter.updateData(filtered);
        }
    }

    // ==================== ОБНОВЛЕНИЕ UI ====================

    private void updateMode() {
        AppLogger.log(this, TAG, "updateMode() START: mode=" + mode + " (" + getModeName() + ")");

        String[] modeNames = {"📖 Алфавит", "🎯 Викторина", "🃏 Карточки"};
        if (btnModeSwitch != null) {
            btnModeSwitch.setText(modeNames[mode]);
        }

        if (tvTitle != null) {
            tvTitle.setText(modeNames[mode] + ": " + currentLanguage.getName());
        }

        AppLogger.log(this, TAG, "updateMode() END");
    }

    private void updateUI() {
        AppLogger.log(this, TAG, "updateUI() START");

        if (tvTitle != null) {
            tvTitle.setText("📖 " + currentLanguage.getName());
        }

        updateStats();

        if (languageAdapter != null) {
            languageAdapter.notifyDataSetChanged();
        }

        AppLogger.log(this, TAG, "updateUI() END");
    }

    private void updateStats() {
        AppLogger.log(this, TAG, "updateStats() START");

        int total = currentLetters.size();
        int learned = getLearnedCount();
        int progress = total > 0 ? (learned * 100 / total) : 0;

        if (tvProgress != null) {
            tvProgress.setText("Букв: " + total +
                    " | Изучено: " + learned +
                    " | ⭐ " + favoriteLetters.size());
        }

        if (tvStats != null) {
            tvStats.setText("📊 " + progress + "% | 🎯 " +
                    LanguageStats.getQuizScore(this, currentLanguage.getName()));
        }

        if (progressBar != null) {
            progressBar.setProgress(progress);
        }

        AppLogger.log(this, TAG, "   Progress: " + learned + "/" + total + " (" + progress + "%)");
        AppLogger.log(this, TAG, "updateStats() END");
    }

    private int getLearnedCount() {
        String key = currentLanguage.getName() + "_learned";
        return getSharedPreferences(PREFS, MODE_PRIVATE).getInt(key, 0);
    }

    // ==================== ДИАЛОГИ ====================

    private void showLanguageSelectorDialog() {
        AppLogger.log(this, TAG, "showLanguageSelectorDialog() START");

        String[] names = new String[languages.size()];
        for (int i = 0; i < languages.size(); i++) {
            names[i] = languages.get(i).getFlag() + " " + languages.get(i).getName();
        }

        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("🌍 Выберите язык");
        builder.setItems(names, (dialog, which) -> {
            AppLogger.log(LanguageLearningActivity.this, TAG,
                    "   Selected language: " + which + " (" + names[which] + ")");
            selectLanguage(which);
        });
        builder.show();

        AppLogger.log(this, TAG, "showLanguageSelectorDialog() END");
    }

    private void resetProgress() {
        AppLogger.log(this, TAG, "resetProgress() START");

        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("⚠️ Сбросить прогресс");
        builder.setMessage("Вы уверены, что хотите сбросить весь прогресс изучения?");
        builder.setPositiveButton("Сбросить", (dialog, which) -> {
            SharedPreferences prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
            prefs.edit().clear().apply();
            favoriteLetters.clear();
            LanguageStats.reset(this);
            updateUI();
            Toast.makeText(LanguageLearningActivity.this, "Прогресс сброшен", Toast.LENGTH_SHORT).show();
            AppLogger.log(LanguageLearningActivity.this, TAG, "   Progress reset");
        });
        builder.setNegativeButton("Отмена", null);
        builder.show();

        AppLogger.log(this, TAG, "resetProgress() END");
    }

    // ==================== ПРЕФЕРЕНСЫ ====================

    private void savePreferences() {
        AppLogger.log(this, TAG, "savePreferences() START");

        SharedPreferences prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        prefs.edit()
            .putInt("last_language", currentLanguageIndex)
            .putString("favorites", String.join(",", favoriteLetters))
            .apply();

        AppLogger.log(this, TAG, "   Saved: last_language=" + currentLanguageIndex +
                ", favorites=" + favoriteLetters.size());
        AppLogger.log(this, TAG, "savePreferences() END");
    }

    private void loadPreferences() {
        AppLogger.log(this, TAG, "loadPreferences() START");

        SharedPreferences prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        int lastLang = prefs.getInt("last_language", 0);

        if (lastLang < languages.size()) {
            currentLanguageIndex = lastLang;
            currentLanguage = languages.get(lastLang);
            currentLetters = currentLanguage.getLetters();
            AppLogger.log(this, TAG, "   Loaded language: " + currentLanguage.getName());
        }

        String favoritesStr = prefs.getString("favorites", "");
        if (!favoritesStr.isEmpty()) {
            String[] parts = favoritesStr.split(",");
            for (String part : parts) {
                if (!part.isEmpty()) {
                    favoriteLetters.add(part);
                }
            }
            AppLogger.log(this, TAG, "   Loaded favorites: " + favoriteLetters.size());
        }

        AppLogger.log(this, TAG, "loadPreferences() END");
    }

    // ==================== ВСПОМОГАТЕЛЬНЫЕ МЕТОДЫ ====================

    private void vibrate(int ms) {
        if (vibrator != null && vibrator.hasVibrator()) {
            vibrator.vibrate(ms);
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions,
                                           @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQUEST_RECORD_AUDIO && grantResults.length > 0 &&
            grantResults[0] == android.content.pm.PackageManager.PERMISSION_GRANTED) {
            AppLogger.log(this, TAG, "✅ RECORD_AUDIO permission granted");
            startRecording();
        } else {
            AppLogger.log(this, TAG, "❌ RECORD_AUDIO permission denied");
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        AppLogger.log(this, TAG, "onDestroy() START");

        if (quizTimer != null) {
            quizTimer.cancel();
            quizTimer = null;
        }

        if (quizDialog != null && quizDialog.isShowing()) {
            quizDialog.dismiss();
            quizDialog = null;
        }

        if (tts != null) {
            tts.stop();
            tts.shutdown();
            AppLogger.log(this, TAG, "   TTS shut down");
        }

        if (mediaPlayer != null) {
            mediaPlayer.release();
            mediaPlayer = null;
            AppLogger.log(this, TAG, "   MediaPlayer released");
        }

        if (mediaRecorder != null) {
            mediaRecorder.release();
            mediaRecorder = null;
            AppLogger.log(this, TAG, "   MediaRecorder released");
        }

        long duration = System.currentTimeMillis() - startTime;
        AppLogger.log(this, TAG, "   Session duration: " + (duration / 1000) + "s");
        AppLogger.log(this, TAG, "   Total actions: " + actionCount);
        AppLogger.log(this, TAG, "onDestroy() END");
    }
}